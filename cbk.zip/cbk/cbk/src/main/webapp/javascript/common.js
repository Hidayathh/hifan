/*
	Common JavaScript functions
*/

function getFormObj() {
	return document.forms[1];
}		

function getCheckedValue(radioObj) {
	if ( radioObj ) {
		if( radioObj.length == undefined ) {
			if( radioObj.checked ) {
				return radioObj.value;
			}
		}
		for( var i = 0; i < radioObj.length; i++ ) {
			if( radioObj[i].checked ) {
				return radioObj[i].value;
			}
		}
	}
	return undefined;
}	

function showDiv(ObjectID){			
	if (document.getElementById(ObjectID) !=  null){
		var div = document.getElementById(ObjectID);
		div.style.visibility="visible";			
	}
}	

function hideDiv(ObjectID){
	if (document.getElementById(ObjectID) != null){
		var div = document.getElementById(ObjectID);	
		div.style.visibility="hidden";
	}
}

function changeRadio(field, radiobutton) {
	var radios = document.getElementsByName(field);
	radios[radiobutton].checked = true;
}

function clearDiv(divID, fldType){
		var d = divID;
		var f = fldType;
		if (document.getElementById(d) != null){
			var div = document.getElementById(d);
			if (div.getElementsByTagName(f) != null){
				var flds = div.getElementsByTagName(f);
				if (flds[0]){
					for (var i=0; i<flds.length;i++){
						flds[i].value="";
					}
				}
				else{
					flds.value="";
				}
			}
		}
}
							
function clearValue(objectName){	
		if (document.getElementById(objectName) != null){
			var ctl = document.getElementById(objectName);
			ctl.value = "";
		}
}

function validateDecimal(objTxt,objTxtName){
	var errMsg = '';
	var x=objTxt;
	var anum=/^((\+|-)?\d*(\.\d{1,2})?|(\+|-)?\d+(\.\d{1,2})?)$/
	if (objTxt != "" && objTxt != null && anum.test(x)) {
		errMsg='';
	} else {
    	errMsg = objTxtName+" should be a valid dollar amount\n";
    }
	return errMsg;
}

function validateNumber(objTxt,objTxtName){
	var errMsg = '';
	var x=objTxt;
	var anum=/^((\+|-)?\d*(\.\d{1,2})?|(\+|-)?\d+(\.\d{1,2})?)$/
	if (objTxt != "" && objTxt != null && anum.test(x)) {
		errMsg='';
	} else {
    	errMsg = objTxtName+" should be a numeric value\n";
    }
	return errMsg;
}

//Validate if String Value, return false if it is an empty 
function validateString(objTxt,objTxtName){
	var errMsg = '';
    if (objTxt == null || objTxt == "") {
    	errMsg = objTxtName+" cannot be empty\n";
	}
	return errMsg;
}

function validateFilenameLength(filename, attachmentType, maxLength) {
	var errMsg = '';
	if (filename != null) {
		var lastSlash = filename.lastIndexOf("\\");
		var actualFilename = filename.substring(lastSlash+1, filename.length);
		if (actualFilename.length > maxLength) {
			errMsg = "The " + attachmentType + " filename must be less than 50 characters.";
		}
	}
	return errMsg;
}

function setCursor(fieldName) {
	if (document.getElementsByName(fieldName)[0] != undefined && document.getElementsByName(fieldName)[0].type != "hidden") {
		document.getElementsByName(fieldName)[0].focus();
	}
}

//Trim spaces
function trim(s) {
    return s.replace( /^\s*/, "" ).replace( /\s*$/, "" );
} 

function trim2(str){
	var trimmed = str.replace(/^\s+|\s+$/g, '') ;
	return trimmed;
}

 function checkDates()
    {
    
      var frmDate=document.getElementsByName("fromDate")[0].value;      
      var nfromDate=new Date(frmDate);
     
      var toDate=document.getElementsByName("toDate")[0].value;     
      var nToDate=new Date(toDate);
     
      var today=new Date();
    
      if(nfromDate > nToDate)
      {
        alert("From Date can not be greater than To Date!!");
        return false;
      }
   
      var diff=monthsBetween(frmDate, today);
      var diff1=monthsBetween(toDate, today);      
   
      if(diff>18)
      {
      alert("From Date should be upto 18 months prior to Current Date!!");
      return false;
      }
      else
      {
       if(diff1>18)
       {
       alert("To Date should be upto 18 months prior to Current Date!!");
       return false;
       }
      }
 
      return true;
      
    }
    function monthsBetween(frmDate, today) { 
  
     
         var number = 0;
         var fromDate=new Date(frmDate);         
         if (today.getFullYear() > fromDate.getFullYear())
          { 
             number = number + (today.getFullYear() - fromDate.getFullYear() - 1) * 12; 
          
          } else {
               return today.getMonth() - fromDate.getMonth(); 
          }  
          if (today.getMonth() > fromDate.getMonth())
          { 
            number = number + 12 + today.getMonth() - fromDate.getMonth(); 
           
          }
         else 
         {   
          number = number + (12 - fromDate.getMonth()) + today.getMonth();
         } 
       return number;
   }



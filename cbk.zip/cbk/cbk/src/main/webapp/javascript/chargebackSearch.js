function goSearch() {
	if (!document.getElementsByName("dateCriteria")[3].checked) {
		document.getElementsByName("fromDate")[0].value = "";
		document.getElementsByName("toDate")[0].value = "";
	}
	
	if (!document.getElementsByName("locationTypeNumber")[0].checked) {
		document.getElementsByName("locationNumber")[0].value = "";
	}
	else {
		if (document.getElementsByName("locationNumber")[0].value == "") {
			document.getElementsByName("locationTypeNumber")[0].checked = false;
		}
	}
	
	if (!document.getElementsByName("locationTypeGroup")[0].checked) {
		document.getElementsByName("locationGroup")[0].selectedIndex = 0;
	}
	
	if (document.getElementsByName("locationTypeRetail")[0].checked || document.getElementsByName("locationTypeDC")[0].checked) {
		if (document.getElementsByName("locationNumberCombined")[0].value == "") {
			alert("Please select a location from the list.");
			return;
		}
	}
	if (document.getElementsByName("locationTypeNumber")[0].checked) {
		if (document.getElementsByName("locationNumber")[0].value == "") {
			alert("Please enter a location number.");
			document.getElementsByName("locationNumber")[0].focus();
			return;
		}
	}
	var netAmt = document.getElementsByName("netAmount1")[0].value;
	if (netAmt != "") {
		if(netAmt.substr(0,1) == " " || isNaN(netAmt/2)) {
			alert("Net Amount must be a number. Do not include a '$'.");
			document.getElementsByName("netAmount1")[0].focus();
			return;
		}
	}
	
	var doc = document.forms[1];
	doc.action = "getDocumentResults";
	doc.submit();
}

function checkLocType(checkboxObject) {
	//checkboxObject.checked = true;	
	var doc = document.forms[1];
	var value = checkboxObject.value;
	if (value == "dc") {
		document.getElementsByName("locationTypeNumber")[0].checked = false;
		document.getElementsByName("locationTypeRetail")[0].checked = false;
	} else if (value == "number") {
		document.getElementsByName("locationTypeDC")[0].checked = false;
		document.getElementsByName("locationTypeRetail")[0].checked = false;
	} else {
		document.getElementsByName("locationTypeNumber")[0].checked = false;
		document.getElementsByName("locationTypeDC")[0].checked = false;
	}
	//resetLocation(value);
}

function changeRadio(field, radiobutton) {
	var radios = document.getElementsByName(field);
	radios[radiobutton].checked = true;
}

function changeLocation(locationType) {
	if ( locationType == 'dc' ) {
		document.getElementsByName("locationTypeNumber")[0].checked = false;
		document.getElementsByName("locationTypeGroup")[0].checked = false;
		document.getElementById("locationGroup").selectedIndex = 0;
		document.getElementsByName("locationNumber")[0].value = "";
		updateForm(locationType);
	}
	else if ( locationType == 'retail' ) {
		document.getElementsByName("locationTypeNumber")[0].checked = false;
		document.getElementsByName("locationTypeGroup")[0].checked = false;
		document.getElementById("locationGroup").selectedIndex = 0;
		document.getElementsByName("locationNumber")[0].value = "";
		updateForm(locationType);
	}
	else if ( locationType == 'group' ) {
		document.getElementsByName("locationTypeDC")[0].checked = false;
		document.getElementsByName("locationTypeRetail")[0].checked = false;
		document.getElementsByName("locationTypeGroup")[0].checked = true;			
		document.getElementsByName("locationTypeNumber")[0].checked = false;
		document.getElementById("locationNumberSelect").selectedIndex = -1;
		document.getElementsByName("locationNumber")[0].value = "";
	}
	else if ( locationType == 'manual' ) {
		document.getElementsByName("locationTypeDC")[0].checked = false;
		document.getElementsByName("locationTypeRetail")[0].checked = false;
		document.getElementsByName("locationTypeNumber")[0].checked = true;
		document.getElementsByName("locationTypeGroup")[0].checked = false;	 					
		document.getElementById("locationNumberSelect").selectedIndex = -1;
		document.getElementById("locationGroup").selectedIndex = 0;		
	}
	return false;
}

function updateForm(updatedField) {
	var pageForm = getFormObj();	
	pageForm.action = "newChargebackSearch?update=" + updatedField;		
	pageForm.submit();		
}

function changeLocationType(value) {
	if (value == "dc") {
		document.getElementsByName("locationTypeDC")[0].checked = true;
		document.getElementsByName("locationTypeRetail")[0].checked = false;
		document.getElementsByName("locationTypeNumber")[0].checked = false;
	} else if (value == "number") {
		document.getElementsByName("locationTypeDC")[0].checked = false;
		document.getElementsByName("locationTypeRetail")[0].checked = false;
		document.getElementsByName("locationTypeNumber")[0].checked = true;
	} else {
		document.getElementsByName("locationTypeDC")[0].checked = false;
		document.getElementsByName("locationTypeRetail")[0].checked = true;
		document.getElementsByName("locationTypeNumber")[0].checked = false;
	}
}

function clearFields() {
    document.getElementsByName("vendorId")[0].value = "";	
	document.getElementsByName("locationNumber")[0].value = "";	
	document.getElementsByName("originator")[0].value = "";	
	document.getElementsByName("approver")[0].value = "";
}

function cancel() {
	location = "home";
}

function openVendorSelector() {
	var url = "vendorSelector?action=open";
	var width  = 820;
	var height = 350;
	var leftPos = (screen.width-width)/2;
	var topPos  = (screen.height-height)/2;
	var aspects = 'toolbar=no,status=no,scrollbars=no,resizable=no,width='+width+',height='+height+',left='+leftPos+',top='+topPos;

	gS = window.open(url, 'VendorSelector', aspects);
	gS.focus();
}

function openChargebackLocationSelector() {
	var url = "chargebackLocationSelector?action=open";
	var width  = 820;
	var height = 350;
	var leftPos = (screen.width-width)/2;
	var topPos  = (screen.height-height)/2;
	var aspects = 'toolbar=no,status=no,scrollbars=no,resizable=no,width='+width+',height='+height+',left='+leftPos+',top='+topPos;

	gS = window.open(url, 'VendorSelector', aspects);
	gS.focus();
}

function openOriginatorSelector(){
		var url = "originatorSelector?action=open";
			var width  = 820;
			var height = 350;
			var leftPos = (screen.width-width)/2;
			var topPos  = (screen.height-height)/2;
			var aspects = 'toolbar=no,status=no,scrollbars=no,resizable=no,width='+width+',height='+height+',left='+leftPos+',top='+topPos;

			gS = window.open(url, 'OriginatorSelector', aspects);
			gS.focus();
		}
		
function openApproverSelector(){
		var url = "approverSelector?action=open";
			var width  = 820;
			var height = 350;
			var leftPos = (screen.width-width)/2;
			var topPos  = (screen.height-height)/2;
			var aspects = 'toolbar=no,status=no,scrollbars=no,resizable=no,width='+width+',height='+height+',left='+leftPos+',top='+topPos;

			gS = window.open(url, 'ApproverSelector', aspects);
			gS.focus();
		}

function getChargebackResults(){
	var doc = document.forms[1];
	doc.action="getChargebackResults";
	doc.submit();
}

function updateVendor(vendorId) {
	document.getElementById("vendor").value = vendorId;
}

function getChargeback(invoiceNumber){
	var doc = document.forms[1];
	doc.action="getChargeback";
	doc.submit();
}

function createChargeback() {
		//alert("create cbk location");
		var doc = document.forms[1];
		//var selectedCount = countSelected();
		//alert("get")
		doc.action = "createChargeback?action=create";
		doc.submit();
		
		
	}

document.onkeypress = doKey;
function doKey(e) {
	whichASC = window.event ? event.keyCode : e.which;
	if (whichASC == 13) {
		goSearch();
	}
}


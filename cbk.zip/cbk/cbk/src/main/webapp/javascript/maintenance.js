/*
 * maintenance.js
 * Standard library of JavaScript functions for the ePASS maintenance area.
 */

/* List Pages */

function done() {
	location ="maintenance";
}

function create() {
	location = pageURL + "?action=create&isformreset=true";
}

function deleteSelected() {
	var pageForm = getFormObj();

	if ( pageForm.selectedItems == null ) {
		return false;
	}

	// Count the number of selected items
	var numSelected = 0;
	var totalItems = pageForm.selectedItems.length;
	
	if ( totalItems > 1 ) {
		for (var i = 0; i < totalItems; i++) {
			if (eval("pageForm.selectedItems[" + i + "].checked") == true) {
				numSelected += 1;
			}
		}
	}
	else {
		if (eval("pageForm.selectedItems.checked") == true) {
			numSelected += 1;
		}		
	}

	if ( numSelected ) {
		if (confirm ("Are you sure you want to delete the selected item(s)?")) {
			pageForm.action = pageURL + "?action=delete";
			pageForm.submit();		
		}
	}
	else {
		alert ("You must select at least one item to delete.");
	}
}

function sortResults(column) {
	var pageForm = getFormObj();

	currentSort = pageForm.sortBy.value;
	
	if (currentSort == column) {
		// Change the sort order
		if (pageForm.sortOrder.value == "ASC") {
			pageForm.sortOrder.value = "DESC";
		} else {
			pageForm.sortOrder.value = "ASC";
		}
	} else {
		pageForm.sortOrder.value = "ASC";
	}
	
	pageForm.sortBy.value = column;

	pageForm.action = pageURL + "?action=list";
	pageForm.submit();
}

function doAction(action,id) {
	var pageForm = getFormObj();
	
	pageForm.action = pageURL + "?action="+action+"&id=" + id;
	pageForm.submit();
}

function vcrSubmit(action) {
	var pageForm = getFormObj();
	pageForm.vcrAction.value = action;
	pageForm.action = pageURL + "?action=list";	
	pageForm.submit();
}

function vcrShowAll(isChecked) {
	var doc = document.forms[1];
	if (isChecked) {
		doc.showAll.value = "true";
	} else {
		doc.showAll.value = "false";
	}
	doc.action = pageURL + "?action=list";
	doc.submit();
}

function refresh() {
	var pageForm = getFormObj();
	pageForm.action = pageURL + "?action=list";
	pageForm.submit();
}

function exportCSV() {
	var pageForm = getFormObj();
	pageForm.action = pageURL + "?action=exportCSV";
	pageForm.submit();	
}

/* Create/Edit Pages */
function submit() {
	var pageForm = getFormObj();
	pageForm.action = pageURL + "?action=save";
	pageForm.submit();	
}

function cancel() {
	if (confirm("Are you sure you want to cancel?")) {
		var pageForm = getFormObj();

		if ( pageForm.vcrAction ) {
			pageForm.vcrAction.value = "current";
		}

		pageForm.action = pageURL + "?action=list";
		pageForm.submit();
	}
}	

function updateForm() {
	var pageForm = getFormObj();
	
	if ( pageForm.isNew.value == "true" ) {
		pageForm.action = pageURL + "?action=create";
	}
	else {
		pageForm.action = pageURL + "?action=edit&update=true";		
	}
	pageForm.submit();		
}

/* Internally Used Functions */
function getFormObj() {
	return document.forms[1];
}	
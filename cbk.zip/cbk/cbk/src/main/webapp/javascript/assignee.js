
	function clearDiv(divID, fldType){
		var d = divID;
		var f = fldType;
		if (document.getElementById(d) != null){
			var div = document.getElementById(d);
			if (div.getElementsByTagName(f) != null){
				var flds = div.getElementsByTagName(f);
				if (flds[0]){
					for (var i=0; i<flds.length;i++){
						flds[i].value="";
					}
				}
				else{
					flds.value="";
				}
			}
		}
	}
							
	function clearValue(objectName){	
		if (document.getElementById(objectName) != null){
			var ctl = document.getElementById(objectName);
			ctl.value = "";
		}
	}
	
	function showView(objectID){
		hideDivs();
		showDivs(objectID);
	}
	
	function switchView(objectID) {
		clearDiv("name_body","input");
		clearDiv("class_body","input");
		clearDiv("assignedGroupName","input");
		showView(objectID);
	}

	function hideDivs(){
		hideDiv("name_body");
		hideDiv("class_body");
		hideDiv("class_button");
	}	
	
	function hideDiv(ObjectID){
		if (document.getElementById(ObjectID) != null){
			var div = document.getElementById(ObjectID);	
			div.style.visibility="hidden";
		}
	}
	
	function showDiv(ObjectID){			
		if (document.getElementById(ObjectID) !=  null){
			var div = document.getElementById(ObjectID);
			div.style.visibility="visible";			
		}
	}
	
	function showDivs(ObjectID){
		if (ObjectID == "name"){
			showDiv("name_body");
			var doc = document.forms[0];
			if (doc.assigneeGrpName.value == "") {
				document.forms[0].assigneeGrpName.focus();		
			}
		}
		else {
			showDiv("class");
			if (ObjectID == "class"){
				showDiv("class_body");
				var div = document.getElementById("class_button");
				div.style.visibility="visible";			
			}
		}
	}
	
	function getSelectedRadio(buttonGroup) {
		if (document.getElementsByName(buttonGroup) != null){
			var group = document.getElementsByName(buttonGroup);
	   		if (group[0]) { // if the button group is an array (one button is not an array)
	      		for (var i=0; i<group.length; i++) {
	         		if (group[i].checked) {
	            		return i
	         		}
	      		}
	   		} 
	   		else {
	      		if (group.checked) {
	      			return 0; 
	      		}
		   }
	   	   return -1;
		}
		return -1;
	} 

	function getSelectedRadioValue(buttonGroup) {
	   	var i = getSelectedRadio(buttonGroup);
   		if (i == -1) {
      		return "";
   		}
   		else {
   			if (document.getElementsByName(buttonGroup) != null){
	   			var group = document.getElementsByName(buttonGroup);
	      		if (group[i]) { // Make sure the button group is an array (not just one button)
	         		return group[i].value;
	      		}
	      		else { // The button group is just the one button, and it is checked
	        		return group.value;
	      		}
	      	}
	      	return "";
   		}	
	}

	function selectOption(){		
		var sel = getSelectedRadioValue("asgnSearchBy");		
		if (sel == null || sel == ""){
			sel = "name";
		}
		showView(sel);
	}
	
	function changeList(form) {
		var doc = form;
		var ddlbValue;
		var grpId = doc.classGrpId.options[doc.classGrpId.selectedIndex].value;
		if (grpId != null && grpId != "") {
			for (i=0;i<form.length;i++) {
				var tempobj=form.elements[i];
				if (tempobj.name == grpId) {
					ddlbValue = tempobj.value;
					break;
				}
			}
	
			doc.classId.options.length = 0;
			doc.classId.options[0] = new Option("Select Class", "");			
			var newList = ddlbValue.split(",");
			var newObj;
			for (j=0;j<newList.length;j++) {
				newObj=newList[j];
				var valueList = newObj.split("^");
				var className = valueList[0];
				var groupId = valueList[1];
				var groupName = valueList[2];
				//doc.classId.options[j+1] = new Option(newObj, newObj);
				doc.classId.options[j+1] = new Option(className, groupId + "^" + groupName);
			}
		} else {
			doc.classId.options.length = 0;
			doc.classId.options[0] = new Option("Select Class", "");			
		}
	}
	
	function passValueBack(form) {
		var selectType = getSelectedRadioValue("asgnSearchBy");
		var hasSelected=false;
		if (selectType != null && selectType != "" && selectType == "name") {
			var assignValue;
			// Iterate through the list and find out the selected assignee
			for (var i=0; i < form.elements.length; i++) {
		   		if (form.elements[i].type == "radio" && form.elements[i].name == "key") {
		   			if (form.elements[i].checked) {
			   			assignValue = form.elements[i].value;
			   			hasSelected=true;
			   			break;
		   			}
		   		}
		   	}
		   	if (hasSelected) {
		   		var currentAssignee = window.opener.document.forms[1].assignedGroupKey.value;
		   		var newAssignee = assignValue.substring(0, assignValue.indexOf('-'));
			   	var newAssigneeName = assignValue.substr(assignValue.indexOf('-')+1);
			   	if (currentAssignee != newAssignee) {
			   		window.opener.document.forms[1].newAssignee.value = "true";
			   		window.opener.document.forms[1].assignedGroupKey.value = newAssignee;
			   		window.opener.document.forms[1].assignedGroupName.value=newAssigneeName;
			   	}
				var assignValue = newAssigneeName;
				opener.document.getElementById("assigneeInformation").innerHTML = newAssigneeName;
			}
		} 
	   	if(!hasSelected) {
	   		alert("Please select a group.");
	   		return false;
	   	}
		window.close();
	}
	
	function fillAssignedToGroup(form) {
		if (form.classId.value != null && form.classId.value != "") {
			if (form.regionNbr.value == null || form.regionNbr.value == ""){
		   		alert("Please Select the Region");
		   		return false;
		   	}
			hasSelected=true;
			var classValue = form.classId.value;
			var assignedToGroup = classValue.substr(classValue.indexOf('^')+1);
			if (assignedToGroup == "") {
				assignedToGroup = "(None)";
			}
			document.getElementById("assignedGroupName").innerHTML = assignedToGroup;				
		}

	}
	
	function search(docForm) {
		var selectType = getSelectedRadioValue("asgnSearchBy");
		if (selectType == "name") {
			if ((docForm.assigneeFirstName.value == null || docForm.assigneeFirstName.value == "")
				&& (docForm.assigneeLastName.value == null || docForm.assigneeLastName.value == "")
				&& (docForm.assigneeGrpName.value == null || docForm.assigneeGrpName.value == "")) {
			   		alert("Please enter the search criteria");
			   		docForm.assigneeGrpName.focus();
			   		return false;
		   	}
		   	document.getElementById("progress").style.display = "inline";
	   	} else {
	   		document.getElementById("progress").style.display = "none";
	   	}
	   	document.getElementById("searching").style.display = "none";
		docForm.action = "assignPASS";
		docForm.submit();
	}
	
	function cancelPopup() {
		window.close();
	}

function validateDocumentReqtForm(form) {
	var canSubmit = true;
	var errorMessage = '';
		// Validate the requester required field

		var reqRole = form.requesterRole.value;
		if (reqRole != null && reqRole == "VendorCorrespondence") {
			errorMessage = errorMessage + validateString(form.requesterName.value,"Requester Name");
		}
		
		errorMessage = errorMessage + validateString(form.requesterEmailAddr.value,"Email Address");
		errorMessage = errorMessage + validateString(form.requesterPhone.value,"Phone Number");
		errorMessage = errorMessage + validateString(form.requesterFax.value,"Fax Number");
		errorMessage = errorMessage + validateString(form.requesterAddr1.value,"Address");
		errorMessage = errorMessage + validateString(form.requesterCity.value,"City");
		errorMessage = errorMessage + validateString(form.requesterState.value,"State Code");
		errorMessage = errorMessage + validateString(form.requesterZip.value,"Zip Code");
		errorMessage = errorMessage + validateString(form.documentDate.value,"Document Date");

		var reqTypeId = getCheckedValue(form.requestTypeChkbox);

		// Validate the location and net amount required field for Document Not found
		if ((reqTypeId != null && reqTypeId) == '4' || form.dnf != undefined) {
			errorMessage = errorMessage + validateDecimal(form.netAmount.value,"Net Amount");

			// Location id validation
			var locationValue;
			if (form.dcLocId.value != null && form.dcLocId.value != "")
				locationValue = form.dcLocId;
			else if (form.retailLocId.value != null && form.retailLocId.value != "")
				locationValue = form.retailLocId;
			else
				locationValue = form.locIdNum;
	
			errorMessage = errorMessage + validateNumber(locationValue.value, "Location");
		}
		
		if (reqTypeId != null && reqTypeId == '2') {
			errorMessage = errorMessage + validateDecimal(form.disputeAmt.value,"Dispute Amount");
			if ((parseFloat(form.disputeAmt.value) > parseFloat(form.netAmount.value)) && parseFloat(form.netAmount.value) > 0) {
				errorMessage = errorMessage + "The Dispute Amount cannot be greater than the Net Amount\n";
			}
			errorMessage = errorMessage + validateString(trim(form.comments.value),"Comments");
		}  

		if (reqTypeId != null && reqTypeId == '1') {
			errorMessage = errorMessage + validateString(trim(form.needComment.value),"What do you need?");
			var ndCmnt = form.needComment.value;
			if (ndCmnt == "Other")
				errorMessage = errorMessage + validateString(trim(form.comments.value),"Comments");
		}

		if (reqTypeId != null && reqTypeId != '4') {
			var pmtType = form.promotionType.value;
			if (pmtType != null && pmtType == "YES") {
				errorMessage = errorMessage + validateString(trim(form.deductionTypeID.value),"PO Deduction Type");
			}
		}

		if (form.requesterType != null && form.requesterType.value == "employee") {
			errorMessage = errorMessage + validateString(form.requestSourceId.value,"Request Source");

			if (form.assignedGroupKey == null || form.assignedGroupKey.value == "" || form.assignedGroupKey.value == "0")
			errorMessage = errorMessage + "Assignee Information is required\n";
		}
		
		if (form.comments != null && trim(form.comments.value) !="" && (trim(form.comments.value)).length > 1500) {
			errorMessage = errorMessage + "Comments cannot be more than 1500 characters\n";
		}
		
		if (form.remitAttach != null) {
			errorMessage = errorMessage + validateString(trim(form.remitAttach.value),"Check Remit Attachment");
			errorMessage = errorMessage + validateFilenameLength(form.remitAttach.value,"Check Remit Attachment", 50);
		}
		
		if (form.otherAttach != null) {
			errorMessage = errorMessage + validateFilenameLength(form.otherAttach.value,"Other Attachment", 50);
		}
		
		if (form.otherAttach2 != null) {
			errorMessage = errorMessage + validateFilenameLength(form.otherAttach2.value,"Other Attachment #2", 50);
		}		
		
		if (form.poNumber != null && trim(form.poNumber.value) !="") {
			errorMessage = errorMessage + validateNumberWithZero(trim(form.poNumber.value),"PO Number");
		}
		
		if (form.resolutionAttach != null) {
			errorMessage = errorMessage + validateFilenameLength(form.resolutionAttach.value,"Resolution Attachment", 50);
		}		
		
		if (errorMessage != null && errorMessage != '') {
			alert(errorMessage);
			return false;
		}

		if (form.requesterZip.value.length < 5) {
			alert("Zip code cannot be less than 5 characters");
			return false;
		}
	
		
		if (reqTypeId != null && reqTypeId == '4' && form.documentDate.value != '' && !isDate(form.documentDate.value))
			return false;
			

		
		// Should not allow same file attached through different file types.
		if (reqTypeId != null && reqTypeId == '4') {
				if ((form.remitAttach != null && form.remitAttach.value != "")
					&& (form.remitAttach.value == form.otherAttach.value)) {
						alert("You are attaching duplicate files");
						return false;
					}
		}

		return true;
}

//Validate if Numeric Value, return false if not Number 
function validateNumber(objTxt,objTxtName){
	var errMsg = '';
		//check numeric
        if (objTxt == null || objTxt == "" || objTxt == '0' || (objTxt != '' & !isInteger(objTxt))) {
	    	errMsg = objTxtName+" should be a non zero positive number\n";
		}
	return errMsg;
}

//Validate if Numeric Value, return false if not Number 
function validateNumberWithZero(objTxt,objTxtName){
	var errMsg = '';
		//check numeric
        if (objTxt == null || objTxt == "" || (objTxt != '' & !isFloat(objTxt))) {
	    	errMsg = objTxtName+" should be a valid number\n";
		}
	return errMsg;
}

//Validate if String Value, return false if it is an empty 
function validateString(objTxt,objTxtName){
	var errMsg = '';
    if (objTxt == null || objTxt == "") {
    	errMsg = objTxtName+" is required\n";
	}
return errMsg;
}

function validateDecimal(objTxt,objTxtName){
	var errMsg = '';
	var x=objTxt;
	var anum=/^((\+|-)?\d*(\.\d{1,2})?|(\+|-)?\d+(\.\d{1,2})?)$/
	if (objTxt != "" && objTxt != null && anum.test(x)) {
		errMsg='';
	} else {
    	errMsg = objTxtName+" should be a valid dollar amount\n";
    }

	return errMsg;
}

// Declaring valid date character, minimum year and maximum year
var dtCh= "/";
var minYear=1900;
var maxYear=2100;

function validateFilenameLength(filename, attachmentType, maxLength) {
	var errMsg = '';
	if (filename != null) {
		var lastSlash = filename.lastIndexOf("\\");
		var actualFilename = filename.substring(lastSlash+1, filename.length);
		if (actualFilename.length > maxLength) {
			errMsg = "The " + attachmentType + " filename must be less than 50 characters.";
		}
	}
	return errMsg;
}

function isIntegerType(s){
	var i;
    for (i = 0; i < s.length; i++){   
        // Check that current character is number.
        var c = s.charAt(i);
        if (((c < "0") || (c > "9"))) return false;
    }
    // All characters are numbers.
    return true;
}

function stripCharsInBag(s, bag){
	var i;
    var returnString = "";
    // Search through string's characters one by one.
    // If character is not in bag, append to returnString.
    for (i = 0; i < s.length; i++){   
        var c = s.charAt(i);
        if (bag.indexOf(c) == -1) returnString += c;
    }
    return returnString;
}

function daysInFebruary (year){
	// February has 29 days in any year evenly divisible by four,
    // EXCEPT for centurial years which are not also divisible by 400.
    return (((year % 4 == 0) && ( (!(year % 100 == 0)) || (year % 400 == 0))) ? 29 : 28 );
}
function DaysArray(n) {
	for (var i = 1; i <= n; i++) {
		this[i] = 31
		if (i==4 || i==6 || i==9 || i==11) {this[i] = 30}
		if (i==2) {this[i] = 29}
   } 
   return this
}

function isDate(dtStr){
	var daysInMonth = DaysArray(12)
	var pos1=dtStr.indexOf(dtCh)
	var pos2=dtStr.indexOf(dtCh,pos1+1)
	var strMonth=dtStr.substring(0,pos1)
	var strDay=dtStr.substring(pos1+1,pos2)
	var strYear=dtStr.substring(pos2+1)
	strYr=strYear
	
	if (pos1==-1 || pos2==-1){
		alert("The date format should be : MM/DD/YYYY")
		return false
	}
	
	if (strMonth.length<2) {
		alert("Please enter a valid 2 digit month");
		return false;
	}
	
	if (strDay.length<2) {
		alert("Please enter a valid 2 digit day");
		return false;
	}
	
	if (strDay.charAt(0)=="0" && strDay.length>1) strDay=strDay.substring(1)
	if (strMonth.charAt(0)=="0" && strMonth.length>1) strMonth=strMonth.substring(1)
	for (var i = 1; i <= 3; i++) {
		if (strYr.charAt(0)=="0" && strYr.length>1) strYr=strYr.substring(1)
	}

	month=parseInt(strMonth)
	day=parseInt(strDay)
	year=parseInt(strYr)

	if (strMonth.length<1 || month<1 || month>12){
		alert("Please enter a valid 2 digit month")
		return false
	}
	
	if (strDay.length<1 || day<1 || day>31 || (month==2 && day>daysInFebruary(year)) || day > daysInMonth[month]){
		alert("Please enter a valid 2 digit day")
		return false
	}
	if (strYear.length != 4 || year==0 || year<minYear || year>maxYear){
		alert("Please enter a valid 4 digit year between "+minYear+" and "+maxYear)
		return false
	}
	if (dtStr.indexOf(dtCh,pos2+1)!=-1 || isIntegerType(stripCharsInBag(dtStr, dtCh))==false){
		alert("Please enter a valid date")
		return false
	}
return true
}

//Verify is of Integer Type
function isInteger(strValue){
	if  (strValue.match(/^[+-]?[0-9]+$/) == null)
		return false;
	if (strValue.match(/^-0*$/) != null)
		return false;
	var iValue = parseInt(strValue);	
	if (isNaN(iValue) || !(iValue >= 0 && iValue <= 2147483647)) {
		return false;
	}
	return true;
}
//Verify is of Integer Type
function isFloat(strValue){
	if  (strValue.match(/^[+-]?[0-9]+$/) == null)
		return false;
	if (strValue.match(/^-0*$/) != null)
		return false;
	var iValue = parseFloat(strValue);	
	if (isNaN(iValue) || !(iValue >= 0 && iValue <= 99999999999999)) {
		return false;
	}
	return true;
}

//Trim spaces
function trim(s) {
    return s.replace( /^\s*/, "" ).replace( /\s*$/, "" );
}

function skip() {
	var cnf = confirm("Changes are not submitted. Click OK to discard the changes or Cancel to continue working with the current PASS#");
	if (cnf) {
		var prcsCnt = parseInt(document.getElementById("epassPrcsCount").value);
		var totalCnt = parseInt(document.getElementById("epassTotalCount").value);
		if ((prcsCnt+1) > totalCnt) {
			getDocumentResults();
		} else {
			var doc = document.forms[1];	
			doc.action = "documentSelfService?action=skipPage"
			doc.submit();
		}
	} else {
		return false;
	}
}

function getDocumentResults(){
	var doc = document.forms[1];
	doc.action="getDocumentResults";
	doc.submit();
}

function assignPASS() {
	
	var url = "assignPASS";
	var width  = 600;
	var height = 340;
	var leftPos = 200;
	var topPos  = 250;
	var aspects = 'resizable=1,status=yes,width='+width+',height='+height+',left='+leftPos+',top='+topPos;
	gS = window.open(url, 'AssignPASS', aspects);
	gS.focus();
	/*var newwin = window.open("assignPASS", "1", "left=200,top=250,width=600,height=340,resizable=1,status=yes");
	newwin.focus();*/
}

function vendorInfo(vendorId) {
	
	
	var url = "showVendorInfo?vendorId=" + vendorId;
	var width  = 660;
	var height = 250;
	var leftPos = 200;
	var topPos  = 250;
	var aspects = 'width='+width+',height='+height+',left='+leftPos+',top='+topPos;
	gS = window.open(url, 'showVendorInfo', aspects);
	gS.focus();
	/*var newwinVen = window.open("showVendorInfo?vendorId=" + vendorId, "1", "left=200,top=250,height=250,width=660");
	newwinVen.focus();*/
}

function cancel() {
	var cnf = confirm("Changes are not submitted.  Click OK to discard this and all subsequent selections and return to the results page or Cancel to continue working with the current PASS#");
	if (cnf)
		getDocumentResults();
	else return false;
}

function submit() {
	var doc = document.forms[1];	
	if(validateDocumentReqtForm(doc)) {
		doc.action = "documentSelfService?action=submitPage";
		doc.submit();
	} else
		return false;
}

function checkLocType(checkboxObject) {
	var doc = document.forms[1];
	var value = checkboxObject.value;
	if (value == "name") {
		doc.nbrLocType.checked = false;
	} else if (value == "number") {
		doc.locationTypeName.checked = false;
	}
}
	
function changeLocationType(objectName) {			
		var chkbx = document.getElementById(objectName);
		var doc = document.forms[1];
		doc.nbrLocType.checked = false;
		doc.retLocType.checked = false;
		doc.DCLocType.checked = false;		
		chkbx.checked = true;
		resetLocation(objectName);
}

function resetLocation(objectName){
		if (objectName == "dcCheck"){
			clearValue("numLoc");
			clearValue("retLoc");
		} else if (objectName == "numCheck"){
			clearValue("dcLoc");
			clearValue("retLoc");
		} else {
			clearValue("numLoc");
			clearValue("dcLoc");
		}
}
	
function clearValue(objectName){	
		if (document.getElementById(objectName) != null){
			var ctl = document.getElementById(objectName);
			ctl.value = "";
		}
}

function switchView(objectID) {
		var rts = document.getElementById("requestTypeSelectedId");
		var grp = document.getElementById("assignedGroupKey");
		//var asgInfo = document.getElementById("assigneeInformation")
		var addlCtl = document.getElementById("addlbackup_body");
		var dispCtl = document.getElementById("dispute_body");
		var cmnt = document.getElementById("comments");
		var cmntFlag = document.getElementById("comment_flag");
		
		var resCtl = document.getElementById("resolutionAttach_body");
		var scBtn  = document.getElementById("submitCloseButton");		
				
		if (objectID == "Additional Backup") {
				var ddt = document.getElementById("needComment");
				if (ddt != null)
					ddt.value = "";
			    addlCtl.style.visibility="visible";
				dispCtl.style.visibility="hidden";
			    cmntFlag.style.visibility="hidden";
			    if (rts != undefined) {
					rts.value=1;
				}
				if (cmnt != undefined) {
					cmnt.value="";
				}
				if ( resCtl != undefined) {
				    resCtl.style.visibility = "visible";
				}
				if ( scBtn != undefined ) {
				    scBtn.style.visibility = "visible";
			    	scBtn.disabled = "";				    
				}
		} else if (objectID == "Deduction Dispute") {
				var amt = document.getElementById("disputeAmt");
				if (amt != undefined) {
					amt.value = "";
				}
				dispCtl.style.visibility="visible";
			    addlCtl.style.visibility="hidden";
			    cmntFlag.style.visibility="visible";
				if (rts != undefined) {
					rts.value=2;
				}
				if (cmnt != undefined) {
					cmnt.value="";
				}
				if ( resCtl != undefined) {
				    resCtl.style.visibility = "hidden";
				}	
				if ( scBtn != undefined ) {
				    scBtn.style.visibility = "hidden";
				    scBtn.disabled = "disabled";				    
				}							
				/*
				if (grp.value == undefined || grp.value == null || grp.value == "") {
					// default to vendor correspondence
					grp.value="1";
					//asgInfo.value = "Vendor Correspondence";
					var txt = "Vendor Correspondence";
					assigneeInformation.innerHTML=txt;
				}
				*/
		} else {
			if (rts != undefined) {
				rts.value=3;
			}
		    cmntFlag.style.visibility="hidden";
			dispCtl.style.visibility="hidden";
		    addlCtl.style.visibility="hidden";
			if ( resCtl != undefined) {
			    resCtl.style.visibility = "hidden";
			}	
			if ( scBtn != undefined ) {
			    scBtn.style.visibility = "hidden";
			    scBtn.disabled = "disabled";
			}				    
		 }
}

function switchViewDNF(objectID) {
	var rts = document.getElementById("requestTypeSelectedId");
	var addlCtl = document.getElementById("addlbackup_body");
	var dispCtl = document.getElementById("dispute_body");
	var cmnt = document.getElementById("comments");
	var cmntFlag = document.getElementById("comment_flag");
	
	var othCtl = document.getElementById("otherAttach2_body");
	var resCtl = document.getElementById("resolutionAttach_body");
	var scBtn  = document.getElementById("submitCloseButton");	
			
	if (objectID == "Additional Backup") {
		var ddt = document.getElementById("needComment");
			if (ddt != null)
				ddt.value = "";
		    addlCtl.style.visibility="visible";
			dispCtl.style.visibility="hidden";
		    cmntFlag.style.visibility="hidden";
		    document.getElementById("needComment").style.visibility="visible";
		    if (rts != undefined) {
				rts.value=1;
			}
			if (cmnt != undefined) {
				cmnt.value="";
			}
			if ( resCtl != undefined) {
			    resCtl.style.visibility = "visible";
			}
			if ( othCtl != undefined) {
			    othCtl.style.visibility = "hidden";
			}			
			if ( scBtn != undefined ) {
			    scBtn.style.visibility = "visible";
		    	scBtn.disabled = "";				    
			}			
	} else if (objectID == "Deduction Dispute") {
			var amt = document.getElementById("disputeAmt");
			if (amt != undefined) {
				amt.value = "";
			}
			dispCtl.style.visibility="visible";
		    addlCtl.style.visibility="hidden";
		    cmntFlag.style.visibility="visible";
		    document.getElementById("needComment").style.visibility="hidden";
		    if (rts != undefined) {
				rts.value=2;
			}
			if (cmnt != undefined) {
				cmnt.value="";
			}
			if ( resCtl != undefined) {
			    resCtl.style.visibility = "hidden";
			}	
			if ( scBtn != undefined ) {
			    scBtn.style.visibility = "hidden";
			    scBtn.disabled = "disabled";				    
			}	
			if ( othCtl != undefined) {
			    othCtl.style.visibility = "visible";
			}								
	} else {
		if (rts != undefined) {
			rts.value=4;
		}
	    cmntFlag.style.visibility="hidden";
		dispCtl.style.visibility="hidden";
	    addlCtl.style.visibility="hidden";
	    document.getElementById("needComment").style.visibility="hidden";
		if ( resCtl != undefined) {
		    resCtl.style.visibility = "visible";
		}
		if ( scBtn != undefined ) {
		    scBtn.style.visibility = "visible";
	    	scBtn.disabled = "";				    
		}	    
		if ( othCtl != undefined) {
		    othCtl.style.visibility = "visible";
		}					
	 }
}

function updateCommentArea(form) {	
	var cmntFlag = document.getElementById("comment_flag");
	var needCmnt = form.needComment.value;
	if (needCmnt == "Other")
	    cmntFlag.style.visibility="visible";
	else cmntFlag.style.visibility="hidden";
//	var cmnt = form.comments.value;
//	form.comments.value = cmnt + needCmnt;
//	form.comments.value = needCmnt;
}

function changeList(form) {
	var doc = form;
	var ddlbValue;
	var grpId = doc.classGrpId.options[doc.classGrpId.selectedIndex].value;
	if (grpId != null && grpId != "") {
		for (i=0;i<form.length;i++) {
			var tempobj=form.elements[i];
			if (tempobj.name == grpId) {
				ddlbValue = tempobj.value;
				break;
			}
		}

		doc.classId.options.length = 0;
		doc.classId.options[0] = new Option("Select Class", "");			
		var newList = ddlbValue.split(",");
		var newObj;
		for (j=0;j<newList.length;j++) {
			newObj=newList[j];
			//doc.classId.options[j+1] = new Option(newObj, newObj);
			var valueList = newObj.split("^");
			var className = valueList[0];
			var groupId = valueList[1];
			var groupName = valueList[2];
			//doc.classId.options[j+1] = new Option(newObj, newObj);
			var classList = className.split("-");
			var classNum = classList[0];
			doc.classId.options[j+1] = new Option(className, classNum);
		}
	} else {
		doc.classId.options.length = 0;
		doc.classId.options[0] = new Option("Select Class", "");			
	}
}

function clearAssignedToGroup() {
	document.forms[1].assignedGroupKey.value = "";
}

// return the value of the radio button that is checked
// return an empty string if none are checked, or
// there are no radio buttons
function getCheckedValue(radioObj) {
	if(!radioObj)
		return "";
	var radioLength = radioObj.length;
	if(radioLength == undefined)
		if(radioObj.checked)
			return radioObj.value;
		else
			return "";
	for(var i = 0; i < radioLength; i++) {
		if(radioObj[i].checked) {
			return radioObj[i].value;
		}
	}
	return "";
}
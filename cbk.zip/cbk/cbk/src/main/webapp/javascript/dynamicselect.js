/*
	Unobtrusive Dynamic Select Boxes
	http://www.bobbyvandersluis.com/articles/unobtrusivedynamicselect.php

	Modified by PDB to add initDynamicSelectOptions() function
*/

/* Dynamic select options code */
function dynamicSelect(id1, id2) {
	// Browser and feature tests to see if there is enough W3C DOM support
	var agt = navigator.userAgent.toLowerCase();
	var is_ie = ((agt.indexOf("msie") != -1) && (agt.indexOf("opera") == -1));
	var is_mac = (agt.indexOf("mac") != -1);
	if (!(is_ie && is_mac) && document.getElementById && document.getElementsByTagName) {
		// Obtain references to both select boxes
		var sel1 = document.getElementById(id1);
		var sel2 = document.getElementById(id2);
		// Clone the dynamic select box
		var clone = sel2.cloneNode(true);
		// Obtain references to all cloned options 
		var clonedOptions = clone.getElementsByTagName("option");		
		// Onload init: remove the extra options from the dynamic select box -- maintains current selection
		initDynamicSelectOptions(sel1, sel2, clonedOptions);
		// Onchange of the main select box: call a generic function to display the related options in the dynamic select box
		//Modified by vinod - method parameter from clonedOptions to clone as IE11 is not supporting the clone  functionality. 
		sel1.onchange = function() {
			//refreshDynamicSelectOptions(sel1, sel2, clonedOptions);
			refreshDynamicSelectOptions(sel1, sel2, clone);
		};
	}
}

function initDynamicSelectOptions(sel1, sel2, clonedOptions) {
	// Create regular expression objects for "dyn-select" and the value of the selected option of the main select box as class names
	var pattern1 = "dyn-select";
	var pattern2 = sel1.options[sel1.selectedIndex].value;

	// Iterate through all cloned options
	for (var i = 0; i < sel2.options.length; i++) {
		// If the classname of a cloned option either equals "dyn-select" or equals the value of the selected option of the main select box
		if (sel2.options[i].className != pattern1 && sel2.options[i].className != pattern2) {
			// Remove the option
			sel2.remove(i);
			// Decrement i so we check the same i value again
			i--;
		}
	}
}

function refreshDynamicSelectOptions(sel1, sel2, clonedOptions) {
	var toSelect = sel2.options[sel2.selectedIndex].value;
	var toSelectIdx = 0;

	// Delete all options of the dynamic select box
	while (sel2.options.length) {
		sel2.remove(0);
	}
	// Create regular expression objects for "dyn-select" and the value of the selected option of the main select box as class names
	var pattern1 = "dyn-select";
	var pattern2 = sel1.options[sel1.selectedIndex].value;

	// Iterate through all cloned options
	for (var i = 0; i < clonedOptions.length; i++) {
		// If the classname of a cloned option either equals "dyn-select" or equals the value of the selected option of the main select box
		if (clonedOptions[i].className == pattern1 || clonedOptions[i].className == pattern2) {
			// Clone the option from the hidden option pool and append it to the dynamic select box
			sel2.appendChild(clonedOptions[i].cloneNode(true));
			
			if ( clonedOptions[i].value == toSelect ) {
				toSelectIdx = sel2.options.length - 1;
			}
		}
	}
	if ( toSelectIdx > 0 ) {
		sel2.selectedIndex = toSelectIdx;
	}
}
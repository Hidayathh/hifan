/**
 * main.js
 */

function confirmLogout() {
       if (confirm("Are you sure you want to logout ?")) {
              location = "/logout.html";
       }
}

function MM_openBrWindow(theURL,winName,features) { //v2.0
window.open(theURL,winName,features);
}

function newChargebackSearch() {
       location="newChargebackSearch?isformreset=true";
}


function newPASSSearch() {
       location="newPASSSearch?isformreset=true";
}


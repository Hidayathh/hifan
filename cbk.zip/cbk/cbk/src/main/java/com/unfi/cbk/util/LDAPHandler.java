package com.unfi.cbk.util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Vector;

import org.apache.log4j.Logger;

import com.supervalu.svharbor.common.util.properties.PropertyManager;
import com.unfi.cbk.beans.UserDataBean;
import com.unfi.cbk.ldap.Carrier;
import com.unfi.cbk.ldap.SVHarborLDAPFuncs;
import com.unfi.cbk.ldap.UserDetail;
import com.unfi.cbk.ldap.Vendor;
import com.unfi.cbk.utilcore.ApplicationProperties;

/**
 * The LDAPHandler class handles all operations that require a call to
 * LDAP and the associated manipulation of the LDAP data.
 * 
 * Calls to LDAP are needed to determine vendors associated with a
 * user, the type of user, and valid vendor numbers. 
 * 
 * @author      yhp6y2l
 * @since       1.0
 */
public class LDAPHandler {
	static Logger log = Logger.getLogger(LDAPHandler.class);
	
	private SVHarborLDAPFuncs ldap;
	private String userId;
	private UserDetail detail = null;
	private PropertyManager propManager = null;
    
	/**
	 * Initializes a newly created <code>LDAPHandler</code> object.
	 * The constructor takes a user ID and makes it available to
	 * the entire instance.
	 * 
	 * @param userId		The LDAP ID of the user.
	 * @since       		1.0
	 */
	public LDAPHandler(String userId) {
		//Constructor
		System.out.println("LDAPHandler.java-------userId---"+userId);
		this.userId = userId;
		//propManager = PropertyManagerFactory.getPropertyManager();
	}
	
	
	/**
	 * Returns an LDAP Connection object specific to this app. 
	 * This method takes no arguments but creates a new LDAP connection.
	 * <p>
	 * The caller is expected to handle any exceptions and 
	 * look for a null object returned. 
	 *
	 * @return      the SVHarbor LDAP connection
	 * @see         SVHarborLDAPFuncs
	 * @since       1.0
	 */
	public SVHarborLDAPFuncs getLDAPConnection() throws Exception {
		SVHarborLDAPFuncs ldap = null;
		
		// Exceptions should be handled by the caller
		this.ldap = new SVHarborLDAPFuncs();
		this.ldap.initialize(ApplicationProperties.getString("ldap.app.base"));
		//log.debug("LDAP connection opened.");
		
		return this.ldap;
		
	}
	
	
	/**
	 * Releases an LDAP Connection object specific to this app. 
	 * This method takes a <code>SVHarborLDAPFuncs</code> object as
	 * the parameter and calls its <code>destroy<code>.
	 *
	 * @param ldap		the <code>SVHarborLDAPFuncs</code> connection to be released
	 * @see				SVHarborLDAPFuncs
	 * @since       	1.0
	 */
	public void closeLDAPConnection(SVHarborLDAPFuncs ldap) {
		try {
			if (ldap != null) {
				ldap.destroy();
				//log.debug("LDAP connection closed.");
			}
			
		} catch (Exception e) {
			log.error("Exception in closeLDAPConnection():" + e);
		
		}
	
	}
	
	private void initUserDetail(){
		if (ldap != null){
			if (this.detail == null){
				try{				
					this.detail = ldap.getUserDetail(this.userId);
				}
				catch(Exception e){
					log.error("initUserDetail():" + e);
				}
			}
		}
	}
	
	public String getUserName(){
		initUserDetail();
		return detail.getFullName();
	}
	
	public String getUserFirstName(){
		initUserDetail();
		return detail.getFirstName();
	}
	
	public String getUserLastName(){
		initUserDetail();
		return detail.getLastName();
	}
	
	public String getUserEmail(){
		initUserDetail();
		return detail.getEmailAddress();
	}
	
	/**
	 * Gets the user's type from LDAP using the uid.
	 * This method takes a <code>SVHarborLDAPFuncs</code> as the parameter
	 * which already has the uid.  It returns a <code>String</code> that will be
	 * one of the following values:
	 * <ul>
	 * <li>manufacturer</li>
	 * <li>broker</li>
	 * <li>employee</li>
	 * </ul>
	 *
	 * @return			the type of user (manufacturer, broker, employee)
	 * @param ldap		the SVHarborLDAPFuncs connection already created
	 * @see				SVHarborLDAPFuncs
	 * @since			1.0
	 */
	public String getLDAPUserType(SVHarborLDAPFuncs ldap) {
		initUserDetail();
		String userType = "";
		String userTypeFromLDAP = StringFunctions.convertNull(detail.getUserType()).toLowerCase();
		
		if (userTypeFromLDAP.equals("vendor")) {
			userType = "manufacturer";			
		} else if (userTypeFromLDAP.equals("carrier")) {
			userType = "carrier";
		} else if (userTypeFromLDAP.equals("admin") || userTypeFromLDAP.equals("store")) {
			userType = "employee";			
		} else if (userTypeFromLDAP.equals("broker")) {
			userType = "broker";			
		}

        log.debug("User Type - LDAP:" + userTypeFromLDAP + " ePASS:" + userType);
		return userType;
		
	}
	
	
	/**
	 * Gets a formatted list of vendors.
	 * This method takes an existing <code>SVHarborLDAPFuncs</code> and the user type
	 * and returns a properly formatted list of vendors for the user.<br>
	 * The proper format is: <br>
	 * Vendor Name 1                0000001<br>
	 * Vendor Name 2                0000002<br>
	 * ...<br>
	 *
	 * @return			an <code>ArrayList</code> of vendor Strings
	 * @param ldap		the <code>SVHarborLDAPFuncs</code> connection already created
	 * @param userType	the type of user (manufacturer, broker, etc.)
	 * @see				SVHarborLDAPFuncs
	 * @since			1.0
	 */
	public ArrayList getVendorsForUser(SVHarborLDAPFuncs ldap, String userType) {
		ArrayList vendorSelections = new ArrayList();
		ArrayList sortedVendorSelections = new ArrayList();
	
		try {
			Vector vendorList = getVendorList(ldap, userType);
			
			//log.debug("# Vendors: " + vendorList.size());
			for (int i = 0; i < vendorList.size(); i++) {
				Vendor vendor = (Vendor) vendorList.elementAt(i);
				//log.debug("Vendor " + i + ":");
				//log.debug("- vendor ID: " + vendor.getVendorID());
				//log.debug("- vendor Name: " + vendor.getVendorName());
				vendorSelections.add(formatVendorSelection(vendor.getVendorName(), vendor.getVendorID()));				
			
			}
		
			//  Sort the ArrayList by Vendor NAME, not Number
		
			//  First, change the ArrayList to an Object[] to 
			//  take advantage of sorting methods in the Arrays class
			Object[] sortedVendors = vendorSelections.toArray();
			Arrays.sort(sortedVendors, new VendorComparator());
		
			//  Change the sorted Object[] back into an ArrayList
			for (int j = 0; j < sortedVendors.length; j++) {
				sortedVendorSelections.add(sortedVendors[j]);
			
			}			
		
		} catch (Exception e) {
			log.error("Exception in getVendorsForUser():" + e.getMessage());
		
		} finally {
			closeLDAPConnection(ldap);
		}
        return sortedVendorSelections;	
	}
	
	/**
	 * Gets a list of vendors from LDAP for given uid.
	 * This method takes a <code>SVHarborLDAPFuncs</code> and the userType
	 * as parameters.  It returns a <code>Vector</code> containing the list of
	 * <code>Vendor</code> objects
	 *
	 * @return			a Vector of Vendor objects.
	 * @param ldap		the SVHarborLDAPFuncs connection already created
	 * @param userType	the String containing the user type of this uid.
	 * @see				SVHarborLDAPFuncs
	 * @see				Vendor
	 * @since			1.0
	 */
	public Vector getVendorList(SVHarborLDAPFuncs ldap, String userType) {
		Vector vendorList = null;
		
		try {
			if (ldap != null) {
				if (userType.equals("carrier")) {
					UserDetail ldapUserDetail = ldap.getUserDetail(this.userId);
					String carrierId = ldapUserDetail.getCarrierID();
					Carrier ldapCarrier = ldap.getCarrierDetail(carrierId);
					Vendor ldapVendor = new Vendor(carrierId, ldapCarrier.getCarrierName(), ldapCarrier.getEmailAddress(), ldapCarrier.getAddress(), ldapCarrier.getCity(), ldapCarrier.getStateCode(), ldapCarrier.getZipCode(), ldapCarrier.getPhoneNumber(), ldapCarrier.getFaxNumber());
					vendorList = new Vector();
					vendorList.add(ldapVendor);
					
				} else if (userType.equals("manufacturer")) {
					vendorList = ldap.getVendorsOfBrokerUser(this.userId);
					
					//  Add the specific vendor assigned to the user
					UserDetail ldapUserDetail = ldap.getUserDetail(this.userId);
					String vendorId = ldapUserDetail.getVendorID();
					Vendor ldapVendor = ldap.getVendorDetail(vendorId);
					vendorList.add(ldapVendor);
					
				} else if (userType.equals("broker")) {
					vendorList = ldap.getVendorsOfBrokerUser(this.userId);
					
				} else {
					vendorList = new Vector();
					
				}
				
				//log.debug("vendors:" + vendorList.size());
				
			} else {
				throw new Exception();
				
			}
			
		} catch (Exception e) {
			log.error("Exception in getVendorList():" + e);
		}
        return vendorList;	
	}
	
	
	/**
	 * Used for building the drop-down list of Vendors on the search form.
	 * When a user's list of vendors is determined this method is used
	 * to format a struts <code>LabelValueBean</code> that will be referenced by the
	 * HTML form.
	 * 
	 * @return				a struts <code>LabelValueBean</code> used for the form drop-down
	 * @param vendorName	the name of the vendor as listed in LDAP
	 * @param vendorId		the ID of the vendor as listed in LDAP
	 * 
	 * @see					LabelValueBean
	 * @since				1.0
	 */
	private LabelValueBean formatVendorSelection(String vendorName, String vendorId) {
		int maxNameLength = 40;
		String insertValue = "&nbsp;";
		StringBuffer formattedVendorName = new StringBuffer(vendorName);
		
		try {
			int insertValuesNeeded = maxNameLength - formattedVendorName.length();
			
			for (int i = 0; i < insertValuesNeeded; i++) {
				formattedVendorName.append(insertValue);
				
			}
			formattedVendorName.append(vendorId);
			
		} catch (Exception e) {
			log.error("Exception in formatVendorSelection():" + e);
			
		}
        
        LabelValueBean lvb = new LabelValueBean(formattedVendorName.toString(), vendorId);
        formattedVendorName = null;
        return lvb;
	}
	
	
	/**
	 * Checks a given vendor ID and determines if it is contained in the
	 * supplied <code>Vector</code>.
	 * Manufacturer and broker users has finite set of vendors it can search against.
	 * This method is used as a server-side validation that the vendor ID passed in the
	 * request was one of the valid vendors they were given in the drop-down.
	 * 
	 * @return				true if vendorId is contained in the Vector vendorList,
	 * 						otherwise false.
	 * @param vendorList	a <code>Vector</code> of <code>Vendor</code> objects
	 * @param vendorId		the vendor ID to check
	 * @see					Vendor
	 * @since				1.0
	 */
	public boolean vendorIsValid(Vector vendorList, String vendorId) {
		boolean vendorIsValid = false;
		
		for (int i = 0; i < vendorList.size(); i++) {
			Vendor vendor = (Vendor) vendorList.elementAt(i);
			
			if (vendor.getVendorID().indexOf(vendorId) >= 0) {
				// A match was found, return
				vendorIsValid = true;
				break;
				
			}
		}
		
		//log.debug("vendorIsValid:" + vendorIsValid);
		return vendorIsValid;
		
	}
	
	
	/**
	 * Takes a vendor ID and determines if it exists in LDAP.
	 * Employee users manually type the vendor ID they want to search against
	 * and therefore a server-side validation is needed to determine if
	 * the value they entered is a valid vendor ID.
	 * 
	 * @return			true if the vendor ID exists in LDAP, otherwise false
	 * @param ldap		the <code>SVHarborLDAPFuncs</code> connection already created
	 * @param vendorId	the vendor ID to validate
	 * @see				SVHarborLDAPFuncs
	 * @since			1.0
	 */
	public boolean vendorExists(SVHarborLDAPFuncs ldap, String vendorId) {
		boolean vendorExists = false;
	
		try {
			Vendor vendor = ldap.getVendorDetail(vendorId);
			
			if (vendor != null) {
				// A valid vendor was returned
				vendorExists = true;			
			}
			
		} catch (Exception e) {
			log.warn("Non-fatal exception in vendorExists():" + e);
			
		}
        
        return vendorExists;
	}
	
	public List getUserRoles(SVHarborLDAPFuncs ldap){
		List l = null;
		try {
			l = ldap.getAppRolesOfUser(userId,ApplicationProperties.getString("ldap.role.base"));
		} catch (Exception e) {
			log.error("Exception in getUserRoles() " + e);
			//e.printStackTrace();
		}
		return l;
	}
	
	public String getBrokerNumber(){
		initUserDetail();
		return this.detail.getBrokerNumber();
	}
	
	public String getVendorID(){
		initUserDetail();
		return this.detail.getVendorID();
	}
	
	public String getCarrierID(){
		initUserDetail();
		return this.detail.getCarrierID();
	}
	
	public String getUserEntity(UserDataBean userDataBean) throws Exception {
		initUserDetail();
		
		String entityValue = "";
		UserDetail ldapUserDetails = ldap.getUserDetail(userId);
		if (userDataBean.isBroker()) {
			entityValue = ldapUserDetails.getBrokerNumber();
		} else if (userDataBean.isCarrier()) {
			entityValue = ldapUserDetails.getCarrierID();
		} else if (userDataBean.isManufacturer() || userDataBean.isEmployee()) {
			entityValue = ldapUserDetails.getVendorID();
		}
		
		return entityValue;
	}
	
	
	public String getUserName(SVHarborLDAPFuncs ldap){
		initUserDetail();
		return detail.getFullName();
	}
    
	public List getRolesOfApp(SVHarborLDAPFuncs ldap) {
		List l = new ArrayList();
		try {
			l = ldap.getAppRolesOfApp(propManager.getProperty("ldap.role.base"));
		} catch (Exception e) {
			log.error("Exception in getRolesOfApp() " + e);
			//e.printStackTrace();
		}
		return l;        
	}

	public List getUsersOfAppRole(SVHarborLDAPFuncs ldap, String roleName) {
		List l = new ArrayList();
		try {
			l = ldap.getUsersOfAppRole(propManager.getProperty("ldap.role.base"), roleName);
		} catch (Exception e) {
			log.error("Exception in getUsersOfAppRole() " + e);
			//e.printStackTrace();
		}
		return l;        
	}
}
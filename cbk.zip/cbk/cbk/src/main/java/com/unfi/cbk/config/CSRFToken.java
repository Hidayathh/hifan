/**
 * 
 */
package com.unfi.cbk.config;

import java.io.Serializable;

/**
 * @author yhp6y2l
 *
 */
public class CSRFToken implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public static final String _CSRF="_csrf";
	
	private String parameterName;
	private String token;

	public String getParameterName() {
		return parameterName;
	}

	public void setParameterName(String parameterName) {
		this.parameterName = parameterName;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

}

/**
 * 
 */
package com.unfi.cbk.exceptions.handlers;

import org.apache.log4j.Logger;

/**
 * @author yhp6y2l
 *
 */
public interface ExceptionHandlerUtil {

	public static Logger log = Logger.getLogger(ExceptionHandlerUtil.class);
	 /** The maximum number of lines to display in a partial stack trace. */
    public static final int STACK_TRACE_SIZE = 10;    
	
    public default void logException(Exception ex) {
        // Don't display the stack trace for ApplicationSecurityExceptions
        if ( ex.getClass().toString().equals("ApplicationSecurityException") ) {
            log.error("Exception: " + ex.getClass().toString() + " - " + ex.getMessage());            
        }
        else {
            log.error("Exception: " + ex.getClass().toString() + " - " + ex.getMessage() + "\n" + getPartialStackTrace(ex));
        }  
    }
    
    /**
     * Given an Exception, return a partial stack trace as a String, only
     *  including STACK_TRACE_SIZE lines of the trace.
     * 
     * This is useful for situations where you need to display a stack trace,
     *  but don't want to print out tons of extra data you won't need.
     * 
     * @param ex the Exception to get the partial stack trace for
     * @return the partial stack trace as a String
     */
    public default String getPartialStackTrace(Exception ex) {
        StackTraceElement[] stack = ex.getStackTrace();
        StringBuffer s = new StringBuffer();

        int len = STACK_TRACE_SIZE;
        if ( len < STACK_TRACE_SIZE ) { 
            len = stack.length;
        } 

        for ( int i = 0; i < len; i++ ) {
            s.append("    at " + stack[i].toString()+"\n");
        }   
        
        s.append("    (only showing first " + STACK_TRACE_SIZE + " lines of trace)");   
        
        return s.toString();
    }
}

/*
 * Created on Oct 12, 2005
 * 
 */
package com.unfi.cbk.email;

import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.log4j.Logger;

import com.unfi.cbk.util.StringFunctions;



/**
 * @author yhp6y2l
 * @version 1.0 Oct 12, 2005
 */
public class TextMapper {

	private static Logger log = Logger.getLogger(TextMapper.class);
    private final static String PATTERN = "<([\\w.]+)>";
	private Map map = null;
	
	
	/**
	 * 
	 */
	public TextMapper() {				
	}

	public String map(Object pass, String string){
		mapVariables(string);
		return replaceVariables(pass,string);
	}
	
	private void mapVariables(String s){
		map = new HashMap();
		Pattern pattern = Pattern.compile(PATTERN);
		Matcher matcher = pattern.matcher(s);
		while (matcher.find()){
			map.put(matcher.group(0),matcher.group(1));
		}
	}
	
	private String replaceVariables(Object pass, String string){
		String temp = string;
		Set keys = map.keySet();
		Iterator iter = keys.iterator();
		while (iter.hasNext()){			
			String s = (String) iter.next();
            // Call quoteReplacement to escape any \ and $ in the string so that
            //  the underlying regex will be evaluated properly.
			String newValue = StringFunctions.quoteReplacement(findValue(pass,(String)map.get(s)));
            temp = temp.replaceAll(s,newValue);                
		}
		return temp;
	}
	
	
	private String findValue(Object pass, String s){
		String value = null;
		try {
			value = BeanUtils.getProperty(pass,s);
			} catch (IllegalAccessException e) {
				log.error("IllegatAccessException " + e);
				//e.printStackTrace();
			} catch (InvocationTargetException e) {				
				log.error("InvocationTargetException " + e);
				//e.printStackTrace();
			} catch (NoSuchMethodException e) {
				log.error("Cannot find method: " + s);
			} catch (IllegalArgumentException e){
				log.error("Illegal argument.  Object " + s + " may be null. " + e);				
			}
			
		return value == null?"":value;				
	}
	
	
}

package com.unfi.cbk.forms;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;

import com.unfi.cbk.bo.ChargebackBO;
import com.unfi.cbk.util.ActionMessages;
import com.unfi.cbk.util.Constants;
import com.unfi.cbk.util.DateFunctions;
import com.unfi.cbk.util.Validations;



/**
 * The RequestSourceForm class is the struts action form used
 * for the request source maintenance section.  It extends
 * the ValidatorActionForm class in order to utilize built-in
 * struts validation and implements Pageable in order to work
 * with the VCR buttons.
 *
 * @author      yhp6y2l
 * @version     1.0
 */
public class ChargebackCreateForm extends SortablePageableActionForm{ 
	static Logger log = Logger.getLogger(ChargebackCreateForm.class);
	
	private boolean isNew;
	public boolean isNew() {
		return isNew;
	}

	public void setNew(boolean isNew) {
		this.isNew = isNew;
	}

	//  Page-specific properties not part of Map
	private List chargebacks;
	private String[] chargebackSelections = new String[]{};

	public String getInvoiceNumber() {
		return invoiceNumber;
	}

	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}

	public String getLocationNumber() {
		return locationNumber;
	}

	public void setLocationNumber(String locationNumber) {
		this.locationNumber = locationNumber;
	}


	

	public String getInvoiceDate() {
		return invoiceDate;
	}

	public void setInvoiceDate(String invoiceDate) {
		this.invoiceDate = invoiceDate;
	}

	public String getVendorId() {
		return vendorId;
	}

	public void setVendorId(String vendorId) {
		this.vendorId = vendorId;
	}

	public String getNetAmount() {
		return netAmount;
	}

	public void setNetAmount(String netAmount) {
		this.netAmount = netAmount;
	}

	public String getOriginator() {
		return originator;
	}

	public void setOriginator(String originator) {
		this.originator = originator;
	}

	public String getApprover() {
		return approver;
	}

	public void setApprover(String approver) {
		this.approver = approver;
	}

	public String getTypeName() {
		return typeName;
	}

	public void setTypeName(String typeName) {
		this.typeName = typeName;
	}

	private String invoiceNumber;
	private String locationNumber;
	private String invoiceDate;
	private String dueDate;
	public String getDueDate() {
		return dueDate;
	}

	public void setDueDate(String dueDate) {
		this.dueDate = dueDate;
	}

	private String vendorId;
	private String netAmount;
	private String originator;
	private String approver;
	private String typeName;
	private String creatorId;
	private String reasonCode;
	private String prdGrpCode;
	


	//Externalize this value
    @Value("${cbk.autoGrowCollectionLimit:100000}")
    private int autoGrowCollectionLimit;
    @InitBinder
    public void initBinder(WebDataBinder dataBinder) {
        dataBinder.setAutoGrowCollectionLimit(autoGrowCollectionLimit);
    }
	
	
	
	public ChargebackBO[] getChargeback(){
		if (chargebacks == null){
			chargebacks = new ArrayList();
		}
		ChargebackBO[] r = new ChargebackBO[chargebacks.size()];
		for (int i = 0 ; i < chargebacks.size(); i++){
			r[i] = (ChargebackBO) chargebacks.get(i);			
		}
		return r;
	}
	public void setChargeback(ChargebackBO[] r){
		chargebacks = Arrays.asList(r);
	}

	public ChargebackBO getChargeback(int i){
		if (chargebacks == null){
			chargebacks = new ArrayList();
		}
		for (int j=chargebacks.size(); j <= i; j++){
			chargebacks.add(j,new ChargebackBO());
		}
		return (ChargebackBO) chargebacks.get(i);
	}
	public void setChargeback(int i, ChargebackBO doc){
		if (chargebacks == null){
			chargebacks = new ArrayList();		
		}
		chargebacks.add(i, doc);
	}

    public List getChargebacks() {
        return chargebacks;
    }    
    public void setChargebacks(List doc) {
        chargebacks = doc;
    }
	
	public String[] getChargebackSelections() {
		return chargebackSelections;
	}
	public void setChargebackSelections(String[] strings) {
		chargebackSelections = strings;
	}
    
	   
	
	 

	
	
	
	/* (non-Javadoc)
	 * @see org.apache.struts.action.ActionForm#reset(org.apache.struts.action.ActionMapping, javax.servlet.http.HttpServletRequest)
	 */
	public void reset( HttpServletRequest request) {
		// Only Employees and Manufacturers can search by date
		if ( request.isUserInRole(Constants.EMPLOYEE_ROLE) ||
			 request.isUserInRole(Constants.MANUFACTURER_ROLE) ) {
			setValue("dateCriteria", "1");            
		}

		// Brokers are the only ones that are required to select a searchBy property
		if ( request.isUserInRole(Constants.BROKER_ROLE) ) { 
			setValue("searchBy", "docnum");
		}
        
		setValue("documentOutputType", "pdf");
		setSortBy("docnum");
		setSortOrder("asc");
		setShowAll(false);
	}
	
	

	/* (non-Javadoc)
	 * @see org.apache.struts.action.ActionForm#validate(org.apache.struts.action.ActionMapping, javax.servlet.http.HttpServletRequest)
	 */
	public ActionMessages validate( HttpServletRequest request, Environment resource ,ActionMessages errors) {
		//ActionMessages errors = new ActionMessages();		
		String user = request.getRemoteUser();
		//String userType = null;	
		Validations validations = new Validations();	
		
		try {
	      
		} catch (Exception e) {
			log.error("Exception in ChargebackSearchForm.validate()" + e);
		}
        
		return errors;
	}

	
	public String getCreatorId() {
		return creatorId;
	}

	public void setCreatorId(String creatorId) {
		this.creatorId = creatorId;
	}

	public String getReasonCode() {
		return reasonCode;
	}

	public void setReasonCode(String reasonCode) {
		this.reasonCode = reasonCode;
	}

	public String getPrdGrpCode() {
		return prdGrpCode;
	}

	public void setPrdGrpCode(String prdGrpCode) {
		this.prdGrpCode = prdGrpCode;
	}


	
	/**
	 * @param cbk
	 */
	public void populateFormFromObject(ChargebackBO cbk) {
		this.isNew = false;
		this.setLocationNumber(cbk.getLocationNumber());
		this.setVendorId(cbk.getVendorId());
		this.setInvoiceNumber(cbk.getInvoiceNumber());
		this.setInvoiceDate(DateFunctions.formatDate(cbk.getInvoiceDate()));
		this.setTypeName(cbk.getTypeName());
		this.setCreatorId(cbk.getCreatorId());
		this.setPrdGrpCode(cbk.getPrdGrpCode());
		this.setReasonCode(cbk.getReasonCode());
		this.setApprover(cbk.getApprover());
		this.setDueDate(DateFunctions.formatDate(cbk.getDueDate()));
		
	}
	
	


}
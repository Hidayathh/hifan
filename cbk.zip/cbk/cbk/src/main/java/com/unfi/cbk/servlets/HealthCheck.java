package com.unfi.cbk.servlets;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;

/**
 * The HealthCheck servlet is what's called by the health check monitor
 * in SVHarbor to determine if the app is available.  The <code>service</code>
 * method simply returns the text 'OK'.
 *
 * @author      yhp6y2l
 * @since       1.0
 */
public class HealthCheck extends HttpServlet {

	public void service (HttpServletRequest request, HttpServletResponse response)
		throws ServletException, IOException {

		PrintWriter out = response.getWriter();
	    
    	response.setContentType("text/plain");
    	
    	System.out.println("Application is UP");
    	out.println("Application is UP");
    	
    	out.close(); 

	}

}
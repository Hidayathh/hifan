/*
 * Created on Jan 19, 2005
 *
 */
package com.unfi.cbk.filter;
import java.security.Principal;
import java.util.HashSet;
import java.util.StringTokenizer;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;

/**
 * @author yhp6y2l
 * @version 1.0
 */

public class HarborHttpServletRequestWrapper extends HttpServletRequestWrapper {

	protected HashSet harborRoles = null;
	private Principal harborPrincipal = null;
	private String login = null;
	
	
	/**
	 * This implementation of the HttpServletRequestWrapper uses the Siteminder headers
	 * to populate both the java.security.Principal object and the roles of the Principal.
	 * 
	 * Names of the variouse SiteMinder headers needed to populate the request object
	 * are located in WrapperConstants. 
	 * 
	 * @see javax.servlet.http.HttpServletRequest
	 */
	
	public HarborHttpServletRequestWrapper(HttpServletRequest request) {
		super(request);	
		
		login = request.getHeader(WrapperConstants.get(WrapperConstants.SM_USER_HEADER));
		
		harborPrincipal = new HarborPrincipal(request.getHeader(WrapperConstants.get(WrapperConstants.SM_LOGIN_HEADER)));								
		
		harborRoles = new HashSet();
		String value = request.getHeader(WrapperConstants.get(WrapperConstants.SM_ROLE_HEADER));
		if (value != null){
			if (value.indexOf(WrapperConstants.SM_ROLE_DELIMITER) > -1) {				
				StringTokenizer st = new StringTokenizer(value, WrapperConstants.get(WrapperConstants.SM_ROLE_DELIMITER));
				while (st.hasMoreElements()) {
					harborRoles.add(st.nextToken());					
				}
			}				
			else{			
				harborRoles.add(value);								
			}
		}	
	}
	
	/**
	 * @return prinicipal	A java.security.Principal object obtained from SiteMinder headers.
	 * @see javax.servlet.http.HttpServletRequest#getUserPrincipal()
	 */
	public Principal getUserPrincipal(){		
		return harborPrincipal;
	}
	/**
	 * @param role	The name of the role to check.
	 * @return	boolean	true if user is authenticated and has the role; otherwise false.
	 * @see javax.servlet.http.HttpServletRequest#isUserInRole(java.lang.String)
	 */
	public boolean isUserInRole(java.lang.String role){
		boolean ret = false;
		
		if (harborRoles != null){
			ret = harborRoles.contains(role);
		}

		return ret;
	}
	
	/**
	 * @return id used by user to authenticate; returns null if user has not been authenticated.
	 * @see javax.servlet.http.HttpServletRequest#getRemoteUser()
	 */
	public String getRemoteUser(){
		return login;		
	}
	
	private class HarborPrincipal implements Principal{
		private String name = null;		
		
		public HarborPrincipal(String name){
			this.name = name;
		}
		
		public String getName(){
			return name;
		}		
	}
}

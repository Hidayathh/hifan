package com.unfi.cbk.ldaputil;

import com.unfi.cbk.ldaputil.ConfigFile;

/**
 * Class to hold misc. constants.
 * Creation date: (02/15/2002 4:02:01 PM)
 * @author: yhp6y2l
 */
public final class CbkLdapConstants
{
    private static CbkLdapConstants _instance = null;
    // The contents of the properties file.
    private ConfigFile props = null;
    // The name of the properties file.
    private final static java.lang.String PROPERTIES_FILENAME = "SVHarborLDAPFuncs.properties";

    /*************** Constants from the properties file. ************/
    private String ldapHost = null;
    private int ldapPort = 0;
    private int ldapVersion = 0;
    private String ldapBaseDN = null;
	private String dominoServerName=null;
	private String dominoUserName=null;
	private String dominoUserPassword=null;
	private String dominoSVHONABPath=null;
	private String dominoCacheMaxAge=null;
    private boolean dominoServletsEnabled = false;
    private String dominoServletUserName = null;
    private String dominoServletPassword = null;
    private String dominoServletBaseURL = null;
    private String centralSupportPhoneNumber = null;
    private String svHarborExitURL = null;
    private String svHarborLogoutURL = null;
    private String eMailSuffix = null;
    private String svHarborPrivacyURL = null;
    private String pubDropoffDir = null;
    private String svHarborTermsURL = null;
    private String ldapLogDir = null;

	public static String SV_CREATED_VENDOR_GROUP = "SV";
	public static String VENDOR_CREATED_VENDOR_GROUP = "VN";

	public static String CORPORATE_VENDOR = "CV";
	public static String EA_EXTENDED_VENDOR = "EV";
	public static String DSD_VENDOR = "DV";
	

/**
 * Loads the properties file into memory.  The constructor is
 * private to prevent anyone outside this class from instantiating
 * it.  If you want an instance of this class, you must use the
 * class's getInstance() method
 *
 * Creation date: (02/04/2002 5:09:15 PM)
 * @exception java.lang.Exception
 */
private CbkLdapConstants()
	throws java.lang.Exception
{
	props = new ConfigFile("", PROPERTIES_FILENAME);

	ldapHost = props.getStringProperty("LDAPHostName");
	ldapPort = props.getIntProperty("LDAPPortNumber");
	ldapVersion = props.getIntProperty("LDAPVersion");
	ldapBaseDN = props.getStringProperty("BaseDN");

	// The following domino parameters are optional.
	dominoServerName = null;
	dominoUserName = null;
	dominoUserPassword = null;
	dominoSVHONABPath = null;
	dominoCacheMaxAge = null;
	try {
		dominoServerName = props.getStringProperty("DominoServerName");
	}
	catch (Exception ignore) { }
	try {
		dominoUserName = props.getStringProperty("DominoUserName");
	}
	catch (Exception ignore) { }
	try {
		dominoUserPassword = props.getStringProperty("DominoUserPassword");
	}
	catch (Exception ignore) { }
	try {
		dominoSVHONABPath = props.getStringProperty("DominoSVHONABPath");
	}
	catch (Exception ignore) { }
	try {
		dominoCacheMaxAge = props.getStringProperty("DominoCacheMaxAge");
	}
	catch (Exception ignore) { }

	dominoServletsEnabled = props.getBooleanProperty("DominoServletsEnabled");
	dominoServletUserName = dominoServletsEnabled ? props.getStringProperty("DominoServletUserName") : null;
	dominoServletPassword = dominoServletPassword = dominoServletsEnabled ? props.getStringProperty("DominoServletPassword") : null;
	dominoServletBaseURL = dominoServletsEnabled ? props.getStringProperty("DominoServletBaseURL") : null;
	centralSupportPhoneNumber = props.getStringProperty("CentralSupportPhoneNumber");
	svHarborExitURL = props.getStringProperty("SVHarborExitURL");
	svHarborLogoutURL = props.getStringProperty("SVHarborLogoutURL");
	eMailSuffix = props.getStringProperty("EMailSuffix");
	svHarborPrivacyURL = props.getStringProperty("SVHarborPrivacyURL");
	svHarborTermsURL = props.getStringProperty("SVHarborTermsURL");

	// The following fields are optional.
	try {
		pubDropoffDir = props.getStringProperty("PubDropoffDir");
	}
	catch (Exception ignore) { }
	try {
		ldapLogDir = props.getStringProperty("LDAPLogDir");
	}
	catch (Exception ignore) {
		ldapLogDir = "C:\\winnt\\java\\trustlib\\com\\supervalu\\svharborldap";
	}
}
/**
 * Get the contents of the centralSupportPhoneNumber field.
 * Creation date: (02/15/2002 4:40:13 PM)
 * @return String
 */
public String getCentralSupportPhoneNumber()
{
	return(centralSupportPhoneNumber);
}
/**
 * Get the contents of the dominoCacheMaxAge field.
 * @return String
 */
public String getDominoCacheMaxAge()
{
	return dominoCacheMaxAge;
}
/**
 * Get the contents of the dominoServerName field.
 * @return String
 */
public String getDominoServerName()
{
	return dominoServerName;
}
/**
 * Get the contents of the dominoServletBaseURL field.
 * Creation date: (02/15/2002 4:40:13 PM)
 * @return String
 */
public String getDominoServletBaseURL()
{
	return dominoServletBaseURL;
}
/**
 * Get the contents of the dominoServletPassword field.
 * Creation date: (02/15/2002 4:40:13 PM)
 * @return String
 */
public String getDominoServletPassword()
{
	return dominoServletPassword;
}
/**
 * Get the contents of the dominoServletUserName field.
 * Creation date: (02/15/2002 4:40:13 PM)
 * @return String
 */
public String getDominoServletUserName()
{
	return dominoServletUserName;
}
/**
 * Get the contents of the dominoSVHONABPath field.
 * @return String
 */
public String getDominoSVHONABPath()
{
	return dominoSVHONABPath;
}
/**
 * Get the contents of the dominoUserName field.
 * @return String
 */
public String getDominoUserName()
{
	return dominoUserName;
}
/**
 * Get the contents of the dominoUserPassword field.
 * @return String
 */
public String getDominoUserPassword()
{
	return dominoUserPassword;
}
/**
 * Get the contents of the eMailSuffix field.
 * Creation date: (02/15/2002 4:40:13 PM)
 * @return String
 */
public String getEMailSuffix()
{
	return(eMailSuffix);
}
/**
 * Returns a reference to a SVHarborConstants object.  The
 * object is created the first time this function
 * is called.  All subsequent calls return a reference
 * to the same object.
 *
 * Creation date: (02/04/2002 5:59:18 PM)
 * @return com.supervalu.svharborldap.SVHarborConstants
 */
public static CbkLdapConstants getInstance()
	throws java.lang.Exception
{
	if (_instance == null) {
		_instance = new CbkLdapConstants();
	}

	return(_instance);
}
/**
 * Get the contents of the ldapBaseDN field.
 * Creation date: (02/15/2002 4:40:13 PM)
 * @return String
 */
public String getLDAPBaseDN()
{
	return ldapBaseDN;
}
/**
 * Get the contents of the ldapHost field.
 * Creation date: (02/15/2002 4:40:13 PM)
 * @return String
 */
public String getLDAPHost()
{
	return ldapHost;
}
/**
 * Gets the LDAP password for the specified application.
 * Creation date: (02/15/2002 4:29:11 PM)
 * @return java.lang.String
 * @param applicationName java.lang.String
 * @exception javax.servlet.ServletException - Throws and exception if
 * a password for the application isn't found in the properties file.
 */
public String getLDAPPassword(String applicationName)
	throws java.lang.Exception
{
	return(props.getStringProperty(applicationName + "_LDAPPassword"));
}
/**
 * Get the contents of the ldapPort field.
 * Creation date: (02/15/2002 4:40:13 PM)
 * @return int
 */
public int getLDAPPort()
{
	return ldapPort;
}
/**
 * Gets the LDAP User name for the specified application.
 * Creation date: (02/15/2002 4:29:11 PM)
 * @return java.lang.String
 * @param applicationName java.lang.String
 * @exception javax.servlet.ServletException - Throws and exception if
 * a user name for the application isn't found in the properties file.
 */
public String getLDAPUserName(String applicationName)
	throws java.lang.Exception
{
	return(props.getStringProperty(applicationName + "_LDAPUserName"));
}
/**
 * Get the contents of the ldapVersion field.
 * Creation date: (02/15/2002 4:40:13 PM)
 * @return int
 */
public int getLDAPVersion()
{
	return ldapVersion;
}
/**
 * Get the contents of the pubDropoffDir field.
 * Creation date: (02/15/2002 4:40:13 PM)
 * @return String
 */
public String getPubDropoffDir()
{
	return(pubDropoffDir);
}
/**
 * Get the contents of the svHarborExitURL field.
 * Creation date: (02/15/2002 4:40:13 PM)
 * @return String
 */
public String getSVHarborExitURL()
{
	return(svHarborExitURL);
}
/**
 * Get the contents of the svHarborLogoutURL field.
 * Creation date: (02/15/2002 4:40:13 PM)
 * @return String
 */
public String getSVHarborLogoutURL()
{
	return(svHarborLogoutURL);
}
/**
 * Get the contents of the svHarborPrivacyURL field.
 * Creation date: (02/15/2002 4:40:13 PM)
 * @return String
 */
public String getSVHarborPrivacyURL()
{
	return(svHarborPrivacyURL);
}
/**
 * Get the contents of the svHarborTermsURL field.
 * Creation date: (02/15/2002 4:40:13 PM)
 * @return String
 */
public String getSVHarborTermsURL()
{
	return(svHarborTermsURL);
}
/**
 * Get the contents of the ldapLogDir field.
 * @return String
 */
public String getLDAPLogDir()
{
	return(ldapLogDir);
}
/**
 * Get the contents of the dominoServletsEnabled field.
 * Creation date: (02/15/2002 4:40:13 PM)
 * @return boolean
 */
public boolean IsDominoServletsEnabled()
{
	return dominoServletsEnabled;
}
/**
 * Call this function to re-read the constants from the file.
 *
 * Creation date: (02/04/2002 5:59:18 PM)
 */
public static void refresh()
	throws java.lang.Exception
{
	_instance = null;
	getInstance();
}
}

/*
 * Created on Nov 4, 2005
 * 
 */
package com.unfi.cbk.util;

import java.util.List;

/**
 * @author yhp6y2l
 * @version 1.0 Nov 4, 2005
 */
public interface Chain {

	public void addChain(Chain c);
	public void process(Object obj, List clauses, List params);
	//public Chain getChain();

}

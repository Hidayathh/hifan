package com.unfi.cbk.actions.chargeback;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.servlet.ModelAndView;

import com.unfi.cbk.actions.PageAccessResolver;
import com.unfi.cbk.beans.ResultList;
import com.unfi.cbk.bo.ChargebackBO;

import com.unfi.cbk.delegates.ChargebackSearchDelegate;
import com.unfi.cbk.forms.ChargebackDetailForm;

import com.unfi.cbk.util.ActionMessages;
import com.unfi.cbk.util.ActionUrlMapping;
import com.unfi.cbk.util.Constants;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


/**
 * The GetResultsAction class is the struts action called when retrieving
 * the search results.
 * The action simply determines the user type and forwards the request to
 * a secondary struts action specific to the user type.
 * <p>
 * This is to accommodate the struts Validator.  Since all three versions
 * of the search form use the same ActionForm, the different validations that 
 * need to be done specific to the type of form used are accomplished by
 * having the validator use the actions to determine which rules to use.<br>
 * This action, then, makes the user type transparent to the user by always
 * having the same action called when searching, regardless of user type.
 *
 * @author      vpil001
 * @since       1.0
 */
@Controller("chargebackUpdateAction_updateChargeback")
@Scope(value=WebApplicationContext.SCOPE_REQUEST, proxyMode=ScopedProxyMode.TARGET_CLASS)
public class ChargebackUpdateAction {//extends Action {
	static Logger log = Logger.getLogger(GetResultsActions.class);	
	@Autowired
    private ChargebackSearchDelegate chargebackSearchDelegate;
	
	public ChargebackUpdateAction(ChargebackSearchDelegate chargebackSearchDelegate) {
		this.chargebackSearchDelegate = chargebackSearchDelegate;
	}
	
	@Autowired
	 ActionMessages messages;
	@Autowired
	Environment env;
	//Externalize this value
    @Value("${cbk.autoGrowCollectionLimit:100000}")
    private int autoGrowCollectionLimit;
    @InitBinder
    public void initBinder(WebDataBinder dataBinder) {
        dataBinder.setAutoGrowCollectionLimit(autoGrowCollectionLimit);
    }
	
	@RequestMapping(value = "/updateChargeback",method = {RequestMethod.GET,RequestMethod.POST})
	public ModelAndView details(@ModelAttribute("chargebackUpdateForm") ChargebackDetailForm chargebackUpdateForm, HttpServletRequest request, HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		log.debug("***** CHARGEBACK Detail- RESULTS *****");
		System.out.println("...........CHARGEBACK Detail- RESULTS......");
		chargebackUpdateForm.setFormParameterMap(request);
		//	****  Exceptions handled by global exception handlers ****
		
		//ChargebackDetailsForm chargebackUpdateForm = (ChargebackDetailsForm) form;
//		MessageResources environmentResources = getResources(request, "environmentResources");
//		String maxPerPage = environmentResources.getMessage("maxDocumentSearchResultsPerPage");

      
		String invoiceNumber= null;
		
		
		if(request.getParameter("invoiceNbr") !=null)
		{
			invoiceNumber = request.getParameter("invoiceNbr");
		}
		String vendorId = null;
		
		if(request.getParameter("vendorId") !=null)
		{
			vendorId = request.getParameter("vendorId");
		}
		
		
		
		System.out.println("CHARGEBACK Detail- invoice number......"+invoiceNumber);
		System.out.println("CHARGEBACK Detail- vendorId......"+vendorId);
		
		
		
		
        String userId = chargebackUpdateForm.getString("userId");
		//System.out.println("CHARGEBACK Detail- RESULTS...userId..."+userId);
       
        Map detailParametersFromForm = chargebackUpdateForm.getMap();
        
       
        
        
   
        
       
        
        
       // chargebackUpdateForm.validate(request,env,messages);
		
		if(!messages.isEmpty())
		{
			System.out.println("---------ERROR MESSAGES-----");
			
			
            
			//TODO return back to the same.
			request.setAttribute("actionMessages", messages);
			messages.saveMessages(request);
			request.setAttribute("chargebackUpdateForm", chargebackUpdateForm);
			mav.setViewName("forward:/getChargebackDetails");
			return mav;
		}
        
		//  Define the display parameters
		int maxRows = 20;
        chargebackUpdateForm.setDisplayCount(maxRows);
        
        detailParametersFromForm.put("invoiceNumber",invoiceNumber);
		detailParametersFromForm.put("vendorId",vendorId);

       if ( chargebackUpdateForm.isShowAll() ) {
            detailParametersFromForm.put("showAll", "true");
        }            
        else {
            detailParametersFromForm.put("rowStart", new Integer(chargebackUpdateForm.getCurrentRecord()));
            detailParametersFromForm.put("rowEnd",   new Integer(chargebackUpdateForm.getCurrentRecord() + maxRows - 1));
        }
       
		
		System.out.println("-------------BEFORE QEURY------------------");
		//  Get the search results based on the parameters in the form
		
		
		
		ChargebackBO cbkBo = chargebackSearchDelegate.getChargebackDetail(detailParametersFromForm);
		chargebackUpdateForm.populateFormFromObject(cbkBo);
		
		//ResultList detailResults = chargebackSearchDelegate.getChargebacks(detailParametersFromForm);
		//System.out.println("-------------AFTER QEURY------searchResults--size----------"+detailResults.getList().size());
		
		//  Populate the 'searchResults' property in the ActionForm
		//chargebackUpdateForm.setDetailResults(detailResults.getList());
		HttpSession session=request.getSession();  
		//session.setAttribute("searchResults",searchResults.getList()); 

		//  Populate the result count property in the ActionForm
		//chargebackUpdateForm.setTotalRecords(searchResults.getTotalCount().intValue());

		// Place the summary information in the messages. 
		// This is necessary, as the criteria is rendered in the header, which knows nothing about our form
       // ActionMessages messages = new ActionMessages();
		//messages.add("searchCriteriaSummary", "messages.searchCriteriaSummary", new String[] {documentDelegate.buildSearchCriteriaSummary(searchParametersFromForm, filterLocations, exclude)});
		//saveMessages(request, messages);
		 messages.saveMessages(request);

		PageAccessResolver resolver = new PageAccessResolver(request);
		if (resolver.hasAccess()){	
			mav.setViewName(ActionUrlMapping.CHARGEBACKDETAILSACTIONS.get(Constants.ACTION_SUCCESS));
			request.setAttribute("actionMessages", messages);
			//return mapping.findForward("success");
			System.out.println("---IF--getChargebackDetailsResults-------"+mav.getViewName());
			return mav;
		}
		else{
			mav.setViewName(ActionUrlMapping.CHARGEBACKDETAILSACTIONS.get("other"));
			//return mapping.findForward("other");
			
			System.out.println("--ELSE---getChargebackDetailsResults-------"+mav.getViewName());
			
			request.setAttribute("actionMessages", messages);
			request.setAttribute("chargebackUpdateForm", chargebackUpdateForm);
			return mav;
		}			
	}
	
	
	
	
	
	private boolean validateSpecialCharacters(String string,String idNamePattern)
	{
		Pattern pattern=Pattern.compile(idNamePattern);
		
		Matcher matcher = pattern.matcher(string);
		 
		boolean  patternFlag = false;
		
	      if (!matcher.matches()) {
	    	  
	    	  patternFlag=true;
	           System.out.println("String--- "+string+" contains special character");
	      } 
		 
		return patternFlag;
	}
}
/*
 * Created on Jan 19, 2005
 *
 */
package com.unfi.cbk.filter;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.apache.log4j.MDC;

import com.unfi.cbk.ldap.ApplicationRole;
import com.unfi.cbk.ldap.SVHarborLDAPFuncs;
import com.unfi.cbk.util.Constants;
import com.unfi.cbk.util.LDAPHandler;

/**
 * @author yhp6y2l
 * @version 1.0
 * 
 */
public class CBKHarborTestHttpServletRequestWrapper
	extends HarborTestHttpServletRequestWrapper {

	private static Logger log = Logger.getLogger(CBKHarborTestHttpServletRequestWrapper.class);
	
	
	/**
	 
	 * @param request	The request being wrapped.
	 * @see javax.servlet.http.HttpServletRequestWrapper
	 */
	
	public CBKHarborTestHttpServletRequestWrapper(HttpServletRequest request) {
		super(request);	

		//	Put the user's username into the Log4J message diagnostic 
		//	context. May be shown using %X{username} in the layout 
		//	pattern.                                     
		MDC.put("username", this.getRemoteUser());
	 
		//log.debug("Constructing request wrapper");	
		//harborRoles = new HashSet();
		LDAPHandler lh = null;
		SVHarborLDAPFuncs ldap = null;

		lh = new LDAPHandler(this.getRemoteUser());
		System.out.println("CBKHarborTestHttpServletRequestWrapper() RemoteUser = "+this.getRemoteUser());
		
		try{
			ldap = lh.getLDAPConnection();
			//Get the user type from LDAP
			String userType = lh.getLDAPUserType(ldap);
			
			if (userType != null){
				harborRoles.add(userType);
				if (userType.equals("carrier")) {
					//  A carrier should be like a vendor
					harborRoles.add("manufacturer");
					request.setAttribute("userType", "manufacturer");
				} else {
					request.setAttribute("userType", userType);
				}

			}
			
			List l = lh.getUserRoles(ldap);
			if (l != null){
				for (int i=0; i<l.size();i++){
					ApplicationRole role = (ApplicationRole) l.get(i);		
					log.debug("add role:" + role.getName());
					harborRoles.add(role.getName());
					
					//User cannot have both employee and VendorFileSupport roles
					/*
					 * if (role.getName().equals(Constants.VENDOR_FILE_SUPPORT)){
					 * harborRoles.remove("employee"); }
					 */
				}
			}
			
			System.out.println("-----roles:" + harborRoles.toString());
			
			
			if (harborRoles.contains(Constants.BROKER_ROLE)){
				request.setAttribute("entityValue", lh.getBrokerNumber());
				log.debug("broker:" + lh.getBrokerNumber());
			}
			
			if (harborRoles.contains(Constants.CARRIER_ROLE)) {
				request.setAttribute("entityValue", lh.getCarrierID());
				log.debug("vendor(carrier):" + lh.getCarrierID());
				
			} else 	if (harborRoles.contains(Constants.MANUFACTURER_ROLE) || harborRoles.contains(Constants.EMPLOYEE_ROLE)){
				request.setAttribute("entityValue", lh.getVendorID());
				log.debug("vendor:" + lh.getVendorID());
			}
			
		}
		catch(Exception e){
			log.error("Exception obtaining ldap connection: " + e);
		}
		finally{
			
			try{
				lh.closeLDAPConnection(ldap);				
			}
			catch(Exception ignore){}
		}
		

	
		
	
		
	
		

		
		
		
		
	}

}

/*
 * Created on Jan 19, 2005
 *
 */
package com.unfi.cbk.filter;
import java.io.IOException;
import java.io.InputStream;
import java.security.Principal;
import java.util.HashSet;
import java.util.Properties;
import java.util.Set;
import java.util.StringTokenizer;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;

/**
 * @author yhp6y2l
 * @version 1.0
 * 
 */
public class HarborTestHttpServletRequestWrapper
	extends HttpServletRequestWrapper {

	protected Set harborRoles = null;	
	
	/**
	 
	 * @param request	The request being wrapped.
	 * @see javax.servlet.http.HttpServletRequestWrapper
	 */
	
	public HarborTestHttpServletRequestWrapper(HttpServletRequest request) {
		super(request);	
				
		harborRoles = new HashSet();
		if (WrapperConstants.getTestRoles() != null){
			harborRoles = new HashSet(WrapperConstants.getTestRoles());
		}	
	}
	/**
	 * @return String constant "Test User"
	 * @see javax.servlet.http.HttpServletRequest#getUserPrincipal()
	 * 	 
	 */
	public Principal getUserPrincipal(){
		Principal principal = new HarborPrincipal("Unknown");		
		String name = WrapperConstants.get(WrapperConstants.DEFAULT_USER_NAME);
		if (name != null){				
			principal = new HarborPrincipal(name);
		}
		return principal;
	}

	/**
	 * @see javax.servlet.http.HttpServletRequest#isUserInRole(java.lang.String)
	 */
	public boolean isUserInRole(java.lang.String role){		
		return harborRoles.contains(role);
	}
	/** 
	 * @see javax.servlet.http.HttpServletRequest#getRemoteUser()
	 * 
	 * @return String id of user
	 */
	public String getRemoteUser(){
		return WrapperConstants.get(WrapperConstants.DEFAULT_USER_ID);
	}
	
	private class HarborPrincipal implements Principal{
	
		private String name = null;		
	
		public HarborPrincipal(String name){
			this.name = name;
		}
		
		public String getName(){
			return name;
		}		
	}
	
	
}

package com.unfi.cbk.servlets;

import javax.servlet.*;
import javax.servlet.http.*;

import com.unfi.cbk.util.ESAPIUtil;

import java.io.*;
import java.util.*;

/**
 * The ShowHeaders class is a troubleshooting servlet used to view the HTTP
 * headers for the application.
 *
 * @author      yhp6y2l
 * @since       1.0
 */
public class ShowHeaders extends HttpServlet {

	public void init() {
		
  	}

	public void doGet (HttpServletRequest request, HttpServletResponse response)
		throws IOException {

		processRequest(request, response);

	}

	private void processRequest(HttpServletRequest request, HttpServletResponse response) 
		throws IOException {
			
		PrintWriter out = response.getWriter();
	    
    	// Set the content type for the output
    	response.setContentType("text/plain");
    	
    	out.println("Request Headers:");
    	out.println();

    	Enumeration names = request.getHeaderNames();
    	while (names.hasMoreElements()) {
    		String name = (String) names.nextElement();
    		Enumeration values = request.getHeaders(name); //support mulitple values
    		if (values != null) {
    			while (values.hasMoreElements()) {
    				String value = (String) values.nextElement();
    				out.println(ESAPIUtil.encode(name) + ": " + ESAPIUtil.encode(value));
    			}
    		}
    	}
    	
    	out.println();
    	out.println();
    	out.println("Cookies:");
    	out.println();
    	
    	Cookie[] cookies = request.getCookies();
    	if (cookies.length > 0) {
    		for (int i = 0; i < cookies.length; i++) {
    			Cookie cookie = cookies[i];
    			out.println("Cookie Name: " + ESAPIUtil.encode(cookie.getName()));
    			out.println("Cookie value: " + ESAPIUtil.encode(cookie.getValue()));
    			out.println();
    		}
    	} else {
    		out.println("No cookies.");
    	}
    	
    	
    	out.close(); 
 
	}
}
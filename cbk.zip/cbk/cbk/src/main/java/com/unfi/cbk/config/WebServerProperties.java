/**
 * 
 */
package com.unfi.cbk.config;
/**
 * 
 */

import java.util.List;
import java.util.Map;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * @author yhp6y2l
 *
 */
@Component
@ConfigurationProperties("tomcat.server")
public class WebServerProperties {

	
	
	private Map<String,String> connector;
	
	private List<Map<String,String>> resource;
	
	

	public List<Map<String, String>> getResource() {
		return resource;
	}

	public void setResource(List<Map<String, String>> resource) {
		this.resource = resource;
	}

	public Map<String, String> getConnector() {
		return connector;
	}

	public void setConnector(Map<String, String> connector) {
		this.connector = connector;
	}

	@Override
	public String toString() {
		return "WebServerProperties [connector=" + connector + ", resource=" + resource + "]";
	}
	
	

	

}

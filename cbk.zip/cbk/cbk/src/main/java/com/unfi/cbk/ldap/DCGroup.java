/*
 * DCGroup.java
 *
 * Created on March 13, 2001, 2:31 PM
 */
package com.unfi.cbk.ldap;

import java.util.Vector;

import com.unfi.cbk.ldaputil.Comparer;
import com.unfi.cbk.ldaputil.VectorFuncs;

/**
 * Class to hold Distribution Center (DC) Group information.
 * @author: yhp6y2l
 */
public class DCGroup extends StoreGroup
{
	public String getDCNumber() {return(getGroupNumber());}

	/** Creates new DCGroup */
	public DCGroup(String dcNumber,
				   String dcName,
				   String owner,
				   String groupID)
	{
		super("DC", dcNumber, dcName, owner, groupID);
	}

	// Sorts by DCNumber + name.
	private static class DCNumberAndNameOrder implements Comparer
	{
		public int compare(java.lang.Object o1, java.lang.Object o2)
		{
			int ret;
			ret = ((DCGroup)o1).getGroupNumber().toLowerCase().compareTo(((DCGroup)o2).getGroupNumber().toLowerCase());
			ret = ret == 0 ? ((DCGroup)o1).getName().toLowerCase().compareTo(((DCGroup)o2).getName().toLowerCase()) : ret;
			return ret;
		}
	}

	/**
	 * Sorts the Vector of StoreGroup objects into order by
	 * DC Number + Name.
	 */
	public static void sortByDCNumberAndName(Vector vector)
	{
		VectorFuncs.sort(vector, new DCGroup.DCNumberAndNameOrder());
	}
}
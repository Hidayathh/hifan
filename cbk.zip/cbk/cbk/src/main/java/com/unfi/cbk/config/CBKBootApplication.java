package com.unfi.cbk.config;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.Banner.Mode;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.context.ApplicationPidFileWriter;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;

@SpringBootApplication(scanBasePackages= {"com.unfi.cbk"},exclude = {DataSourceAutoConfiguration.class})
public class CBKBootApplication extends SpringBootServletInitializer {
/**
 * 
 * @param args
 */
	public static void main(String[] args) {

		SpringApplication springApplication = new SpringApplication(CBKBootApplication.class);
        springApplication.addListeners(new ApplicationPidFileWriter());     // register PID write to spring boot. It will write PID to file
        springApplication.setBannerMode(Mode.LOG);
        springApplication.run(args);
		
	}

	@Override
	public void onStartup(ServletContext servletContext) throws ServletException {
		super.onStartup(servletContext);
	}

}



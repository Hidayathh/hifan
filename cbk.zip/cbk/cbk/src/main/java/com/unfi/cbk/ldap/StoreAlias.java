package com.unfi.cbk.ldap;

import com.unfi.cbk.ldaputil.CompareTo;

/**
 * Class to hold Store Alias information.
 * @author: yhp6y2l
 */
public class StoreAlias extends Object implements CompareTo
{
    private String storeNumber;
    private String alias;
    private String description;
    /** Creates new StoreAlias */
    public StoreAlias(String storeNumber,
                      String alias,
                      String description)
    {
        super();
        
        this.storeNumber = storeNumber;
        this.alias = alias;
        this.description = description;
    }
    // Sorts by store number + alias.
    public int compareTo(java.lang.Object storeAliasObj) {
        int ret = storeNumber.toLowerCase().compareTo(((StoreAlias)storeAliasObj).storeNumber.toLowerCase());
        
        ret = ret == 0 ? alias.toLowerCase().compareTo(((StoreAlias)storeAliasObj).alias.toLowerCase()) : ret;

        return(ret);
    }
    public String getAlias()        {return(alias);}
    public String getDescription()  {return(description);}
    public String getStoreNumber()  {return(storeNumber);}
}

/*
 * Created on Mar 17, 2006
 */
package com.unfi.cbk.forms;

import java.util.Arrays;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

/**
 * 
 * @author yhp6y2l
 * @version 1.0
 */
public class MapBackedActionForm {//extends ValidatorActionForm {

    private Map values = new HashMap();

    /**
     * @param key
     * @param value
     */
    public void setValue(String key, Object value) {
        values.put(key, value);
    }

    /**
     * @param key
     * @return
     */
    public Object getValue(String key) {
        return values.get(key);
    }
    
	/**
     * @return
     */
    public Map getMap() {
        return values;
    }
    
    /**
     * @param map
     */
    public void setMap(Map map) {
        values = map;      
    }

    public void putAll(Map map) {
        values.putAll(map);
    }
    
    public boolean containsKey(String key) {
        return values.containsKey(key);
    }

    public String getString(String key) {
        return  (String) values.get(key);
    }

    public Integer getInteger(String key) {
        return Integer.decode((String) values.get(key));
    }
    
    public boolean getBool(String key) {
        if ( ((String) values.get(key)).equals("0") ) {
            return false;
        }
        else if ( ((String) values.get(key)).equals("1") ) {
            return true;
        }
        else {
            throw new RuntimeException();
        }
    }
    
/*public void setFormParameterMap(HttpServletRequest request) {
		
		Map<String, Object> map = new HashMap<>();
		
		Enumeration<String> paramnames = request.getParameterNames();
		while(paramnames.hasMoreElements())
		{
			String param = paramnames.nextElement();
			String value = request.getParameter(param);
			
			Object objValue = map.get(param);
			if(objValue == null)
			{
				map.put(param, value);
			}
			else
			{
				String[] values_Arr= (String[])objValue;
				String[] new_values_Arr= Arrays.copyOf(values_Arr, values_Arr.length+1);
				new_values_Arr[ values_Arr.length+1] = (String)value;
				map.put(param, new_values_Arr);
			}
		}
		this.setMap(map);
		
	}*/
    public void setFormParameterMap(HttpServletRequest request) {

    	Map<String, Object> map =this.getMap();

    	Enumeration<String> paramnames = request.getParameterNames();
    	while(paramnames.hasMoreElements())
    	{
    	String param = paramnames.nextElement();
    	String value = request.getParameter(param);

    	Object objValue = map.get(param);
    	if(objValue == null)
    	{
    	map.put(param, value);
    	}
    	/*else
    	{

    	if(objValue.getClass().isArray())
    	{
    	Object[] objArr = (Object[]) objValue;

    	  List<Object> tempList= new ArrayList(Arrays.asList(objArr));
    	  tempList.add(value);
    	  map.put(param,tempList.toArray());
    	}


    	Object[] values_Arr= (Object[])objValue;
    	Object[] new_values_Arr= Arrays.copyOf(values_Arr, values_Arr.length+1);
    	new_values_Arr[ values_Arr.length+1] = (Object)value;

    	}*/
    	}
    	//this.setMap(map);

    	}

}

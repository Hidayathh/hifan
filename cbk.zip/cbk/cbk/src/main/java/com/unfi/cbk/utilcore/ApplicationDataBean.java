package com.unfi.cbk.utilcore;

import java.util.Properties;
import org.apache.log4j.Logger;

/**
 * 
 * @author yhp6y2l
 *
 */
public class ApplicationDataBean {
	static Logger log = Logger.getLogger(ApplicationDataBean.class);
	private Properties props;
	
	
	/**
	 * Add a new property to the bean.
	 * This method takes a property name and value and adds them to the bean.
	 * 
	 * @param name		the name of the property to be set
	 * @param value		the value of the property to be set
	 * @since			1.0
	 */
	public void addProperty(String name, String value) {
		if (this.props == null) {
			props = new Properties();
			
		}
		props.setProperty(name, value);
		log.debug("Adding Name: "+ name + " Value: "+ value + " to the properties.");
	}
	
	/**
	 * Get a property value from the bean.
	 * This method returns the <code>String</code> value of the specified property
	 * 
	 * @return			the value of the named proeprty as a <code>String</code>
	 * @param name		the name of the property to be retrieved
	 * @since			1.0
	 */
	public String getProperty(String name) {
		if (this.props == null) {
			return null;
			
		} else {
			return (String) this.props.getProperty(name);
			
		}
		
	}

}
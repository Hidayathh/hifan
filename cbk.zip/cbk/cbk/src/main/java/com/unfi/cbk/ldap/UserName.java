/*
 * UserName.java
 *
 * Created on March 16, 2001, 11:50 AM
 */
package com.unfi.cbk.ldap;

import java.util.Vector;

import com.unfi.cbk.ldaputil.CompareTo;
import com.unfi.cbk.ldaputil.Comparer;
import com.unfi.cbk.ldaputil.VectorFuncs;

/**
 * Class to hold User Name information.
 * @author: yhp6y2l
 */
public class UserName extends Object implements CompareTo
{
    private String loginID;
    private String firstName;
    private String middleInitial;
    private String lastName;
    private String fullName;

    public String getLoginID()          {return(loginID);}
    public String getFirstName()        {return(firstName);}
    public String getMiddleInitial()    {return(middleInitial);}
    public String getLastName()         {return(lastName);}
    public String getFullName()         {return(fullName);}

    /** Creates new UserName object */
    public UserName(String loginID,
                    String firstName,
                    String middleInitial,
                    String lastName,
                    String fullName)
    {
        super();
        
        this.loginID = loginID;
        this.fullName = fullName;
        
        this.firstName = firstName;
        this.middleInitial = middleInitial;
        this.lastName = lastName;
    }
    
    // Sorts by login id.
    public int compareTo(java.lang.Object obj) {
        int ret = loginID.toLowerCase().compareTo(((UserName)obj).loginID.toLowerCase());
        
        return(ret);
    }

    // Sorts by lastName + firstName + middleInitial.
    private static class LastFirstMiddleOrder implements Comparer
    {
        public int compare(java.lang.Object o1, java.lang.Object o2)
        {
            int ret;
            
            ret = ((UserName)o1).lastName.toLowerCase().compareTo(((UserName)o2).lastName.toLowerCase());
            ret = ret == 0 ? ((UserName)o1).firstName.toLowerCase().compareTo(((UserName)o2).firstName.toLowerCase()) : ret;
            ret = ret == 0 ? ((UserName)o1).middleInitial.toLowerCase().compareTo(((UserName)o2).middleInitial.toLowerCase()) : ret;
            return(ret);
        }
    }
    
    /**
     * Sorts the Vector of UserName objects into order by
     * lastName + firstName + middleInitial.
     */
    public static void sortByLastFirstMiddle(Vector vector)
    {
        VectorFuncs.sort(vector, new UserName.LastFirstMiddleOrder());
    }
}

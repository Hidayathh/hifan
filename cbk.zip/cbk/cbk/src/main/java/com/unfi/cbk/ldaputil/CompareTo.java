/*
 * CompareTo.java
 *
 * Created on April 18, 2001, 12:11 PM
 */
package com.unfi.cbk.ldaputil;


/**
 * Interface for comparing things.  Classes should implement
 * this interface if you want to compare instances of the classes
 * to one another.
 * @author: yhp6y2l
 */
public interface CompareTo 
{
    public int compareTo(java.lang.Object o);
}

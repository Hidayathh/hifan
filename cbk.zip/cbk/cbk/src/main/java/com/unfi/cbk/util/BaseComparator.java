/*
 * Created on Nov 8, 2005
 * 
 */
package com.unfi.cbk.util;

import java.util.Comparator;
import org.apache.commons.beanutils.PropertyUtils;

// see http://jakarta.apache.org for the latest version of the Jakarta Commons, including BeanUtils

public class BaseComparator implements Comparator {

	private String sortingField;
	private boolean sortAscending = true;

	public BaseComparator() {
		super();
	}
	
	public BaseComparator(String sortingField,boolean ascending){
		this.sortingField = sortingField;
		this.sortAscending = ascending;
	}

	public void setSortingField(String s) {
		sortingField = s;
	}

	public String getSortingField() {
		return sortingField;
	}

	public boolean isSortAscending() {
		return sortAscending;
	}

	public void setSortAscending(boolean sortAscending) {
		this.sortAscending = sortAscending;
	}

	public int compare(Object o1, Object o2) {
		int comp = 0;
				
		try{
			Object prop1 = PropertyUtils.getProperty(o1,sortingField);
			Object prop2 = PropertyUtils.getProperty(o2,sortingField);
			
			if (prop1 != null && prop2 != null){		
				if (prop1 instanceof Comparable && prop2 instanceof Comparable){
					Comparable c1 = (Comparable) prop1;
					Comparable c2 = (Comparable) prop2;
					comp = c1.compareTo(c2);
				}
				else{
					String value1 = prop1.toString();
					String value2 = prop2.toString();
					comp = value1.compareTo(value2);
				}
			}
			else if (prop1 == null){
				comp = -1;
			}
			else if (prop2 == null){
				comp = 1;
			}
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		// default is to sort ascending; if the sort is set to descending, reverse the return value
		if (!isSortAscending()) {
			comp = comp * -1;
		}
		return comp;
	}

}
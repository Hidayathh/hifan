package com.unfi.cbk.ldap;
import java.util.*;

import com.unfi.cbk.ldap.*;
import com.unfi.cbk.ldaputil.*;
public class TestAPI {
	protected String appName = "SupAdmin";
	SVHarborLDAPFuncs fun = null;
	long begTime=0, endTime=0;
	
	public static void main(String[] args) {
		TestAPI api = new TestAPI();
		api.init();
	//	api.checkVendorAccess();
	//	api.addUser();
	//	api.getVendorsOfBrokerUser();
	//	api.getAllUsers();
	//	api.getUsersOfAppRole();
		
	//	api.addUserToRole();	
	  		
	//	api.testVersion();
	//	api.testUserDetail();
	//	api.testPromotionRegions();
	//	api.testStoreList();
	//	api.testAppList();
	//	api.testStoreAppList();
	//	api.testAppRoleList();
		
	//	api.addVendorGroup();	
	//	api.testAddVendorToVendorGroup();
	//	api.testAddUserToVendorGroup();
	//	api.getVendorCreatedVendorGroups();
	//	api.testGetVendorsInVendorGroup();
	//	api.testDeleteVendorGroup();
	//	api.testGetUserList();
	//	api.testGetVendorGroupsForUser();
	//	api.getDistributionGroupsOfVendor();
	//	api.testGetVendorsOfVendorUser();
	//	api.addVendor();
	//	api.testAddBroker();
	//  api.testAddDistibutionGroup();
	//	api.testAddUserToDistributionGroup();
	//	api.testUserFromDistibutionGroup();
	//	api.testDeleteDistibutionGroup();
	//	api.testExistDistributionGroup();
	//	api.testGetVendorGroupsCreatedByUser();
	//	api.testGetDistributionGroups();
	//	api.testGetDistributionGroupDetails();
	//	api.testUpdateDistributionGroup();
	//	api.addVendorGroupToVendor();
	//	api.testDeleteVendorGroupFromVendor();
	//	api.getVendorGroupsOfVendor();
	//	api.getAppRolesOfUser();
	//	api.getUsersOfBroker();
	//	api.findBrokers();
	//	api.resetPassword();
	//	api.getVendorGroupDetail();
	
	//	api.getStoreListForUser();
		
	//	api.getDCsOfUser();
	//	api.getVendorsAuthorizedForVendorGroup();
		api.existVendor();
		api.destroy();
	
	}
	
	private void init()
	{
		try
		{
			fun = new SVHarborLDAPFuncs();
			
			fun.initialize(appName);
			System.out.println("Connected to LDAP");
			begTime = System.currentTimeMillis();
			System.out.println("Start Time : " + begTime);
				
		}catch (Exception e)
		{
			System.out.println("Unable to connect to LDAP");
		}		
		
	}	
	private void destroy()
	{
		try
		{
			fun.destroy();
			System.out.println("Connection closed");
			endTime = System.currentTimeMillis();
			System.out.println("End   Time :"  + endTime + " Time Taken : " + (endTime - begTime));
			
		}catch (Exception e)
		{
			System.out.println("Unable to destroy connection");
		}		
		
	}	


	private void testVersion()
	{
		try
		{
			System.out.println("Version Number " + fun.getVersionNumber());		
		}catch (Exception e)
		{
			System.out.println("Unable to connect to LDAP");
		}		
		
	}	
	
	private void testUserDetail()
	{
		try
		{
			UserDetail user = null;
			user = fun.getUserDetail("HHKJT0");
			
			System.out.println("User Detail :");
			System.out.println("Fname : " + user.getFirstName());
			System.out.println("Lname : " +user.getLastName());
			System.out.println("Login : " +user.getLoginID());
			System.out.println("Broker# : " +user.getBrokerNumber());
			System.out.println("Carrier : " +user.getCarrierID());
			System.out.println("e-mail  : " +user.getEmailAddress());
			System.out.println("e-mail type : " +user.getEmailType());
			System.out.println("Phone   : " +user.getPhoneNumber());
			System.out.println("Region  : " +user.getRegion());
			System.out.println("Store#  : " +user.getStoreNumber());
			System.out.println("Title   : " +user.getTitle());
			System.out.println("User Type: " +user.getUserType());
			System.out.println("Vendor#  : " +user.getVendorID());
		}catch (Exception e)
		{
			System.out.println("Unable to connect to LDAP");
		}		
		
	}	
	private void testPromotionRegions()
	{
		try
		{
			Vector v = null;
			v = fun.getPromoRegionsOfUser("JKUMAR");
		}catch (Exception e)
		{
			System.out.println("Unable to connect to LDAP");
		}		
		
	}	
	
	private void testStoreList()
	{
		try
		{
			Vector v = null;
			v = fun.getStoreListForUser("JKUMAR");
			System.out.println("Nbr of stores : " + v.size());
		}catch (Exception e)
		{
			System.out.println("Unable to connect to LDAP");
		}		
		
	}	
	private void testAppList()
	{
		String appName = "";
		try
		{
			Vector v = null;
			v = fun.getAppListForUser("HOJRK0");
			for (int i=0;i<v.size();++i)
			{
				appName = (String) v.get(i);
				System.out.println("App Name : " + appName);
			}	
		}catch (Exception e)
		{
			e.printStackTrace();
			
			System.out.println("Unable to connect to LDAP" + e.toString());
		}		
		
	}	
	
	private void testStoreAppList()
	{
		Application app = null;
		try
		{
			Vector v = null;
			v = fun.getAppListForStore("0155095");
			for (int i=0;i<v.size();++i)
			{
				app = (Application) v.get(i);
				System.out.println("App Name : " + app.getName());
			}	
		}catch (Exception e)
		{
			e.printStackTrace();
			
			System.out.println("Unable to connect to LDAP" + e.toString());
		}		
		
	}	

	private void testAppRoleList()
	{
		Application app = null;
		try
		{
			Vector v = null;
			v = fun.getUsersOfAppRole("eMerch","ReviewAndRevise");
			System.out.println("Nbr of users : " + v.size());
		}catch (Exception e)
		{
			e.printStackTrace();
			
			System.out.println("Unable to connect to LDAP" + e.toString());
		}		
		
	}	

	private void addVendorGroup()
	{
		try
		{
			fun.addVendorGroup("JOSH_3",CbkLdapConstants.SV_CREATED_VENDOR_GROUP,"HOJRK0");
			
			System.out.println("Group added successfully");		

		}catch (Exception e)
		{
			
			System.out.println("Add failed" + e.toString());
		}
	}	

	private void testAddVendorToVendorGroup()
	{
		try
		{
			Vendor vend = new Vendor();
			vend.setVendorID("0324905");
			fun.addVendorToVendorGroup(vend, "JOSH_3");
			System.out.println("Group added successfully");		

		}catch (Exception e)
		{
			System.out.println("Add failed");
		}
	}	

	private void testAddUserToVendorGroup()
	{
		try
		{
			Vendor vend = new Vendor();
			fun.addUserToVendorGroup("HOOJA0", "VendorGroup1");
			System.out.println("User added to Group successfully");		

		}catch (Exception e)
		{
			System.out.println("Add failed" + e.toString());
			e.printStackTrace();
		}
	}	

	private void getVendorCreatedVendorGroups()
	{
		try
		{
			Vector v = null;
			v = fun.getVendorCreatedVendorGroups();
			System.out.println("v.size() : " + v.size());
		}catch (Exception e)
		{
			System.out.println("Read failed - " + e.toString());
			e.printStackTrace();
		}							
	}	
	
	private void testGetVendorsInVendorGroup()
	{
		
		try
		{
			Vector v = fun.getVendorsOfBrokerUser("testbroker");
			System.out.println("Size : " + v.size());
		}catch (Exception e)
		{
			System.out.println("Read failed - " + e.toString());
			e.printStackTrace();
		}							
		
		
	} 
/*	
	private void testDeleteVendorGroup()
	{
		try
		{
			fun.deleteVendorGroup("Test Vendor # 1");
			System.out.println("Delete successful");
		}catch (Exception e)
		{
			System.out.println("Read failed - " + e.toString());
			e.printStackTrace();
		}							
	}		
*/	
	private void testGetUserList()
	{
		try
		{
			Vector v = null;
			v = fun.getUserList("JKUM*","kjosh");
		}catch (Exception e)
		{
			System.out.println("Read failed - " + e.toString());
			e.printStackTrace();
		}							
		
	}		
	
	private void testGetVendorGroupsForUser()
	{
		try
		{
			Vector v = null;
			v = fun.getVendorGroupsForUser("HOJRK0");
			
			VendorGroup group = null;
			for (int i=0;i<v.size();++i)
			{
				group = (VendorGroup) v.get(i);
				System.out.println("Name : " + group.getGroupName() + "Type : " + group.getGroupType() + "Owner : " + group.getOwner());
			}	
		}catch (Exception e)
		{
			System.out.println("Read failed - " + e.toString());
			e.printStackTrace();
		}							
	}	

	private void getVendorsOfBrokerUser()
	{
		try 
		{
			Vector v = null;
			//v = fun.getVendorsOfBrokerUser("testamy");
			v = fun.getVendorsOfVendorUser("HOJRK0_vendor");
			Vendor vendor = null;
			for (int i=0;i<v.size();++i)
			{
				vendor = (Vendor) v.get(i);
				System.out.println("Nbr : " + vendor.getId() + " Name : " + vendor.getName() );
			}	
		}catch (Exception e)
		{
			System.out.println("Read failed - " + e.toString());
			e.printStackTrace();
		}							
		
	}		
	private void testGetVendorsOfVendorUser()
	{
		try 
		{
			Vector v = null;
			v = fun.getVendorsOfVendorUser("hojrk0_vendor");
			
			Vendor vendor = null;
			for (int i=0;i<v.size();++i)
			{
				vendor = (Vendor) v.get(i);
				System.out.println("Nbr : " + vendor.getId() + " Name : " + vendor.getName() );
			}	
		}catch (Exception e)
		{
			System.out.println("Read failed - " + e.toString());
			e.printStackTrace();
		}							
		
	}		
	
	private void addVendor()
	{
		
/*
0158055
0158584
0159798
0163758
0166157
0167627
0170001
0174540
0176008
0177725
0188870
*/		
		try
		{
			String s = fun.addVendor("016615700"
						    ,"My Vendor"
						    ,"123 address"
						    ,"Eden Prairie"
						    ,"MN"
						    ,"55379"
						    ,"1234567890"
						    ,"1234567890"
						    ,"email"
						    ,"contact"
						    ,null
						    ,"VendorUserAdmin"
						    ,CbkLdapConstants.EA_EXTENDED_VENDOR
						    );
		}catch (Exception e)
		{
			System.out.println("Add failed - " + e.toString());
			e.printStackTrace();
		}							
						    
		
	}	

	private void testAddBroker()
	{
		
		try
		{
			String s = fun.addBroker("112115"
						    ,"My Vendor"
						    ,"123 address"
						    ,"Eden Prairie"
						    ,"MN"
						    ,"55379"
						    ,"1234567890"
						    ,"1234567890"
						    ,"email"
						    ,"contact"
						    ,null
						    ,"BrokerUserAdmin"
						    );
		}catch (Exception e)
		{
			System.out.println("Add failed - " + e.toString());
			e.printStackTrace();
		}							
	}	
	
	private void testAddDistibutionGroup()
	{
		try
		{
			fun.addDistributionGroup("014","Fargo");
		}catch (Exception e)
		{
			System.out.println("Add failed - " + e.toString());
			e.printStackTrace();
		}							
		
	}	
	
	private void testDeleteDistibutionGroup()
	{
		try
		{
			fun.deleteDistibutionGroup("014");
		}catch (Exception e)
		{
			System.out.println("Delete failed - " + e.toString());
			e.printStackTrace();
		}							
		
	}	

	private void testUserFromDistibutionGroup()
	{
		try 
		{
			fun.deleteUserFromDistributionGroup("JKUMAR","014");
		}catch (Exception e)
		{
			System.out.println("Delete failed - " + e.toString());
			e.printStackTrace();
		}							
		
	}	

	private void testAddUserToDistributionGroup()
	{
		try
		{
			fun.addUserToDistributionGroup("HOJRK0","014");
		}catch (Exception e)
		{
			System.out.println("Add failed - " + e.toString());
			e.printStackTrace();
		}							

		try
		{
			fun.addUserToDistributionGroup("JKUMAR","014");
		}catch (Exception e)
		{
			System.out.println("Add failed - " + e.toString());
			e.printStackTrace();
		}		
	}	
	
	private void testExistDistributionGroup()
	{
		
		try
		{
			if  (fun.existDistributionGroup("015sdf"))
			{
				System.out.println("group exists");
			}
		}catch (Exception e)
		{
			System.out.println("failed - " + e.toString());
			e.printStackTrace();
		}		
			
			
	}	

	private void testGetVendorGroupsCreatedByUser()
	{
		try
		{
			Vector v = null;
			//v = fun.getVendorGroupsForUser("HOJRK0");
//			v = fun.getVendorGroupsCreatedByUser(SVHarborConstants.SV_CREATED_VENDOR_GROUP,"HODAO0","");
			
			VendorGroup group = null;
			for (int i=0;i<v.size();++i)
			{
				group = (VendorGroup) v.get(i);
				System.out.println("Name : " + group.getGroupName() + "  Type : " + group.getGroupType() + "  Owner : " + group.getOwner());
			}	
		}catch (Exception e)
		{
			System.out.println("failed - " + e.toString());
			e.printStackTrace();
		}		
	}		

	private void getDistributionGroupsOfVendor()
	{
		try
		{
			Vector v = null;
			v = fun.getDistributionGroupsOfVendor("5688536");
			
			DistributionGroup group = null;
			for (int i=0;i<v.size();++i)
			{
				group = (DistributionGroup) v.get(i);
				System.out.println("cn : " + group.getNumber() + "  description : " + group.getDescription());
			}	
		}catch (Exception e)
		{
			System.out.println("failed - " + e.toString());
			e.printStackTrace();
		}		
	}		

	private void testGetDistributionGroupDetails()
	{
		try
		{
			DistributionGroup group = null;
			group = fun.getDistributionGroupDetails("015");
			System.out.println("cn : " + group.getNumber() + "  description : " + group.getDescription());
		}catch (Exception e)
		{
			System.out.println("failed - " + e.toString());
			e.printStackTrace();
		}		
		
	}		
	
	private void testUpdateDistributionGroup()
	{
		try
		{
			fun.updateDistributionGroup("015","MSP");
		}catch (Exception e)
		{
			System.out.println("failed - " + e.toString());
			e.printStackTrace();
		}		
	}	
	
	private void addVendorGroupToVendor()
	{
		try
		{
			//fun.addVendorGroupToVendor("JOSH_3","0462275");
			fun.addVendorGroupToBroker("JOSH_1","5555555");
			fun.addVendorGroupToBroker("JOSH_2","5555555");
			fun.addVendorGroupToBroker("JOSH_3","5555555");
			
		}catch (Exception e)
		{
			System.out.println("failed - " + e.toString());
			e.printStackTrace();
		}		
	}	
	
	private void testDeleteVendorGroupFromVendor()
	{
		try
		{
			fun.deleteVendorGroupFromVendor("Josh1","0462275");
		}catch (Exception e)
		{
			System.out.println("failed - " + e.toString());
			e.printStackTrace();
		}		
	}	
	

	
	private void getVendorGroupsOfVendor()
	{
		try
		{
			Vector v = null;
			v = fun.getVendorGroupsOfBroker("5555555");
			VendorGroup group = null;
			for (int i=0;i<v.size();++i)
			{
				group = (VendorGroup) v.get(i);
				System.out.println("Name : " + group.getGroupName() + " Type : " + group.getGroupType() + " Owner : " + group.getOwner());
			}	
		}catch (Exception e)
		{
			System.out.println("Read failed - " + e.toString());
			e.printStackTrace();
		}							
	}	

	private void addUserToRole()
	{
		try
		{
			fun.addUserToRole("hotmh0","eMerchandisingHO","houserreviewrevise");
		}catch (Exception e)
		{
			System.out.println("Read failed - " + e.toString());
			e.printStackTrace();
		}							
		
		
	}	
	private void getAppRolesOfUser()
	{
		try
		{
			Vector v = null;
			v = fun.getAppRolesOfUser("vendoradmin0000027","SupplierUserAdmin");
			ApplicationRole group = null;
			for (int i=0;i<v.size();++i)
			{
				group = (ApplicationRole) v.get(i);
				System.out.println("role : " + group.getName() + " description : " + group.getDescription());
			}	
		}catch (Exception e)
		{
			System.out.println("Read failed - " + e.toString());
			e.printStackTrace();
		}							
	}	
	
	private void getUsersOfBroker()
	{
		try
		{
			Vector v = null;
			v = fun.getUsersOfBroker("0000012");
			UserName group = null;
			for (int i=0;i<v.size();++i)
			{
				group = (UserName) v.get(i);
				System.out.println("id : " + group.getLoginID() + "  name : " + group.getFullName());
			}	
		}catch (Exception e)
		{
			System.out.println("Read failed - " + e.toString());
			e.printStackTrace();
		}							
	}	
	private void getUsersOfAppRole()
	{
		try
		{
			Vector v = null;
			v = fun.getUsersOfAppRole("SupplierUserAdmin","Administrator","hojrk0",null);	
			UserName group = null;
			for (int i=0;i<v.size();++i)
			{
				group = (UserName) v.get(i);
				System.out.println("id : " + group.getLoginID() + "  name : " + group.getFullName());
			}	
		}catch (Exception e)
		{
			System.out.println("Read failed - " + e.toString());
			e.printStackTrace();
		}							
	}	

	
	private void getAllUsers()
	{
		try
		{
			Vector v = null;
			v = fun.getAllUsers();
		}catch (Exception e)
		{
			System.out.println("Read failed - " + e.toString());
			e.printStackTrace();
		}							
	}	

	private void findBrokers()
	{
		try
		{
			Vector v = fun.findBrokers("","","","");
			System.out.println("broker size " + v.size());
		}catch (Exception e)
		{
			System.out.println("Read failed - " + e.toString());
			e.printStackTrace();
		}							
	}	
	private void resetPassword()
	{
		String userId = "hxuxs0-2";
		String password = "";
		try
		{
			password = fun.resetPassword(userId);
			System.out.println(userId + "'s new password is : " + password);
		}catch (Exception e)
		{
			System.out.println("Read failed - " + e.toString());
			e.printStackTrace();
		}
	}								
	private void getVendorGroupDetail()
	{
		VendorGroup group = null;
		try
		{
			group = fun.getVendorGroupDetail("derektestasdf");
			System.out.println("group name : " + group.getGroupName() + " type:" + group.getGroupType() + " owner:" + group.getOwner());
		}catch (Exception e)
		{
			System.out.println("Read failed - " + e.toString());
			e.printStackTrace();
		}
	}								
	
	private void getStoreListForUser()
	{
		try
		{
			Vector v = fun.getStoreNumberListForUser("ebybrown");
			for (int i=0;i<v.size();++i)
			{
				String store = (String)v.get(i);
				System.out.println("StoreNbr : " + store);
			}	
		}catch (Exception e)
		{
			System.out.println("Read failed - " + e.toString());
			e.printStackTrace();
		}

	}	

	private void addUser()
	{
		try
		{
		
			String password = fun.addUser("hxuxs0-2"
										,"0155095"
										,"Umesh"
										,"Sachdev"
										,"x"
										,"Contractor"
										,"952-111-1111"
										,"umesh.sachdev@supervalu.com"
										);
			/*
			String password = fun.addAdminUser("hxuxs0-1"
									    ,"Northern Region"
									 	,"Umesh"
										,"Sachdev"
										,"x"
										,"Contractor"
										,"952-111-1111");
			*/
			System.out.println("Password : " + password);							
		}catch (Exception e)
		{
			System.out.println("Add user failed - " + e.toString());
			e.printStackTrace();
		}
	}		
	private void getDCsOfUser()
	{
		try
		{
			Vector v = fun.getDCsOfUser("opske0");
			for (int i=0;i<v.size();++i)
			{
				DCGroup dc = (DCGroup)v.get(i);
				System.out.println(dc.getDCNumber() + "-" + dc.getName() + "-" +dc.getType() + "-" + dc.getGroupID());
			}	
		}catch (Exception e)
		{
			System.out.println("Read failed - " + e.toString());
			e.printStackTrace();
		}

	}	

	private void checkVendorAccess()
	{
		try
		{
			if  (fun.checkVendorAccess("BrokerAdmin2468101","0158055"))	
				System.out.println("Access true");
			else
				System.out.println("Access false");
				
		}catch (Exception e)
		{
			System.out.println("Read failed - " + e.toString());
			e.printStackTrace();
		}

	}	

	private void getVendorsAuthorizedForVendorGroup()
	{
/*		try
		{
			Vector v = fun.getVendorsAuthorizedForVendorGroup("JOSH VENDOR GROUP");
			for (int i=0;i<v.size();++i)
			{
				Vendor vendor = (Vendor)v.get(i);
				System.out.println(vendor.getVendorID() + " " + vendor.getVendorName() + " " + vendor.getVendorType());
			}	
		}catch (Exception e)
		{
			System.out.println("Read failed - " + e.toString());
			e.printStackTrace();
		}
		
		try
		{
			Vector v = fun.getBrokersAuthorizedForVendorGroup("JOSH VENDOR GROUP");
			for (int i=0;i<v.size();++i)
			{
				Broker broker = (Broker)v.get(i);
				System.out.println(broker.getBrokerID() + " " + broker.getBrokerName());
			}	
		}catch (Exception e)
		{
			System.out.println("Read failed - " + e.toString());
			e.printStackTrace();
		}
*/
		try
		{
			Vector v = fun.getVendorGroupsContainingVendor("0324905");
			for (int i=0;i<v.size();++i)
			{
				String  s = (String)v.get(i);
				System.out.println("Vendor Group : " + s);
			}	
		}catch (Exception e)
		{
			System.out.println("Read failed - " + e.toString());
			e.printStackTrace();
		}
		
		
	}		
	
	private void existVendor()
	{
		try
		{
			if  (fun.existVendor("0324905"))
			{
				System.out.println("Vendor exists");
			}else
			{
				System.out.println("Vendor doesn't exist");
			}
		}catch (Exception e)
		{
			System.out.println("Read failed - " + e.toString());
			e.printStackTrace();
		}
				
	}	
}


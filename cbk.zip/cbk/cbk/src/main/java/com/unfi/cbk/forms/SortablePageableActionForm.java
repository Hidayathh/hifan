/*
 * Created on Nov 30, 2006
 */
package com.unfi.cbk.forms;


import com.unfi.cbk.common.util.ui.Pageable;
import com.unfi.cbk.common.util.ui.Sortable;

/**
 * @author yhp6y2l
 * @version 1.0
 */
public class SortablePageableActionForm extends MapBackedActionForm implements Pageable, Sortable {

    private int currentRecord = 1;
    private int displayCount;
    private int totalRecords;
    private String sortBy;
    private String sortOrder="asc";
    
    

    private String vcrAction = null;
    private boolean showAll = false;    


    /* (non-Javadoc)
     * @see com.svharbor.ui.Pageable#isShowAll()
     */
    public boolean isShowAll() {
        return showAll;
    }
    
    /**
     * @deprecated use isShowAll() instead
     */
    public String getShowAll() {
        return Boolean.toString(showAll);
    }

    /* (non-Javadoc)
     * @see com.svharbor.ui.Pageable#getVcrAction()
     */
    public String getVcrAction() {
        return vcrAction;
    }

    /* (non-Javadoc)
     * @see com.svharbor.ui.Pageable#getVcrStart()
     */
    public String getVcrStart() {
        return String.valueOf(currentRecord);
    }

    /* (non-Javadoc)
     * @see com.svharbor.ui.Pageable#setVcrAction(java.lang.String)
     */
    public void setVcrAction(String string) {
        vcrAction = string;
    }

    /* (non-Javadoc)
     * @see com.svharbor.ui.Pageable#setVcrStart(java.lang.String)
     */
    public void setVcrStart(String string) {
        currentRecord = Integer.parseInt(string);
    }

    /**
     * @param b
     */
    public void setShowAll(boolean b) {
        showAll = b;
    }

    /* (non-Javadoc)
     * @see com.svharbor.ui.Sortable#getSortBy()
     */
    public String getSortBy() {
       // return this.getString("sortBy");
    	return this.sortBy;
    }

    /* (non-Javadoc)
     * @see com.svharbor.ui.Sortable#getSortOrder()
     */
    public String getSortOrder() {
      //  return this.getString("sortOrder");
        return this.sortOrder;
    }

    /* (non-Javadoc)
     * @see com.svharbor.ui.Sortable#setSortBy(java.lang.String)
     */
    public void setSortBy(String string) {
        this.setValue("sortBy", string);
    	this.sortBy = string;
    }

    /* (non-Javadoc)
     * @see com.svharbor.ui.Sortable#setSortOrder(java.lang.String)
     */
    public void setSortOrder(String string) {
        this.setValue("sortOrder", string);
    	this.sortOrder = string;
    }



    /**
     * @return
     */
    public int getCurrentRecord() {
        return currentRecord;
    }

    /**
     * @return
     */
    public int getDisplayCount() {
        return displayCount;
    }

    /**
     * @return
     */
    public int getTotalRecords() {
        return totalRecords;
    }

    /**
     * @param i
     */
    public void setCurrentRecord(int i) {
        currentRecord = i;
    }

    /**
     * @param i
     */
    public void setDisplayCount(int i) {
        displayCount = i;
    }

    /**
     * @param i
     */
    public void setTotalRecords(int i) {
        totalRecords = i;
    }

	@Override
	public String getSortName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setSortName(String name) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public String getSortDirection() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setSortDirection(String direction) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public String getPreviousSortName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setPreviousSortName(String name) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public String getPreviousSortDirection() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setPreviousSortDirection(String name) {
		// TODO Auto-generated method stub
		
	}

}

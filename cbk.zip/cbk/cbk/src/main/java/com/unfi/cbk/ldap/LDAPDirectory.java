//package LDAPDirectory;
/*
 * LDAPDirectory.java
 *
 * Created on February 23, 2001, 2:07 PM
 */

package com.unfi.cbk.ldap;

import java.util.*;
import javax.naming.*;
import javax.naming.directory.*;

/**
 * Class to provide access to an LDAP directory.
 *
 * @author  Howmr0
 * @version .01
 */
public class LDAPDirectory extends java.lang.Object 
{
	private DirContext  theContext = null;
	private NameParser  nameParser = null;
	private String      host = null;
	private int         port;
	private int         ldapVersion;
	private int         limit = 0;
	private int         timeout = 0;
    
	/** Creates new LDAPDirectory */
	public LDAPDirectory() {
		super();
	}
    
	/**
	 * Creates a BasicAttribute object with the attribute name
	 * and array of values.
	 * Parameters:
	 *      name = Attribute name.
	 *      values = Array of values for the named attribute.
	 */
	private BasicAttribute convertValues(String name, Object[] values)
	{
		BasicAttribute att = new BasicAttribute(name);
        
		for (int i = 0; i < values.length; i++) {
			att.add(values[i]);
		}

		return(att);
	}

	/**
	 * Converts a hashtable of attribute names and values into
	 * a BasicAttributes object.
	 */
	private BasicAttributes convertHashtable(Hashtable hTable)
	{
		BasicAttributes atts = new BasicAttributes();
		Enumeration     e = hTable.keys();
        
		while(e.hasMoreElements()) {
			String key = (String) e.nextElement();
			Object [] values = (Object[]) hTable.get(key);
			BasicAttribute at = convertValues(key, values);
			atts.put(at);
		}

		return(atts);
	}

	/**
	 * Connect to the LDAP directory.
	 */
	public void connect(String host,
						int port,
						int ldapVersion,
						String userName,
						String password)
			throws Exception
	{
		this.host = host;
		this.port = port;
		this.ldapVersion = ldapVersion;
        
		try {
			Hashtable env = new Hashtable(11);
			env.put("java.naming.ldap.version", String.valueOf(ldapVersion));
			env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
			env.put(Context.PROVIDER_URL, "ldap://" + host + ":" + port);

			env.put(Context.SECURITY_AUTHENTICATION, "simple");
			env.put(Context.SECURITY_PRINCIPAL, userName);
			env.put(Context.SECURITY_CREDENTIALS, password);

			// Create the initial directory context
			theContext = new InitialDirContext(env);
		}
		catch (NamingException e) {
			String tMsg = "Unable to connect to LDAP server.";
			throw new Exception(tMsg);
		}
	}

	/**
	 * Disconnect from the LDAP directory.
	 */
	public void disconnect()
			throws Exception
	{
		if (theContext != null) {
			try {
				// Close the context when we're done
				theContext.close();
				theContext = null;
			}
			catch  (NamingException e) {
				String tMsg = "Unable while disconnecting from LDAP server.";
				throw new Exception(tMsg);
			}
		}
	}

	// Authenticate the user.
	public boolean isValidPassword(String userName,
								   String password)
			throws Exception
	{
		// An empty password will always authenticate, so don't allow it.
		if (password.length() == 0) {
			return(false);
		}
        
		DirContext	tContext = null;
		boolean	rc = false;
        
		Hashtable env = new Hashtable(11);
		env.put("java.naming.ldap.version", String.valueOf(ldapVersion));
		env.put(DirContext.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
		env.put(DirContext.PROVIDER_URL, "ldap://" + host + ":" + port);
        
		env.put(DirContext.SECURITY_AUTHENTICATION, "simple");
		env.put(DirContext.SECURITY_PRINCIPAL, userName);
		env.put(DirContext.SECURITY_CREDENTIALS, password);

		try {
			// Create the initial directory context
			tContext = new InitialDirContext(env);
			tContext = null;
			rc = true;
		}
		catch (AuthenticationException e) {
			// Do nothing.
		}
		catch (NamingException e) {
			String tMsg = "Unable to authenticate user in LDAP.";
			throw new Exception(tMsg);
		}

		return(rc);
	}

	/**
	 * Converts the dn from a String object to a Name object.
	 */
	public Name convertToName(String dn)
			throws Exception
	{
		Name ret;

		try {
			// Get the parser for the namespace
			if (nameParser == null) {
				nameParser = theContext.getNameParser("");
			}

			ret = nameParser.parse(dn);
		}
		catch(NamingException e){
			String tMsg = e.toString();
			throw new Exception(tMsg);
		}    

		return(ret);
	}
    
	/**
	 * Check if the specified object exists.
	 * Returns:
	 *      true - If the object exists.
	 *      false - If the object doesn't exist.
	 */
	public boolean existObject(String dn)
			throws Exception
	{
		boolean rc = false;

		try {
			theContext.getAttributes(dn, new String[] {});
			rc = true;
		}
		catch(NameNotFoundException e) {
			// Do nothing.
		}    
		catch(NamingException e){
			String tMsg = "Unable to check for object in LDAP.  Error: " + e.toString();
			throw new Exception(tMsg);
		}    

		return(rc);
	}

	/**
	 * Check if the specified attribute exists in the specified object.
	 * Returns:
	 *      true - if the attribute exists with the specified value.
	 *      false - if the object doesn't exist, or the attribute
	 *              doesn't exist, or the attribute exists but doesn't
	 *              have the specified value.
	 *
	 */
	public boolean existAttributeInObject(String dn,
										  String attribName,
										  String attribValue)
			throws Exception
	{
		Name        tDNName;
		String      tObjectName;
		String      tObjectPath = "";
		boolean     rc = false;

		try {
			// Break the DN down into object name and object path.
			tDNName = convertToName(dn);
			tObjectName = tDNName.get(tDNName.size() - 1);
			for (int x = tDNName.size() - 2; x >= 0; x--) {
				if (tObjectPath.length() > 0) {
					tObjectPath = tObjectPath + ",";
				}
				tObjectPath = tObjectPath + tDNName.get(x);
			}
		}
		catch (Exception e) {
			return(false);
		}

		NamingEnumeration results = null;

		// See if the object has the specified attribute and value.
		try {
			final String filter = "(&(" + tObjectName + ")(" + attribName + "=" + attribValue + "))";
			results = search(tObjectPath, filter, new String[] {}, SearchControls.ONELEVEL_SCOPE);

			if (results != null && results.hasMoreElements()) {
				rc = true;
			}
		}
		catch(NameNotFoundException e) {
			// Do nothing.
		}    
		catch (NamingException e) {
			String tMsg = "LDAP search failed.  Error: " + e.toString();
			throw new Exception(tMsg);
		}
		finally {
			if (results != null) {
				try {
					results.close();
				}
				catch (Exception ignore) {
				}
			}
		}

		return rc;
	}
    
	/**
	 * Adds an object with the specified dn, and attributes.
	 */
	public void addObject(String dn,
						  Hashtable attribs)
			throws Exception
	{
		try { 
			Attributes ats = convertHashtable(attribs);
			theContext.createSubcontext(dn, ats);
		} 
		catch (NameAlreadyBoundException e) {
			String tMsg = "Unable to add object \"" + dn + "\" to LDAP.  Error: Object already exists.";
			throw new Exception(tMsg);
		}
		catch (NamingException e) {
			String tMsg = "Unable to add object \"" + dn + "\" to LDAP.  Error: " + e.toString();
			throw new Exception(tMsg);
		}
	}

	/**
	 * Updates the specified object with the specified attributes.
	 * Existing attributes with the same name in the object are
	 * overwritten.
	 */
	public void updateObject(String dn,
							 Hashtable attribs)
			throws Exception
	{
		try {
			Attributes ats = convertHashtable(attribs);

			theContext.modifyAttributes(dn, DirContext.REPLACE_ATTRIBUTE, ats);
		}
		catch (AttributeModificationException e) {
			String tMsg = "Unable to complete the update of object \"" + dn + "\" in LDAP.  Some changes may not have been saved.";
			throw new Exception(tMsg);
		}
		catch (NamingException e) {
			String tMsg = "Unable to update object \"" + dn + "\" in LDAP.  Error: " + e.toString();
			throw new Exception(tMsg);
		}
	}

	/**
	 * Deletes the specified object.
	 * This method succeeds even if the terminal atomic name is not
	 * bound in the target context, but throws an Exception if any of the
	 * intermediate contexts do not exist.
	 */
	public void deleteObject(String dn)
			throws Exception
	{
		try { 
			theContext.destroySubcontext(dn);
		} 
		catch (NamingException e) {
			String tMsg = "Unable to delete object \"" + dn + "\" from LDAP.  Error: " + e.toString();
			throw new Exception(tMsg);
		}
	}  

	/**
	 * Binds a new name to the object bound to an old name, and 
	 * unbinds the old name. Any attributes associated with the 
	 * old name become associated with the new name.  Intermediate
	 * contexts of the old name are not changed.
	 */
	public void renameObject(String oldDN,
							 String newDN)
			throws Exception
	{
		try {
			theContext.rename(oldDN, newDN);
		}
		catch (NameAlreadyBoundException e) {
			String tMsg = "Unable to rename object \"" + oldDN + "\" to \"" + newDN + "\" in LDAP.  An object with the new name already exists.  Error: " + e.toString();
			throw new Exception(tMsg);
		}
		catch (NamingException e) {
			String tMsg = "Unable to rename object \"" + oldDN + "\" to \"" + newDN + "\" in LDAP.  Error: " + e.toString();
			throw new Exception(tMsg);
		}
	}    

	private void modifyObject(String dn,
							  int mod_type,
							  String attr,
							  Object[] values) 
		throws Exception
	{
		ModificationItem[]  mods = new ModificationItem[1];
		BasicAttribute      mod1;
        
		if (values == null) {
			mod1 = new BasicAttribute(attr);
		}
		else {
			mod1 = convertValues(attr, values);
		}
        
		mods[0] = new ModificationItem(mod_type, mod1);

		theContext.modifyAttributes(dn, mods);
	}

	/**
	 * Adds the specified attribute to the object.
	 */
	public void addAttribute(String dn,
							 String attr,
							 Object[] values)
			throws Exception
	{
		try {
			modifyObject(dn, DirContext.ADD_ATTRIBUTE, attr, values);
		}
		catch( NamingException e ) {      
			String tMsg = "Unable to add \"" + attr + "\" attribute for " + dn + " in LDAP.  Error: " + e.toString();
			throw new Exception(tMsg);
		}
	}

	/**
	 * Updates the specified attribute in the object.
	 * NOTE... If you are updating an attribute that has multiple
	 *         values and you don't supply the extra values along
	 *         with your replacement value, the other values will
	 *         be removed.
	 */
	public void updateAttribute(String dn,
								String attr,
								Object[] values) 
			throws Exception
	{
		try {
			modifyObject(dn, DirContext.REPLACE_ATTRIBUTE, attr, values);
		}
		catch( NamingException e ) {      
			String tMsg = "Unable to update \"" + attr + "\" attribute for " + dn + " in LDAP.  Error: " + e.toString();
			throw new Exception(tMsg);
		}
	}

	/**
	 * Deletes the specified attribute from the object.
	 */
	public void deleteAttribute(String dn,
								String attr,
								Object[] values)
			throws Exception
	{
		try {
			modifyObject(dn, DirContext.REMOVE_ATTRIBUTE, attr, values);
		}
		catch( NamingException e ) {      
			String tMsg = "Unable to delete \"" + attr + "\" attribute for " + dn + " in LDAP.  Error: " + e.toString();
			throw new Exception(tMsg);
		}
	}

	private NamingEnumeration search(String dn,
									 String filter,
									 String[] attribs,
									 int type) 
		throws NamingException
	{
		// Specify search constraints to search subtree.
		SearchControls constraints = new SearchControls();

		constraints.setSearchScope(type);	 
		constraints.setCountLimit(limit);
		constraints.setTimeLimit(timeout);
		constraints.setReturningAttributes(attribs);

		NamingEnumeration results = theContext.search(dn, filter, constraints);	
		return(results);
	}

	/**
	 * Searches for objects that meet the filter criteria.  Returns
	 * the names of any objects that meet the criteria.
	 * Parameters:
	 *      dn = Starting point of the search.
	 * Returns:
	 *      Vector - A Vector containing a the name of each object found.
	 *      null - If no objects were found that match the filter.
	 */
	public Vector search(String dn,
						 String filter,
						 boolean one_level)
			throws Exception
	{
		NamingEnumeration results = null;
		Vector tmp = new Vector();

		try {
			final int scope = one_level ? SearchControls.ONELEVEL_SCOPE : SearchControls.SUBTREE_SCOPE;

			results = search(dn, filter, new String[] {}, scope);

			// Process each entry that was found.
			while (results != null && results.hasMoreElements()) {
				SearchResult    srchResult = (SearchResult) results.next();			
				String          name = srchResult.getName().trim(); 

				if (name.length() == 0) {
					tmp.addElement(dn);
				}
				else {
					tmp.addElement(name + "," + dn);
				}
			}
		}
		catch(NameNotFoundException e) {
			// Do nothing.
		}    
		catch (NamingException e) {
			String tMsg = "LDAP search failed.  Error: " + e.toString();
			throw new Exception(tMsg);
		}
		finally {
			if (results != null) {
				try {
					results.close();
				}
				catch (Exception ignore) {
				}
			}
		}
        
		return(tmp.isEmpty() ? null : tmp);
	}

	/**
	 * Searches for objects that meet the filter criteria.  Returns
	 * the names of any objects that meet the criteria and the specified
	 * attributes.
	 * Parameters:
	 *      dn = Starting point of the search.
	 *      attribs = Array of attributes that should be returned or 
	 *                null to return all attributes.
	 * Returns:
	 *      Vector of vectors.  Each vector in the vector has two elements.
	 *      The first element is a String that contains the DN of the object
	 *      that was found.  The second element is a Hashtable of the attributes
	 *      from the object.  The attribute names are forced to lower-case to make
	 *      it easier to retrieve them from the hash table.  The HashTable.Get()
	 *      function is case-sensitive.
	 *      null - If no objects were found that match the filter.
	 */
	public Vector search(String dn,
						 String filter,
						 String[] attribs,
						 boolean one_level)
			throws Exception
	{
		NamingEnumeration results = null;
		NamingEnumeration ae = null;
		Vector retVect = new Vector();

		try {
			final int scope = one_level ? SearchControls.ONELEVEL_SCOPE : SearchControls.SUBTREE_SCOPE;

			results = search(dn, filter, attribs, scope);

			while (results != null && results.hasMoreElements()) {
				String          attrID = null;
				Hashtable       hTable = new Hashtable();
				Vector          tVect = new Vector();
				SearchResult    srchResult = (SearchResult) results.next();
				String          name = srchResult.getName().trim(); 

				if (name.length() == 0) {
					tVect.addElement(dn);
				}
				else {
					tVect.addElement(name + "," + dn);
				}

				BasicAttributes attrs = (BasicAttributes) srchResult.getAttributes();

				for (ae = attrs.getAll(); ae.hasMoreElements();) {
					BasicAttribute attr = (BasicAttribute) ae.next();

					attrID = attr.getID().toLowerCase();

					Object[] valuesA = new Object [attr.size()];

					int i = 0;
					Enumeration vals = attr.getAll();
					while(vals.hasMoreElements()) {
						Object tmp = vals.nextElement();	    

						valuesA[i] = tmp;
						i++;
					}
					hTable.put(attrID, valuesA);
				}

				try {
					ae.close();
				}
				catch (Exception ignore) {
				}
				ae = null;

				tVect.addElement(hTable);
				retVect.addElement(tVect);
			}
		}
		catch(NameNotFoundException e) {
			// Do nothing.
		}    
		catch (NamingException e) {
			String tMsg = "LDAP search failed.  Error: " + e.toString();
			throw new Exception(tMsg);
		}
		finally {
			if (ae != null) {
				try {
					ae.close();
				}
				catch (Exception ignore) {
				}
			}
			if (results != null) {
				try {
					results.close();
				}
				catch (Exception ignore) {
				}
			}
		}
        
		return(retVect.isEmpty() ? null : retVect);
	}

	/**
	 * Reads the specified attribute(s) from the specified object.
	 * Parameters:
	 *      dn = Distinguished name of the object.
	 *      attribs = Array of attributes that should be returned or null to
	 *                return all attributes.
	 * Returns:
	 *      Hashtable - The attributes in a hashtable if they exist.  The
	 *                  attribute names are forced to lower-case to make
	 *                  it easier to retrieve them from the hash table.  The
	 *                  HashTable.Get() function is case-sensitive.
	 *      null - If the specified attributes don't exist in the
	 *             object or if the object doesn't exist.
	 */
	public Hashtable read(String dn,
						  String[] attribs)
			throws Exception
	{
		NamingEnumeration results = null;
		NamingEnumeration ae = null;
		Object      tmp = null;
		Hashtable   hTable = new Hashtable();
		int         i;

		try {
			String attrID = null;

			// Used to use getAttributes for this, but found that search() is much faster.
			results = search(dn, "(objectclass=*)", attribs, SearchControls.OBJECT_SCOPE);

			if (results != null && results.hasMoreElements()) {
				SearchResult    srchResult = (SearchResult) results.next();
				BasicAttributes attrs = (BasicAttributes) srchResult.getAttributes();

				for (ae = attrs.getAll(); ae.hasMoreElements();) {
					BasicAttribute attr = (BasicAttribute) ae.next();

					attrID = attr.getID().toLowerCase();

					Object[] valuesA = new Object [attr.size()];

					i = 0;
					Enumeration vals = attr.getAll();
					while(vals.hasMoreElements()) {
						tmp = vals.nextElement();	    

						valuesA[i] = tmp;
						i++;
					}
					hTable.put(attrID, valuesA);
				}
			}
		}
		catch(NameNotFoundException e) {
			// Do nothing.
		}    
		catch(NamingException e){
			String tMsg = "Unable to read LDAP attributes.  Error: " + e.toString();
			throw new Exception(tMsg);
		}    
		finally {
			if (ae != null) {
				try {
					ae.close();
				}
				catch (Exception ignore) {
				}
			}
			if (results != null) {
				try {
					results.close();
				}
				catch (Exception ignore) {
				}
			}
		}

		return(hTable.isEmpty() ? null : hTable);
	}
    
	public static void main(String[] arguments)
			throws Exception
	{
		LDAPDirectory  obj = new LDAPDirectory();
		String      host = "LDAPTEST.SUPERVALU.COM";
		int         port = 20389;
		String      ldapUserID = "uid=hadladm,ou=People,o=supervalu.com";
		String      ldapPassword = "8xw27c3";
		String      userID = "Test1aTest1b";
		String      givenName = "Test1a";
		String      sn = "Test1b";
		String      cn = "Test1a Test1b";
		String      userDN = "uid=" + userID + ",ou=People,ou=SVHarbor,o=supervalu.com";
		Hashtable   attrib_set = new Hashtable(20);

		// Establish a connection with the server.
		obj.connect(host, port, 3, ldapUserID, ldapPassword);

		if (obj.existObject(userDN)) {
			System.out.println("Record already exists in LDAP");
			obj.deleteObject(userDN);
			System.out.println("Record deleted from LDAP.");
		}

		attrib_set.put("objectclass", new String[] {"top", "person", "organizationalPerson", "inetOrgPerson"});
		attrib_set.put("uid", new String[] {userID});
		attrib_set.put("givenname", new String[] {givenName});
		attrib_set.put("sn", new String[] {sn});
		attrib_set.put("cn", new String[] {cn});
		obj.addObject(userDN, attrib_set);
		System.out.println("Record successfully added to LDAP!");

		attrib_set.clear();
		attrib_set.put("givenname", new String[] {givenName + "!!!"});
		attrib_set.put("sn", new String[] {sn});
		attrib_set.put("cn", new String[] {cn});
		obj.updateObject(userDN, attrib_set);
		System.out.println("Record successfully updated in LDAP!");

		obj.addAttribute(userDN, "telephoneNumber", new String[] {"952-828-0000"});

		if (obj.existObject(userDN)) {
			System.out.println("Found the record in LDAP");
			obj.deleteObject(userDN);
			System.out.println("Record deleted from LDAP.");
		}
 
		// Disconnect from the server.
		obj.disconnect();
	}
}
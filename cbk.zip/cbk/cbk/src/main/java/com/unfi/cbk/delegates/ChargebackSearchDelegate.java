package com.unfi.cbk.delegates;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.unfi.cbk.beans.ResultList;
import com.unfi.cbk.bo.ChargebackBO;
import com.unfi.cbk.dao.ChargebackSearchDao;
import com.unfi.cbk.exceptions.DataAccessException;
import com.unfi.cbk.exceptions.CbkServiceException;
import com.unfi.cbk.util.DateFunctions;

/**
 * @author  yhp6y2l
 * @version 3.3
 */

public class ChargebackSearchDelegate {

    private static Logger log = Logger.getLogger(ChargebackSearchDelegate.class);
    private ChargebackSearchDao chargebackSearchDao;
	
	public ChargebackSearchDelegate(ChargebackSearchDao chargebackSearchDao) {
		this.chargebackSearchDao = chargebackSearchDao;
	}
	
	public ResultList getChargebacks(Map params) throws DataAccessException {  
       
		
        // Set up the date range of the search
        this.calculateSearchDates(params);
        System.out.println("----------ChargebackSearchDelegate.java----getChargebacks()-----");
        ResultList rL = chargebackSearchDao.getChargebacks(params);

        // Only keep the fromDate and toDate parameters in the map if the user
        //  entered a manual date selection.        
        String dateCriteria = (String) params.get("dateCriteria");
        if ( dateCriteria != null && !dateCriteria.equals("manual") ) {
            params.remove("fromDate");
            params.remove("toDate");
        }
       
		return rL;	
	}
	
	public ChargebackBO getChargebackDetail(Map params) throws DataAccessException {
		return chargebackSearchDao.getChargebackDetail(params);
	}
	
	public ChargebackBO CreateChargeback(Map params) throws DataAccessException {
		return chargebackSearchDao.CreateChargeback(params);
	}
	
	public ChargebackBO UpdateChargeback(Map params) throws DataAccessException {
		return chargebackSearchDao.UpdateChargeback(params);
	}

	public ResultList getAvailableChargebacks() throws DataAccessException {  
        System.out.println("----------ChargebackSearchDelegate.java----getAvailableChargebacks()-----");
        ResultList rL = chargebackSearchDao.getAvailableChargebacks();
		return rL;	
	}
	
	  public List getChargebackTypes() throws DataAccessException {
	  System.out.println("--in DELEGATE---FETCHING CHARGEBACK TYPES------");
	  List l = chargebackSearchDao.getChargebackTypes();
	  
	  return l;
	  }
	 
	
	public ResultList locationNumberValidator(Map params) throws DataAccessException {
		ResultList rL = chargebackSearchDao.locationNumberValidator(params);	
		return rL;
	}
	
	public ResultList vendorNumberValidator(Map params) throws DataAccessException {
		ResultList rL = chargebackSearchDao.vendorNumberValidator(params);	
		return rL;
	}
	
	public ResultList originatorValidator(Map params) throws DataAccessException {
		ResultList rL = chargebackSearchDao.originatorValidator(params);	
		return rL;
	}
	
	public ResultList approverValidator(Map params) throws DataAccessException {
		ResultList rL = chargebackSearchDao.approverValidator(params);	
		return rL;
	}
	
    private ResultList checkForNotFoundCbks(ResultList rL, List docNumList) {
		// TODO Auto-generated method stub
		return null;
	}

	private List buildCbkNumberList(Map params) {
        return buildList(params, "docNum", 21);
    }
    
    private List buildNetAmountList(Map params) {
        return buildList(params, "netAmount", 21);
    }    
    
    private List buildList(Map params, String prefix, int count) {
        List l = new ArrayList();

        for ( int i = 1; i <= count; i++ ) {
            String key = prefix + i;
            if ( params.containsKey(key) && params.get(key) != null && !((String) params.get(key)).equals("")) {
                l.add(((String) params.get(key)).trim().toUpperCase());                
            }
        }
    
        return l;
    }
    
   
    
    private void calculateSearchDates(Map params) {
        //  Determine the dates to use
        String dateCriteria = (String) params.get("dateCriteria");
        String fromDate = (String) params.get("fromDate");
        String toDate = (String) params.get("toDate");
        String from = "";
        String to = "";       
        
        if ((dateCriteria != null) && (!dateCriteria.equals(""))) {
            if (dateCriteria.equals("manual")) {
                //  Use the dates provided
                from = DateFunctions.formatYear(fromDate);
				params.put("fromDate", from);
                params.put("searchFromDate", DateFunctions.formatDate(from));
                to = DateFunctions.formatYear(toDate);
				params.put("toDate", to);
                params.put("searchToDate", DateFunctions.formatDate(to));
            }
            else {
                String dateCriteriaDays = null;
                
                if (dateCriteria.equalsIgnoreCase("1")) {
                    dateCriteriaDays = "30";
                }
                else if (dateCriteria.equalsIgnoreCase("2")) {
                    dateCriteriaDays = "60";
                }
                else if (dateCriteria.equalsIgnoreCase("3")) {
                    dateCriteriaDays = "90";
                }
                
                from = DateFunctions.adjustCurrentDate( - (Integer.parseInt(dateCriteriaDays)));
                to = DateFunctions.getToday();
    			
				params.put("fromDate", from);
                params.put("searchFromDate", DateFunctions.formatDate(from));
				params.put("toDate", to);
                params.put("searchToDate", DateFunctions.formatDate(to));
            }
        }        
    }
    
    public String buildSearchCriteriaSummary(Map formSearchValuesMap, List filterParams, boolean exclude) {
        HashMap searchCriteriaText = new HashMap();
    
        String vendorId = (String) formSearchValuesMap.get("vendorId");
        System.out.println("Cbk deligate calss"+vendorId);
        if ((vendorId != null) && (!vendorId.equals(""))) {
            searchCriteriaText.put("vendor", "Vendor " + vendorId);
        }
    
        //  Determine the dates to use
        String dateCriteria = (String) formSearchValuesMap.get("dateCriteria");
        String fromDate = (String) formSearchValuesMap.get("fromDate");
        String toDate = (String) formSearchValuesMap.get("toDate");
        String from = "";
        String to = "";
        
        if ((dateCriteria != null) && (!dateCriteria.equals(""))) {
            if (dateCriteria.equals("manual")) {
                //  Use the dates provided
                from = DateFunctions.formatYear(fromDate);
                to = DateFunctions.formatYear(toDate);
                searchCriteriaText.put("date", from + " - " + to);
            }
            else {
                //  Use the value submitted to determine how many days to go back
                //  (The span value submitted is either 1, 2, or 3 - the value is
                //  translated based on values from the Resource Bundle
                String dateCriteriaDays = null;
                if (dateCriteria.equalsIgnoreCase("1")) {
                    dateCriteriaDays = "30";
                }
                else if (dateCriteria.equalsIgnoreCase("2")) {
                    dateCriteriaDays = "60";
                }
                else if (dateCriteria.equalsIgnoreCase("3")) {
                    dateCriteriaDays = "90";
                }
                //String dateCriteriaDays = applicationResources.getMessage("label.dateCriteria.span" + dateCriteria);
                from = DateFunctions.adjustCurrentDate( - (Integer.parseInt(dateCriteriaDays)));
                to = DateFunctions.getToday();

                searchCriteriaText.put("date", "Last " + dateCriteriaDays + " days");
            }
        }
    
        //  Build the summary string that is used on the results page
        //  to show what criteria was used in the search.
        StringBuffer searchCriteriaSummary = new StringBuffer();
    
        if (searchCriteriaText.containsKey("date")) {
            searchCriteriaSummary.append((String) searchCriteriaText.get("date"));
        }
        if (searchCriteriaText.containsKey("vendor")) {
            if (searchCriteriaSummary.length() > 0) {
                searchCriteriaSummary.append(", ");
            }
            searchCriteriaSummary.append((String) searchCriteriaText.get("vendor"));
        }
        if (searchCriteriaText.containsKey("location")) {
            if (searchCriteriaSummary.length() > 0) {
                searchCriteriaSummary.append(", ");
            }
            searchCriteriaSummary.append(
                (String) searchCriteriaText.get("location"));
        }
        if (searchCriteriaText.containsKey("docnum")) {
            if (searchCriteriaSummary.length() > 0) {
                searchCriteriaSummary.append(", ");
            }
            searchCriteriaSummary.append((String) searchCriteriaText.get("docnum"));
    
            if (searchCriteriaText.containsKey("docnummore")) {
                searchCriteriaSummary.append(
                    (String) searchCriteriaText.get("docnummore"));
            }
        }
        if (searchCriteriaText.containsKey("netamount")) {
            if (searchCriteriaSummary.length() > 0) {
                searchCriteriaSummary.append(", ");
            }
            searchCriteriaSummary.append(
                (String) searchCriteriaText.get("netamount"));
    
            if (searchCriteriaText.containsKey("netamountmore")) {
                searchCriteriaSummary.append(
                    (String) searchCriteriaText.get("netamountmore"));
            }
        }
    
        return searchCriteriaSummary.toString();
    }

    /**
     * @param chargeback
     */
	/*
	 * public void fillCheckDetails(Chargeback chargeback) throws
	 * CbkServiceException { chargebackSearchDao.fillCheckDetails(chargeback); }
	 * 
	 * public List getChargebackAttachments(Chargeback chargeback) throws
	 * DataAccessException { return
	 * chargebackSearchDao.getChargebackAttachments(chargeback); }
	 */
}

package com.unfi.cbk.ldap;

import java.util.Vector;

import com.unfi.cbk.ldaputil.CompareTo;
import com.unfi.cbk.ldaputil.Comparer;
import com.unfi.cbk.ldaputil.VectorFuncs;

/**
 * Class to hold Carrier information.
 * Creation date: (04/27/2003 7:04:00 PM)
 * @author: John Ebert
 */
public class Carrier implements CompareTo
{
	private java.lang.String carrierID;
	private java.lang.String carrierName;
	private java.lang.String emailAddress;
	private java.lang.String address;
	private java.lang.String city;
	private java.lang.String stateCode;
	private java.lang.String zipCode;
	private java.lang.String phoneNumber;
	private java.lang.String faxNumber;

	// Sorts by carrierName.
	private static class CarrierNameOrder implements Comparer
	{
		public int compare(java.lang.Object o1,
						   java.lang.Object o2)
		{
			/*
			 * Caution, don't use compareToIgnoreCase(), it's not supported
			 * in Microsoft Java Environment.
			 */
			int ret = ((Carrier) o1).carrierName.toLowerCase().compareTo(((Carrier) o2).carrierName.toLowerCase());
			return(ret);
		}
	}

	public Carrier()
	{
		super();

		carrierID = "";
		carrierName = "";
		emailAddress = "";
		address = "";
		city = "";
		stateCode = "";
		zipCode = "";
		phoneNumber = "";
		faxNumber = "";
	}

	/* Creates new Carrier object */
	public Carrier(java.lang.String carrierID,
				  java.lang.String carrierName,
				  java.lang.String emailAddress,
				  java.lang.String address,
				  java.lang.String city,
				  java.lang.String stateCode,
				  java.lang.String zipCode,
				  java.lang.String phoneNumber,
				  java.lang.String faxNumber)
	{
		super();

		this.carrierID = carrierID;
		this.carrierName = carrierName;
		this.emailAddress = emailAddress;
		this.address = address;
		this.city = city;
		this.stateCode = stateCode;
		this.zipCode = zipCode;
		this.phoneNumber = phoneNumber;
		this.faxNumber = faxNumber;
	}

	// Sorts by carrierName.
	public int compareTo(java.lang.Object obj)
	{
		final int ret = carrierName.toLowerCase().compareTo(((Carrier) obj).carrierName.toLowerCase());
		return(ret);
	}

	/**
	 * Sorts the Vector of Carrier objects into order by
	 * Carrier Name.
	 */
	public static void sortByCarrierName(Vector vector)
	{
		VectorFuncs.sort(vector, new Carrier.CarrierNameOrder());
	}

	/**
	 * Returns the contents of the address field.
	 *
	 * @return String
	 */
	public java.lang.String getAddress()	{return(address);}

	/**
	 * Returns the contents of the city field.
	 *
	 * @return String
	 */
	public java.lang.String getCity()	{return(city);}

	/**
	 * Returns the contents of the emailAddress field.
	 *
	 * @return String
	 */
	public java.lang.String getEmailAddress()	{return(emailAddress);}

	/**
	 * Returns the contents of the faxNumber field.
	 *
	 * @return String
	 */
	public java.lang.String getFaxNumber()	{return(faxNumber);}

	/**
	 * Returns the contents of the phoneNumber field.
	 *
	 * @return String
	 */
	public java.lang.String getPhoneNumber()	{return(phoneNumber);}

	/**
	 * Returns the contents of the stateCode field.
	 *
	 * @return String
	 */
	public java.lang.String getStateCode()	{return(stateCode);}

	/**
	 * Returns the contents of the carrierID field.
	 *
	 * @return String
	 */
	public java.lang.String getCarrierID()	{return(carrierID);}

	/**
	 * Returns the contents of the carrierName field.
	 *
	 * @return String
	 */
	public java.lang.String getCarrierName()	{return(carrierName);}

	/**
	 * Returns the contents of the zipCode field.
	 *
	 * @return String
	 */
	public java.lang.String getZipCode()	{return(zipCode);}

}

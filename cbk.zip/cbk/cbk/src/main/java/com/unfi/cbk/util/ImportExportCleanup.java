
package com.unfi.cbk.util;

import java.io.File;
import java.io.FilenameFilter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;

import com.unfi.cbk.utilcore.ApplicationProperties;



public class ImportExportCleanup {

    private static Logger log = Logger.getLogger(ImportExportCleanup.class);

    /**
     * 
     */
    public void cleanup() {
        log.info("***** FILE CLEANUP - START *****");
        
        List files = this.getFiles();
        
        log.info("Found " + files.size() + " file(s) to delete.");
        
        Iterator i = files.iterator();
        
        while ( i.hasNext() ) {
            File f = (File) i.next();
            this.removeFile(f);
        }

        log.info("***** FILE CLEANUP - COMPLETE *****");        
    }
    
    /**
     * Get a List of files that need to be deleted from disk.
     * 
     * @return a List of File objects to delete.
     */
    private List getFiles() {
    	String directory = ApplicationProperties.getProdFilePath();
    	
        File dir = new File(directory);
        
        if ( dir.exists() ) {
            File files[] = dir.listFiles(new ImportExportFilenameFilter());
            return Arrays.asList(files);        
        }
        else {
            log.error("Directory (" + directory + ") does not exist!");
            return new ArrayList();
        }        
    }
    
    /**
     * @param f
     * @return
     */
    private boolean removeFile(File f) {
        boolean status = false;
        
        if ( f.exists() ) {
            if ( f.canWrite() ) {
                status = f.delete();
            }
        }
        else {
            // The file does not exist anymore, so it must have been removed.
            status = true;
        }

        log.info("Removing File: " + f.getName() + " Result: " + status);
        return status;
    }
    
    private static class ImportExportFilenameFilter implements FilenameFilter {

        private long currentTS;
        private static final long MAX_AGE =  20 * 60 * 1000; //20 minutes

        public ImportExportFilenameFilter() {
            currentTS = System.currentTimeMillis();
        }

        public boolean accept(File dir, String name) {

			//Is a file
			File test = new File(dir,name);
			boolean isFile = test.isFile();
			
			if (!isFile){
				return false;
			}
			
			//Has 1st dot in name
			int x = name.indexOf('.');
			if (x == -1){
				return false;
			}
			String fileType = name.substring(0,x);		
			
			//Has last dot prior to timestamp
			int tsi =  name.lastIndexOf('.') + 1;
			if (tsi == -1) {
				return false;
			}
			
			//Text after last dot a timestamp?
			long fileTS = 0;
			try {
				fileTS = Long.parseLong(name.substring(tsi));
			} catch (NumberFormatException nfe){
				fileTS = -1;
			}
			 
            return (fileType.equals("ImportExport") &&( fileTS < (currentTS - MAX_AGE) ));
        }
        
    }
}

package com.unfi.cbk.actions;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class LogoutAction {

	
	@Value("${logutURL}")
	private String logouturl;
	
	@RequestMapping(value="/logoutAction",method = {RequestMethod.GET,RequestMethod.POST})
	public ModelAndView logout(HttpServletRequest request, HttpServletResponse response) throws Exception 
	{
		request.getSession().invalidate();
		ModelAndView mav  = new ModelAndView();
		mav.setViewName("redirect:"+logouturl);
		
		return mav;
	}
}

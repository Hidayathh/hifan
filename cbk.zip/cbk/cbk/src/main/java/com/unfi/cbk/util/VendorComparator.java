package com.unfi.cbk.util;

import java.io.Serializable;
import java.util.Comparator;

import org.apache.log4j.Logger;


/**
 * The VendorComparator is an implementation of the java.util.Comparator
 * class and is used to compare struts LabelValueBean objects.
 *
 * @author      yhp6y2l
 * @since       1.0
 */
public class VendorComparator implements Comparator, Serializable {
	static Logger log = Logger.getLogger(VendorComparator.class);
	
	/* (non-Javadoc)
	 * @see java.util.Comparator#compare(java.lang.Object, java.lang.Object)
	 */
	public int compare(Object object1, Object object2) {
		//  As per the java.util.Comparator specification, this method
		//  returns an int according to the following criteria:
		//  - returns a negative value if arg1 < arg2
		//  - returns a positive value if arg1 > arg2
		//  - returns a zero if ar1 = arg2
		
		//  Get the objects (LabelValueBeans) from the arguments
		LabelValueBean lvb1 = (LabelValueBean) object1;
		LabelValueBean lvb2 = (LabelValueBean) object2;
		
		//  Get the string values to sort on out of the LabelValueBean's 'label' property
		String value1 = lvb1.getLabel();
		String value2 = lvb2.getLabel();
		
		//  Use a String compare to determine positive/negative/equals
		int stringCompare = value1.compareToIgnoreCase(value2);
		
		return stringCompare;
		
	}

}
package com.unfi.cbk.dao;

import java.util.List;
import java.util.Map;

import com.unfi.cbk.beans.ResultList;
import com.unfi.cbk.bo.ChargebackBO;
import com.unfi.cbk.exceptions.DataAccessException;
import com.unfi.cbk.exceptions.CbkServiceException;

/**
 * The ChargebackSearchDao interface creates the bridge between the
 * caller and the actual work in retrieving the data.
 *
 * @author      yhp6y2l
 * @since       1.0
 */
public interface ChargebackSearchDao {
	
	/**
	 * Gets the search results from the database.
	 * This method takes the search values provided on the form and creates a
	 * database query.  The list of documents that match the criteria are the
	 * results that are returned to the caller.
	 * 
	 * @return						the list of chargebacks from the index table
	 * @param formSearchValuesMap	the Map for the search page
	 * @since						1.0
	 */
	public ResultList getChargebacks(Map formSearchValuesMap)
		throws DataAccessException;
	
	public ResultList getAvailableChargebacks()
			throws DataAccessException;
	
	public ResultList locationNumberValidator(Map formSearchValuesMap) 
			throws DataAccessException;
	
	public ResultList vendorNumberValidator(Map formSearchValuesMap) 
			throws DataAccessException;
	
	
	public ResultList originatorValidator(Map formSearchValuesMap) 
			throws DataAccessException;
	
	public ResultList approverValidator(Map formSearchValuesMap) 
			throws DataAccessException;
	
	public List getChargebackTypes() throws DataAccessException;
	
	public ChargebackBO getChargebackDetail(Map formSearchValuesMap)
			throws DataAccessException;
	
	public ChargebackBO CreateChargeback(Map formSearchValuesMap)
			throws DataAccessException;
	
	
	public ChargebackBO UpdateChargeback(Map formSearchValuesMap)
			throws DataAccessException;
		
	
	
	
	
	
	/*
	 * public void fillCheckDetails(Chargeback doc) throws CbkServiceException;
	 * 
	 * public List getChargebackAttachments(Chargeback document) throws
	 * DataAccessException;
	 */

	//public ResultList getCbks(Map params, List filterParams, boolean exclude);
}
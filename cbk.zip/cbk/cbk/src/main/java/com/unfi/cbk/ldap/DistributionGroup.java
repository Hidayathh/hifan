package com.unfi.cbk.ldap;

import java.util.Vector;

import com.unfi.cbk.ldaputil.CompareTo;
import com.unfi.cbk.ldaputil.Comparer;
import com.unfi.cbk.ldaputil.VectorFuncs;

/**
 * Class to hold a DistributionGroup.
 * Creation date: (06/10/2003 5:02 PM)
 * @author: John Ebert
 */
public class DistributionGroup implements CompareTo
{
	private java.lang.String number;
	private java.lang.String description;

	// Sorts by number.
	private static class NumberOrder implements Comparer
	{
		public int compare(java.lang.Object o1,
						   java.lang.Object o2)
		{
			/*
			 * Caution, don't use compareToIgnoreCase(), it's not supported
			 * in Microsoft Java Environment.
			 */
			int ret = ((DistributionGroup) o1).number.toLowerCase().compareTo(((DistributionGroup) o2).number.toLowerCase());
			return(ret);
		}
	}

	public DistributionGroup()
	{
		super();

		number = "";
		description = "";
	}

	/* Creates new DistributionGroup object */
	public DistributionGroup(java.lang.String number,
				  java.lang.String description)
	{
		super();

		this.number = number;
		this.description = description;
	}

	// Sorts by number.
	public int compareTo(java.lang.Object obj)
	{
		final int ret = number.toLowerCase().compareTo(((DistributionGroup) obj).number.toLowerCase());
		return(ret);
	}

	/**
	 * Sorts the Vector of DistributionGroup objects into order by
	 * number.
	 */
	public static void sortByNumber(Vector vector)
	{
		VectorFuncs.sort(vector, new DistributionGroup.NumberOrder());
	}

	/**
	 * Returns the contents of the number field.
	 *
	 * @return String
	 */
	public java.lang.String getNumber()	{return(number);}

	/**
	 * Returns the contents of the description field.
	 *
	 * @return String
	 */
	public java.lang.String getDescription()	{return(description);}
	
	public boolean equals(Object o1)
	{
		boolean areEqual = false;
		// If its an instance of Distribution Group , call compare, else call super.equals 
		if(o1 instanceof com.unfi.cbk.ldap.DistributionGroup)
		{
			NumberOrder numberOrder = new NumberOrder();
			if(numberOrder.compare((Object)this,o1) == 0)
			{
				areEqual = true;
			}
		}
		else
		{
			areEqual = super.equals(o1);
		}
		return areEqual;
	}


}

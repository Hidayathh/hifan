/*
 * Created on Mar 16, 2006
 * @author tcjpt0
 */
package com.unfi.cbk.common.util.ui;

import java.util.ArrayList;
import java.util.StringTokenizer;

import org.apache.log4j.Logger;

/**
 * @author tcjpt0
 * Created Mar 16, 2006
 * 
 */
public class HarborList implements Securable {
	private String className;
	private String name;
	private ArrayList roles;
	public static final String DELIMITER = ",";
	private String delimiter = DELIMITER;
	

	private static Logger log = Logger.getLogger(HarborList.class);
	
	public HarborList(){
		log.debug("Creating Harbor List");
        roles = new ArrayList();        
	}
	/**
	 * @return
	 */
	public String getClassName() {
		return className;
	}

	/**
	 * @return
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param string
	 */
	public void setClassName(String string) {
		log.debug("Setting class name to " + string);
		className = string;
	}

	/**
	 * @param string
	 */
	public void setName(String string) {
		log.debug("Setting name to " + string);
		name = string;
	}

	public void addRole(String role){
        roles.add(role);	
	}

	/* (non-Javadoc)
	 * @see com.supervalu.svharbor.common.util.ui.Securable#getRoleNames()
	 */
	public String[] getRoleNames() {
        return (String[]) roles.toArray(new String[roles.size()]);
	}
	/* (non-Javadoc)
	 * @see com.supervalu.svharbor.common.util.ui.Securable#setRoles(java.lang.String)
	 */
	public void setRoles(String roles) {
		if (roles.indexOf(delimiter) > -1) {				
			StringTokenizer st = new StringTokenizer(roles, delimiter);
			while (st.hasMoreElements()) {
				this.addRole(st.nextToken());					
			}
		}				
		else{			
			this.addRole(roles);								
		}	
	}
	/* (non-Javadoc)
	 * @see com.supervalu.svharbor.common.util.ui.Securable#setRoles(java.lang.String, java.lang.String)
	 */
	public void setRoles(String roles, String delimiter) {
		this.delimiter = delimiter;
		this.setRoles(roles);
	}

}

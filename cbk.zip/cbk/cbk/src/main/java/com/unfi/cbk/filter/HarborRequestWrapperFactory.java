/*
 * Created on Jan 19, 2005
 *
 */
package com.unfi.cbk.filter;
import java.lang.reflect.Constructor;

import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;

import org.apache.commons.beanutils.ConstructorUtils;
import org.apache.log4j.Logger;

/**
 * @author yhp6y2l
 * @version 1.0
 */
public class HarborRequestWrapperFactory {
	
	private static Logger log = Logger.getLogger(HarborRequestWrapperFactory.class);
	/**
	 * 
	 * @param request	HttpServletRequest to be wrapped
	 * @return			HttpServletRequest
	 * 
	 * The factory attempts to instantiate a HttpServletRequestWrapper object using the 
	 * ServletRequest object passed in.  The class of the wrapper instantiated is determined by the 
	 * current value of the Constants.WRAPPER_CLASS variable.  If no class is specified, or the factory cannot 
	 * instantiate the wrapper, the request is returned without a wrapper.
	 */
	public static HttpServletRequest getHarborRequestWrapper(ServletRequest request){
		HttpServletRequest req = (HttpServletRequest) request;		
		if (WrapperConstants.get(WrapperConstants.WRAPPER_CLASS) != null && WrapperConstants.get(WrapperConstants.WRAPPER_CLASS).length()> 0 && ! WrapperConstants.get(WrapperConstants.WRAPPER_CLASS).equalsIgnoreCase(WrapperConstants.NONE)){
			try{
				//load the specified class
				//System.out.println("Trying to instantiate: " + WrapperConstants.get(WrapperConstants.WRAPPER_CLASS));
				Class c = Class.forName(WrapperConstants.get(WrapperConstants.WRAPPER_CLASS));
				
				Object obj = ConstructorUtils.invokeConstructor(c,request);
												
				if (obj != null){				
					//cast the returned objec											
					req = (HttpServletRequestWrapper) obj;
				}			
				
				/*
				// get the array of constructors (there is only one for the wrapper class);				
				Constructor constructor[] = c.getDeclaredConstructors();
				
				//pick out the constructor we are using
				Constructor cons = constructor[0];
				
				//create an array of constructor parameters
				HttpServletRequest requests[] = new HttpServletRequest[1];
				
				//set the request as the only parameter for the constructo
				requests[0]=req;
				
				//get an instance of the object
				Object obj = cons.newInstance(requests);
				
				if (obj != null){				
					//cast the returned objec											
					req = (HttpServletRequestWrapper) obj;
				}
				*/			
			}
			catch (Exception e){
//				System.out.println("Cannot instantiate Wrapper.");
//				System.out.println("Cannot instantiate Wrapper.");
//				e.printStackTrace();
				log.error("Cannot instantiate Wrapper " + e.getMessage(),e);								
			}							
		}
		return req;
	}

}

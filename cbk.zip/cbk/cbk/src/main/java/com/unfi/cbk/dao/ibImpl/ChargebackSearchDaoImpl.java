package com.unfi.cbk.dao.ibImpl;

import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.orm.ibatis.SqlMapClientTemplate;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;
import com.unfi.cbk.beans.ResultList;
import com.unfi.cbk.bo.ChargebackBO;
import com.unfi.cbk.dao.ChargebackSearchDao;
import com.unfi.cbk.exceptions.DataAccessException;
import com.unfi.cbk.exceptions.CbkServiceException;
import com.unfi.cbk.util.StringFunctions;

/**
 * The ChargebackSearchDaoImpl class handles the call to the database to get
 * the results of the chargebacks search based on the form values.
 *
 * @author      vpil001
 * @since       1.0
 */

public class ChargebackSearchDaoImpl extends SqlMapClientDaoSupport implements ChargebackSearchDao {
	
	private static Logger log = Logger.getLogger(ChargebackSearchDaoImpl.class);
	protected static Date BAD_DATE = null;

	public ChargebackSearchDaoImpl(SqlMapClientTemplate sqlMapTemplate){
		this.setSqlMapClientTemplate(sqlMapTemplate);
	}
	
	public ResultList getChargebacks(Map formSearchValuesMap) throws DataAccessException {
        ResultList rL = new ResultList();

		try {
			
			System.out.println("------ChargebackSearchDaoImpl.java-------getChargebacks()------");
			System.out.println("---status::"+formSearchValuesMap.get("status"));
			System.out.println("---apStatus::"+formSearchValuesMap.get("apStatus"));
			rL.setList((List) getSqlMapClientTemplate().queryForList("ChargebackSearch.getChargebacks", formSearchValuesMap));
            System.out.println("------------ChargebackSearchDaoImpl.java--ResultList size----"+rL.getList().size());
            if ( rL.getList().size() == 0 ) {
                rL.setTotalCount(new Integer(0));
            }
            else if ( formSearchValuesMap.get("showAll") != null && ((String) formSearchValuesMap.get("showAll")).equals("true") )  {
                rL.setTotalCount(new Integer(rL.getList().size()));
            }
            //else {
             //   rL.setTotalCount((Integer) getSqlMapClientTemplate().queryForObject("ChargebackSearch.getChargebacksCount", formSearchValuesMap));                
           // }
		} catch (Exception e) {
			e.printStackTrace();
			log.error("Error in getChargebacks() " + e);
			//e.printStackTrace();
			throw new DataAccessException(e);
		}
	
		return rL;	
	} 
	
	public ChargebackBO getChargebackDetail(Map formSearchValuesMap)
			throws DataAccessException {
		ChargebackBO c = null;

			try {
				//HashMap map = new HashMap();
				//map.put("authCode", authCode);

				c =
					(ChargebackBO) getSqlMapClientTemplate().queryForObject(
						"ChargebackSearch.getChargebackDetail", formSearchValuesMap);

			} catch (Exception e) {
				log.error(e);
				throw new DataAccessException(e);
			}

			checkIfNull(c);
			return c;
		}
	
	
	public ChargebackBO CreateChargeback(Map formSearchValuesMap)
			throws DataAccessException {
		ChargebackBO c = null;

			try {
				//HashMap map = new HashMap();
				//map.put("authCode", authCode);

				c =
					(ChargebackBO) getSqlMapClientTemplate().queryForObject(
						"ChargebackSearch.createChargeback", formSearchValuesMap);

			} catch (Exception e) {
				log.error(e);
				throw new DataAccessException(e);
			}

			checkIfNull(c);
			return c;
		}
	
	public ChargebackBO UpdateChargeback(Map formSearchValuesMap)
			throws DataAccessException {
		ChargebackBO c = null;

			try {
				//HashMap map = new HashMap();
				//map.put("authCode", authCode);

				c =
					(ChargebackBO) getSqlMapClientTemplate().queryForObject(
						"ChargebackSearch.getChargebackDetail", formSearchValuesMap);

			} catch (Exception e) {
				log.error(e);
				throw new DataAccessException(e);
			}

			checkIfNull(c);
			return c;
		}
	

	public ResultList getAvailableChargebacks() throws DataAccessException {
        ResultList rL = new ResultList();

		try {
			
			System.out.println("------ChargebackSearchDaoImpl.java-------getAvailableChargebacks()------");
			rL.setList((List) getSqlMapClientTemplate().queryForList("ChargebackSearch.getAvailableChargebacks"));
            System.out.println("------------ChargebackSearchDaoImpl.java--ResultList size----"+rL.getList().size());
            if ( rL.getList().size() == 0 ) {
                rL.setTotalCount(new Integer(0));
            }
			/*
			 * else if ( formSearchValuesMap.get("showAll") != null && ((String)
			 * formSearchValuesMap.get("showAll")).equals("true") ) { rL.setTotalCount(new
			 * Integer(rL.getList().size())); }
			 */
            //else {
             //   rL.setTotalCount((Integer) getSqlMapClientTemplate().queryForObject("ChargebackSearch.getChargebacksCount", formSearchValuesMap));                
           // }
		} catch (Exception e) {
			e.printStackTrace();
			log.error("Error in getAvailableChargebacks() " + e);
			e.printStackTrace();
			throw new DataAccessException(e);
		}
		return rL;	
	} 

	public List getChargebackTypes() throws DataAccessException {
		
		List l= null;
		try {
			//HashMap map = new HashMap();
			System.out.println("------in Impl---getChargebackTypes()-------");
			l=(List) getSqlMapClientTemplate().queryForList("ChargebackSearch.getChargebackTypes");
			 System.out.println("------------ChargebackSearchDaoImpl.java-getChargebackTypes---List size----"+l.size());
	           
		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
			throw new DataAccessException(e);
		}
		
		
		return l;
				
		
		
	}
	
	  public ResultList locationNumberValidator(Map formSearchValuesMap)throws DataAccessException {
		  ResultList rL = new ResultList();
				try {
					//HashMap map = new HashMap();
					System.out.println("------in Impl---LocationNumberValidator-------");
					rL.setList((List) getSqlMapClientTemplate().queryForList("ChargebackSearch.locationNumberValidator",formSearchValuesMap));
					 System.out.println("------------ChargebackSearchDaoImpl.java-locationNumberValidator---ResultList size----"+rL.getList().size());
			           
				} catch (Exception e) {
					e.printStackTrace();
					log.error(e);
					throw new DataAccessException(e);
				}
				//checkIfNull(s);
				return rL;
		}
	  
	  
	  
	  public ResultList vendorNumberValidator(Map formSearchValuesMap)throws DataAccessException {
		  ResultList rL = new ResultList();
				try {
					//HashMap map = new HashMap();
					System.out.println("------in Impl---vendorNumberValidator-------");
					rL.setList((List) getSqlMapClientTemplate().queryForList("ChargebackSearch.vendorNumberValidator",formSearchValuesMap));
					 System.out.println("------------ChargebackSearchDaoImpl.java-vendorNumberValidator---ResultList size----"+rL.getList().size());
			           
				} catch (Exception e) {
					e.printStackTrace();
					log.error(e);
					throw new DataAccessException(e);
				}
				//checkIfNull(s);
				return rL;
		}
	  
	  public ResultList originatorValidator(Map formSearchValuesMap)throws DataAccessException {
		  ResultList rL = new ResultList();
				try {
					System.out.println("------in Impl---originatorValidator-------");
					rL.setList((List) getSqlMapClientTemplate().queryForList("ChargebackSearch.originatorValidator",formSearchValuesMap));
					 System.out.println("------------ChargebackSearchDaoImpl.java--originatorValidator---ResultList size----"+rL.getList().size());
			           
				} catch (Exception e) {
					e.printStackTrace();
					log.error(e);
					throw new DataAccessException(e);
				}
				//checkIfNull(s);
				return rL;
		}
	  
	  public ResultList approverValidator(Map formSearchValuesMap)throws DataAccessException {
		  ResultList rL = new ResultList();
				try {
					System.out.println("------in Impl---approverValidator-------");
					rL.setList((List) getSqlMapClientTemplate().queryForList("ChargebackSearch.approverValidator",formSearchValuesMap));
					 System.out.println("------------ChargebackSearchDaoImpl.java--approverValidator---ResultList size----"+rL.getList().size());
			           
				} catch (Exception e) {
					e.printStackTrace();
					log.error(e);
					throw new DataAccessException(e);
				}
				//checkIfNull(s);
				return rL;
		}
	  
		/**
		 * Check if an object is null and throw a DataAccessException if it is.
		 * 
		 * @param o the object to test
		 * @throws DataAccessException whenever the object is null
		 */
		private void checkIfNull(Object o) throws DataAccessException {
			if (o == null) {
				throw new DataAccessException("Object not found.");
			}
		}

	  
	  
    /* (non-Javadoc)
     * @see com.unfi.cbk.dao.DocumentSearchDao#fillCheckDetails(com.unfi.cbk.bo.Document)
     */
   /* public void fillCheckDetails(Chargeback doc) throws CbkServiceException {
        try {
            // The vendor number needs to be a space-padded string
            doc.setVendorNumber(StringFunctions.spaceFillLeft(doc.getVendorNumber(),9,true));
            // The location number needs to be zero-padded            
            doc.setLocationNumber(StringFunctions.zeroFillLeft(doc.getLocationNumber(),5));
            
            List results = getSqlMapClientTemplate().queryForList("DocumentSearch.getCheckDetailsForDocument", doc);
            if ( results.size() > 0 && results.get(0) != null ) {
                Chargeback result = (Chargeback) results.get(0);
                doc.setProductGroup(result.getProductGroup());
                doc.setCheckNumber(result.getCheckNumber().trim());
                doc.setCheckDate(getValidDate(result.getCheckDate()));
                doc.setAuthCode(result.getAuthCode());    
                doc.setBankClearDate(getValidDate(result.getBankClearDate()));   
                doc.setDueDate(getValidDate(result.getDueDate()));         
            }
            
            // Remove the spaces we put on the vendor number earlier
            doc.setVendorNumber(doc.getVendorNumber().trim());
        } catch (Exception e) {
			log.error("Error in fillCheckDetails() " + e);
			//e.printStackTrace();
            throw new DataAccessException(e);
        }
    }
    
	public List getChargebackAttachments(Chargeback document) throws DataAccessException {
		
		List results;
			
		try {
			results = getSqlMapClientTemplate().queryForList("DocumentSearch.getChargebackAttachments", document);
		} catch (Exception e){
			log.error("Error in getChargebackAttachments() " + e);
			//e.printStackTrace();
			throw new DataAccessException(e);
		}
		
		return results;
	} 
	
	private Date getValidDate(Date val){
		if (BAD_DATE == null){
			Calendar cal = Calendar.getInstance();
			cal.set(1900,0,1);
			BAD_DATE = new Date(cal.getTime().getTime());
		}
		
		Date ret = null;
		if (val != null && (val.after(BAD_DATE))){
			ret = val;
		}		
		return ret;
		
	}
*/
	
	
}
package com.unfi.cbk.util;

import java.util.HashMap;
import java.util.Map;

public class ActionUrlMapping {
	
	/*
	 * CBK
	 * 
	 */
	public static Map<String,String> HOMEACTION;
	public static Map<String,String> AVAILABLECHARGEBACKACTION;
	public static Map<String,String> CHARGEBACKNEWSEARCHACTION;
	public static Map<String,String> VENDORSELECTORACTIONS;
	public static Map<String,String> GLOBAL;
	public static Map<String,String> CHARGEBACKLOCATIONSELECTORACTIONS;
	public static Map<String,String> ORIGINATORSELECTORACTIONS;
	public static Map<String,String> APPROVERSELECTORACTIONS;
	public static Map<String,String> CHARGEBACKGETRESULTSACTION;
	public static Map<String,String> CHARGEBACKDETAILSACTIONS;
	public static Map<String,String> CHARGEBACKCREATEACTIONS;
	public static Map<String,String> CHARGEBACKADMINACTION;
	
	
	
	//END
	
	
	public static Map<String,String> ERRORACTION;
	public static Map<String,String> DOCUMENTSEXPORTSEARCHRESULTSACTION;
	public static Map<String,String> PASSGETATTACHMENTACTION;
	public static Map<String,String> DOCUMENTSLOADDOCUMENTACTION;
	public static Map<String,String> LOADCHECKIMAGEACTION;
	public static Map<String,String> PASSCREATEMISCPASSACTIONS;
	public static Map<String,String> PRINTPASSDETAILSACTION;
	public static Map<String,String> DOCUMENTADDITIONALINFOACTION;
	public static Map<String,String> MAINTENANCEMENUACTION;
	
	
	
	
	
	
	
	
	static
	{
		GLOBAL = new HashMap<>();
		GLOBAL.put("failure","error.def");
		GLOBAL.put("error","error.display.def");
	}
	
	
	
	static {
		ERRORACTION=new HashMap<>(GLOBAL);
		ERRORACTION.put("success","errorPageDef");
		
		   }
	
	
	
	
	static {
		CHARGEBACKGETRESULTSACTION=new HashMap<>(GLOBAL);
		CHARGEBACKGETRESULTSACTION.put("success","chargeback.results.def");
		CHARGEBACKGETRESULTSACTION.put("error","errorPageDef");
		CHARGEBACKGETRESULTSACTION.put("other","chargeback.disabled.def");
	}
	
	static {
		CHARGEBACKDETAILSACTIONS=new HashMap<>(GLOBAL);
		CHARGEBACKDETAILSACTIONS.put("success","chargeback.details.def");
		CHARGEBACKDETAILSACTIONS.put("error","errorPageDef");
		CHARGEBACKDETAILSACTIONS.put("other","chargeback.disabled.def");
	}
	
	static {
		HOMEACTION=new HashMap<>(GLOBAL);
		HOMEACTION.put("home","homePageDef");
	}
	static {
		AVAILABLECHARGEBACKACTION=new HashMap<>(GLOBAL);
		AVAILABLECHARGEBACKACTION.put("success","availableChargeback.results.def");
		AVAILABLECHARGEBACKACTION.put("error","errorPageDef");
		AVAILABLECHARGEBACKACTION.put("other","availableChargeback.disabled.def");
	}
	static {
		CHARGEBACKCREATEACTIONS=new HashMap<>(GLOBAL);
		CHARGEBACKCREATEACTIONS.put("success","chargeback.create.def");
		CHARGEBACKCREATEACTIONS.put("error","errorPageDef");
		CHARGEBACKCREATEACTIONS.put("other","chargeback.disabled.def");
	}
	static {
		CHARGEBACKNEWSEARCHACTION=new HashMap<>(GLOBAL);
		CHARGEBACKNEWSEARCHACTION.put("success","chargeback.search.page");
		
	}
	
	static {
		CHARGEBACKLOCATIONSELECTORACTIONS=new HashMap<>(GLOBAL);
		CHARGEBACKLOCATIONSELECTORACTIONS.put("open","chargebackLocationSelector.def");
	}
	
	static {
		VENDORSELECTORACTIONS=new HashMap<>(GLOBAL);
		VENDORSELECTORACTIONS.put("open","vendorselector.def");
	}
	
	static {
		ORIGINATORSELECTORACTIONS=new HashMap<>(GLOBAL);
		ORIGINATORSELECTORACTIONS.put("open","originatorselector.def");
	}
	
	static {
		APPROVERSELECTORACTIONS=new HashMap<>(GLOBAL);
		APPROVERSELECTORACTIONS.put("open","approverselector.def");
	}
	
	static {
		CHARGEBACKADMINACTION=new HashMap<>(GLOBAL);
		CHARGEBACKADMINACTION.put("open","adminMenu.def");
		CHARGEBACKADMINACTION.put("userSearch","userSearch.def");
	}
	
	
	
	
	
	
	static {
		DOCUMENTSLOADDOCUMENTACTION=new HashMap<>(GLOBAL);
		DOCUMENTSLOADDOCUMENTACTION.put("status","document.load.def");
		DOCUMENTSLOADDOCUMENTACTION.put("sview","document.load.sview.def");
		DOCUMENTSLOADDOCUMENTACTION.put("failure","error.plain.def");
		
	}
	
	
	static {
		LOADCHECKIMAGEACTION=new HashMap<>(GLOBAL);
		LOADCHECKIMAGEACTION.put("status","document.load.checkimageload");
		LOADCHECKIMAGEACTION.put("sview","document.load.checkimage.def");
		LOADCHECKIMAGEACTION.put("failure","error.plain.def");
	}
	
	static {
		PASSCREATEMISCPASSACTIONS=new HashMap<>(GLOBAL);
		PASSCREATEMISCPASSACTIONS.put("duplicatePass","pass.create.misc.duplicate.def");
		PASSCREATEMISCPASSACTIONS.put("newPass","pass.create.misc.def");
		PASSCREATEMISCPASSACTIONS.put("submitPass","pass.create.misc.summary.def");
	}
	
	
	
	
	static {
		PRINTPASSDETAILSACTION=new HashMap<>(GLOBAL);
		PRINTPASSDETAILSACTION.put("print","pass.details.def.print");
		PRINTPASSDETAILSACTION.put("failure","error.plain.def");
	}
	

	static {
		DOCUMENTADDITIONALINFOACTION=new HashMap<>(GLOBAL);
		DOCUMENTADDITIONALINFOACTION.put("success","documentAdditionalInfo");
		DOCUMENTADDITIONALINFOACTION.put("failure","error.display.def");
	}
	
	
	
	static {
		MAINTENANCEMENUACTION=new HashMap<>(GLOBAL);
		MAINTENANCEMENUACTION.put("success","maint.menu.def");
	}
	
	
	

	
}

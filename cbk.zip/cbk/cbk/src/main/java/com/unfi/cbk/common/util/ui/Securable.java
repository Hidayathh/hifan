/*
 * Created on Mar 14, 2005
 * 
 */
package com.unfi.cbk.common.util.ui;

/**
 * 
 * @author yhp6y2l
 *
 */
public interface Securable {
	
	public abstract String[] getRoleNames();
	public abstract void setRoles(String roles);
	public abstract void setRoles(String roles, String delimiter);	
}

package com.unfi.cbk.actions.chargeback;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.servlet.ModelAndView;

import com.unfi.cbk.beans.ResultList;
import com.unfi.cbk.delegates.ChargebackSearchDelegate;
//import com.unfi.cbk.dao.ibImpl.MaintenanceDaoImpl;
import com.unfi.cbk.forms.ChargebackSearchForm;
import com.unfi.cbk.util.ActionMessages;
import com.unfi.cbk.util.ActionUrlMapping;
import com.unfi.cbk.util.Constants;
import com.unfi.cbk.util.SpringUtils;


/**
 * The NewSearchAction class is the struts action called for the 
 * search criteria entry page.
 * The action sets the user data in the request, sets any values
 * needed for the form, and forwards to the JSP specific to the userType.
 *
 * @author      vpil001
 * @since       1.0
 */
@Controller("newSearchAction_chargeback")
@Scope(value=WebApplicationContext.SCOPE_REQUEST, proxyMode=ScopedProxyMode.TARGET_CLASS)
public class ChargebackNewSearchAction {//extends Action { 
	static Logger log = Logger.getLogger(ChargebackNewSearchAction.class);
	@Autowired
	ActionMessages errors;
	@Autowired
    private ChargebackSearchDelegate chargebackSearchDelegate;
	/*
	 * public ChargebackNewSearchAction(ChargebackSearchDelegate
	 * chargebackSearchDelegate) { this.chargebackSearchDelegate =
	 * chargebackSearchDelegate; }
	 */
	
	//Externalize this value
    @Value("${cbk.autoGrowCollectionLimit:100000}")
    private int autoGrowCollectionLimit;
    @InitBinder
    public void initBinder(WebDataBinder dataBinder) {
        dataBinder.setAutoGrowCollectionLimit(autoGrowCollectionLimit);
    }
	/* (non-Javadoc)
	 * @see org.apache.struts.action.Action#execute(org.apache.struts.action.ActionMapping, org.apache.struts.action.ActionForm, javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	@RequestMapping(value = "/newChargebackSearch", method = {RequestMethod.GET,RequestMethod.POST})
	public ModelAndView execute(
		@ModelAttribute("chargebackSearchForm") ChargebackSearchForm chargebackSearchForm,
		HttpServletRequest request,
		HttpServletResponse response)
		throws Exception {
		System.out.println("***** CHARGEBACK SEARCH *****-NewSearchAction.java-- execute()---");
		ModelAndView mav = new ModelAndView();
		//ActionErrors errors = new ActionErrors();
		//ActionMessages errors = new ActionMessages();
		//ActionForward forward = new ActionForward(); // return value
		//DocumentSearchForm documentSearchForm = (DocumentSearchForm) form;
		chargebackSearchForm.setFormParameterMap(request);
		
		if(request.getParameter("isformreset") !=null)
		{
			chargebackSearchForm.reset(request);
		}
		String userType = null;
		if (request.getAttribute("userType") != null){	
			userType = (String) request.getAttribute("userType");
		}
		boolean exceptionOccurred = false;
		
		System.out.println("---userType--"+userType);
		log.debug("***** CHARGEBACK SEARCH *****");
		System.out.println("--*** CHARGEBACK SEARCH ******--");
		
		boolean Approver = true;
		
		//if ( request.getParameter("update") == null || request.getParameter("update").equals("") ) {
		
		if(Approver) {
			String searchCBK = (String)request.getParameter("searchCBK");
			System.out.println("-------searchCBK------"+searchCBK);
			
			if(searchCBK!=null) {
				
			//Get the ChargebackType list
		  List chargebackTypes = chargebackSearchDelegate.getChargebackTypes();
		  System.out.println("----RETURN LIST----chargebackTypes--"+chargebackTypes.size());
		  chargebackSearchForm.setChargebackTypes(chargebackTypes);
		  System.out.println("----RETURN LIST----");
		 
		// Get the document date range in months
		/*
		MaintenanceDaoImpl mdi = (MaintenanceDaoImpl)SpringUtils.getBeanFromRequest(request, "maintenanceDao");
		Integer months = mdi.getDocDateRange();
		chargebackSearchForm.setMaxMonths(months);
		*/
		/*
		if (!exceptionOccurred) {
			System.out.println("-----------TRUE-------");
			//	Logic to determinine how the user should be forwarded.
			if (userType == null || userType.equals("")) {
				errors.add("error", "errors.invalidrole",null);
				//forward = mapping.findForward("failure");
				mav.setViewName(ActionUrlMapping.GLOBAL.get(Constants.ACTION_FAILURE));
						
			} else {
				//forward = mapping.findForward("success");
				mav.setViewName(ActionUrlMapping.CHARGEBACKNEWSEARCHACTION.get(Constants.ACTION_SUCCESS));
			}
					
		}
				
		//	If a message is required, save the specified key(s) into the request.
		if (!errors.isEmpty()) {
			log.debug("FAILED");
			//saveMessages(request, errors);
			errors.saveMessages(request);
		}
			*/	
		// Finish with
		//return (forward);
		mav.setViewName(ActionUrlMapping.CHARGEBACKNEWSEARCHACTION.get(Constants.ACTION_SUCCESS));
		System.out.println("URL mapping"+mav.getViewName());
		request.setAttribute("actionMessages", errors);
		request.setAttribute("chargebackSearchForm", chargebackSearchForm);
		}
			else
			{
				mav.setViewName(ActionUrlMapping.AVAILABLECHARGEBACKACTION.get(Constants.ACTION_SUCCESS));
				System.out.println("URL mapping"+mav.getViewName());
				request.setAttribute("actionMessages", errors);
				request.setAttribute("chargebackSearchForm", chargebackSearchForm);
			}
		}
		else {
			//Available Chargebacks List
			//ResultList searchResults = chargebackSearchDelegate.getAvailableChargebacks();
			//System.out.println("-------------getAvailableChargebacks()------searchResults--size----------"+searchResults.getList().size());
			
			//  Populate the 'searchResults' property in the ActionForm
			///chargebackSearchForm.setSearchResults(searchResults.getList());
			
			
			mav.setViewName(ActionUrlMapping.AVAILABLECHARGEBACKACTION.get(Constants.ACTION_SUCCESS));
			System.out.println("URL mapping"+mav.getViewName());
			request.setAttribute("actionMessages", errors);
			request.setAttribute("chargebackSearchForm", chargebackSearchForm);
			
			
			
		}
		return mav;

	}
	
	
	
	
	
	
}
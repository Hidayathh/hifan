package com.unfi.cbk.bo;

import com.unfi.cbk.util.Constants;
import com.unfi.cbk.util.DateFunctions;
import java.util.Date;
import java.util.List;


/**
 * The Chargeback class is a means for representing a single result
 * when searching for Chargebacks.
 * <p>
 * Each property represents a column in the display table.
 *
 * @author		vpil001
 * @since       1.0
 */
public class ChargebackBO {
	
	/*
	 * CBK
	 */
	
	private String invoiceNumber;
	private String locationNumber;
	private Date invoiceDate;
	private String vendorId;
	private String netAmount;
	private String originator;
	private String approver;
	private String fin;
	private String ca;
	private int documentNumber;
	
	private Integer typeId;
	private String typeName;
	private Integer memberCount;
	private List memberList;
	private String documentEncKey;
	private Date checkDate;
	private Date bankClearDate;
	private Date dueDate;
	private String batchId;
	private String docType;
	private String mimeType;
	private String notFound;
	private String creatorId;
	public String getCreatorId() {
		return creatorId;
	}

	public void setCreatorId(String creatorId) {
		this.creatorId = creatorId;
	}

	public String getReasonCode() {
		return reasonCode;
	}

	public void setReasonCode(String reasonCode) {
		this.reasonCode = reasonCode;
	}

	public String getPrdGrpCode() {
		return prdGrpCode;
	}

	public void setPrdGrpCode(String prdGrpCode) {
		this.prdGrpCode = prdGrpCode;
	}

	private String reasonCode;
	private String prdGrpCode;
	
	
	
	
	
	
	public Integer getTypeId() {
		return typeId;
	}

	public void setTypeId(Integer typeId) {
		this.typeId = typeId;
	}

	public String getTypeName() {
		return typeName;
	}

	public void setTypeName(String typeName) {
		this.typeName = typeName;
	}

	public Integer getMemberCount() {
		return memberCount;
	}

	public void setMemberCount(Integer memberCount) {
		this.memberCount = memberCount;
	}

	public List getMemberList() {
		return memberList;
	}

	public void setMemberList(List memberList) {
		this.memberList = memberList;
	}

	public String getInvoiceNumber() {
		return invoiceNumber;
	}

	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}

	public String getLocationNumber() {
		return locationNumber;
	}

	public void setLocationNumber(String locationNumber) {
		this.locationNumber = locationNumber;
	}

	public String getVendorId() {
		return vendorId;
	}

	public void setVendorId(String vendorId) {
		this.vendorId = vendorId;
	}

	public int getDocumentNumber() {
		return documentNumber;
	}

	public void setDocumentNumber(int documentNumber) {
		this.documentNumber = documentNumber;
	}

	
	
	public Date getInvoiceDate() {
		return invoiceDate;
	}

	public void setInvoiceDate(Date invoiceDate) {
		this.invoiceDate = invoiceDate;
	}

	/*
	 * public String getVendor() { return vendor; }
	 * 
	 * public void setVendor(String vendor) { this.vendor = vendor; }
	 */

	public String getNetAmount() {
		return netAmount;
	}

	public void setNetAmount(String netAmount) {
		this.netAmount = netAmount;
	}

	public String getOriginator() {
		return originator;
	}

	public void setOriginator(String originator) {
		this.originator = originator;
	}

	public String getApprover() {
		return approver;
	}

	public void setApprover(String approver) {
		this.approver = approver;
	}

	public String getFin() {
		return fin;
	}

	public void setFin(String fin) {
		this.fin = fin;
	}

	public String getCa() {
		return ca;
	}

	public void setCa(String ca) {
		this.ca = ca;
	}

	
	
	
	
	
	
	
	public String getNotFound() {
		return notFound;
	}

	public void setNotFound(String notFound) {
		this.notFound = notFound;
	}

	public String getInvoiceDateString(){
		String s = null;
		if (invoiceDate != null){
			s = DateFunctions.formatDate(invoiceDate);
		}
		return s;
	}
	
	public void setInvoiceDateString(String s){
		if (s != null && s.trim().length() > 0){
			invoiceDate = DateFunctions.stringToDate(s);
		}
	}
	
	
	
	
	/**
	 * Get documentEncKey
	 * @return String
	 */
	public String getDocumentEncKey() {
		return documentEncKey;
	}
	/**
	 * Set documentEncKey
	 * @param string	<code>String</code> to set
	 */
	public void setDocumentEncKey(String string) {
		documentEncKey = string;
	}
	
	public String getCheckDateString() {
		String s = null;
		if (checkDate != null){
			s = DateFunctions.formatDate(checkDate);
		}
		return s;
	}
	
	public void setCheckDateString(String s){
		if (s != null && s.trim().length() > 0){
			checkDate = DateFunctions.stringToDate(s);
		}
	}

	

	
	/**
	 * @return
	 */
	public Date getBankClearDate() {
		return bankClearDate;
	}

	/**
	 * @param date
	 */
	public void setBankClearDate(Date date) {
		bankClearDate = date;
	}
	
	public String getBankClearDateString() {
		String s = null;
		if (bankClearDate != null){
			s = DateFunctions.formatDate(bankClearDate);
		}
		return s;
	}

	/**
	 * @return
	 */
	public String getMimeType() {
		return mimeType;
	}

	/**
	 * @param string
	 */
	public void setMimeType(String string) {
		mimeType = string;
	}

	/**
	 * @return
	 */
	public Date getDueDate() {
		return dueDate;
	}

	/**
	 * @param date
	 */
	public void setDueDate(Date date) {
		dueDate = date;
	}
	
	public String getDueDateString() {
		String s = null;
		if (dueDate != null){
			s = DateFunctions.formatDate(dueDate);
		}
		return s;
	}

}
/*
 * Created on Feb 8, 2006
 * 
 */
package com.unfi.cbk.actions;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;

import com.unfi.cbk.beans.UserDataBean;

import com.unfi.cbk.util.SpringUtils;
import com.unfi.cbk.utilcore.ApplicationProperties;

/**
 * 
 * @author yhp6y2l
 *
 */
public class PageAccessResolver {
	
	private static Logger log = Logger.getLogger(PageAccessResolver.class);
	
	private HttpServletRequest request;
	
	public PageAccessResolver(HttpServletRequest request){
		this.request = request;
	}
	
	public boolean hasAccess(){
		boolean ret = false;
		
		UserDataBean user = new UserDataBean (request);
		if (user.isEmployee()){
			//  Changed 10/12/2006 - JKW
			//  Update employee users should NOT be able to create PASS#'s.
			//  Only Vendor Correspondence employees can create.
			//ret = (user.isVendorCorrespondence());
			ret= true;
			//ret = (user.isUpdate() || user.isVendorCorrespondence());
			
		} else {
			String control = ApplicationProperties.getPageControlFlag();
			if (control != null && "yes".equalsIgnoreCase(control.trim())){			
				String action = request.getServletPath();
				log.debug("Action for control: " + action);
				//String entityValue = user.getEntityValue();
				String entityValue= "true";
				if (entityValue != null && entityValue.trim().length() > 0){
					//if the entityValue is numeric, strip off the leading 0s
					int temp = 0;
					try{
						temp = Integer.parseInt(entityValue);
					}
					catch(Exception e){
						
					}
					if (temp != 0){
						
						entityValue = String.valueOf(temp);						
					}
//					//entityValue = String.valueOf(Integer.valueOf(entityValue));
//					CbkCommonDao dao = (CbkCommonDao) SpringUtils.getBeanFromRequest(request, "passCommonDao");
//					try{
//						VendorControl vc = dao.getVendorPageAccessCtrl(entityValue,action);
//						if (vc != null){							
//							ret = true;
//						}
//					}
//					catch(Exception e){
//						log.error("Error in Access Control");
//					}
				}
			} else{
				//we are not limiting access to the pass creation
				ret = true;
			}
		}
		return ret;		
	}

}

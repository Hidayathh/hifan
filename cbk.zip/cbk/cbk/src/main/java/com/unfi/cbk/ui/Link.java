package com.unfi.cbk.ui;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Vector;

import org.apache.log4j.Logger;

public class Link {
	static Logger log = Logger.getLogger(Link.class);
	
	// use the following variables for recursion
	private Link parent;
	private Vector children;
	// a list of all the child ID's in the Vector
	private List childIDs;
	
	// standard link properties
	private String ID;
	private String url;
	private String alt;
	private String text;
	private String type;
	private String breadCrumbOnClick;
	
	// buttons tied to the link
	private ButtonCollection buttons;
	// roles for this link
	private Roles roles;
	
	// add a child link while setting the parent into the child
	public void addChild(Link link) {
		if (children == null) {
			children = new Vector();
		}
		if (childIDs == null) {
			childIDs = new ArrayList();
		}
	
		// set the parent into the child
		link.setParent(this);
		
		//log.debug("Now adding the child link: "+ link.getAlt() +" to link: "+ this.getAlt() );
		// ass the child link to the vector of childeren
		children.add(link);
		// add the link to the child ID list
		childIDs.add(link.getID());
	}
	
	public Link getChild(String ID) {
		Link childLink = null;
		// if the link has childeren check for the requested link
		if ((childIDs != null) && (children != null)) {
		
			// if this link contains the child I'm looking for return it
			if (childIDs.contains(ID)) {
				for (int i=0; i < children.size(); i++){
					// if the ID's match return the link
					if ((((Link) children.get(i)).getID()).equalsIgnoreCase(ID)) {
						childLink = (Link) children.get(i);
						break; // break out of the loop
					}
				}
			}
		
			if (childLink == null) {
				// this link does not contain the child but it's children might?
				for (int i=0; i < children.size(); i++){
					// ask this link's childeren to search for the requested link
					childLink = ((Link) children.get(i)).getChild(ID);
					// we have found our link!
					if (childLink != null) {
						break;// break out of the loop
					}
				}
			}
		}
	
		return childLink;
	}
	
	// return a link based on the number in the collection
	public Link getChild(int i) {
		Link childLink = null;
	
		try {
			childLink = (Link) children.get(i);
		} catch (Exception e) {
			log.error("Unable to return a link at "+ i+ " "+ e);
		}
	
		return childLink;
	}
	
	public String getBreadcrumbs(String ID) {
		if (ID.equals("0")) {
			return "&nbsp;";
		}
		StringBuffer buf = new StringBuffer();
		
		String divider = " &gt; ";
		
		//log.debug("Value = " + this.getID());
		
		if (this.getID().equals(ID)) {
			buf.insert(0, "<strong>" + this.getText() + "</strong>");
		} else {
			if (this.getBreadCrumbOnClick() == null) {
				//add the link to the crumb
				buf.insert(0," <a href=\""+this.getUrl()+"\"/>"+this.getText()+"</a>");
			} else {
				buf.insert(0," <a href=\"javascript:;\"/ onClick=\""+ this.getBreadCrumbOnClick()+" return false;\">"+this.getText()+"</a>");
			}
		}
		
		// make the parents do the same
		if (this.getParent() != null) {
			buf.insert(0, divider);
			buf.insert(0,this.getParent().getBreadcrumbs(ID));
		}

		return buf.toString();
	}
	
	public String getTopLinkID() {
		String ID = this.getID();
		if (this.getID().indexOf("-") > 0) {
			// remove any child IDs from the main ID
			ID = this.getID().substring(0, ID.indexOf("-"));
		}
		return ID;
	}
	
	public ButtonCollection getButtons() {
		return buttons;
	}
	
	public boolean hasButtons() {
		if (buttons == null) {
			return false; 
		} else {
			return true;
		}
	}

	public Collection getChilderen() {
		return children;
	}

	public String getID() {
		return ID;
	}

	public Link getParent() {
		return parent;
	}

	public Roles getRoles() {
		if (roles == null) {
			roles = new Roles();
		}
		return roles;
	}

	public String getText() {
		return text;
	}

	public String getAlt() {
		return alt;
	}

	public String getType() {
		return type;
	}

	public String getUrl() {
		return url;
	}

	public void setButtons(ButtonCollection collection) {
		buttons = collection;
	}

	public void setChilderen(Vector map) {
		children = map;
	}

	public void setID(String string) {
		ID = string;
	}

	public void setParent(Link link2) {
		parent = link2;
	}

	public void setRoles(Roles roles) {
		this.roles = roles;
	}

	public void setText(String string) {
		text = string;
	}

	public void setAlt(String string) {
		alt = string;
	}

	public void setType(String string) {
		type = string;
	}

	public void setUrl(String string) {
		url = string;
	}
	public List getChildIDs() {
		return childIDs;
	}

	public void setChildIDs(List list) {
		childIDs = list;
	}

	public String getBreadCrumbOnClick() {
		return breadCrumbOnClick;
	}

	public void setBreadCrumbOnClick(String string) {
		breadCrumbOnClick = string;
	}
	
}
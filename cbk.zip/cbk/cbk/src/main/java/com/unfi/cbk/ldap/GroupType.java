/*
 * GroupType.java
 *
 * Created on April 11, 2001, 11:13 AM
 */
package com.unfi.cbk.ldap;

import com.unfi.cbk.ldaputil.CompareTo;

/**
 * Class to hold Group Type information.
 * @author: yhp6y2l
 */
public class GroupType extends Object implements CompareTo
{
    private String type;        // "DC".
    private String description; // "Distribution Center.

    public String getType()         {return(type);}
    public String getDescription()  {return(description);}

    /** Creates new GroupType */
    public GroupType(String type,
                     String description) 
    {
        super();

        this.type = type;
        this.description = description;
    }

    // Sorts by description.
    public int compareTo(java.lang.Object groupTypeObj) {
        int ret = description.toLowerCase().compareTo(((GroupType)groupTypeObj).description.toLowerCase());
        
        return(ret);
    }
}

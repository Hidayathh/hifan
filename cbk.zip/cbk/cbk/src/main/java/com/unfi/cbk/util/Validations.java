package com.unfi.cbk.util;

import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Vector;

import javax.sql.rowset.CachedRowSet;

import org.apache.commons.validator.GenericValidator;
import org.apache.log4j.Logger;
import org.springframework.web.multipart.MultipartFile;

import com.unfi.cbk.dao.DaoFactory;
import com.unfi.cbk.util.ESAPIUtil;
import com.unfi.cbk.utilcore.ApplicationProperties;
import com.unfi.cbk.utilcore.DaoDBUtil;
import com.unfi.cbk.ldap.SVHarborLDAPFuncs;


/**
 * The Validations class is used to perform server-side validations that
 * can't be done by the struts validator.
 *
 * @author      yhp6y2l
 * @since       1.0
 */
public class Validations extends DaoDBUtil implements Serializable {
	static Logger log = Logger.getLogger(Validations.class);	
	
	/**
	 * Determines if a given location number exists in the database.
	 * This method takes a location number and does a search against the
	 * database to see if it exists.
	 * 
	 * @return						true if the location number was found, otherwise false
	 * @param locationNumber		the location number <code>String</code> to validate
	 * @param errors				the <code>ActionErrors</code> object to write errors to for this request
	 * @param environmentResources	the <code>MessageResources</code> object for this environment
	 * @since						1.0
	 */
	public boolean isValidLocationNumber(String locationNumber) {
		boolean isValid = false;
		CachedRowSet resultsBean = null;
		
		try {
			// Verify a location number was passed from the form
			if (locationNumber == null || locationNumber.equals("")) {
				// No location was passed - do not validate
				isValid = true;
				
			} else {
				// A location number was passed - proceed
				// Get the DB schema name specific to the server environment
				String dbSchema = ApplicationProperties.getDBSchema();
				
				// Define SQL for PreparedStatement
				String sql = "SELECT * FROM " + dbSchema + ".ap_proc_lev_loc WHERE location_nbr = ?";
				// Define all parameters for above PreparedStatement (for each '?' in the SQL)
				Vector stmtParams = new Vector();
				stmtParams.add(0, locationNumber);
				
				// Run the query
				resultsBean = (CachedRowSet) executeSQLQuery(sql,stmtParams,Constants.EXECUTE_TYPE_SELECT);
				
				// Get the number of results
				int resultCount = getResultCount(resultsBean);
				
				if (resultCount > 0) {
					isValid = true;					
				}				
			}
			
		} catch (Exception e) {
			log.error("Exception in isValidLocationNumber():" + e);
			isValid = false;
			
		} finally {
			try{
				resultsBean.close();
			} catch(Exception ignore){}
			
			log.debug(ESAPIUtil.encode("isValidLocationNumber (" + locationNumber + "): " + isValid));
			return isValid;
		}
	
	}
    
    /**
     * Verify the from date is less than the to date.
     * 
     * @param fromDate
     * @param toDate
     * @return
     */
    public boolean isValidDateRange(String fromDate, String toDate) {
    	boolean isValid = true;
        try {
			Date fromDateObj = DateFunctions.stringToDate(fromDate);
	        Date toDateObj = DateFunctions.stringToDate(toDate);
	        
	        //  If either date object is null, there was a problem parsing the
	        //  date, so assume that it isn't a valid date.
	        if ( fromDateObj == null || toDateObj == null ) {
				isValid = false;
				
	        } else {
				//  Verify condition
				int dateCompare = DateFunctions.compareDates(fromDateObj, toDateObj);
				
				if (dateCompare > 0) {
					//  The from date is greater than the to date - invalid.
					isValid = false;
				}
	        }	                

        } catch (Exception e) {
			log.error("Exception in isValidDateRange():" + e);
			isValid = false;
        }
        
        //log.debug("isValidDateRange: " + isValid);
        return isValid;
    }
    
    /**
     * Verify neither date goes back farther than the passed in number of years 
     * 
     * @param fromDate
     * @param toDate
     * @param maxYears
     * @return
     */
    public boolean isValidTimePeriod(String fromDate, String toDate, String maxYears) {
		boolean isValid = true;
		try {
	        Date fromDateObj = DateFunctions.stringToDate(fromDate);
	        Date toDateObj = DateFunctions.stringToDate(toDate);
	
	        //  If either date object is null, there was a problem parsing the
	        //  date, so assume that it isn't a valid date.
	        if ( fromDateObj == null || toDateObj == null ) {
				isValid = false;
	        } else {
				//  Verify condition
				int maxYearsToGoBack = -Integer.parseInt(maxYears);
				Date maxYearsAgo = DateFunctions.adjustCurrentDateNoFormat(maxYearsToGoBack);
	        
				int dateCompare1 = DateFunctions.compareDates(maxYearsAgo, fromDateObj);
				int dateCompare2 = DateFunctions.compareDates(maxYearsAgo, toDateObj);
				
				if (dateCompare1 > 0 || dateCompare2 > 0) {
					//  One of the dates is more than the max specified years ago - invalid
					isValid = false;
				}
	        	
	        }
	        
		} catch (Exception e) {
			log.error("Exception in isValidTimePeriod():" + e);
			isValid = false;
		}

        //log.debug("isValidTimePeriod: " + isValid);         
        return isValid;
    }
    
    /**
     * Verify neither date is in the future
     * 
     * @param fromDate
     * @param toDate
     * @return
     */
    public boolean isNotFutureDate(String fromDate, String toDate) {
        boolean isValid = true;
        try {
       		Date fromDateObj = DateFunctions.stringToDate(fromDate);
	        Date toDateObj = DateFunctions.stringToDate(toDate);
	
	        //  If either date object is null, there was a problem parsing the
	        //  date, so assume that it isn't a valid date.
	        if ( fromDateObj == null || toDateObj == null ) {
				isValid = false;
	        } else {
				//  Verify condition (3)
				int dateCompare1 = DateFunctions.compareDates(fromDateObj, new Date());
				int dateCompare2 = DateFunctions.compareDates(toDateObj, new Date());
	        
				if (dateCompare1 > 0 || dateCompare2 > 0) {
					//  One of the dates is a future date - invalid
					isValid = false;
				}
	        }
	
        } catch (Exception e) {
			log.error("Exception in isNotFutureDate():" + e);
			isValid = false;
        }
        
        //log.debug("isNotFutureDate:" + isValid);
        return isValid;
    }
    
    /**
     * Verify neither date is in the future
     * 
     * @param fromDate
     * @param toDate
     * @return
     */
    public boolean isNot30PlusDaysInFuture(String fromDate, String toDate) {
        boolean isValid = true;
        try {
       		Date fromDateObj = DateFunctions.stringToDate(fromDate);
	        Date toDateObj = DateFunctions.stringToDate(toDate);
	
	        //  If either date object is null, there was a problem parsing the
	        //  date, so assume that it isn't a valid date.
	        if ( fromDateObj == null || toDateObj == null ) {
				isValid = false;
	        } else {
				//  Verify condition (3)
	        	
	        	Date testDate1 = DateFunctions.adjustCurrentDateByDaysNoFormat(30);
	        	
				int dateCompare1 = DateFunctions.compareDates(fromDateObj, testDate1);
				int dateCompare2 = DateFunctions.compareDates(toDateObj, testDate1);
	        
				if (dateCompare1 > 0 || dateCompare2 > 0) {
					//  One of the dates is a future date - invalid
					isValid = false;
				}
	        }
	
        } catch (Exception e) {
			log.error("Exception in isNot30PlusDaysInFuture():" + e);
			isValid = false;
        }
        
        //log.debug("isNotFutureDate:" + isValid);
        return isValid;
    }
    
	/**
	 * Takes a vendor ID and adds any leading zeros needed to make it 7 digits.
	 * 
	 * @return			the formatted vendor ID
	 * @param vendorId	the vendor ID to format
	 * @since			1.0
	 */
	public static String formatVendorId(String vendorId) {
		StringBuffer formattedVendorId = new StringBuffer(vendorId);
		int targetLength = 7;
		
		while (formattedVendorId.length() < targetLength) {
			formattedVendorId.insert(0, "0");
			
		}
		
		return formattedVendorId.toString();
		
	}
	
	public boolean isValidVendor(String vendorId){
		boolean isValid = false;
		CachedRowSet resultsBean = null;
		
		try {
			// Get the DB schema name specific to the server environment
			String dbSchema = ApplicationProperties.getDBSchema();
			
			// Define SQL for PreparedStatement			
			String sql = "SELECT * FROM " + dbSchema + ".SVH_APVENMAST WHERE VENDOR_GROUP='SVVG' AND VENDOR=?";
			// Define all parameters for above PreparedStatement (for each '?' in the SQL)
			Vector stmtParams = new Vector();
			stmtParams.add(0, StringFunctions.spaceFillLeft(vendorId,9,true));
		
			// Run the query
			resultsBean = (CachedRowSet) executeSQLQuery(sql,stmtParams,Constants.EXECUTE_TYPE_SELECT);
		
			// Get the number of results
			int resultCount = getResultCount(resultsBean);
		
			if (resultCount > 0) {
				isValid = true;
			}			
						
		} catch (Exception e) {
			log.error("Exception in isValidVendor():" + e);
			isValid = false;
	
		} finally {
			try {
				resultsBean.close();			
			} catch (Exception ignore){}
			
			log.debug(ESAPIUtil.encode("isValidVendor(" + vendorId + "):" + isValid));
			return isValid;			
		}
		
	}
	
	
    
    public boolean isValidUserId(String userId) {
        LDAPHandler lh = new LDAPHandler(userId);
        SVHarborLDAPFuncs ldap = null;

        boolean isValid = false;

        try {
            ldap = lh.getLDAPConnection();
            isValid = ldap.existUser(userId);
        } catch (Exception e) {
            log.error("Could not get LDAP connection: " + e.getMessage());
        } finally {
            try {
                lh.closeLDAPConnection(ldap);
            } catch (Exception ignore) {}
            
			log.debug("isValidUserId(" + userId + "):" + isValid);
			return isValid;
        }		
    }
    
    public boolean isValidDocumentNumber(String docNum) {
        return GenericValidator.isInt(docNum);
    }
    
    public boolean isValidAmount(String amount) {
        return GenericValidator.isDouble(amount);
    }
    
	public boolean isValidAttachment(MultipartFile attachment){
		boolean isValid = true;
		
		try {
			if (attachment != null && !attachment.getName().equals("")){
				log.debug("Uploaded file " + attachment.getName() + ": " + attachment.getSize() + " bytes");
				if (attachment.getSize() > Constants.MAX_ATTACHMENT_SIZE_BYTES) {
					isValid = false;
				}
			}
						
		} catch (Exception e) {
			log.error("Exception in isValidAttachment():" + e);
			isValid = false;
		}
		
		log.debug("isValidAttachment:" + isValid);
		return isValid;
	}
	
	/**
	 * Verify the date does not go back farther than the passed in number of months 
	 * 
	 * @param docDate
	 * @param maxYears
	 * @return
	 */
	public boolean isValidTimePeriodMonths(String docDate, int maxMonths){		
		Date date = DateFunctions.stringToDate(docDate);
		if (date == null){
			return false;
		}
		Date today = new Date();
		Calendar now = Calendar.getInstance();
		now.setTime(today);
		Calendar testDate = Calendar.getInstance();
		testDate.setTime(date);
		testDate.add(Calendar.MONTH, maxMonths);
		if (testDate.before(now)){
			return false;
		} else {
			return true;
		}
	}
	
	/**
	 * Verify neither date goes back farther than the passed in number of months 
	 * 
	 * @param fromDate
	 * @param toDate
	 * @param maxYears
	 * @return
	 */
	public boolean isValidTimePeriodMonths(String fromDate, String toDate, int maxMonths){		
		Date fromDateObj = DateFunctions.stringToDate(fromDate);
		Date toDateObj = DateFunctions.stringToDate(toDate);
		if (fromDateObj == null || toDateObj == null){
			return false;
		}
		Date today = new Date();
		Calendar now = Calendar.getInstance();
		now.setTime(today);
		Calendar testDate = Calendar.getInstance();
		testDate.setTime(fromDateObj);
		testDate.add(Calendar.MONTH, maxMonths);
		if (testDate.before(now)){
			return false;
		} 
		testDate.setTime(toDateObj);
		testDate.add(Calendar.MONTH, maxMonths);
		if (testDate.before(now)){
			return false;
		} 
		return true;
		
	}
}
package com.unfi.cbk.forms;

import java.util.List;

import org.apache.log4j.Logger;


/**
 * The VendorSelectorForm class is the struts action form used
 * for the vendor selector pop up.  It extends
 * the ValidatorActionForm class in order to utilize built-in
 * struts validation.
 *
 * @author      yhp6y2l
 * @version     1.0
 */
public class VendorSelectorForm {//extends ValidatorActionForm {
	static Logger log = Logger.getLogger(VendorSelectorForm.class);

	private String vendorNumber = null;
	private String vendorName = null;
	private List searchResults = null;
	private Integer results = null;
	private String selectedResult = null;

	/**
	 * @return
	 */
	public Integer getResults() {
		return results;
	}

	/**
	 * @return
	 */
	public String getVendorName() {
		return vendorName;
	}

	/**
	 * @return
	 */
	public String getVendorNumber() {
		return vendorNumber;
	}

	/**
	 * @return
	 */
	public List getSearchResults() {
		return searchResults;
	}

	/**
	 * @param i
	 */
	public void setResults(Integer i) {
		results = i;
	}

	/**
	 * @param string
	 */
	public void setVendorName(String string) {
		vendorName = string;
	}

	/**
	 * @param string
	 */
	public void setVendorNumber(String string) {
		vendorNumber = string;
	}
	
	/**
	 * @param list
	 */
	public void setSearchResults(List list) {
		searchResults = list;
	}

	/**
	 * @return
	 */
	public String getSelectedResult() {
		return selectedResult;
	}

	/**
	 * @param string
	 */
	public void setSelectedResult(String string) {
		selectedResult = string;
	}

}
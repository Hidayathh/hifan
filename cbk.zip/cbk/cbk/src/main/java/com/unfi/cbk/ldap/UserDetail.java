/*
 * UserDetail.java
 *
 * Created on March 16, 2001, 11:52 AM
 */
package com.unfi.cbk.ldap;
import com.unfi.cbk.ldaputil.CompareTo;
import com.unfi.cbk.ldaputil.Comparer;

/**
 * Class to hold User Detail information.
 * @author: yhp6y2l
 */
public class UserDetail extends Object implements CompareTo
{
    private String loginID;
    private String firstName;
    private String lastName;
    private String middleInitial;
    private String fullName;
    private String storeNumber;
    private String region;
    private String title;
    private String phoneNumber;
    private String emailType;
    private String emailAddress;
    
    public String getLoginID()          {return(loginID);}
    public String getFirstName()        {return(firstName);}
    public String getLastName()         {return(lastName);}
    public String getMiddleInitial()    {return(middleInitial);}
    public String getFullName()         {return(fullName);}
    public String getStoreNumber()      {return(storeNumber);}
    public String getRegion()           {return(region);}
    public String getVendorID()         {return (getUserType().equalsIgnoreCase("Vendor") ? storeNumber : null);}
    public String getBrokerNumber()     {return (getUserType().equalsIgnoreCase("Broker") ? storeNumber : null);}
    public String getCarrierID()        {return (getUserType().equalsIgnoreCase("Carrier") ? storeNumber : null);}
    public String getTitle()            {return(title);}
    public String getPhoneNumber()      {return(phoneNumber);}
    public String getEmailType()        {return(emailType);}
    public String getEmailAddress()     {return(emailAddress);}

	/**
	 * Returns "Vendor", "Broker", "Carrier", "Store" or "Admin"
	 * depending on what type of user this is.
	 * @return java.lang.String
	 */
	public String getUserType()
	{
		String rc;

		if (region.equalsIgnoreCase("Vendor")) {
			rc = "Vendor";
		}
		else if (region.equalsIgnoreCase("Broker")) {
			rc = "Broker";
		}
		else if (region.equalsIgnoreCase("Carrier")) {
			rc = "Carrier";
		}
		else if (storeNumber.length() > 0) {
			rc = "Store";
		}
		else {
			rc = "Admin";
		}

		return rc;
	}

    /** Creates new UserDetail object */
    public UserDetail(String loginID,
                      String firstName,
                      String lastName,
                      String middleInitial,
                      String fullName,
                      String storeNumber,
                      String region,
                      String title,
                      String phoneNumber,
                      String emailType,
                      String emailAddress)
    {
        super();
        this.loginID = loginID;
        this.firstName = firstName;
        this.lastName = lastName;
        this.middleInitial = middleInitial;
        this.fullName = fullName;
        this.storeNumber = storeNumber;
        this.region = region;
        this.title = title;
        this.phoneNumber = phoneNumber;
        this.emailType = emailType;
        this.emailAddress = emailAddress;
    }
    public int compareTo(java.lang.Object obj) {
        int ret = loginID.toLowerCase().compareTo(((UserDetail)obj).loginID.toLowerCase());
        
        return(ret);
    }
    
}

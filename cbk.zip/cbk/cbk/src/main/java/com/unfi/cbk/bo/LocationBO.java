package com.unfi.cbk.bo;

import com.unfi.cbk.util.StringFunctions;

/**
 * The Location class is a way of representing a single
 * 	result when listing locations.
 * 
 * Each field corresponds to a column in the display table.
 * 
 * @author yhp6y2l
 * @version 1.0
 */
public class LocationBO {
	
	private Integer locationNumber = null;
	

	private String locationName = null;
	private String formattedName;
	private String formattedNumber;

	public Integer getLocationNumber() {
		return locationNumber;
	}

	public void setLocationNumber(Integer locationNumber) {
		this.locationNumber = locationNumber;
	}

	public String getLocationName() {
		return locationName;
	}

	public void setLocationName(String locationName) {
		this.locationName = locationName;
	}

	public void setFormattedName(String formattedName) {
		this.formattedName = formattedName;
	}

	public void setFormattedNumber(String formattedNumber) {
		this.formattedNumber = formattedNumber;
	}

	

	public String getName() {
		return locationName;
	}
    
	public void setName(String string) {
		locationName = string;
	}

	public Integer getNumber() {
        return locationNumber;
	}
    
	public void setNumber(Integer i) {
		locationNumber = i;
	}
	
	public String getId() {
		return locationNumber.toString();
	}
    
	public void setId(String s) {
        
        
        if ( s.trim().equals("") || s == null ) {
            locationNumber = null;            
        }
        else {
            // We need to use parseInt() here instead of decode(), because the
            //  leading zero on the location number causes decode to think the
            //  number is octal format.  This then can cause a NumberFormatException
            //  to be thrown if the location has digits other than 0-7.
            locationNumber = new Integer(Integer.parseInt(s));
        }
	}
	
	public String getFormattedName() {
		StringBuffer formattedLocationName = new StringBuffer();
		int maxNameLength = 31;
		String insertValue = "&nbsp;";
			
		try {			
			String locationNum = StringFunctions.zeroFillLeft(locationNumber.toString(),5);
			formattedLocationName = new StringBuffer(this.locationName);

			int numberOfInsertValuesNeeded = maxNameLength - formattedLocationName.length();
	
			for (int i = 0; i < numberOfInsertValuesNeeded; i++) {
				formattedLocationName.append(insertValue);		
			}
			formattedLocationName.append(locationNum);
	
		} catch (Exception e) {
			//  Ignore
	
		}
        
        return formattedLocationName.toString();
	}
	
	public String getFormattedNumber() {
		String formattedLocationNum = "";
		
		try {			
			formattedLocationNum = StringFunctions.zeroFillLeft(locationNumber.toString(),5);

		} catch (Exception e) {
			//  Ignore

		}

        return formattedLocationNum;
	}
	
	public void setFormattedListName(String string) {
		locationName = formattedName;
	}

}
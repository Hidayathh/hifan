/*
 * ApplicationRole.java
 *
 * Created on March 13, 2001, 2:34 PM
 */
package com.unfi.cbk.ldap;

import com.unfi.cbk.ldaputil.CompareTo;

/**
 * Class to hold Application Role information.
 * Creation date: (04/04/2002 3:34:51 PM)
 * @author: yhp6y2l
 */
public class ApplicationRole extends Object implements CompareTo
{
    private String roleName;
    private String roleDescription;

    public String getName()         {return(roleName);}
    public String getDescription()  {return(roleDescription);}

    /** Creates new ApplicationRole object */
    public ApplicationRole(String roleName,
                           String roleDescription)
    {
        super();

        this.roleName = roleName;
        this.roleDescription = roleDescription;
    }
    
    // Sorts by description.
    public int compareTo(java.lang.Object obj) {
        int ret = roleDescription.toLowerCase().compareTo(((ApplicationRole)obj).roleDescription.toLowerCase());
        
        return(ret);
    }
    
    public boolean equals(Object obj)
    {
	    return(roleName.toLowerCase().equals(((ApplicationRole)obj).roleName.toLowerCase()));
    }    

}

package com.unfi.cbk.actions.chargeback;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.unfi.cbk.beans.ResultList;
import com.unfi.cbk.bo.ChargebackBO;
import com.unfi.cbk.delegates.ChargebackSearchDelegate;
import com.unfi.cbk.forms.ChargebackSearchForm;
import com.unfi.cbk.util.ESAPIUtil;
import com.unfi.cbk.util.ActionMessages;
import com.unfi.cbk.util.Constants;
import com.unfi.cbk.util.DateFunctions;
import com.unfi.cbk.util.StringFunctions;


/**
 * The ExportSearchResultsAction class is the struts action called to
 * export the search results to a CSV file.
 * The action makes the call to the database for the results, parses
 * through each row, and creates a CSV with one line per result row.
 * <p>
 * The resulting text file is sent to the requesing page as the response
 * with the appropriate mime type and response headers set.
 *
 * @author      vpil001
 * @since       1.0
 */
@Controller("exportSearchResultsAction_chargeback")
public class ExportSearchResultsAction {//extends Action {
	static Logger log = Logger.getLogger(ExportSearchResultsAction.class);
	@Autowired
    private ChargebackSearchDelegate chargebackSearchDelegate;
    @Autowired
    ActionMessages error;
  //Externalize this value
    @Value("${cbk.autoGrowCollectionLimit:100000}")
    private int autoGrowCollectionLimit;
    @InitBinder
    public void initBinder(WebDataBinder dataBinder) {
        dataBinder.setAutoGrowCollectionLimit(autoGrowCollectionLimit);
    }
    public ExportSearchResultsAction(ChargebackSearchDelegate chargebackSearchDelegate) {
        this.chargebackSearchDelegate = chargebackSearchDelegate;
    }

	/* (non-Javadoc)
	 * @see org.apache.struts.action.Action#execute(org.apache.struts.action.ActionMapping, org.apache.struts.action.ActionForm, javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
    @RequestMapping(value = "/exportChargebacktResults",method = {RequestMethod.GET,RequestMethod.POST})
	public ModelAndView execute(
		@ModelAttribute("chargebackSearchForm") ChargebackSearchForm chargebackSearchForm,
		HttpServletRequest request,
		HttpServletResponse response)
		throws Exception {
    	chargebackSearchForm.setFormParameterMap(request);
		//ActionErrors errors = new ActionErrors();
    	//ActionMessages errors = new ActionMessages();
		//ActionForward forward = new ActionForward();
		//DocumentSearchForm documentSearchForm = (DocumentSearchForm) form;
		
		ServletOutputStream out = null;

		try { 
			log.debug("***** CHARGEBACK SEARCH - EXPORT *****");
			System.out.println("----CHARGEBACK SEARCH - EXPORT-----");
		//determine if we need to filter the results for SV or SAL
		
		//Commented by Vinod for epass new user role changes
		/*	List filter = null;
			
			if (request.isUserInRole(Constants.SAL_ROLE) || request.isUserInRole(Constants.SV_ROLE)){
				filter = Arrays.asList(Constants.SAL);
				if (request.isUserInRole(Constants.SV_ROLE)){
					exclude = true;					
				}
			}
		*/
			  // chargebackSearchForm.setValue("showAll", "true");
			  HttpSession session=request.getSession();  
		      // session.setAttribute("searchParametersFromForm",searchParametersFromForm); 
			  Map searchParametersFromForm = (Map)session.getAttribute("searchParametersFromForm");
				System.out.println("-------------BEFORE QEURY------------------");
				//  Get the search results based on the parameters in the form
				ResultList chargebacksList = chargebackSearchDelegate.getChargebacks(searchParametersFromForm);
				System.out.println("-------------AFTER QEURY------searchResults--size----------"+chargebacksList.getList().size());
				
			
		/*
			// Get the list of documents from the DB and put it into the bean for the .jsp to use
			ResultList chargebacksList = chargebackSearchDelegate.getChargebacksList(chargebackSearchForm.getMap());
			
			String searchCriteriaSummary = chargebackSearchDelegate.buildSearchCriteriaSummary(chargebackSearchForm.getMap());			
			
			String dateRangeUsed = "";
			if (!searchCriteriaSummary.startsWith("Vendor")) {
				//  Not a broker result
				int firstComma = searchCriteriaSummary.indexOf(",");
				if (firstComma >= 0) {
					dateRangeUsed = searchCriteriaSummary.substring(0, firstComma);
				
				}
			} 
			*/
			String vendorUsed = String.valueOf(chargebackSearchForm.getValue("vendorId"));
			
			out = response.getOutputStream();
			
			// The response headers must be set in the following order, or else IE
			// won't handle things properly.            
			//response.setHeader("Content-length", ""+file.getFile().length());
			response.setHeader("Content-disposition", "attachment; filename=ChargebackSearchResults.csv");
			response.setContentType("text/comma-separated-values");
			response.setHeader("Pragma", "public");
			response.setHeader("Cache-control", "must-revalidate");			
			
			//out.println("Document Results  (" + searchCriteriaSummary + ")");
			out.println("Deduction chargebacks pulled for vendor number: " + vendorUsed);
			out.println("Deduction chargebacks pulled: " + DateFunctions.getTodayTime());
			/*if (!dateRangeUsed.equals("")) {
				out.println("Deduction extract date range: " + dateRangeUsed);
			}	*/	
			out.println();		
			out.println("Invoice, Location, Invoice Date, Vendor, Amount, Originator, Next Approver, FIN, CA");
			
			for (int i = 0; i < chargebacksList.getList().size(); i++ ) {
				ChargebackBO chargebackBO = (ChargebackBO) chargebacksList.getList().get(i);
				
				//  Put a '=' and quotes around the document number to avoid
				//  Excel dropping any leading zeros in the value.
				
				out.print("=\"" + ESAPIUtil.encodeforXSS(StringFunctions.convertNull(chargebackBO.getInvoiceNumber())) + "\"");
				out.print(",");
				out.print(ESAPIUtil.encodeforXSS(StringFunctions.convertNull(chargebackBO.getLocationNumber())));
				out.print(",");
				out.print(ESAPIUtil.encodeforXSS(StringFunctions.convertNull(chargebackBO.getInvoiceDateString())));
				out.print(",");
				out.print(ESAPIUtil.encodeforXSS(StringFunctions.convertNull(chargebackBO.getVendorId())));
				out.print(",");
				out.print(ESAPIUtil.encodeforXSS(StringFunctions.convertNull(chargebackBO.getNetAmount())));
				out.print(",");
				out.print(ESAPIUtil.encodeforXSS(StringFunctions.convertNull(chargebackBO.getOriginator())));
				out.print(",");
				out.print(ESAPIUtil.encodeforXSS(StringFunctions.convertNull(chargebackBO.getApprover())));
				out.print(",");
				out.print(ESAPIUtil.encodeforXSS(StringFunctions.convertNull(chargebackBO.getFin())));
				out.print(",");
				out.print(ESAPIUtil.encodeforXSS(StringFunctions.convertNull(chargebackBO.getCa())));
				out.print("\n");
			}

		} catch (Exception e) {
            e.printStackTrace();
			// Report the error using the appropriate name and ID.
			log.error("Exception in execute():" + e);
		} finally {
			if (out != null) {
				out.close();
			}
			response.flushBuffer();
		}

		// No mappings or forwards for this action...
		return null;
	}
	
}
/*
 * StoreDC.java
 *
 * Created on March 15, 2001, 11:46 AM
 */
package com.unfi.cbk.ldap;

import java.util.Vector;

import com.unfi.cbk.ldaputil.Comparer;
import com.unfi.cbk.ldaputil.VectorFuncs;

/**
 * Class to hold Store DC information.
 * @author: yhp6y2l
 */
public class StoreDC extends Object
{
    private String storeNumber;
    private String name;
    private String distributionCenter;
    private String region;
    
    public String getStoreNumber()  {return(storeNumber);}
    public String getName()         {return(name);}
    public String getDC()           {return(distributionCenter);}
    public String getRegion()       {return(region);}

    public void setDC(String dc)          {this.distributionCenter = dc;}
    public void setRegion(String region)  {this.region = region;}
    
    /** Creates new StoreDC object */
    public StoreDC(String storeNumber,
                   String name,
                   String dc,
                   String region)
    {
        super();

        this.storeNumber = storeNumber;
        this.name = name;
        this.distributionCenter = dc;
        this.region = region;
    }

    /**
     * Compares this StoreDC to the specified object.
     * The result is true if and only if the argument is not 
     * null and is a StoreDC object that represents 
     * the same store group as this object.
     *
     * @param   anObject   the object to compare this StoreDC against.
     * @return  true if the StoreDCs are equal;
     *          false otherwise.
     */
    public boolean equals(Object anObject)
    {
        if (this == anObject) {
            return(true);
        }

        if (anObject instanceof StoreDC) {
            StoreDC tStoreDC = (StoreDC) anObject;

            if ((this.getStoreNumber().equalsIgnoreCase(tStoreDC.getStoreNumber())) &&
                (this.getName().equalsIgnoreCase(tStoreDC.getName())) &&
                (this.getDC().equalsIgnoreCase(tStoreDC.getDC())) &&
                (this.getRegion().equalsIgnoreCase(tStoreDC.getRegion()))) {

                return(true);
            }
        }

        return(false);
    }
    
    // Sorts by Region + DC + Store Number.
    private static class RegionDCNumberOrder implements Comparer
    {
        public int compare(java.lang.Object o1, java.lang.Object o2)
        {
            int ret;
            
            ret = ((StoreDC)o1).region.toLowerCase().compareTo(((StoreDC)o2).region.toLowerCase());

            ret = ret == 0 ? ((StoreDC)o1).distributionCenter.toLowerCase().compareTo(((StoreDC)o2).distributionCenter.toLowerCase()) : ret;
            
            ret = ret == 0 ? ((StoreDC)o1).storeNumber.toLowerCase().compareTo(((StoreDC)o2).storeNumber.toLowerCase()) : ret;

            return(ret);
        }
    }
    
    /**
     * Sorts the Vector of StoreDC objects into order by
     * Region + DC + Store Number.
     */
    public static void sortByRegionDCStoreNumber(Vector vector)
    {
        VectorFuncs.sort(vector, new StoreDC.RegionDCNumberOrder());
    }

    // Sorts by Store Number.
    private static class StoreNumberOrder implements Comparer
    {
        public int compare(java.lang.Object o1, java.lang.Object o2)
        {
            int ret = ((StoreDC)o1).storeNumber.toLowerCase().compareTo(((StoreDC)o2).storeNumber.toLowerCase());

            return(ret);
        }
    }
    
    /**
     * Sorts the Vector of StoreDC objects into order by
     * Region + DC + Store Number.
     */
    public static void sortByStoreNumber(Vector vector)
    {
        VectorFuncs.sort(vector, new StoreDC.StoreNumberOrder());
    }
}

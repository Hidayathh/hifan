package com.unfi.cbk.dao;

import org.apache.log4j.Logger;

import com.unfi.cbk.utilcore.ApplicationDataBean;

/**
 * The DaoFactory class is used to create new DAO objects
 * needed for the application.
 *
 * @author      yhp6y2l
 * @since       1.0
 */
public class DaoFactory {
	static Logger log = Logger.getLogger(DaoFactory.class);

	private static DaoFactory factory = null;
	private static ApplicationDataBean aBean = null;
	
	/**
	 * Initializes a newly created <code>DaoFactory</code> object.
	 * The constructor takes an <code>ApplicationDataBean</code>
	 * and makes it available to the instance.
	 * 
	 * @param a		the <code>ApplicationDataBean</code> that contains the DAO properties
	 */
	private DaoFactory(ApplicationDataBean a) {
		// Constructor
		this.setApplicationDataBean(a);
		
	}

	/**
	 * This is the init method for the class.
	 
	 * @since			1.0
	 */
	public static synchronized void init(ApplicationDataBean aBean) {
		if (factory == null) {
			factory = new DaoFactory(aBean);
			
		}
		
	}
	
	/**
	 * Gets an instance of this class.
	 * 
	 * @return			new <code>DAOFactory instance
	 * @since			1.0
	 */
	public static DaoFactory getInstance() {
		return factory;
		
	}
	
	/**
	 * Set the ApplicationDataBean.
	 * 
	 * @param a			<code>ApplicationDataBean</code> to be set
	 * @since			1.0
	 */
	private void setApplicationDataBean(ApplicationDataBean a) {
		aBean = a;
		
	}
	

	
	/**
	 * Gets the DAO object for the chargeback search
	 * 
	 * @return			<code>ChargebackSearchDao</code>
	 * @since			1.0
	 */
	public synchronized static ChargebackSearchDao getChargebackSearchDao() {
		//  This DAO represents the Location drop-down on the search screen
		String objectType = "ChargebackSearchDao";
		//log.debug("Requesting "+objectType+" from the factory");
		// get the actual class name from the xml props
		String className = aBean.getProperty(objectType); // get from the properties bean
		//log.debug("Found "+className+" from the properties file");
		return (ChargebackSearchDao) instantiate(className);
		
	}
	
	

	


	/**
	 * Gets the DAO object for the search results
	 * 
	 * @return          <code>DocumentsDAO</code>
	 * @since           1.0
	 */
	public synchronized static Object getDao(String objectType) {
		//  This DAO represents the document results returned on each search
		//log.debug("Requesting "+objectType+" from the factory.");
		//  Get the actual class name from the xml props
		String className = aBean.getProperty(objectType); // get from the properties bean
		//log.debug("Found "+className+" from the properties file.");
		return instantiate(className);
        
	} 
    
       
    
	/**
	 * This method will create a new object based on the 
	 * classname that was passed to it.
	 * The calling method must appropriately cast the 
	 * interface and return it.
	 * 
	 * @return			<code>Object</code>
	 * @param className	the name of the class
	 * @since			1.0
	 */
	private static Object instantiate(String className) {
		Object o = null;
		try {
			Class c = Class.forName(className);
			
			try {
				o = c.newInstance();
				
			} catch (InstantiationException ie) {
				log.error("Unable to Instantiate " + className + " "+ ie);
				
			} catch (IllegalAccessException iae) {
				log.error("Unable to Access " + className + " "+ iae);
				
			}
			
		} catch (ClassNotFoundException cnfe) {
			log.error("Unable to find " + className + " "+ cnfe);
			
		}
		
		return o;
		
	}

}
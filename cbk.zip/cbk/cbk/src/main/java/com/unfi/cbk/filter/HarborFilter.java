/*
 * Created on Jan 19, 2005
 *
 */
package com.unfi.cbk.filter;
import java.io.IOException;
import java.util.Enumeration;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

/**
 * @author yhp6y2l
 * @version 1.0
 */
public class HarborFilter implements Filter {

	private static Logger log = Logger.getLogger(HarborFilter.class);
	
	public void init(FilterConfig config){
	}
	
	/* (non-Javadoc)
	 * @see javax.servlet.Filter#doFilter(javax.servlet.ServletRequest, javax.servlet.ServletResponse, javax.servlet.FilterChain)
	 */
	public void doFilter(
		ServletRequest request,
		ServletResponse response,
		FilterChain chain)
		throws IOException, ServletException {
				
		System.out.println("------HarborFilter.java method doFilter() method--------");
		//log.debug("Filtering request");
		request = HarborRequestWrapperFactory.getHarborRequestWrapper(request);
		if (response instanceof HttpServletResponse) {
            ((HttpServletResponse) response).addHeader("X-UA-Compatible", "IE=EmulateIE7");}
		chain.doFilter(request,response);

	}
	
	public void destroy(){		
	}

}

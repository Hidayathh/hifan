/*
 * ConfigFile.java
 *
 * Created on March 22, 2001, 5:08 PM
 */
package com.unfi.cbk.ldaputil;

import java.io.*;
import java.util.*;

/**
 * This class reads a configuration file and creates a name value pair for each line read.
 * Each line must be: 'thename=thevalue'  with no spaces or extra characters
 * comment lines must start with '//'
 *
 * @author: yhp6y2l
 */
public class ConfigFile extends Object {
	String      iniFilePath = "";
	String      iniFileName = "";
	Properties  prop = new Properties();    // Names, values in config file	
    
	/**
	 * ConfigFile constructor.
	 */
	public ConfigFile()
	{
		super();
	}
    
	/**
	 * ConfigFile constructor.
	 */
	public ConfigFile(String filePath, String fileName)
			throws Exception
	{
		super();

		// Load the ini file.
		loadFile(filePath, fileName);
	}
    
	private String getFullFileName()
	{
		return(iniFilePath + iniFileName);
	}
    
	/**
	 * Returns the string value associated with the name.
	 * @return String.
	 */
	public String getStringProperty(String name) 
			throws Exception
	{
		final String value = prop.getProperty(name);
		
		if (value == null) {
			String tMsg = "Couldn't find value in configuration file for: \"" + name + "\"";
			throw new Exception(tMsg);
		}
		
		return(value);
	}
    
	/**
	 * Returns the integer value associated with the name.
	 * @return integer.
	 */
	public int getIntProperty(String name) 
			throws Exception
	{
		final String    strValue = getStringProperty(name);
		int             intValue;
		
		try {
			intValue = Integer.parseInt(strValue);
		}
		catch (NumberFormatException e) {
			String tMsg = "Value in configuration file for property \"" + name + "\" must be a number.";
			throw new Exception(tMsg);
		}
		
		return(intValue);
	}

	/**
	 * Returns the boolean value associated with the name.
	 * @return value.
	 */
	public boolean getBooleanProperty(String name) 
			throws Exception
	{
		final String    strValue = getStringProperty(name);
		boolean         booleanValue;
		
		if (strValue.equalsIgnoreCase("true")) {
			booleanValue = true;
		}
		else if (strValue.equalsIgnoreCase("false")) {
			booleanValue = false;
		}
		else {
			String tMsg = "Value in configuration file for property \"" + name + "\" must be a true or false.";
			throw new Exception(tMsg);
		}
		
		return(booleanValue);
	}

	/**
	 * Load the config file into memory.
	 * @return boolean
	 * @param file java.lang.String
	 * @param path java.lang.String
	 */
	public void loadFile(String filePath, String fileName)
			throws Exception
	{
		InputStream	iniStream = null;

		iniFilePath = filePath.length() == 0 ? "/" : filePath;
		iniFileName = fileName;
		
		try {
			/*
			 * if ((iniStream = getClass().getResourceAsStream(iniFilePath + iniFileName))
			 * == null) { String tMsg = "Unable to find configuration file."; throw new
			 * Exception(tMsg); }
			 */
			if ((iniStream = getClass().getResourceAsStream(iniFilePath + iniFileName)) == null) 
			{
				System.out.println("*******************svHarborLdapFuncsFilePath="+System.getProperty("svHarborLdapFuncsFilePath", "/work/nfs/config/")+", filename ="+iniFileName);
				String filePathProp = System.getProperty("svHarborLdapFuncsFilePath", "/work/nfs/config/");
				
				//iniStream = getClass().getResourceAsStream(filePathProp + iniFileName);
				iniStream = new FileInputStream(filePathProp + iniFileName);
			}

			// Load the properties into memory.	
			prop.load(iniStream);
		}
		catch (FileNotFoundException ex) {
			String tMsg = "Unable to find configuration file.";
			throw new Exception(tMsg);
		}
		catch (java.io.IOException ex) {
			String tMsg = "Unable to read configuration file.";
			throw new Exception(tMsg);
		}
		
		finally {
			if (iniStream != null) {
				try { iniStream.close(); }
				catch (IOException noe) { }
			}
		}
	}
}
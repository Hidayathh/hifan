package com.unfi.cbk.dao.ibImpl;

import java.io.InputStream;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.ibatis.SqlMapClientTemplate;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;
import org.springframework.stereotype.Repository;
import org.springframework.web.multipart.MultipartFile;


import com.unfi.cbk.bo.VendorBO;

import com.unfi.cbk.dao.ChargebackCommonDao;

import com.unfi.cbk.exceptions.DataAccessException;
//import com.unfi.cbk.exceptions.ChargebackFileServiceException;
import com.unfi.cbk.util.DateFunctions;

/**
 * The ChargebackCommonDaoImpl class implements the generic ChargebackCommonDao interface.
 * 
 * @author vpil001
 * @version 1.0
 */

public class ChargebackCommonDaoImpl extends SqlMapClientDaoSupport implements ChargebackCommonDao {

	static Logger log = Logger.getLogger(ChargebackCommonDaoImpl.class);
	
	/**
     * @param sqlMapTemplate
     */
    public ChargebackCommonDaoImpl(SqlMapClientTemplate sqlMapTemplate) {
		this.setSqlMapClientTemplate(sqlMapTemplate);
		
	}

  
	/* (non-Javadoc)
     * @see com.unfi.cbk.dao.ChargebackCommonDao#doVendorSearch(java.lang.String, java.lang.String)
     */
    public List doVendorSearch(String vendorNumber, String vendorName) throws DataAccessException {
        List l = null;
        
        try {
        	System.out.println("--------ChargebackCommomDaoImpl.java-------doVendorSearch()---");
            HashMap map = new HashMap();
            map.put("vendorNumber", vendorNumber.replace('*', '%'));
            map.put("vendorName", vendorName.replace('*', '%').toUpperCase());
        
            l = getSqlMapClientTemplate().queryForList("ChargebackCommon.doVendorSearch", map);
        }
        catch (Exception e) {
            throw new DataAccessException(e);
        }
        
        return l;         
	}

/* (non-Javadoc)
     * @see com.unfi.cbk.dao.ChargebackCommonDao#doLocationSearch(java.lang.String, java.lang.String)
     */
    public List doLocationSearch(String locationNumber, String locationName) throws DataAccessException {
        List l = null;
        
        try {
        	System.out.println("--------ChargebackCommomDaoImpl.java-------doLocationSearch()---");
            HashMap map = new HashMap();
            map.put("locationNumber", locationNumber.replace('*', '%'));
            map.put("locationName", locationName.replace('*', '%').toUpperCase());
        
            l = getSqlMapClientTemplate().queryForList("ChargebackCommon.doLocationSearch", map);
        }
        catch (Exception e) {
            throw new DataAccessException(e);
        }
        
        return l;         
	}


    /* (non-Javadoc)
     * @see com.unfi.cbk.dao.ChargebackCommonDao#doOriginatorSearch(java.lang.String, java.lang.String)
     */
    public List doOriginatorSearch(String userId, String userName) throws DataAccessException {
        List l = null;
        
        try {
        	System.out.println("--------ChargebackCommomDaoImpl.java-------doOriginatorSearch()---"+userId+":::"+userName);
            HashMap map = new HashMap();
            map.put("userId", userId.replace('*', '%'));
            map.put("userName", userName.replace('*', '%').toUpperCase());
        
            l = getSqlMapClientTemplate().queryForList("ChargebackCommon.doOriginatorSearch", map);
        }
        catch (Exception e) {
            throw new DataAccessException(e);
        }
        
        return l;         
	}

    /* (non-Javadoc)
     * @see com.unfi.cbk.dao.ChargebackCommonDao#doApproverSearch(java.lang.String, java.lang.String)
     */
    public List doApproverSearch(String userId, String userName) throws DataAccessException {
        List l = null;
        
        try {
        	System.out.println("--------ChargebackCommomDaoImpl.java-------doApproverSearch()---"+userId+":::"+userName);
            HashMap map = new HashMap();
            map.put("userId", userId.replace('*', '%'));
            map.put("userName", userName.replace('*', '%').toUpperCase());
        
            l = getSqlMapClientTemplate().queryForList("ChargebackCommon.doApproverSearch", map);
        }
        catch (Exception e) {
            throw new DataAccessException(e);
        }
        
        return l;         
	}

    
    
	/**
	 * Check if an object is null and throw a DataAccessException if it is.
	 * 
	 * @param o the object to test
	 * @throws DataAccessException whenever the object is null
	 */
	private void checkIfNull(Object o) throws DataAccessException {
		if ( o == null ) {
			throw new DataAccessException("Object not found.");
		}
	}
	
	
}
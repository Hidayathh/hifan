package com.unfi.cbk.ui;

import java.util.Vector;

public class Roles {
	private Vector roles;
	
	public Vector getRoles() {
		if(this.roles == null) {
			this.roles = new Vector();
			
		}
		return roles;
		
	}

	public void setRoles(Vector list) {
		roles = list;
		
	}
	
	public void addRole(String role) {
		//System.out.println("Adding role: " + role);
		this.getRoles().add(role);
		
	}
	
	public boolean hasRole(String role) {
		if (this.getRoles() == null || this.getRoles().isEmpty()) {
			return true;
			
		} else {
			return this.roles.contains((String) role);
			
		}
		
	}
	
	public String toString() {
		StringBuffer buf = new StringBuffer();
		buf.append("--- ROLES ---\n");
		if (this.getRoles() != null) {
			for (int i=0; i < this.getRoles().size(); i++) {
				buf.append((String) this.getRoles().get(i) + "\n");
				
			}
			
		} else {
			buf.append("*");
			
		}
		return buf.toString();
		
	}
	
}
package com.unfi.cbk.util;

import java.text.DecimalFormat;
import java.text.ParseException;
import org.apache.log4j.Logger;

/**
 * The DateFunctions class is a utility class for performing date
 * functions needed by other classes.  All methods are static.
 *
 * @author      yhp6y2l
 * @since       1.0
 */
public class NumberFunctions {
	
	static Logger log = Logger.getLogger(DateFunctions.class);
	
	private static final String formatsToTry[] = 
					{	"0.0",
						"0.00" ,
						"0.000",
						"0.0000", 
						};
	
	public static String decimalFormat(Double num,int precision) {
		
		if( precision <= formatsToTry.length )
		{	DecimalFormat formatter = new DecimalFormat(formatsToTry[precision-1]);
			return formatter.format(num);
		}	
		return num.toString();
		
		}	
	}
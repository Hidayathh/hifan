/*
 * Comparer.java
 *
 * Created on April 18, 2001, 4:50 PM
 */
package com.unfi.cbk.ldaputil;


/**
 * Interface for comparing things.
 * Creation date: (04/04/2002 3:34:51 PM)
 * @author: yhp6y2l
 */
public interface Comparer 
{
    public int compare(java.lang.Object o1, java.lang.Object o2);
}

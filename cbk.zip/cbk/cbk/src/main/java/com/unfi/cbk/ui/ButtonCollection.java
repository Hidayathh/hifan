package com.unfi.cbk.ui;

import java.util.Vector;

import org.apache.log4j.Logger;

public class ButtonCollection {
	static Logger log = Logger.getLogger(MenuLinks.class);
	private Vector buttons = new Vector();
	 
	public void addButton(Button button) {
		this.buttons.addElement(button);
	}
	
	public Button getButton(int i) {
		return (Button) this.buttons.get(i);
	}
	
	public Vector getButtons() {
		return buttons;
	}
	
	public int getSize() {
		if (buttons == null) {
			return 0;
		}
		return buttons.size();
	}
	
	public void setButtons(Vector vector) {
		buttons = vector;
	}
	
	public String toString(){
		StringBuffer bufer = new StringBuffer();
		try {
			bufer.append("--- Buttons ---\n");
			bufer.append(this.getButtons().size() +" buttons found\n");
			
			if (buttons != null) {
				for (int i=0; i < this.getButtons().size(); i++) {
					Button button = (Button) this.getButtons().elementAt(i);
					bufer.append(button.toString()).append("\n");
				}
			} else {
				log.debug("No buttons have been added to the collection!");
			}
			
		} catch (Exception e) {
			log.error("Unable to set the buttons to strings" + e);
			//e.printStackTrace();
		}
		return bufer.toString();
	}

}
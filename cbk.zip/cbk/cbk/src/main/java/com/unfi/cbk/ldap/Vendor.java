package com.unfi.cbk.ldap;

import java.util.Vector;

import com.unfi.cbk.ldaputil.CompareTo;
import com.unfi.cbk.ldaputil.Comparer;
import com.unfi.cbk.ldaputil.VectorFuncs;


/**
 * Class to hold Vendor information.
 * Creation date: (04/04/2002 3:07:26 PM)
 * @author: yhp6y2l
 */
public class Vendor extends Object implements SupplierInf, CompareTo
{
	protected java.lang.String vendorID;
	protected java.lang.String vendorName;
	protected java.lang.String emailAddress;
	protected java.lang.String address;
	protected java.lang.String city;
	protected java.lang.String stateCode;
	protected java.lang.String zipCode;
	protected java.lang.String phoneNumber;
	protected java.lang.String faxNumber;
	protected java.lang.String contact;
	protected java.lang.String vendorType;

	public Vendor()
	{
		super();
		
		vendorID = "";
		vendorName = "";
		emailAddress = "";
		address = "";
		city = "";
		stateCode = "";
		zipCode = "";
		phoneNumber = "";
		faxNumber = "";
		contact ="";
		vendorType="";
		
	}
    public int compareTo(java.lang.Object obj) {
  
    	Vendor vend = (Vendor) obj;
//    	System.out.println("vendorID.toLowerCase this : " + vendorID.toLowerCase() + " size : " + vendorID.toLowerCase().length());
//    	System.out.println("vendorID.toLowerCase parm : " + vend.vendorID.toLowerCase() + " size : " + vend.vendorID.toLowerCase().length());
        int ret = vendorID.toLowerCase().compareTo(((Vendor)obj).vendorID.toLowerCase());
//        System.out.println("Ret : " + ret);
        return(ret);
    }

	/** Creates new Vendor object */
	public Vendor(java.lang.String vendorID,
				  java.lang.String vendorName,
				  java.lang.String emailAddress,
				  java.lang.String address,
				  java.lang.String city,
				  java.lang.String stateCode,
				  java.lang.String zipCode,
				  java.lang.String phoneNumber,
				  java.lang.String faxNumber)
	{
		super();

		this.vendorID = vendorID;
		this.vendorName = vendorName;
		this.emailAddress = emailAddress;
		this.address = address;
		this.city = city;
		this.stateCode = stateCode;
		this.zipCode = zipCode;
		this.phoneNumber = phoneNumber;
		this.faxNumber = faxNumber;
	}

	public Vendor(java.lang.String vendorID,
				  java.lang.String vendorName,
				  java.lang.String emailAddress,
				  java.lang.String address,
				  java.lang.String city,
				  java.lang.String stateCode,
				  java.lang.String zipCode,
				  java.lang.String phoneNumber,
				  java.lang.String faxNumber,
				  java.lang.String contact)
	{
		super();

		this.vendorID = vendorID;
		this.vendorName = vendorName;
		this.emailAddress = emailAddress;
		this.address = address;
		this.city = city;
		this.stateCode = stateCode;
		this.zipCode = zipCode;
		this.phoneNumber = phoneNumber;
		this.faxNumber = faxNumber;
		this.contact   = contact;
	}
	public Vendor(java.lang.String vendorID,
				  java.lang.String vendorName,
				  java.lang.String emailAddress,
				  java.lang.String address,
				  java.lang.String city,
				  java.lang.String stateCode,
				  java.lang.String zipCode,
				  java.lang.String phoneNumber,
				  java.lang.String faxNumber,
				  java.lang.String contact,
				  java.lang.String vendorType)
	{
		super();

		this.vendorID = vendorID;
		this.vendorName = vendorName;
		this.emailAddress = emailAddress;
		this.address = address;
		this.city = city;
		this.stateCode = stateCode;
		this.zipCode = zipCode;
		this.phoneNumber = phoneNumber;
		this.faxNumber = faxNumber;
		this.contact   = contact;
		this.vendorType = vendorType;
	}

/**
 * Returns the contents of the address field.
 *
 * @return String
 */
public java.lang.String getAddress()  {return(address);}
/**
 * Returns the contents of the city field.
 *
 * @return String
 */
public java.lang.String getCity()  {return(city);}
/**
 * Returns the contents of the emailAddress field.
 *
 * @return String
 */
public java.lang.String getEmailAddress()  {return(emailAddress);}
/**
 * Returns the contents of the faxNumber field.
 *
 * @return String
 */
public java.lang.String getFaxNumber()  {return(faxNumber);}
/**
 * Returns the contents of the phoneNumber field.
 *
 * @return String
 */
public java.lang.String getPhoneNumber()  {return(phoneNumber);}
/**
 * Returns the contents of the stateCode field.
 *
 * @return String
 */
public java.lang.String getStateCode()  {return(stateCode);}
/**
 * Returns the contents of the vendorID field.
 *
 * @return String
 */
public java.lang.String getVendorID()  {return(vendorID);}
/**
 * Returns the contents of the vendorName field.
 *
 * @return String
 */
public java.lang.String getVendorName()  {return(vendorName);}
/**
 * Returns the contents of the zipCode field.
 *
 * @return String
 */
public java.lang.String getZipCode()  {return(zipCode);}
/**
 * Sorts the Vector of Vendor objects into order by
 * Vendor Name.
 */

	// Sorts by vendorNumber.
	public boolean equals(Object o1)
	{
		return ( this.vendorID.equals(((Vendor)o1).vendorID) );
	}
		
	private static class VendorNumberOrder implements Comparer
	{
		public int compare(java.lang.Object o1, java.lang.Object o2)
		{
			int ret = ((Vendor)o1).vendorID.toLowerCase().compareTo(((Vendor)o2).vendorID.toLowerCase());
			return ret;
		}
	}

	public static void sortByVendorNumber(Vector vector)
	{
		VectorFuncs.sort(vector, new Vendor.VendorNumberOrder());
	}

	// Sorts by vendorName.
	private static class VendorNameOrder implements Comparer
	{
		public int compare(java.lang.Object o1, java.lang.Object o2)
		{
			int ret = ((Vendor)o1).vendorName.toLowerCase().compareTo(((Vendor)o2).vendorName.toLowerCase());
			return ret;
		}
	}

	public static void sortByVendorName(Vector vector)
	{
		VectorFuncs.sort(vector, new Vendor.VendorNameOrder());
	}
	/**
	 * Sets the vendorID
	 * @param vendorID The vendorID to set
	 */
	public void setVendorID(java.lang.String vendorID) {
		this.vendorID = vendorID;
	}

	/**
	 * Sets the vendorName
	 * @param vendorName The vendorName to set
	 */
	public void setVendorName(java.lang.String vendorName) {
		this.vendorName = vendorName;
	}

	/**
	 * Sets the emailAddress
	 * @param emailAddress The emailAddress to set
	 */
	public void setEmailAddress(java.lang.String emailAddress) {
		this.emailAddress = emailAddress;
	}

	/**
	 * Sets the address
	 * @param address The address to set
	 */
	public void setAddress(java.lang.String address) {
		this.address = address;
	}

	/**
	 * Sets the city
	 * @param city The city to set
	 */
	public void setCity(java.lang.String city) {
		this.city = city;
	}

	/**
	 * Sets the stateCode
	 * @param stateCode The stateCode to set
	 */
	public void setStateCode(java.lang.String stateCode) {
		this.stateCode = stateCode;
	}

	/**
	 * Sets the zipCode
	 * @param zipCode The zipCode to set
	 */
	public void setZipCode(java.lang.String zipCode) {
		this.zipCode = zipCode;
	}

	/**
	 * Sets the phoneNumber
	 * @param phoneNumber The phoneNumber to set
	 */
	public void setPhoneNumber(java.lang.String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	/**
	 * Sets the faxNumber
	 * @param faxNumber The faxNumber to set
	 */
	public void setFaxNumber(java.lang.String faxNumber) {
		this.faxNumber = faxNumber;
	}
	
	public String getId()
	{
		return this.vendorID;
	}
	
	public String getName()
	{
		return this.vendorName;
	}		
	/**
	 * Gets the contact
	 * @return Returns a java.lang.String
	 */
	public java.lang.String getContact() {
		return contact;
	}
	/**
	 * Sets the contact
	 * @param contact The contact to set
	 */
	public void setContact(java.lang.String contact) {
		this.contact = contact;
	}
	public java.lang.String getVendorType() {
		return vendorType;
	}
	public void setVendorType(java.lang.String type) {
		this.vendorType = type;
	}

}

/*
 * EventLog.java
 *
 * Created on May 31, 2001, 2:21 PM
 */

package com.unfi.cbk.ldaputil;

import java.io.*;
import java.util.*;
import java.text.DateFormat;

/**
 * Class to provide access to the Event Log File.
 * @author: yhp6y2l
 */
public class EventLog extends java.lang.Object
{
    private String logFilePath = "";
    private String appName = "";
    private String appUserLoginID = "";

    /** Creates new EventLog */
    public EventLog() {
        super();
    }

    /** Creates new EventLog */
    public EventLog(String logFilePath,
                    String appName,
                    String appUserLoginID)
    {
        super();
        this.logFilePath = logFilePath;
        this.appName = appName;
        this.appUserLoginID = appUserLoginID;
    }

    public void setAppName(String appName)
    {
        this.appName = appName;
    }

    public void setAppUserLoginID(String appUserLoginID)
    {
        this.appUserLoginID = appUserLoginID;
    }

    public void writeLog(String table, String action, String text)
			throws Exception
    {
        final String        auditLogFileName = logFilePath + "\\SVHarborLDAPFuncs.log";
        File                logFile = null;
        FileOutputStream    logStream = null;
        BufferedWriter      logWriter = null;
        String              tLogMsg;
        final Calendar      currDateTime = new GregorianCalendar();
        final int           yy = currDateTime.get(Calendar.YEAR);
        final int           mm = currDateTime.get(Calendar.MONTH) + 1; 
        final int           dd = currDateTime.get(Calendar.DAY_OF_MONTH);
        final int           hh = currDateTime.get(Calendar.HOUR_OF_DAY);
        final int           mn = currDateTime.get(Calendar.MINUTE);
        final int           ss = currDateTime.get(Calendar.SECOND);
        int                 retry_count = 0;
        boolean             done = false;

        // Build the message.
        tLogMsg = Integer.toString(yy) + "/" + (mm < 10 ? "0" : "") + Integer.toString(mm) + "/" + (dd < 10 ? "0" : "") + Integer.toString(dd) + " " + 
                  (hh < 10 ? "0" : "") + Integer.toString(hh) + ":" + (mn < 10 ? "0" : "") + Integer.toString(mn) + ":" + (ss < 10 ? "0" : "") + Integer.toString(ss) + "," +
                  appName + "," +
                  appUserLoginID + "," +
                  table + "," +
                  action + "," +
                  text;

        do {
            try {
                logFile = new File(auditLogFileName);
                logStream = new FileOutputStream(logFile.getPath(), true);
                logWriter = new BufferedWriter(new OutputStreamWriter(logStream));

                logWriter.write(tLogMsg, 0, tLogMsg.length());
                logWriter.newLine();
                done = true;
            }

            catch (java.io.FileNotFoundException ex) {
                if ((! ex.toString().endsWith("used by another process)")) ||
                    (++retry_count > 10)) {  // Try a few times before giving up when the file is busy.
                        
                    String tMsg = "Error writing to audit log file.";
                    throw new Exception(tMsg);
                }
            }

            catch (java.io.IOException ex) {
                String tMsg = "Error writing to audit log file.";
                throw new Exception(tMsg);
            }

            finally {
                if (logWriter != null) {
                    try { logWriter.close(); }
                    catch (IOException noe) { }
                }
                if (logStream != null) {
                    try { logStream.close(); }
                    catch (IOException noe) { }
                }
            }
        } while (! done);
    }

    // Used for testing the class.
    public static void main(String[] arguments)
			throws Exception
	{
        EventLog obj = new EventLog("C:\\MyProjects\\LDAPDirectory\\", "TestApp", "howmr0");

        obj.writeLog("TestTable", "TestAction", "TestText1");
        obj.writeLog("TestTable", "TestAction", "TestText2");
	}
}

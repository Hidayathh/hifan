package com.unfi.cbk.ldap;

import java.io.*;
import java.util.*; 
import javax.naming.*;
import java.util.Random;

import com.unfi.cbk.ldaputil.DominoServletFuncs;
import com.unfi.cbk.ldaputil.EventLog;
import com.unfi.cbk.ldaputil.CbkLdapConstants;
import com.unfi.cbk.ldaputil.VectorFuncs;

/**
 * *** This is the main class that provides access to LDAP ***<BR><BR>
 * 
 * How to use this class:<BR><BR>
 *
 *	1)	Create an instance of the class.<BR>
 *	2)	Call the initialize() method.  Be sure to pass the application name that you used when you set up the _LDAPUserName and _LDAPPassword properties in the properties file.  The initialize() method initializes the object and establishes a connection to LDAP<BR>
 *	3)	Call the methods you need.<BR>
 *	4)	When you are done, you can call destroy() to force the LDAP connection closed.<BR><BR>
 * 
 *	Here is some sample Java code that retrieves and prints the<BR>
 *	details for a particular store.<BR><BR>
 *
 *    SVHarborLDAPFuncs obj = new SVHarborLDAPFuncs();<BR>
 *    obj.initialize("TestApplication");<BR><BR>
 *
 *    String tStoreNumber = "0988888";<BR>
 *    System.out.println("Details for store: " + tStoreNumber);<BR>
 *    Store tDetail = obj.getStoreDetail(tStoreNumber);<BR>
 *    System.out.println("Store #: \"" + tDetail.getStoreNumber() + "\"" +<BR>
 *                       " Type: \"" + tDetail.getType() + "\"" +<BR>
 *                       " Name: \"" + tDetail.getName() + "\"" +<BR>
 *                       " Address: \"" + tDetail.getAddress() + "\"" +<BR>
 *                       " City: \"" + tDetail.getCity() + "\"" +<BR>
 *                       " St: \"" + tDetail.getStateCode() + "\"" +<BR>
 *                       " Zip: \"" + tDetail.getZipCode() + "\"" +<BR>
 *                       " Contact: \"" + tDetail.getContact() + "\"" +<BR>
 *                       " Phone: \"" + tDetail.getPhoneNumber() + "\"" +<BR>
 *                       " Logo: \"" + tDetail.getLogo() + "\"");<BR>
 *    System.out.println("");<BR><BR>
 *
 *    obj.destroy():<BR>
 *
 * @author: yhp6y2l
 * 
 *@com.register ( clsid=BCE992F9-BD94-11D5-BAFE-0002A51BDB06, typelib=BCE992FA-BD94-11D5-BAFE-0002A51BDB06 )
 *@com.transaction (notSupported)
 */
public class SVHarborLDAPFuncs extends java.lang.Object
{
	private static long         previousRandomSeed = -1;
	private CbkLdapConstants	svharborConstants = null;
	private LDAPDirectory       ldapDir = null;
	private DominoServletFuncs  domino = null;
	private Properties			dominoAccessProperties = null;

	private EventLog            eventLog = null;
	private String              baseDN;
	
	private boolean             formatVendorNumber = true; 
	
	/** Creates new SVHarborLDAPFuncs */
	public SVHarborLDAPFuncs()
			throws Exception
	{
		super();
	}
	/**
	 * Adds the specified admin user to the LDAP database.
	 * Returns the password for the newly added user.
	 * 
	 * @return java.lang.String
	 * @param loginID java.lang.String
	 * @param adminGroup java.lang.String
	 * @param firstName java.lang.String
	 * @param lastName java.lang.String
	 * @param middleInitial java.lang.String
	 * @param title java.lang.String
	 * @param phoneNumber java.lang.String
	 * @exception java.lang.Exception
	 */
	public String addAdminUser(String loginID,
							   String adminGroup,
							   String firstName,
							   String lastName,
							   String middleInitial,
							   String title,
							   String phoneNumber)
			throws Exception
	{
		final String tPeopleObjectDN = "uid=" + loginID + ",ou=People," + baseDN;
		Hashtable   attrib_set = new Hashtable(20);
		String      password;
		String      tDN;

		// Check for a duplicate user.
		if (existUser(loginID, false)) {
			String tMsg = "Duplicate Login ID error.  Login ID: \"" + loginID + "\" is already being used.";
			throw new Exception(tMsg);
		}

		// Make sure the specified admin group exists.
		if (! existAdminGroup(adminGroup)) {
			String tMsg = "Admin Group: \"" + adminGroup + "\" doesn't exist.";
			throw new Exception(tMsg);
		}

		// Get a password for the user.
		password = generatePassword();

		// Add the People Object.
		attrib_set.put("objectclass", new String[] {"top", "person", "organizationalPerson", "inetOrgPerson"});
		attrib_set.put("businessCategory", new String[] {"person"});
		attrib_set.put("givenname", new String[] {firstName});
		attrib_set.put("sn", new String[] {lastName});
		attrib_set.put("initials", new String[] {middleInitial});
		attrib_set.put("cn", new String[] {firstName + " " + lastName});
		attrib_set.put("title", new String[] {title});
		attrib_set.put("telephoneNumber", new String[] {phoneNumber});
		attrib_set.put("userPassword", new String[] {password});
		attrib_set.put("carLicense", new String[] {"16777216"});
		ldapDir.addObject(tPeopleObjectDN, attrib_set);

		// Add the user to the admin group.
		tDN = "cn=" + adminGroup + ",ou=AdminGroups,ou=Groups," + baseDN;
		ldapDir.addAttribute(tDN, "uniqueMember", new String[] {tPeopleObjectDN});

		// Write a record to the audit log.
		eventLog.writeLog("User", "Add", "\"" + loginID + "\" (Address=\"\")");

		return(password);
	}
	/**
	 * Adds a store alias to the database.
	 * 
	 * @return void
	 * @param storeNumber java.lang.String
	 * @param alias java.lang.String
	 * @param description java.lang.String
	 * @exception java.lang.Exception
	 */
	public void addAlias(String storeNumber,
						 String alias,
						 String description)
			throws Exception
	{
		final String tStoreObjectDN = "uid=" + storeNumber + ",ou=Stores," + baseDN;
		final String tAliasObjectDN = "uid=" + alias + ",ou=StoreAlias,ou=Stores," + baseDN;
		Hashtable   attrib_set = new Hashtable(20);

		// Check for a duplicate alias.
		if (existAlias(alias)) {
			String tMsg = "Duplicate store alias error.  Store alias: \"" + alias + "\" is already being used.";
			throw new Exception(tMsg);
		}

		// Make sure the specified store exists.
		if (! ldapDir.existObject(tStoreObjectDN)) {
			String tMsg = "Unable create store alias.  The store doesn't exist." +
						  "  Store: \"" + storeNumber + "\"" +
						  "  Alias: \"" + alias + "\"";
			throw new Exception(tMsg);
		}

		// Add the Store Alias Object.
		attrib_set.put("objectclass", new String[] {"top", "person", "organizationalPerson", "inetOrgPerson"});
		attrib_set.put("sn", new String[] {storeNumber});
		attrib_set.put("cn", new String[] {"Alias " + storeNumber});
		attrib_set.put("givenname", new String[] {"alias"});
		attrib_set.put("description", new String[] {description});
		attrib_set.put("businessCategory", new String[] {"alias"});
		ldapDir.addObject(tAliasObjectDN, attrib_set);

		// Write a record to the audit log.
		eventLog.writeLog("Alias", "Add", "\"" + alias + "\" to \"" + storeNumber + "\"");
	}
	/**
	 * Gives the broker access to an application.
	 * NOTE... The appName parameter must be the "short"
	 *         version of the app name.
	 * 
	 * @return void
	 * @param brokerNumber java.lang.String
	 * @param appName java.lang.String
	 * @exception java.lang.Exception
	 */
	public void addAppToBroker(String brokerNumber,
							   String appName)
			throws Exception
	{
		
		final String tAppListObjectDN = "uid=" + appName + ",ou=ApplicationList,ou=Applications," + baseDN;
		final String tBrokerObjectDN = "cn=" + brokerNumber + ",ou=Brokers," + baseDN;

		// Make sure the specified broker exists.
		if (! ldapDir.existObject(tBrokerObjectDN)) {
			String tMsg = "Unable to add application to broker.  The broker doesn't exist." +
						  "  Broker: \"" + brokerNumber + "\"" +
						  "  Application: \"" + appName + "\"";
			throw new Exception(tMsg);
		}

		// Make sure the specified application exists.
		if (! ldapDir.existObject(tAppListObjectDN)) {
			String tMsg = "Unable to add application to broker.  Application doesn't exist." +
						  "  Broker: \"" + brokerNumber + "\"" +
						  "  Application: \"" + appName + "\"";
			throw new Exception(tMsg);
		}

		// Add the application to the broker (if it's not there already).
		if (! ldapDir.existAttributeInObject(tBrokerObjectDN, "uniqueMember", tAppListObjectDN)) {
			ldapDir.addAttribute(tBrokerObjectDN, "uniqueMember", new String[] {tAppListObjectDN});

			// Write a record to the audit log.
			eventLog.writeLog("BrokerApp", "Add", "\"" + appName + "\" to \"" + brokerNumber + "\"");
		}
	}
	/**
	 * Gives the store access to an application.
	 * NOTE... The appName parameter must be the "short"
	 *         version of the app name.
	 * 
	 * @return void
	 * @param storeNumber java.lang.String
	 * @param appName java.lang.String
	 * @exception java.lang.Exception
	 */
	public void addAppToStore(String storeNumber,
							  String appName)
			throws Exception
	{
		final String tAppListObjectDN = "uid=" + appName + ",ou=ApplicationList,ou=Applications," + baseDN;
		final String tStoreObjectDN = "cn=" + storeNumber + ",ou=Stores," + baseDN;

		// Make sure the specified store exists.
		if (! ldapDir.existObject(tStoreObjectDN)) {
			String tMsg = "Unable to add application to store.  The store doesn't exist." +
						  "  Store: \"" + storeNumber + "\"" +
						  "  Application: \"" + appName + "\"";
			throw new Exception(tMsg);
		}

		// Make sure the specified application exists.
		if (! ldapDir.existObject(tAppListObjectDN)) {
			String tMsg = "Unable to add application to store.  Application doesn't exist." +
						  "  Store: \"" + storeNumber + "\"" +
						  "  Application: \"" + appName + "\"";
			throw new Exception(tMsg);
		}

		// Add the application to the store (if it's not there already).
		if (! ldapDir.existAttributeInObject(tStoreObjectDN, "uniqueMember", tAppListObjectDN)) {
			ldapDir.addAttribute(tStoreObjectDN, "uniqueMember", new String[] {tAppListObjectDN});

			// Write a record to the audit log.
			eventLog.writeLog("StoreApp", "Add", "\"" + appName + "\" to \"" + storeNumber + "\"");
		}
	}
	/**
	 * Gives the vendor access to an application.
	 * NOTE... The appName parameter must be the "short"
	 *         version of the app name.
	 * 
	 * @return void
	 * @param vendorID java.lang.String
	 * @param appName java.lang.String
	 * @exception java.lang.Exception
	 */
	// Jan 26, 2003 - Modified for Vendor Conversion
		public void addAppToVendor(String vendorID,
							   String appName)
			throws Exception
	{
		
		String 			originalVendorNumber = "";
		originalVendorNumber = vendorID;		
		vendorID = convertToInternalVendorNbr(vendorID);
	
		final String tAppListObjectDN = "uid=" + appName + ",ou=ApplicationList,ou=Applications," + baseDN;
		final String tVendorObjectDN = "cn=" + vendorID + ",ou=Vendors," + baseDN;

		// Make sure the specified vendor exists.
		if (! ldapDir.existObject(tVendorObjectDN)) {
			String tMsg = "Unable to add application to vendor.  The vendor doesn't exist." +
						  "  Vendor: \"" + vendorID + "\"" +
						  "  Application: \"" + appName + "\"";
			throw new Exception(tMsg);
		}

		// Make sure the specified application exists.
		if (! ldapDir.existObject(tAppListObjectDN)) {
			String tMsg = "Unable to add application to vendor.  Application doesn't exist." +
						  "  Vendor: \"" + vendorID + "\"" +
						  "  Application: \"" + appName + "\"";
			throw new Exception(tMsg);
		}

		// Add the application to the vendor (if it's not there already).
		if (! ldapDir.existAttributeInObject(tVendorObjectDN, "uniqueMember", tAppListObjectDN)) {
			ldapDir.addAttribute(tVendorObjectDN, "uniqueMember", new String[] {tAppListObjectDN});

			// Write a record to the audit log.
			eventLog.writeLog("VendorApp", "Add", "\"" + appName + "\" to \"" + vendorID + "\"");
		}
	}
	/**
	 * Adds the specified broker to the LDAP database.
	 * The default broker user "Admin{BrokerNumber}" is
	 * also created.
	 * Returns the password for the newly added default
	 * broker user.
	 * 
	 * @return java.lang.String
	 * @param brokerNumber java.lang.String
	 * @param name java.lang.String
	 * @param address java.lang.String
	 * @param city java.lang.String
	 * @param state java.lang.String
	 * @param zip java.lang.String
	 * @param phoneNumber java.lang.String
	 * @param faxNumber java.lang.String
	 * @param emailAddress java.lang.String
	 * @exception java.lang.Exception
	 */
	public String addBroker(String brokerNumber,
						    String name,
						    String address,
						    String city,
						    String state,
						    String zip,
						    String phoneNumber,
						    String faxNumber,
						    String emailAddress)
			throws Exception
	{
		String s = 	addBroker(brokerNumber,
						    name,
						    address,
						    city,
						    state,
						    zip,
						    phoneNumber,
						    faxNumber,
						    emailAddress,
						    "",   // contact name
						    "",   // admin id
						    ""    // appName
						    );
		return s;
	}						    
			
	/**
	 * Adds the specified broker to the LDAP database.
	 * The default broker user "Admin{BrokerNumber}" is
	 * also created.
	 * Returns the password for the newly added default
	 * broker user.
	 * 
	 * @return java.lang.String
	 * @param brokerNumber java.lang.String
	 * @param name java.lang.String
	 * @param address java.lang.String
	 * @param city java.lang.String
	 * @param state java.lang.String
	 * @param zip java.lang.String
	 * @param phoneNumber java.lang.String
	 * @param faxNumber java.lang.String
	 * @param emailAddress java.lang.String
	 * @param contact      java.lang.String
	 * @param adminId      java.lang.String
	 * @param appName      java.lang.String
	 * @exception java.lang.Exception
	 */
	public String addBroker(String brokerNumber,
						    String name,
						    String address,
						    String city,
						    String state,
						    String zip,
						    String phoneNumber,
						    String faxNumber,
						    String emailAddress,
						    String contact,
						    String userId,
						    String appName)
			throws Exception
	{
		final String    brokerDN = "uid=" + brokerNumber + ",ou=Brokers," + baseDN;
		final String    brokerGroupDN = "cn=" + brokerNumber + ",ou=Brokers," + baseDN;
		Hashtable       attrib_set = new Hashtable(20);
		Hashtable       hashT;
		Vector          vector1;
		String          tFilter;
		String          tDN;
		String          tPassword;

		String tInitialUser = "";
		String tInitialAppName = "";
		if  ((userId == null) || (userId.length() <= 0))
		{
			tInitialUser = "BrokerAdmin" + brokerNumber;
		}else
		{
			tInitialUser = userId;
		}		

		if  ((appName == null) || (appName.length() <= 0))
		{
			tInitialAppName = "BrokerUserAdmin";
		}else
		{
			tInitialAppName = appName;
		}		

		if  (contact == null)
		{
			contact = "";
		}		

		// Check for a duplicate broker.
		if (existUserAnywhere(brokerNumber)) {
			String tMsg = "Duplicate Broker Number error.  Broker Number: \"" + brokerNumber + "\" already exists in the system.";
			throw new Exception(tMsg);
		}

		// Add the Broker Object.
		attrib_set.put("objectclass", new String[] {"top", "person", "organizationalPerson", "inetOrgPerson"});
		attrib_set.put("sn", new String[] {name});
		attrib_set.put("cn", new String[] {"Broker " + name});
		attrib_set.put("mail", new String[] {emailAddress});
		attrib_set.put("street", new String[] {address});
		attrib_set.put("homePostalAddress", new String[] {city});
		attrib_set.put("st", new String[] {state});
		attrib_set.put("postalCode", new String[] {zip});
		attrib_set.put("telephoneNumber", new String[] {phoneNumber});
		attrib_set.put("facsimileTelephoneNumber", new String[] {faxNumber});
		attrib_set.put("manager", new String[] {contact});
		ldapDir.addObject(brokerDN, attrib_set);

		// Write a record to the audit log.
		eventLog.writeLog("Broker", "Add", "\"" + brokerNumber + "\"");

		// Add the BrokerGroup Object.
		attrib_set.clear();
		attrib_set.put("objectclass", new String[] {"top", "groupofuniquenames"});
		ldapDir.addObject(brokerGroupDN, attrib_set);

		// Assign the broker to all default and forced "broker" applications.
		tDN = "ou=ApplicationList,ou=Applications," + baseDN;
		tFilter = "(&(preferredlanguage=vendor/broker)(|(physicalDeliveryOfficeName=default)(physicalDeliveryOfficeName=forced)))";
		if ((vector1 = ldapDir.search(tDN, tFilter, true)) != null) {
			final int vectorSize = vector1.size();
			for (int x = 0; x < vectorSize; x++) {
				tDN = (String) vector1.elementAt(x);

				// Add the application's DN to the BrokerGroup object.
				ldapDir.addAttribute(brokerGroupDN, "uniqueMember", new String[] {tDN});
			}
		}

		// Create the initial user for the broker.
		
		tPassword = addBrokerUser(tInitialUser, brokerNumber, "Temporary",
								  "Administrator", "", "Initial Administrative User",
								  phoneNumber, "");

		// Flag the user as system generated.
		final String tPeopleObjectDN = "uid=" + tInitialUser + ",ou=People," + baseDN;
		attrib_set.clear();
		attrib_set.put("preferredDeliveryMethod", new String[] {"System Generated"});
		ldapDir.updateObject(tPeopleObjectDN, attrib_set);

		// Give the the initial user rights to the broker user administration application.
//		System.out.println("*** LDAP API -> Adding user : " + tInitialUser + " to app: " + tInitialAppName);
		addUserToRole(tInitialUser, tInitialAppName, "Administrator");

		return tPassword;
	}
	/**
	 * Adds the specified broker user to the LDAP database.
	 * Returns the password for the newly added user.
	 * 
	 * @return java.lang.String
	 * @param loginID java.lang.String
	 * @param brokerNumber java.lang.String
	 * @param firstName java.lang.String
	 * @param lastName java.lang.String
	 * @param middleInitial java.lang.String
	 * @param title java.lang.String
	 * @param phoneNumber java.lang.String
	 * @param emailAddress java.lang.String
	 * @exception java.lang.Exception
	 */
	public String addBrokerUser(String loginID,
						  		String brokerNumber,
						  		String firstName,
							  	String lastName,
							  	String middleInitial,
							  	String title,
							  	String phoneNumber,
							  	String emailAddress)
			throws Exception
	{
		final String tPeopleObjectDN = "uid=" + loginID + ",ou=People," + baseDN;
		Hashtable   attrib_set = new Hashtable(20);
		String      password;
		String      tDN;

		// Check for a duplicate user.
		if (existUser(loginID, false)) {
			String tMsg = "Duplicate Login ID error.  Login ID: \"" + loginID + "\" is already being used.";
			throw new Exception(tMsg);
		}

		// Make sure the specified broker exists.
		if (! existBroker(brokerNumber)) {
			String tMsg = "Broker: \"" + brokerNumber + "\" doesn't exist.";
			throw new Exception(tMsg);
		}

		// Get a password for the user.
		password = generatePassword();

		// Add the People Object.
		attrib_set.put("objectclass", new String[] {"top", "person", "organizationalPerson", "inetOrgPerson"});
		attrib_set.put("businessCategory", new String[] {"person"});
		attrib_set.put("roomNumber", new String[] {brokerNumber});
		attrib_set.put("givenname", new String[] {firstName});
		attrib_set.put("sn", new String[] {lastName});
		attrib_set.put("initials", new String[] {middleInitial});
		attrib_set.put("cn", new String[] {firstName + " " + lastName});
		attrib_set.put("title", new String[] {title});
		attrib_set.put("telephoneNumber", new String[] {phoneNumber});
		attrib_set.put("destinationIndicator", new String[] {"Broker"});
		attrib_set.put("userPassword", new String[] {password});
		attrib_set.put("carLicense", new String[] {"16777216"});
		attrib_set.put("mail", new String[] {emailAddress});
		ldapDir.addObject(tPeopleObjectDN, attrib_set);

		// Add the user to the broker's group.
		tDN = "cn=" + brokerNumber + ",ou=Brokers," + baseDN;
		ldapDir.addAttribute(tDN, "uniqueMember", new String[] {tPeopleObjectDN});

		// Write a record to the audit log.
		eventLog.writeLog("User", "Add", "\"" + loginID + "\"");

		return password;
	}
	/**
	 * Adds a new store group to the LDAP database.
	 * 
	 * @return void
	 * @param groupName java.lang.String
	 * @param groupType java.lang.String
	 * @param loginID java.lang.String
	 * @param adminGroup java.lang.String
	 * @exception java.lang.Exception
	 */
	public void addGroup(String groupName,
						 String groupType,
						 String loginID,
						 String adminGroup)
			throws Exception
	{
		final String tAdminGroupDN = "cn=" + adminGroup + ",ou=AdminGroups,ou=Groups," + baseDN;

		doAddGroup(groupName, groupType, loginID, tAdminGroupDN, null);
	}
	/**
	 * Adds a new numbered store group to the LDAP database.
	 * This is for adding DCs, Regions and other numbered
	 * store groups.
	 * 
	 * @return void
	 * @param groupName java.lang.String
	 * @param groupType java.lang.String
	 * @param loginID java.lang.String
	 * @param adminGroup java.lang.String
	 * @param groupNumber java.lang.String
	 * @exception java.lang.Exception
	 */
	public void addGroup(String groupName,
						 String groupType,
						 String loginID,
						 String adminGroup,
						 String groupNumber)
			throws Exception
	{
		final String tAdminGroupDN = "cn=" + adminGroup + ",ou=AdminGroups,ou=Groups," + baseDN;

		doAddGroup(groupName, groupType, loginID, tAdminGroupDN, groupNumber);
	}
	/**
	 * Adds the specified store to the LDAP database.
	 * The default store user "Admin{StoreNumber}" is
	 * also created.
	 * Returns the password for the newly added default
	 * store user.
	 * 
	 * @return java.lang.String
	 * @param userLoginID java.lang.String
	 * @param storeNumber java.lang.String
	 * @param type java.lang.String
	 * @param name java.lang.String
	 * @param address java.lang.String
	 * @param city java.lang.String
	 * @param state java.lang.String
	 * @param zip java.lang.String
	 * @param contact java.lang.String
	 * @param phone java.lang.String
	 * @param logo java.lang.String
	 * @param regionName java.lang.String
	 * @param dcName java.lang.String
	 * @exception java.lang.Exception
	 */
	public String addStore(String userLoginID,
						   String storeNumber,
						   String type,
						   String name,
						   String address,
						   String city,
						   String state,
						   String zip,
						   String contact,
						   String phone,
						   String logo,
						   String regionName,
						   String dcName)
			throws Exception
	{
		final String    storeObjectDN = "uid=" + storeNumber + ",ou=Stores," + baseDN;
		final String    storeInfoDN = "cn=" + storeNumber + ",ou=Stores," + baseDN;
		Hashtable       attrib_set = new Hashtable(20);
		Hashtable       hashT;
		Vector          vector1;
		String          tFilter;
		String          tDN;
		String          tUserRegionAdminGroupDN;
		String          tPassword;
		
		// Check for a duplicate store.
		if (ldapDir.existObject(storeObjectDN)) {
			String tMsg = "Duplicate Store Number error.  Store Number: \"" + storeNumber + "\" already exists in the system.";
			throw new Exception(tMsg);
		}

		// Make sure a valid type parameter was passed.
		if ((! type.equalsIgnoreCase("store")) && (! type.equalsIgnoreCase("HQ"))) {
			String tMsg = "Error in addStore().  \"Type\" parameter must be either \"store\" or \"HQ\"";
			throw new Exception(tMsg);
		}

		// Make sure the desired Region Group object exists.
		tDN = "cn=" + regionName + ",ou=SharedGroups," + baseDN;
		if (! ldapDir.existObject(tDN)) {
			String tMsg = "Region Group object \"" + regionName + "\" doesn't exist.";
			throw new Exception(tMsg);
		}

		// Make sure the desired DC Group object exists.
		tDN = "cn=" + dcName + ",ou=SharedGroups," + baseDN;
		if (! ldapDir.existObject(tDN)) {
			String tMsg = "DC Group object \"" + dcName + "\" doesn't exist.";
			throw new Exception(tMsg);
		}

		// Add the Store Object.
		attrib_set.put("objectclass", new String[] {"top", "person", "organizationalPerson", "inetOrgPerson"});
		attrib_set.put("sn", new String[] {name});
		attrib_set.put("cn", new String[] {"Store " + name});
		attrib_set.put("givenname", new String[] {"Store"});
		attrib_set.put("businessCategory", new String[] {type});
		attrib_set.put("street", new String[] {address});
		attrib_set.put("homePostalAddress", new String[] {city});
		attrib_set.put("st", new String[] {state});
		attrib_set.put("postalCode", new String[] {zip});
		attrib_set.put("manager", new String[] {contact});
		attrib_set.put("telephoneNumber", new String[] {phone});
		attrib_set.put("labeledURI", new String[] {logo});
		ldapDir.addObject(storeObjectDN, attrib_set);

		// Write a record to the audit log.
		eventLog.writeLog("Store", "Add", "\"" + storeNumber + "\"");
		
		// Add the StoreInfo Object.
		attrib_set.clear();
		attrib_set.put("objectclass", new String[] {"top", "groupofuniquenames"});
		ldapDir.addObject(storeInfoDN, attrib_set);

		// Add the "uniqueMember" attribute to Region SharedGroup Object.
		tDN = "cn=" + regionName + ",ou=SharedGroups," + baseDN;
		ldapDir.addAttribute(tDN, "uniqueMember", new String[] {storeObjectDN});

		// Add the "uniqueMember" attribute to DC SharedGroup Object.
		tDN = "cn=" + dcName + ",ou=SharedGroups," + baseDN;
		ldapDir.addAttribute(tDN, "uniqueMember", new String[] {storeObjectDN});

		// Add an HQ SharedGroup if this is an HQ store.
		if (type.equalsIgnoreCase("HQ")) {
			tDN = "cn=" + name + ",ou=SharedGroups," + baseDN;
			if (! ldapDir.existObject(tDN)) {
				// Get the DN of the user's Region Admin Group.
				tUserRegionAdminGroupDN = getRegionAdminGroupDNOfUser(userLoginID);

				// Add the new group.
				doAddGroup(name, "HQ", userLoginID, tUserRegionAdminGroupDN, null);
			}

			// Make this store a member of the group.
			addStoreToGroup(storeNumber, name);
		}

		// Assign the store to all default and forced "store" applications.
		tDN = "ou=ApplicationList,ou=Applications," + baseDN;
		tFilter = "(&(preferredlanguage=store)(|(physicalDeliveryOfficeName=default)(physicalDeliveryOfficeName=forced)))";
		if ((vector1 = ldapDir.search(tDN, tFilter, true)) != null) {
			final int vectorSize = vector1.size();
			for (int x = 0; x < vectorSize; x++) {
				tDN = (String) vector1.elementAt(x);

				// Add the application's DN to the StoreInfo object.
				ldapDir.addAttribute(storeInfoDN, "uniqueMember", new String[] {tDN});
			}
		}

		// Create the initial user for the store.
		final String tInitialUser = "Admin" + storeNumber;
		tPassword = addUser(tInitialUser, storeNumber, "Temporary",
							"Administrator", "", "Initial Administrative User",
							phone, "");
		
		// Flag the user as system generated.
		final String tPeopleObjectDN = "uid=" + tInitialUser + ",ou=People," + baseDN;
		attrib_set.clear();
		attrib_set.put("preferredDeliveryMethod", new String[] {"System Generated"});
		ldapDir.updateObject(tPeopleObjectDN, attrib_set);

		// For HQ stores, add the initial user to the HQ group.
		if (type.equalsIgnoreCase("HQ")) {
			addUserToGroup(tInitialUser, name);
		}

		// Give the the initial user rights to the user administration application.
		addUserToRole(tInitialUser, "UserAdmin", "UserAdminUsers");

		return(tPassword);
	}
	/**
	 * Adds the store to the group.
	 * 
	 * @return void
	 * @param storeNumber java.lang.String
	 * @param groupName java.lang.String
	 * @exception java.lang.Exception
	 */
	public void addStoreToGroup(String storeNumber,
								String groupName)
			throws Exception
	{
		final String tStoreDN = "uid=" + storeNumber + ",ou=Stores," + baseDN;
		final String tGroupDN = "cn=" + groupName + ",ou=SharedGroups," + baseDN;

		// Make sure the specified store exists.
		if (! ldapDir.existObject(tStoreDN)) {
			String tMsg = "Unable to add store to group.  Store doesn't exist." +
						  "  Store: \"" + storeNumber + "\"" +
						  "  Group: \"" + groupName + "\"";
			throw new Exception(tMsg);
		}

		// Make sure the specified group exists.
		if (! ldapDir.existObject(tGroupDN)) {
			String tMsg = "Unable to add store to group.  Group doesn't exist." +
						  "  Store: \"" + storeNumber + "\"" +
						  "  Group: \"" + groupName + "\"";
			throw new Exception(tMsg);
		}

		// Add the store to the group (if it's not there already).
		if (! ldapDir.existAttributeInObject(tGroupDN, "uniqueMember", tStoreDN)) {
			ldapDir.addAttribute(tGroupDN, "uniqueMember", new String[] {tStoreDN});

			// Write a record to the audit log.
			eventLog.writeLog("StoreGroup", "Add", "\"" + storeNumber + "\" to \"" + groupName + "\"");
		}
	}
	/**
	 * Adds the specified user to the LDAP database.
	 * Returns the password for the newly added user.
	 * 
	 * @return java.lang.String
	 * @param loginID java.lang.String
	 * @param storeNumber java.lang.String
	 * @param firstName java.lang.String
	 * @param lastName java.lang.String
	 * @param middleInitial java.lang.String
	 * @param title java.lang.String
	 * @param phoneNumber java.lang.String
	 * @param emailAddress java.lang.String
	 * @exception java.lang.Exception
	 */
	public String addUser(String loginID,
						  String storeNumber,
						  String firstName,
						  String lastName,
						  String middleInitial,
						  String title,
						  String phoneNumber,
						  String emailAddress)
			throws Exception
	{
		final String tPeopleObjectDN = "uid=" + loginID + ",ou=People," + baseDN;
		Hashtable   attrib_set = new Hashtable(20);
		String      password;
		String      storeRegion;
		String      tDN;

		// Check for a duplicate user.
		if (existUser(loginID, false)) {
			String tMsg = "Duplicate Login ID error.  Login ID: \"" + loginID + "\" is already being used.";
			throw new Exception(tMsg);
		}

		// Make sure the specified store exists.
		if (! existStore(storeNumber)) {
			String tMsg = "Store: \"" + storeNumber + "\" doesn't exist.";
			throw new Exception(tMsg);
		}

		// Get the region that the store belongs to.
		storeRegion = getGroupOfStore(storeNumber, "RG");

		// Get a password for the user.
		password = generatePassword();

		// Add the user to Domino if the user has an email address.
		if (emailAddress.length() > 0) {
			domino.createUser(loginID, firstName, middleInitial, lastName, emailAddress);
		}
		
		// Add the People Object.
		attrib_set.put("objectclass", new String[] {"top", "person", "organizationalPerson", "inetOrgPerson"});
		attrib_set.put("businessCategory", new String[] {"person"});
		attrib_set.put("roomNumber", new String[] {storeNumber});
		attrib_set.put("givenname", new String[] {firstName});
		attrib_set.put("sn", new String[] {lastName});
		attrib_set.put("initials", new String[] {middleInitial});
		attrib_set.put("cn", new String[] {firstName + " " + lastName});
		attrib_set.put("title", new String[] {title});
		attrib_set.put("telephoneNumber", new String[] {phoneNumber});
		attrib_set.put("destinationIndicator", new String[] {storeRegion});
		attrib_set.put("userPassword", new String[] {password});
		attrib_set.put("carLicense", new String[] {"16777216"});
		attrib_set.put("mail", new String[] {emailAddress});
		ldapDir.addObject(tPeopleObjectDN, attrib_set);

		// Add the user to the store's group.
		tDN = "cn=" + storeNumber + ",ou=Stores," + baseDN;
		ldapDir.addAttribute(tDN, "uniqueMember", new String[] {tPeopleObjectDN});

		// Write a record to the audit log.
		eventLog.writeLog("User", "Add", "\"" + loginID + "\" (Address=\"" + emailAddress + "\")");

		return(password);
	}
	/**
	 * Gives the user access to an admin group.
	 * 
	 * @return void
	 * @param loginID java.lang.String
	 * @param adminGroupName java.lang.String
	 * @exception java.lang.Exception
	 */
	public void addUserToAdminGroup(String loginID,
									String adminGroupName)
			throws Exception
	{
		final String tGroupDN = "cn=" + adminGroupName + ",ou=AdminGroups,ou=Groups," + baseDN;
		final String tPeopleObjectDN = "uid=" + loginID + ",ou=People," + baseDN;

		// Make sure the specified group exists.
		if (! ldapDir.existObject(tGroupDN)) {
			String tMsg = "Unable to add user to admin. group.  Admin. group doesn't exist." +
						  "  User: \"" + loginID + "\"" +
						  "  Group: \"" + adminGroupName + "\"";
			throw new Exception(tMsg);
		}

		// Add the user to the group (if it's not there already).
		if (! ldapDir.existAttributeInObject(tGroupDN, "uniqueMember", tPeopleObjectDN)) {
			ldapDir.addAttribute(tGroupDN, "uniqueMember", new String[] {tPeopleObjectDN});

			// Write a record to the audit log.
			eventLog.writeLog("AdminGroup", "Add", "\"" + loginID + "\" to \"" + adminGroupName + "\"");
		}
	}
	/**
	 * Gives the user access to a group of stores.
	 * 
	 * @return void
	 * @param loginID java.lang.String
	 * @param groupName java.lang.String
	 * @exception java.lang.Exception
	 */
	public void addUserToGroup(String loginID,
							   String groupName)
			throws Exception
	{
		final String tGroupDN = "cn=" + groupName + ",ou=SharedGroups," + baseDN;
		final String tPeopleObjectDN = "uid=" + loginID + ",ou=People," + baseDN;

		// Make sure the specified group exists.
		if (! ldapDir.existObject(tGroupDN)) {
			String tMsg = "Unable to add user to group.  Group doesn't exist." +
						  "  User: \"" + loginID + "\"" +
						  "  Group: \"" + groupName + "\"";
			throw new Exception(tMsg);
		}

		// Add the user to the group (if it's not there already).
		if (! ldapDir.existAttributeInObject(tGroupDN, "uniqueMember", tPeopleObjectDN)) {
			ldapDir.addAttribute(tGroupDN, "uniqueMember", new String[] {tPeopleObjectDN});

			// Write a record to the audit log.
			eventLog.writeLog("UserGroup", "Add", "\"" + loginID + "\" to \"" + groupName + "\"");
		}
	}
	/**
	 * Gives the user an application role.
	 * 
	 * @return void
	 * @param loginID java.lang.String
	 * @param appName java.lang.String
	 * @param roleName java.lang.String
	 * @exception java.lang.Exception
	 */
	public void addUserToRole(String loginID,
							  String appName,
							  String roleName)
			throws Exception
	{
		final String tPeopleObjectDN = "uid=" + loginID + ",ou=People," + baseDN;
		String tDN;

		// Make sure the specified application exists.
		tDN = "ou=" + appName + ",ou=Applications," + baseDN;
		if (! ldapDir.existObject(tDN)) {
			String tMsg = "Unable to add user to application role.  Application doesn't exist." +
						  "  User: \"" + loginID + "\"" +
						  "  Application: \"" + appName + "\"" +
						  "  Role: \"" + roleName + "\"";
			throw new Exception(tMsg);
		}

		// Make sure the specified application role exists.
		tDN = "cn=" + roleName + ",ou=" + appName + ",ou=Applications," + baseDN;
		if (! ldapDir.existObject(tDN)) {
			String tMsg = "Unable to add user to application role.  Role doesn't exist." +
						  "  User: \"" + loginID + "\"" +
						  "  Application: \"" + appName + "\"" +
						  "  Role: \"" + roleName + "\"";
			throw new Exception(tMsg);
		}

		// Add the user to the application role (if it's not there already).
		tDN = "cn=" + roleName + ",ou=" + appName + ",ou=Applications," + baseDN;
		if (! ldapDir.existAttributeInObject(tDN, "uniqueMember", tPeopleObjectDN)) {
			ldapDir.addAttribute(tDN, "uniqueMember", new String[] {tPeopleObjectDN});

			// Write a record to the audit log.
			eventLog.writeLog("UserRole", "Add", "\"" + loginID + "\" to \"" + appName + "\"/\"" + roleName + "\"");
		}
	}
	/**
	 * Adds the specified vendor to the LDAP database.
	 * The default vendor user "Admin{VendorNumber}" is
	 * also created.
	 * Returns the password for the newly added default
	 * vendor user.
	 * 
	 * @return java.lang.String
	 * @param vendorNumber java.lang.String
	 * @param name java.lang.String
	 * @param address java.lang.String
	 * @param city java.lang.String
	 * @param state java.lang.String
	 * @param zip java.lang.String
	 * @param phoneNumber java.lang.String
	 * @param faxNumber java.lang.String
	 * @param emailAddress java.lang.String
	 * @exception java.lang.Exception
	 */
	public String addVendor(String vendorNumber,
						    String name,
						    String address,
						    String city,
						    String state,
						    String zip,
						    String phoneNumber,
						    String faxNumber,
						    String emailAddress)
			throws Exception
	{
		String s = addVendor(vendorNumber
							,name
							,address
							,city
							,state
							,zip
							,phoneNumber
							,faxNumber
							,emailAddress
							,null   // company contact
							,null   // admin user id
							,null   // appName
							,null   // vendorType
							);
						
		return s;
	}
	/**
	 * Adds the specified vendor to the LDAP database.
	 * The default vendor user "Admin{VendorNumber}" is
	 * also created.
	 * Returns the password for the newly added default
	 * vendor user.
	 * 
	 * @return java.lang.String
	 * @param vendorNumber java.lang.String
	 * @param name java.lang.String
	 * @param address java.lang.String
	 * @param city java.lang.String
	 * @param state java.lang.String
	 * @param zip java.lang.String
	 * @param phoneNumber java.lang.String
	 * @param faxNumber java.lang.String
	 * @param emailAddress java.lang.String
	 * @param contact      java.lang.String
	 * @param adminUserId  java.lang.String
	 * @param appName      java.lang.String
	 * @exception java.lang.Exception
	 */
	// Jan 26, 2003 - Modified for Vendor Conversion	
	public String addVendor(String vendorNumber,
						    String name,
						    String address,
						    String city,
						    String state,
						    String zip,
						    String phoneNumber,
						    String faxNumber,
						    String emailAddress,
						    String contact,
						    String userId,
						    String appName,
						    String vendorType
						    )
			throws Exception
	{

		String 			originalVendorNumber = "";
		originalVendorNumber = vendorNumber;		
		vendorNumber = convertToInternalVendorNbr(vendorNumber);
		
		final String    vendorDN = "uid=" + vendorNumber + ",ou=Vendors," + baseDN;
		final String    vendorGroupDN = "cn=" + vendorNumber + ",ou=Vendors," + baseDN;
		Hashtable       attrib_set = new Hashtable(20);
		Hashtable       hashT;
		Vector          vector1;
		String          tFilter;
		String          tDN;
		String          tPassword;

		// Check for a duplicate vendor.
		if (existVendor(originalVendorNumber)) {
			String tMsg = "Duplicate Vendor Number error.  Vendor Number: \"" + originalVendorNumber + "\" already exists in the system.";
			throw new Exception(tMsg);
		}
		

		String tInitialUser = "";
		String tInitialAppName = "";
		String tContact = "";
		if  (userId == null || userId.trim().length() <= 0) 
		{
				tInitialUser = "VendorAdmin" + originalVendorNumber;
		}else
		{
				tInitialUser = userId;
		}		

		
		if  (appName == null || appName.trim().length() <= 0) 
		{
			tInitialAppName = "VendorUserAdmin";
		}else
		{
			tInitialAppName = appName;
		}		

		if  (contact == null || contact.trim().length() <= 0)
		{
			tContact = "";
		}else
		{
			tContact = contact;
		}		
		if  (vendorType == null || vendorType.trim().length() <= 0)
		{
			vendorType = CbkLdapConstants.CORPORATE_VENDOR;
		}
					
		if (existUser(tInitialUser)) 
		{
			throw new Exception("Duplicate User Error.  User '" + tInitialUser + "' already exists in the system.");
		}

		
		// Add the Vendor Object.
		attrib_set.put("objectclass", new String[] {"top", "person", "organizationalPerson", "inetOrgPerson"});
		attrib_set.put("sn", new String[] {name});
		attrib_set.put("cn", new String[] {"Vendor " + name});
		attrib_set.put("mail", new String[] {emailAddress});
		attrib_set.put("street", new String[] {address});
		attrib_set.put("homePostalAddress", new String[] {city});
		attrib_set.put("st", new String[] {state});
		attrib_set.put("postalCode", new String[] {zip});
		attrib_set.put("telephoneNumber", new String[] {phoneNumber});
		attrib_set.put("facsimileTelephoneNumber", new String[] {faxNumber});
		attrib_set.put("manager", new String[] {tContact});
		attrib_set.put("businessCategory", new String[] {vendorType});
	
		
		ldapDir.addObject(vendorDN, attrib_set);

		// Write a record to the audit log.
		eventLog.writeLog("Vendor", "Add", "\"" + vendorNumber + "\"");

		// Add the Vendor Group Object.
		attrib_set.clear();
		attrib_set.put("objectclass", new String[] {"top", "groupofuniquenames"});
		ldapDir.addObject(vendorGroupDN, attrib_set);

		// Assign the vendor to all default and forced "vendor" applications.
		tDN = "ou=ApplicationList,ou=Applications," + baseDN;
		tFilter = "(&(preferredlanguage=vendor/broker)(|(physicalDeliveryOfficeName=default)(physicalDeliveryOfficeName=forced)))";
		if ((vector1 = ldapDir.search(tDN, tFilter, true)) != null) {
			final int vectorSize = vector1.size();
			for (int x = 0; x < vectorSize; x++) {
				tDN = (String) vector1.elementAt(x);

				// Add the application's DN to the VendorGroup object.
				ldapDir.addAttribute(vendorGroupDN, "uniqueMember", new String[] {tDN});
			}
		}

		// Create the initial user for the vendor.

		tPassword = addVendorUser(tInitialUser, originalVendorNumber, "Temporary",
								  "Administrator", "", "Initial Administrative User",
								  phoneNumber, "");

		// Flag the user as system generated.
		final String tPeopleObjectDN = "uid=" + tInitialUser + ",ou=People," + baseDN;
		attrib_set.clear();
		attrib_set.put("preferredDeliveryMethod", new String[] {"System Generated"});
		ldapDir.updateObject(tPeopleObjectDN, attrib_set);

		// Give the the initial user rights to the vendor/supplier user administration application.
		addUserToRole(tInitialUser, tInitialAppName, "Administrator");

		return tPassword;
	}
	/**
	 * Adds the vendor to the broker.
	 * 
	 * @return void
	 * @param vendorNumber java.lang.String
	 * @param brokerNumber java.lang.String
	 * @exception java.lang.Exception
	 */
	// Jan 26, 2003 - Modified for Vendor Conversion		
	public void addVendorToBroker(String vendorNumber,
								  String brokerNumber)
			throws Exception
	{

		String 			originalVendorNumber = "";
		originalVendorNumber = vendorNumber;		
		vendorNumber = convertToInternalVendorNbr(vendorNumber);

		
		
		final String tVendorDN = "uid=" + vendorNumber + ",ou=Vendors," + baseDN;
		final String tBrokerGroupDN = "cn=" + brokerNumber + ",ou=Brokers," + baseDN;

		// Make sure the specified vendor exists.
		if (! existVendor(originalVendorNumber)) {
			String tMsg = "Unable to add vendor to broker.  Vendor doesn't exist." +
						  "  Vendor: \"" + originalVendorNumber + "\"" +
						  "  Broker: \"" + brokerNumber + "\"";
			throw new Exception(tMsg);
		}

		// Make sure the specified broker exists.
		if (! ldapDir.existObject(tBrokerGroupDN)) {
			String tMsg = "Unable to add vendor to broker.  Broker doesn't exist." +
						  "  Vendor: \"" + originalVendorNumber + "\"" +
						  "  Broker: \"" + brokerNumber + "\"";
			throw new Exception(tMsg);
		}

		// Add the vendor to the broker (if it's not there already).
		if (! ldapDir.existAttributeInObject(tBrokerGroupDN, "uniqueMember", tVendorDN)) {
			ldapDir.addAttribute(tBrokerGroupDN, "uniqueMember", new String[] {tVendorDN});

			// Write a record to the audit log.
			eventLog.writeLog("VendorsOfBroker", "Add", "vendor \"" + vendorNumber + "\" to broker \"" + brokerNumber + "\"");
		}
	}
	/**
	 * Adds the specified vendor user to the LDAP database.
	 * Returns the password for the newly added user.
	 * 
	 * @return java.lang.String
	 * @param loginID java.lang.String
	 * @param vendorNumber java.lang.String
	 * @param firstName java.lang.String
	 * @param lastName java.lang.String
	 * @param middleInitial java.lang.String
	 * @param title java.lang.String
	 * @param phoneNumber java.lang.String
	 * @param emailAddress java.lang.String
	 * @exception java.lang.Exception
	 */
	// Jan 26, 2003 - Modified for Vendor Conversion	
	public String addVendorUser(String loginID,
						  		String vendorNumber,
						  		String firstName,
							  	String lastName,
							  	String middleInitial,
							  	String title,
							  	String phoneNumber,
							  	String emailAddress)
			throws Exception
	{

		String 			originalVendorNumber = "";
		originalVendorNumber = vendorNumber;		
		vendorNumber = convertToInternalVendorNbr(vendorNumber);
		
		
		final String tPeopleObjectDN = "uid=" + loginID + ",ou=People," + baseDN;
		Hashtable   attrib_set = new Hashtable(20);
		String      password;
		String      tDN;

		// Check for a duplicate user.
		if (existUser(loginID, false)) {
			String tMsg = "Duplicate Login ID error.  Login ID: \"" + loginID + "\" is already being used.";
			throw new Exception(tMsg);
		}

		// Make sure the specified vendor exists.
		if (! existVendor(originalVendorNumber)) {
			String tMsg = "Vendor: \"" + originalVendorNumber + "\" doesn't exist.";
			throw new Exception(tMsg);
		}

		// Get a password for the user.
		password = generatePassword();

		// Add the People Object.
		attrib_set.put("objectclass", new String[] {"top", "person", "organizationalPerson", "inetOrgPerson"});
		attrib_set.put("businessCategory", new String[] {"person"});
		attrib_set.put("roomNumber", new String[] {originalVendorNumber});  // do not prefix roomNumber with 'V'
		attrib_set.put("givenname", new String[] {firstName});
		attrib_set.put("sn", new String[] {lastName});
		attrib_set.put("initials", new String[] {middleInitial});
		attrib_set.put("cn", new String[] {firstName + " " + lastName});
		attrib_set.put("title", new String[] {title});
		attrib_set.put("telephoneNumber", new String[] {phoneNumber});
		attrib_set.put("destinationIndicator", new String[] {"Vendor"});
		attrib_set.put("userPassword", new String[] {password});
		attrib_set.put("carLicense", new String[] {"16777216"});
		attrib_set.put("mail", new String[] {emailAddress});
		ldapDir.addObject(tPeopleObjectDN, attrib_set);

		// Add the user to the vendor's group.
		tDN = "cn=" + vendorNumber + ",ou=Vendors," + baseDN;
		ldapDir.addAttribute(tDN, "uniqueMember", new String[] {tPeopleObjectDN});

		// Write a record to the audit log.
		eventLog.writeLog("User", "Add", "\"" + loginID + "\"");

		return password;
	}
	/**
	 * Checks to see if the specified user has access to the
	 * specified DC number.  Returns a boolean with the result.
	 *
	 * @return boolean
	 * @param loginID java.lang.String
	 * @param dcNumber java.lang.String
	 * @exception java.lang.Exception
	 */
	public boolean checkDCAccess(String loginID,
								 String dcNumber)
			throws Exception
	{
		final String    tUserDN = "uid=" + loginID + ",ou=People," + baseDN;
		String    		tDCDN;
		Vector          vector1, vector2;
		Hashtable       hashT1;
		Object[]        attrib_value;
		String          tDN;
		String          tAdminGroupDN;
		String          tFilter;
	
		// Retrieve the DC record for the specified DC number.
		tDN = "ou=SharedGroups," + baseDN;
		tFilter = "(description=" + dcNumber + ")";
		if ((vector1 = ldapDir.search(tDN, tFilter, new String[] {"uniquemember"}, true)) == null) {
			return false;
		}
	
		vector2 = (Vector) vector1.elementAt(0);
	
		// Retrieve the DN for this DC number.
		tDCDN = (String) vector2.elementAt(0);
	
		// See if the user is assigned directly to the DC.
		hashT1 = (Hashtable) vector2.elementAt(1);
		if ((attrib_value = (Object[]) hashT1.get("uniquemember")) != null) {
			for (int x = 0; x < attrib_value.length; x++) {
				if (attrib_value[x].toString().equalsIgnoreCase(tUserDN)) {
					return(true);
				}
			}
		}
	
		// Check if there is a shared group that both the user and the DC are a member of.
		tDN = "ou=SharedGroups," + baseDN;
		tFilter = "(&(uniquemember=" + tDCDN + ")(uniquemember=" + tUserDN + "))";
		if (ldapDir.search(tDN, tFilter, true) != null) {
			return(true);
		}
	
		// Get a list of all the AdminGroups the user is a member of.
		tDN = "ou=AdminGroups,ou=Groups," + baseDN;
		tFilter = "(uniquemember=" + tUserDN + ")";
		if ((vector1 = ldapDir.search(tDN, tFilter, true)) != null) {
			final int vector1Size = vector1.size();
			for (int x1 = 0; x1 < vector1Size; x1++) {
				tAdminGroupDN = (String) vector1.elementAt(x1);
				
				// Check if there is a shared group that both the DC and the AdminGroup are a member of.
				tDN = "ou=SharedGroups," + baseDN;
				tFilter = "(&(uniquemember=" + tDCDN + ")(uniquemember=" + tAdminGroupDN + "))";
				if (ldapDir.search(tDN, tFilter, true) != null) {
					return(true);
				}
			}
		}
	   
		return(false);
	}
	/**
	 * Checks to see if the specified user has access to the
	 * specified group.  Returns a boolean with the result.
	 *
	 * @return boolean
	 * @param loginID java.lang.String
	 * @param groupName java.lang.String
	 * @param groupType java.lang.String
	 *    Can be "DC", "HQ", "UD", "RG", etc.
	 * @exception java.lang.Exception
	 */
	public boolean checkGroupAccess(String loginID,
									String groupName,
									String groupType)
			throws Exception
	{
		final String    tUserDN = "uid=" + loginID + ",ou=People," + baseDN;
		Vector          vector1;
		String          tDN;
		String          tAdminGroupDN;
		String          tFilter;

		tDN = "ou=SharedGroups," + baseDN;
		tFilter = "(&(cn=" + groupName + ")" +
				  "  (businesscategory=" + groupType + ")" +
				  "  (uniquemember=" + tUserDN + "))";

		// See if the user is assigned to the group.
		if (ldapDir.search(tDN, tFilter, true) != null) {
			return true;
		}

		tDN = "ou=AdminGroups,ou=Groups," + baseDN;
		tFilter = "(uniquemember=" + tUserDN + ")";

		// Get a list of all the AdminGroups the user is a member of.
		if ((vector1 = ldapDir.search(tDN, tFilter, true)) != null) {
			final int vector1Size = vector1.size();
			for (int x1 = 0; x1 < vector1Size; x1++) {
				tAdminGroupDN = (String) vector1.elementAt(x1);
				
		  		tDN = "ou=SharedGroups," + baseDN;
				tFilter = "(&(cn=" + groupName + ")" +
						  "  (businesscategory=" + groupType + ")" +
						  "  (uniquemember=" + tAdminGroupDN + "))";

				// See if the AdminGroup is assigned to the group.
				if (ldapDir.search(tDN, tFilter, true) != null) {
					return true;
				}
			}
		}

		return false;
	}
	/**
	 * Checks to see if the specified user has access to the
	 * specified group.  Returns a boolean with the result.
	 *
	 * @return boolean
	 * @param loginID java.lang.String
	 * @param groupNumber java.lang.String
	 * @param groupType java.lang.String
	 *    Can be "DC", "HQ", "UD", "RG", etc.
	 * @exception java.lang.Exception
	 */
	public boolean checkGroupAccessByNumber(String loginID,
											String groupNumber,
											String groupType)
			throws Exception
	{
		final String    tUserDN = "uid=" + loginID + ",ou=People," + baseDN;
		Vector          vector1;
		String          tDN;
		String          tAdminGroupDN;
		String          tFilter;

		tDN = "ou=SharedGroups," + baseDN;
		tFilter = "(&(description=" + groupNumber + ")" +
				  "  (businesscategory=" + groupType + ")" +
				  "  (uniquemember=" + tUserDN + "))";

		// See if the user is assigned to the group.
		if (ldapDir.search(tDN, tFilter, true) != null) {
			return true;
		}

		tDN = "ou=AdminGroups,ou=Groups," + baseDN;
		tFilter = "(uniquemember=" + tUserDN + ")";

		// Get a list of all the AdminGroups the user is a member of.
		if ((vector1 = ldapDir.search(tDN, tFilter, true)) != null) {
			final int vector1Size = vector1.size();
			for (int x1 = 0; x1 < vector1Size; x1++) {
				tAdminGroupDN = (String) vector1.elementAt(x1);
				
		  		tDN = "ou=SharedGroups," + baseDN;
				tFilter = "(&(description=" + groupNumber + ")" +
						  "  (businesscategory=" + groupType + ")" +
						  "  (uniquemember=" + tAdminGroupDN + "))";

				// See if the AdminGroup is assigned to the group.
				if (ldapDir.search(tDN, tFilter, true) != null) {
					return true;
				}
			}
		}

		return false;
	}
	/**
	 * Checks to see if the specified user has access to the
	 * specified region.  Returns a boolean with the result.
	 *
	 * @return boolean
	 * @param loginID java.lang.String
	 * @param regionName java.lang.String
	 * @exception java.lang.Exception
	 */
	public boolean checkRegionAccess(String loginID,
									 String regionName)
			throws Exception
	{
		return checkGroupAccess(loginID, regionName, "RG");
	}
	/**
	 * Checks to see if the specified user has access to the
	 * specified region.  Returns a boolean with the result.
	 *
	 * @return boolean
	 * @param loginID java.lang.String
	 * @param regionNumber java.lang.String
	 * @exception java.lang.Exception
	 */
	public boolean checkRegionAccessByNumber(String loginID,
											 String regionNumber)
			throws Exception
	{
		return checkGroupAccessByNumber(loginID, regionNumber, "RG");
	}
	/**
	 * Checks to see if the specified user has access to the
	 * specified vendor.  Returns a boolean with the result.
	 *
	 * @return boolean
	 * @param loginID java.lang.String
	 * @param vendorID java.lang.String
	 * @exception java.lang.Exception
	 */
	// Jan 26, 2003 - Modified for Vendor Conversion	
	// Note : This method does not require vendor conversion.  

	public boolean checkVendorAccess(String loginID,
								     String vendorID)
			throws Exception
	{
		
		UserDetail userDetail;
		String 			originalVendorNumber = "";

		// Make sure the user exists.
		if (! existUser(loginID)) {
			return false;
		}

		// Get the user details.
		userDetail = getUserDetail(loginID, 0);

		/*
		 * If the user is an admin user or a store user, always
		 * return true (they have access to all vendors).
		 */
		if ((userDetail.getUserType().equals("Admin")) ||
			(userDetail.getUserType().equals("Store"))) {

			return true;
		}

		/*
		 * If the user is a carrier user, always return false
		 * (they don't have access to vendors).
		 */

//		else if (userDetail.getUserType().equals("Carrier")) {
//			return false;
//		}

		/*
		 * If the user is a vendor user, return true if the passed
		 * vendorID matches the users vendorID.
		 */
//		else if (userDetail.getUserType().equals("Vendor")) {
//			if (userDetail.getVendorID().equalsIgnoreCase(vendorID)) {
//				return true;
//			}
//		}

		/*
		 * If the user is a broker user, check to see if the vendor
		 * is one of the broker's vendors.
		 */
//		else if (userDetail.getUserType().equals("Broker")) {
//			originalVendorNumber = vendorID;		
//			vendorID = convertToInternalVendorNbr(vendorID);
//			final String tVendorDN = "uid=" + vendorID + ",ou=Vendors," + baseDN;
//	  		final String tDN = "ou=Brokers," + baseDN;
//			final String tFilter = "(&(cn=" + userDetail.getBrokerNumber() + ")" +
//								   "  (uniquemember=" + tVendorDN + "))";
//
//			// See if the vendor is assigned to the broker that the user works for.
//			if (ldapDir.search(tDN, tFilter, true) != null) {
//				return true;
//			}
//		}


		Vector v = null;
		if  (userDetail.getUserType().equals("Vendor") 
		||  userDetail.getUserType().equals("Broker"))	{
			if  (userDetail.getUserType().equals("Vendor")) {
				v = getVendorsOfVendorUser(loginID);
			}else	{
				v = getVendorsOfBrokerUser(loginID);	
			}
			
			if  (v.size() > 0)	{
				Vendor vend = null;
				for (int i=0;i<v.size();++i){
					vend = (Vendor) v.elementAt(i);
					
					if  (vend.getVendorID().equals(vendorID)){
						return true;
					}	
				}		
			} // end of if	
		}	
		
		return false;
	}
	/**
	 * Checks to see if the specified user has access to the
	 * specified broker.  Returns a boolean with the result.
	 *
	 * @return boolean
	 * @param loginID java.lang.String
	 * @param brokerNumber java.lang.String
	 * @exception java.lang.Exception
	 */
	public boolean checkBrokerAccess(String loginID,
								     String brokerNumber)
			throws Exception
	{
		UserDetail userDetail;

		// Make sure the user exists.
		if (! existUser(loginID)) {
			return false;
		}

		// Get the user details.
		userDetail = getUserDetail(loginID, 0);

		/*
		 * If the user is an admin user or a store user, always
		 * return true (they have access to all brokers).
		 */
		if ((userDetail.getUserType().equals("Admin")) ||
			(userDetail.getUserType().equals("Store"))) {

			return true;
		}

		/*
		 * Return false if the user is a vendor or carrier user.
		 */
		else if ((userDetail.getUserType().equals("Vendor")) ||
			(userDetail.getUserType().equals("Carrier"))) {
			return false;
		}

		/*
		 * If the user is a broker user, return true if the passed
		 * brokerNumber matches the users brokerNumber.
		 */
		else if (userDetail.getUserType().equals("Broker")) {
			if (userDetail.getBrokerNumber().equalsIgnoreCase(brokerNumber)) {
				return true;
			}
		}

		return false;
	}
	/**
	 * Checks to see if the loginID matches the first name or last name
	 * of any existing users.
	 * 
	 * @return boolean
	 * @param loginID java.lang.String
	 * @exception java.lang.Exception
	 */
	public boolean checkLoginID(String loginID)
			throws Exception
	{
		Vector          vector1;
		String          tDN;
		String          tFilter;
		boolean         rc = false;

		tDN = "ou=People," + baseDN;
		tFilter = "(|(givenname=" + loginID + ")(sn=" + loginID + "))";

		if ((vector1 = ldapDir.search(tDN, tFilter, true)) != null) {
			rc = true;
		}

		return(rc);
	}
	/**
	 * Checks if the specified user has the specified password.
	 * Returns true if the specified user exists with the specified password.
	 * Returns false if the user doesn't exist or if it exists with a 
	 * different password.
	 * 
	 * @return boolean
	 * @param loginID java.lang.String
	 * @param password java.lang.String
	 * @exception java.lang.Exception
	 */
	public boolean checkPassword(String loginID,
								 String password)
			throws Exception
	{
		final String    tDN = "uid=" + loginID + ",ou=People," + baseDN;
		boolean         rc = false;

		rc = ldapDir.isValidPassword(tDN, password);

		return(rc);
	}
	/**
	 * Checks to see if the specified user has access to the
	 * specified store.
	 * 
	 * @return boolean
	 * @param loginID java.lang.String
	 * @param storeNumber java.lang.String
	 * @exception java.lang.Exception
	 */
	public boolean checkStoreAccess(String loginID,
									String storeNumber)
			throws Exception
	{
		final String    tUserDN = "uid=" + loginID + ",ou=People," + baseDN;
		final String    tStoreDN = "uid=" + storeNumber + ",ou=Stores," + baseDN;
		Vector          vector1;
		Hashtable       hashT1;
		Object[]        attrib_value;
		String          tDN;
		String          tAdminGroupDN;
		String          tFilter;

		// See if the user is assigned to the store.
		if (((hashT1 = ldapDir.read(tUserDN, new String[] {"roomnumber"})) != null) &&
			((attrib_value = (Object[]) hashT1.get("roomnumber")) != null) &&
			(attrib_value[0].toString().equalsIgnoreCase(storeNumber))) {

			return(true);
		}

		// Check if there is a shared group that both the user and the store are a member of.
		tDN = "ou=SharedGroups," + baseDN;
		tFilter = "(&(uniquemember=" + tStoreDN + ")(uniquemember=" + tUserDN + "))";
		if (ldapDir.search(tDN, tFilter, true) != null) {
			return(true);
		}

		// Get a list of all the AdminGroups the user is a member of.
		tDN = "ou=AdminGroups,ou=Groups," + baseDN;
		tFilter = "(uniquemember=" + tUserDN + ")";
		if ((vector1 = ldapDir.search(tDN, tFilter, true)) != null) {
			final int vector1Size = vector1.size();
			for (int x1 = 0; x1 < vector1Size; x1++) {
				tAdminGroupDN = (String) vector1.elementAt(x1);
				
				// Check if there is a shared group that both the store and the admin group are a member of.
				tDN = "ou=SharedGroups," + baseDN;
				tFilter = "(&(uniquemember=" + tStoreDN + ")(uniquemember=" + tAdminGroupDN + "))";
				if (ldapDir.search(tDN, tFilter, true) != null) {
					return(true);
				}
			}
		}
	   
		return(false);
	}

	/**
	 * Converts the specified store to a headquarters.
	 * Creates the HQ store group if it's not there already.
	 * Makes sure the HQ user administrators have access
	 * to the HQ group.
	 * 
	 * @return void
	 * @param userLoginID java.lang.String
	 * @param storeNumber java.lang.String
	 * @exception java.lang.Exception
	 */
	public void convertStoreToHQ(String userLoginID,
								String storeNumber)
			throws Exception
	{
		final String	storeObjectDN = "uid=" + storeNumber + ",ou=Stores," + baseDN;
		final Vector	userAdminUsers = getUserAdminUsersOfStore(storeNumber);
		final int		adminCount = userAdminUsers.size();
		Hashtable		attrib_set = new Hashtable(20);
		Vector			tVect;
		String			tDN;
		String			tUserRegionAdminGroupDN;
		Store			tStore;
		UserName		tUserName;
		String			hqGroupName;

		// Make sure store exists and is not an HQ.
		tStore = getStoreDetail(storeNumber);
		if (! (tStore.getType()).equalsIgnoreCase("store")) {
			String tMsg = "Store Type error.  Store Number: \"" + storeNumber + "\" is not a regular store.";
			throw new Exception(tMsg);
		}

		// Update the Store Object.
		attrib_set.put("businessCategory", new String[] {"hq"});
		ldapDir.updateObject(storeObjectDN, attrib_set);

		// Write a record to the audit log.
		eventLog.writeLog("Store", "ConvertToHQ", "\"" + storeNumber + "\"");

		// See if this store/hq is in an HQ group yet.
		tVect = getGroupsOfStore(storeNumber, null, "HQ");
		if (tVect.size() > 0) {

			// If it is, save the group's name.
			final StoreGroup firstHQGroup = (StoreGroup) tVect.elementAt(0);
			hqGroupName = firstHQGroup.getName();
		}
		else {

			// Otherwise, make sure an HQ group exists with the right name.
			hqGroupName = tStore.getName();
			tDN = "cn=" + hqGroupName + ",ou=SharedGroups," + baseDN;
			if (! ldapDir.existObject(tDN)) {

				// Get the DN of the user's Region Admin Group.
				tUserRegionAdminGroupDN = getRegionAdminGroupDNOfUser(userLoginID);

				// Add the new group.
				doAddGroup(hqGroupName, "HQ", userLoginID, tUserRegionAdminGroupDN, null);
			}

			// Make this store a member of the group.
			addStoreToGroup(storeNumber, hqGroupName);
		}

		// Loop thru the admin users.
		for (int x1 = 0; x1 < adminCount; x1++) {
			tUserName = (UserName) userAdminUsers.elementAt(x1);

			// Add the admin user to the HQ group.
			addUserToGroup(tUserName.getLoginID(), hqGroupName);
		}
	}

	/**
	 * Deletes the specified alias from the database.
	 * 
	 * @return void
	 * @param alias java.lang.String
	 * @exception java.lang.Exception
	 */
	public void deleteAlias(String alias)
			throws Exception
	{
		final String    tDN = "uid=" + alias + ",ou=StoreAlias,ou=Stores," + baseDN;
		Hashtable       hashT;

		if ((hashT = ldapDir.read(tDN, new String[] {"sn"})) != null) {
			ldapDir.deleteObject(tDN);

			// Write a record to the audit log.
			eventLog.writeLog("Alias", "Delete", "\"" + alias + "\" from \"" + getAttributeValue(hashT, "sn") + "\"");
		}
	}
	/**
	 * Removes access to an application.  Also removes access to the app
	 * for any users at the broker that were using the application.
	 * 
	 * @return void
	 * @param brokerNumber java.lang.String
	 * @param appName java.lang.String
	 * @exception java.lang.Exception
	 */
	public void deleteAppFromBroker(String brokerNumber,
								    String appName)
			throws Exception
	{
		final String tAppListObjectDN = "uid=" + appName + ",ou=ApplicationList,ou=Applications," + baseDN;
		final String tBrokerObjectDN = "cn=" + brokerNumber + ",ou=Brokers," + baseDN;
		Vector          vector1;
		Vector          vector2;
		UserName        tUserName;
		ApplicationRole tAppRole;
		String          loginID;

		// First delete access to roles of the app for all users at the broker.
		vector1 = getUsersOfBroker(brokerNumber);
		final int vector1Size = vector1.size();
		for (int x1 = 0; x1 < vector1Size; x1++) {
			tUserName = (UserName) vector1.elementAt(x1);
			loginID = tUserName.getLoginID();

			vector2 = getAppRolesOfUser(loginID, appName);
			final int vector2Size = vector2.size();
			for (int x2 = 0; x2 < vector2Size; x2++) {
				tAppRole = (ApplicationRole) vector2.elementAt(x2);

				deleteUserFromRole(loginID, appName, tAppRole.getName());
			}
		}

		// Remove the app from the broker.
		if (ldapDir.existAttributeInObject(tBrokerObjectDN, "uniqueMember", tAppListObjectDN)) {
			ldapDir.deleteAttribute(tBrokerObjectDN, "uniqueMember", new String[] {tAppListObjectDN});

			// Write a record to the audit log.
			eventLog.writeLog("BrokerApp", "Delete", "\"" + appName + "\" from \"" + brokerNumber + "\"");
		}
	}
	/**
	 * Removes access to an application.  Also removes access to the app
	 * for any users at the store store that were using the application.
	 * 
	 * @return void
	 * @param storeNumber java.lang.String
	 * @param appName java.lang.String
	 * @exception java.lang.Exception
	 */
	public void deleteAppFromStore(String storeNumber,
								   String appName)
			throws Exception
	{
		final String tAppListObjectDN = "uid=" + appName + ",ou=ApplicationList,ou=Applications," + baseDN;
		final String tStoreObjectDN = "cn=" + storeNumber + ",ou=Stores," + baseDN;
		Vector          vector1;
		Vector          vector2;
		UserName        tUserName;
		ApplicationRole tAppRole;
		String          loginID;

		// First delete access to roles of the app for all users in the store.
		vector1 = getUsersOfStore(storeNumber);
		final int vector1Size = vector1.size();
		for (int x1 = 0; x1 < vector1Size; x1++) {
			tUserName = (UserName) vector1.elementAt(x1);
			loginID = tUserName.getLoginID();

			vector2 = getAppRolesOfUser(loginID, appName);
			final int vector2Size = vector2.size();
			for (int x2 = 0; x2 < vector2Size; x2++) {
				tAppRole = (ApplicationRole) vector2.elementAt(x2);

				deleteUserFromRole(loginID, appName, tAppRole.getName());
			}
		}

		// Remove the app from the store.
		if (ldapDir.existAttributeInObject(tStoreObjectDN, "uniqueMember", tAppListObjectDN)) {
			ldapDir.deleteAttribute(tStoreObjectDN, "uniqueMember", new String[] {tAppListObjectDN});

			// Write a record to the audit log.
			eventLog.writeLog("StoreApp", "Delete", "\"" + appName + "\" from \"" + storeNumber + "\"");
		}
	}
	/**
	 * Removes access to an application.  Also removes access to the app
	 * for any users at the vendor that were using the application.
	 * 
	 * @return void
	 * @param vendorID java.lang.String
	 * @param appName java.lang.String
	 * @exception java.lang.Exception
	 */
	// Jan 26, 2003 - Modified for Vendor Conversion		
	public void deleteAppFromVendor(String vendorID,
								    String appName)
			throws Exception
	{
		String 			originalVendorNumber = "";
		originalVendorNumber = vendorID;		
		vendorID = convertToInternalVendorNbr(vendorID);
		
		final String tAppListObjectDN = "uid=" + appName + ",ou=ApplicationList,ou=Applications," + baseDN;
		final String tVendorObjectDN = "cn=" + vendorID + ",ou=Vendors," + baseDN;
		Vector          vector1;
		Vector          vector2;
		UserName        tUserName;
		ApplicationRole tAppRole;
		String          loginID;

		// First delete access to roles of the app for all users at the vendor.
		vector1 = getUsersOfVendor(originalVendorNumber);
		final int vector1Size = vector1.size();
		for (int x1 = 0; x1 < vector1Size; x1++) {
			tUserName = (UserName) vector1.elementAt(x1);
			loginID = tUserName.getLoginID();

			vector2 = getAppRolesOfUser(loginID, appName);
			final int vector2Size = vector2.size();
			for (int x2 = 0; x2 < vector2Size; x2++) {
				tAppRole = (ApplicationRole) vector2.elementAt(x2);

				deleteUserFromRole(loginID, appName, tAppRole.getName());
			}
		}

		// Remove the app from the vendor.
		if (ldapDir.existAttributeInObject(tVendorObjectDN, "uniqueMember", tAppListObjectDN)) {
			ldapDir.deleteAttribute(tVendorObjectDN, "uniqueMember", new String[] {tAppListObjectDN});

			// Write a record to the audit log.
			eventLog.writeLog("VendorApp", "Delete", "\"" + appName + "\" from \"" + vendorID + "\"");
		}
	}
	/**
	 * Removes the broker and all the broker's users from the
	 * database.
	 * 
	 * @return void
	 * @param brokerNumber java.lang.String
	 * @exception java.lang.Exception
	 */
	public void deleteBroker(String brokerNumber)
			throws Exception
	{
		final String    tPeopleBaseDN = "ou=People," + baseDN;
		final Name      tPeopleBaseDNName = ldapDir.convertToName(tPeopleBaseDN);
		Vector          vector1;
		Hashtable       hashT1;
		Hashtable       hashT2;
		Object[]        attrib_value1;
		Object[]        attrib_value2;
		StoreAlias      tAlias;
		String          tDN;
		Name            tDNName;
		UserDetail user = null;
		// Delete all the broker's users.
		tDN = "cn=" + brokerNumber + ",ou=Brokers," + baseDN;
		if (((hashT1 = ldapDir.read(tDN, new String[] {"uniquemember"})) != null) &&
			((attrib_value1 = (Object[]) hashT1.get("uniquemember")) != null)) {

			// Look at each member and pull out the users.
			for (int i = 0; i < attrib_value1.length; i++) {	
				tDN = attrib_value1[i].toString();
				tDNName = ldapDir.convertToName(tDN);

				// Delete all the broker's users.
				if ((tDNName.startsWith(tPeopleBaseDNName)) &&
					((hashT2 = ldapDir.read(tDN, new String[] {"uid"})) != null) &&
					((attrib_value2 = (Object[]) hashT2.get("uid")) != null)) {

					// Delete the user.
					// changed on 05/20/2004.  Delete only the users attached to the broker
					user = getUserDetail(attrib_value2[0].toString());
					
					if  (user.getUserType().equalsIgnoreCase("Broker")
					&& user.getBrokerNumber().equalsIgnoreCase(brokerNumber))
					{
						deleteBrokerUser(attrib_value2[0].toString());
					}
					
				}
			}
		}

		// Delete the BrokerGroup Object.
		tDN = "cn=" + brokerNumber + ",ou=Brokers," + baseDN;
		ldapDir.deleteObject(tDN);

		// Delete the Broker Object.
		tDN = "uid=" + brokerNumber + ",ou=Brokers," + baseDN;
		ldapDir.deleteObject(tDN);

		// Write a record to the audit log.
		eventLog.writeLog("Broker", "Delete", "\"" + brokerNumber + "\"");
	}
	/**
	 * Deletes the specified Store Group from the database.
	 * 
	 * @return void
	 * @param groupName java.lang.String
	 * @exception java.lang.Exception
	 */
	public void deleteGroup(String groupName)
			throws Exception
	{
		final String tDN = "cn=" + groupName + ",ou=SharedGroups," + baseDN;

		ldapDir.deleteObject(tDN);

		// Write a record to the audit log.
		eventLog.writeLog("Group", "Delete", "\"" + groupName + "\"");
	}
	/**
	 * Removes the store and all the store's users from
	 * the database.
	 * 
	 * @return void
	 * @param storeNumber java.lang.String
	 * @exception java.lang.Exception
	 */
	public void deleteStore(String storeNumber)
			throws Exception
	{
		final String    tPeopleBaseDN = "ou=People," + baseDN;
		final Name      tPeopleBaseDNName = ldapDir.convertToName(tPeopleBaseDN);
		Vector          vector1;
		Hashtable       hashT1;
		Hashtable       hashT2;
		Object[]        attrib_value1;
		Object[]        attrib_value2;
		StoreAlias      tAlias;
		String          tDN;
		Name            tDNName;

		// Delete all the store's users.
		tDN = "cn=" + storeNumber + ",ou=Stores," + baseDN;
		if (((hashT1 = ldapDir.read(tDN, new String[] {"uniquemember"})) != null) &&
			((attrib_value1 = (Object[]) hashT1.get("uniquemember")) != null)) {

			// Look at each member and pull out the users.
			for (int i = 0; i < attrib_value1.length; i++) {	
				tDN = attrib_value1[i].toString();
				tDNName = ldapDir.convertToName(tDN);

				// Delete all the store's users.
				if ((tDNName.startsWith(tPeopleBaseDNName)) &&
					((hashT2 = ldapDir.read(tDN, new String[] {"uid"})) != null) &&
					((attrib_value2 = (Object[]) hashT2.get("uid")) != null)) {
						
					// Delete the user.
					deleteUser(attrib_value2[0].toString());
				}
			}
		}

		// Delete all the store's aliases.
		vector1 = getAliasListForStore(storeNumber);
		final int vector1Size = vector1.size();
		for (int x1 = 0; x1 < vector1Size; x1++) {
			tAlias = (StoreAlias) vector1.elementAt(x1);
			deleteAlias(tAlias.getAlias());
		}
		
		// Delete the StoreInfo Object.
		tDN = "cn=" + storeNumber + ",ou=Stores," + baseDN;
		ldapDir.deleteObject(tDN);

		// Delete the Store Object.
		tDN = "uid=" + storeNumber + ",ou=Stores," + baseDN;
		ldapDir.deleteObject(tDN);

		// Write a record to the audit log.
		eventLog.writeLog("Store", "Delete", "\"" + storeNumber + "\"");
	}
	/**
	 * Removes the store from the group.
	 * 
	 * @return void
	 * @param storeNumber java.lang.String
	 * @param groupName java.lang.String
	 * @exception java.lang.Exception
	 */
	public void deleteStoreFromGroup(String storeNumber,
									 String groupName)
			throws Exception
	{
		final String tStoreDN = "uid=" + storeNumber + ",ou=Stores," + baseDN;
		final String tGroupDN = "cn=" + groupName + ",ou=SharedGroups," + baseDN;

		// Remove the user from the group.
		if (ldapDir.existAttributeInObject(tGroupDN, "uniqueMember", tStoreDN)) {
			ldapDir.deleteAttribute(tGroupDN, "uniqueMember", new String[] {tStoreDN});

			// Write a record to the audit log.
			eventLog.writeLog("StoreGroup", "Delete", "\"" + storeNumber + "\" from \"" + groupName + "\"");
		}
	}
	/**
	 * Delete the specified user.  So far, SUPERVALU users and
	 * retail users are also saved in Domino, pass true for the
	 * callDomino flag on those users.
	 * 
	 * @return void
	 * @param loginID java.lang.String
	 * @param callDomino boolean
	 * @exception java.lang.Exception
	 */
	private void deleteUser(String loginID, boolean callDomino)
			throws Exception
	{
		final String tPeopleObjectDN = "uid=" + loginID + ",ou=People," + baseDN;

		// Delete the user from Domino.
		if (callDomino)
		{
			domino.deleteUser(loginID);
		}

		// Delete the People Object.
		ldapDir.deleteObject(tPeopleObjectDN);

		// Write a record to the audit log.
		eventLog.writeLog("User", "Delete", "\"" + loginID + "\"");
	}
	/**
	 * Delete the specified corporate or retail user.
	 *
	 * @return void
	 * @param loginID java.lang.String
	 * @exception java.lang.Exception
	 */
	public void deleteUser(String loginID)
			throws Exception
	{
		deleteUser(loginID, true);
	}
	/**
	 * Removes the user from the admin group.
	 * 
	 * @return void
	 * @param loginID java.lang.String
	 * @param adminGroupName java.lang.String
	 * @exception java.lang.Exception
	 */
	public void deleteUserFromAdminGroup(String loginID,
										 String adminGroupName)
			throws Exception
	{
		final String tGroupDN = "cn=" + adminGroupName + ",ou=AdminGroups,ou=Groups," + baseDN;
		final String tPeopleObjectDN = "uid=" + loginID + ",ou=People," + baseDN;

		// Remove the user from the group.
		if (ldapDir.existAttributeInObject(tGroupDN, "uniqueMember", tPeopleObjectDN)) {
			ldapDir.deleteAttribute(tGroupDN, "uniqueMember", new String[] {tPeopleObjectDN});

			// Write a record to the audit log.
			eventLog.writeLog("AdminGroup", "Delete", "\"" + loginID + "\" from \"" + adminGroupName + "\"");
		}
	}
	/**
	 * Removes access to a group of stores from the user.
	 * 
	 * @return void
	 * @param loginID java.lang.String
	 * @param groupName java.lang.String
	 * @exception java.lang.Exception
	 */
	public void deleteUserFromGroup(String loginID,
									String groupName)
			throws Exception
	{
		final String tGroupDN = "cn=" + groupName + ",ou=SharedGroups," + baseDN;
		final String tPeopleObjectDN = "uid=" + loginID + ",ou=People," + baseDN;

		// Remove the user from the group.
		if (ldapDir.existAttributeInObject(tGroupDN, "uniqueMember", tPeopleObjectDN)) {
			ldapDir.deleteAttribute(tGroupDN, "uniqueMember", new String[] {tPeopleObjectDN});

			// Write a record to the audit log.
			eventLog.writeLog("UserGroup", "Delete", "\"" + loginID + "\" from \"" + groupName + "\"");
		}
	}
	/**
	 * Removes the user from all the Mail Roles
	 * that they are a member of.
	 * 
	 * @return void
	 * @param loginID java.lang.String
	 * @exception java.lang.Exception
	 */
	private void deleteUserFromMailRoles(String loginID)
			throws Exception
	{
		final String    tUserDN = "uid=" + loginID + ",ou=People," + baseDN;
		Vector          vector1;
		String          tDN;
		String          tFilter;

		tDN = "ou=MailGroups,ou=Applications," + baseDN;
		tFilter = "(uniquemember=" + tUserDN + ")";

		// Get a list of all the Mail Groups the user is a member of.
		if ((vector1 = ldapDir.search(tDN, tFilter, true)) != null) {
			final int vectorSize = vector1.size();
			for (int x = 0; x < vectorSize; x++) {
				tDN = (String) vector1.elementAt(x);
				ldapDir.deleteAttribute(tDN, "uniqueMember", new String[] {tUserDN});
			}
		}
	}
	/**
	 * Removes the user from an application role.
	 * 
	 * @return void
	 * @param loginID java.lang.String
	 * @param appName java.lang.String
	 * @param roleName java.lang.String
	 * @exception java.lang.Exception
	 */
	public void deleteUserFromRole(String loginID,
								   String appName,
								   String roleName)
			throws Exception
	{
		final String tPeopleObjectDN = "uid=" + loginID + ",ou=People," + baseDN;
		String tDN;

		// Remove the user from the role.
		tDN = "cn=" + roleName + ",ou=" + appName + ",ou=Applications," + baseDN;
		if (ldapDir.existAttributeInObject(tDN, "uniqueMember", tPeopleObjectDN)) {
			ldapDir.deleteAttribute(tDN, "uniqueMember", new String[] {tPeopleObjectDN});

			// Write a record to the audit log.
			eventLog.writeLog("UserRole", "Delete", "\"" + loginID + "\" from \"" + appName + "\"/\"" + roleName + "\"");
		}
	}
	/**
	 * Removes the vendor and all the vendor's users from the
	 * database.
	 * 
	 * @return void
	 * @param vendorNumber java.lang.String
	 * @exception java.lang.Exception
	 */
	// Jan 26, 2003 - Modified for Vendor Conversion		
	public void deleteVendor(String vendorNumber)
			throws Exception
	{
		String 			originalVendorNumber = "";
		originalVendorNumber = vendorNumber;		
		vendorNumber = convertToInternalVendorNbr(vendorNumber);
		
		final String    tPeopleBaseDN = "ou=People," + baseDN;
		final Name      tPeopleBaseDNName = ldapDir.convertToName(tPeopleBaseDN);
		Vector          vector1;
		Hashtable       hashT1;
		Hashtable       hashT2;
		Object[]        attrib_value1;
		Object[]        attrib_value2;
		StoreAlias      tAlias;
		String          tDN;
		Name            tDNName;
		UserDetail user = null;

		// Delete all the vendor's users.
		tDN = "cn=" + vendorNumber + ",ou=Vendors," + baseDN;
		if (((hashT1 = ldapDir.read(tDN, new String[] {"uniquemember"})) != null) &&
			((attrib_value1 = (Object[]) hashT1.get("uniquemember")) != null)) {

			// Look at each member and pull out the users.
			for (int i = 0; i < attrib_value1.length; i++) {	
				tDN = attrib_value1[i].toString();
				tDNName = ldapDir.convertToName(tDN);

				// Delete all the vendor's users.
				if ((tDNName.startsWith(tPeopleBaseDNName)) &&
					((hashT2 = ldapDir.read(tDN, new String[] {"uid"})) != null) &&
					((attrib_value2 = (Object[]) hashT2.get("uid")) != null)) {

					// Delete the user.
					// changed on 05/20/2004.  Delete only the users attached to the vendor
					user = getUserDetail(attrib_value2[0].toString());
					
					if  (user.getUserType().equalsIgnoreCase("Vendor")
					&& user.getVendorID().equals(originalVendorNumber))
					{
						deleteVendorUser(attrib_value2[0].toString());
					}
				}
			}
		}

		// Delete the VendorGroup Object.
		tDN = "cn=" + vendorNumber + ",ou=Vendors," + baseDN;
		ldapDir.deleteObject(tDN);

		// Delete the Vendor Object.
		tDN = "uid=" + vendorNumber + ",ou=Vendors," + baseDN;
		ldapDir.deleteObject(tDN);

		// Write a record to the audit log.
		eventLog.writeLog("Vendor", "Delete", "\"" + vendorNumber + "\"");
	}
	/**
	 * Removes the vendor from the broker.
	 * 
	 * @return void
	 * @param vendorNumber java.lang.String
	 * @param brokerNumber java.lang.String
	 * @exception java.lang.Exception
	 */
	// Jan 26, 2003 - Modified for Vendor Conversion		
	public void deleteVendorFromBroker(String vendorNumber,
									   String brokerNumber)
			throws Exception
	{
		String 			originalVendorNumber = "";
		originalVendorNumber = vendorNumber;		
		vendorNumber = convertToInternalVendorNbr(vendorNumber);
	
		final String tVendorDN = "uid=" + vendorNumber + ",ou=Vendors," + baseDN;
		final String tBrokerGroupDN = "cn=" + brokerNumber + ",ou=Brokers," + baseDN;

		// Remove the vendor from the broker group.
		if (ldapDir.existAttributeInObject(tBrokerGroupDN, "uniqueMember", tVendorDN)) {
			ldapDir.deleteAttribute(tBrokerGroupDN, "uniqueMember", new String[] {tVendorDN});

			// Write a record to the audit log.
			eventLog.writeLog("VendorsOfBroker", "Delete", "vendor \"" + vendorNumber + "\" from broker \"" + brokerNumber + "\"");
		}
	}
	/**
	 * This function undoes whatever initialize() does.
	 * 
	 * @return void
	 * @exception java.lang.Exception
	 */
	public void destroy() 
			throws Exception
	{
		if (ldapDir == null) {
			return;
		}
	
		try {
			// Disconnect the connection with the server.
			ldapDir.disconnect();
		}
		catch (Exception e) {
			throw e;    // Rethrow the exception.
		}
		finally {
			ldapDir = null;
			svharborConstants = null;
			domino = null;
			eventLog = null;
		}
	}
	/**
	 * Adds a new store group to the LDAP database.
	 * 
	 * @return void
	 * @param groupName java.lang.String
	 * @param groupType java.lang.String
	 * @param loginID java.lang.String
	 * @param adminGroupDN java.lang.String
	 * @param groupNumber java.lang.String - Pass null if
	 * the new group doesn't have a number.
	 * @exception java.lang.Exception
	 */
	private void doAddGroup(String groupName,
							String groupType,
							String loginID,
							String adminGroupDN,
							String groupNumber)
			throws Exception
	{
		final String tSharedGroupsDN = "cn=" + groupName + ",ou=SharedGroups," + baseDN;
		final String tAdminGroupName = getObjectName(adminGroupDN);
		Hashtable   attrib_set = new Hashtable(10);
		Date        currDate = new Date();
		String      tDN;

		// Check for a duplicate group.
		if (existGroup(groupName)) {
			String tMsg = "Duplicate Store Group error.  Group: \"" + groupName + "\" is already being used.";
			throw new Exception(tMsg);
		}

		if (! ldapDir.existObject(adminGroupDN)) {
			String tMsg = "Admin Group: \"" + tAdminGroupName + "\" doesn't exist.";
			throw new Exception(tMsg);
		}

		// Add the SharedGroups object.
		attrib_set.put("objectclass", new String[] {"top", "groupofuniquenames"});
		attrib_set.put("businessCategory", new String[] {groupType});
		attrib_set.put("owner", new String[] {loginID});
		attrib_set.put("uniqueMember", new String[] {adminGroupDN});
		attrib_set.put("seeAlso", new String[] {Long.toString(currDate.getTime())});
		if ((groupNumber != null) &&
			(groupNumber.length() > 0))
		{
			attrib_set.put("description", new String[] {groupNumber});
		}
		ldapDir.addObject(tSharedGroupsDN, attrib_set);

		// Write a record to the audit log.
		eventLog.writeLog("Group", "Add", "\"" + groupName + "\" (AdminGroup=\"" + tAdminGroupName + "\")(Manager=\"" + loginID + "\")(GroupType=\"" + groupType + "\")");
	}
	/**
	 * Checks if the specified Admin Group exists in the database.
	 * 
	 * @return boolean
	 * @param adminGroupName java.lang.String
	 * @exception java.lang.Exception
	 */
	private boolean existAdminGroup(String adminGroupName)
			throws Exception
	{
		final String    tDN = "cn=" + adminGroupName + ",ou=AdminGroups,ou=Groups," + baseDN;
		boolean         rc = false;

		rc = ldapDir.existObject(tDN);
		
		return(rc);
	}
	/**
	 * Checks if the specified alias exists in the database.
	 * 
	 * @return boolean
	 * @param alias java.lang.String
	 * @exception java.lang.Exception
	 */
	public boolean existAlias(String alias)
			throws Exception
	{
		final String    tDN = "uid=" + alias + ",ou=StoreAlias,ou=Stores," + baseDN;
		boolean         rc = false;

		rc = ldapDir.existObject(tDN);
		
		return(rc);
	}
	/**
	 * Checks if the specified store has access to the
	 * specified application.
	 * 
	 * @return boolean
	 * @param storeNumber java.lang.String
	 * @param appName java.lang.String
	 * @exception java.lang.Exception
	 */
	private boolean existAppAtStore(String storeNumber,
									String appName)
			throws Exception
	{
		final String 	tAppListObjectDN = "uid=" + appName + ",ou=ApplicationList,ou=Applications," + baseDN;
		final String 	tStoreObjectDN = "cn=" + storeNumber + ",ou=Stores," + baseDN;
		boolean			rc;

		rc = ldapDir.existAttributeInObject(tStoreObjectDN,
											"uniqueMember",
											tAppListObjectDN);

		return rc;
	}
	/*
	 * Determine if the specified attribute exists in the object.
	 * 
	 * @return boolean
	 * @param table Hashtable
	 * @param attrName java.lang.String
	 * @exception java.lang.Exception
	 */
	private boolean existAttribute(Hashtable table,
								   String attrName)
	{
		boolean     ret = false;

		ret = table.get(attrName.toLowerCase()) != null ? true : false;
		
		return(ret);
	}
	/**
	 * Determines if the specified attribute exists with the
	 * specified value in the table of attributes.
	 * 
	 * @return boolean
	 * @param table Hashtable
	 * @param attribName java.lang.String
	 * @param attribValue java.lang.String
	 * @exception java.lang.Exception
	 */
	private boolean existAttributeValue(Hashtable table,
										String attribName,
										String attribValue)
	{
		Object[]    value;
		boolean     ret = false;

		if ((value = (Object[]) table.get(attribName.toLowerCase())) != null) {
			for (int i = 0; i < value.length; i++) {
				if (value[i].toString().equalsIgnoreCase(attribValue)) {
					ret = true;
					break;
				}
			}
		}
		
		return(ret);
	}
	/**
	 * Determines if the specified attribute exists with the
	 * specified value in the table of attributes.
	 * 
	 * @return boolean
	 * @param table Hashtable
	 * @param attribName java.lang.String
	 * @param attribValue Name
	 * @exception java.lang.Exception
	 */
	private boolean existAttributeValue(Hashtable table,
										String attribName,
										Name attribValue)
	{
		Object[]    value;
		Name        tName;
		String      tValue;
		boolean     ret = false;

		if ((value = (Object[]) table.get(attribName.toLowerCase())) != null) {
			for (int i = 0; i < value.length; i++) {
				tValue = value[i].toString();
				try {
					tName = ldapDir.convertToName(tValue);

					if (tName.compareTo(attribValue) == 0) {
						ret = true;
						break;
					}
				}
				catch(Exception e){
					// Do nothing.
				}
			}
		}
		
		return(ret);
	}
	/**
	 * Checks if the specified broker exists in the database.
	 * 
	 * @return boolean
	 * @param brokerNumber java.lang.String
	 * @exception java.lang.Exception
	 */
	public boolean existBroker(String brokerNumber)
			throws Exception
	{
		final String	tDN = "uid=" + brokerNumber + ",ou=Brokers," + baseDN;
		boolean			rc;

		rc = ldapDir.existObject(tDN);

		return rc;
	}
	/**
	 * Checks if the specified Store Group exists in the database.
	 * 
	 * @return boolean
	 * @param groupName java.lang.String
	 * @exception java.lang.Exception
	 */
	public boolean existGroup(String groupName)
			throws Exception
	{
		final String    tDN = "cn=" + groupName + ",ou=SharedGroups," + baseDN;
		boolean         rc = false;

		rc = ldapDir.existObject(tDN);
		
		return(rc);
	}
	/**
	 * Checks if the specified Store Group Type exists in the database.
	 * 
	 * @return boolean
	 * @param groupType java.lang.String
	 * @exception java.lang.Exception
	 */
	public boolean existGroupType(String groupType)
			throws Exception
	{
		final String    tGroupTypeDN = "uid=" + groupType + ",ou=SharedGroupTypes,ou=SharedGroups," + baseDN;
		boolean         rc = false;

		rc = ldapDir.existObject(tGroupTypeDN);
		
		return(rc);
	}
	/**
	 * Checks if the specified store exists in the database.
	 * 
	 * @return boolean
	 * @param storeNumber java.lang.String
	 * @exception java.lang.Exception
	 */
	public boolean existStore(String storeNumber)
			throws Exception
	{
		final String    tDN = "uid=" + storeNumber + ",ou=Stores," + baseDN;
		boolean         rc = false;

		rc = ldapDir.existObject(tDN);
		
		return(rc);
	}
	/**
	 * Checks if the specified store is a member of the
	 * specified group.
	 * 
	 * @return boolean
	 * @param storeNumber java.lang.String
	 * @param groupName java.lang.String
	 * @exception java.lang.Exception
	 */
	private boolean existStoreInGroup(String storeNumber,
									  String groupName)
			throws Exception
	{
		final String    tStoreDN = "uid=" + storeNumber + ",ou=Stores," + baseDN;
		final String    tGroupDN = "cn=" + groupName + ",ou=SharedGroups," + baseDN;
		boolean         rc = false;

		rc = ldapDir.existAttributeInObject(tGroupDN, "uniqueMember", tStoreDN);
		
		return(rc);
	}
    /**
	 * Checks if the specified user exists in the SVHarbor portion of the database.
	 * 
	 * @return boolean
	 * @param loginID java.lang.String
	 * @exception java.lang.Exception
	 */
	public boolean existUser(String loginID)
			throws Exception
	{
		final String    tDN = "uid=" + loginID + ",ou=People," + baseDN;
		boolean         rc = false;

		rc = ldapDir.existObject(tDN);
		
		return(rc);
	}
    /**
	 * Checks if the specified user exists in the database.
     * if svHarborOnly is true, the function checks only the SVHarbor portion of the database.
     * if svHarborOnly is false, the function checks the entire database.
	 * 
	 * @return boolean
	 * @param loginID java.lang.String
	 * @param svHarborOnly boolean
	 * @exception java.lang.Exception
	 */
	public boolean existUser(String loginID,
                             boolean svHarborOnly)
			throws Exception
	{
		boolean rc = svHarborOnly ? existUser(loginID) : existUserAnywhere(loginID);
		
		return(rc);
	}
	/**
	 * Checks if the specified user exists anywhere in the database.
	 * 
	 * @return boolean
	 * @param loginID java.lang.String
	 * @exception java.lang.Exception
	 */
	private boolean existUserAnywhere(String loginID)
			throws Exception
	{
		String  tDN;
		String  tFilter;
		boolean rc = false;
        
		tDN = ldapDir.convertToName(baseDN).get(0);
		tFilter = "(&(objectclass=person)(uid=" + loginID + "))";

        // Check the entire tree from "o=supervalu.com" on down.
		if (ldapDir.search(tDN, tFilter, false) != null) {
			rc = true;
		}

		return(rc);
	}
	/**
	 * Checks if the specified vendor exists in the database.
	 * 
	 * @return boolean
	 * @param vendorNumber java.lang.String
	 * @exception java.lang.Exception
	 */
	// Jan 26, 2003 - Modified for Vendor Conversion		
	public boolean existVendor(String vendorNumber)
			throws Exception
	{
		String 			originalVendorNumber = "";
		originalVendorNumber = vendorNumber;		
		vendorNumber = convertToInternalVendorNbr(vendorNumber);
		
		final String	tDN = "uid=" + vendorNumber + ",ou=Vendors," + baseDN;
		
		//System.out.println("DN " + tDN);
		boolean			rc;

		rc = ldapDir.existObject(tDN);

		return rc;
	}

	/**
	 * Checks if the specified vendor group exists in the database.
	 * 
	 * @return boolean
	 * @param vendorGroupName java.lang.String
	 * @exception java.lang.Exception
	 */
	public boolean existVendorGroup(String groupName)
			throws Exception
	{
		final String    tDN = "cn=" + groupName + ",ou=VendorGroups," + baseDN;
		boolean         rc = false;

		rc = ldapDir.existObject(tDN);
		
		return(rc);
	}

	/**
	 * Checks if the specified distribution group exists in the database.
	 * 
	 * @return boolean
	 * @param distributionGroupNbr java.lang.String
	 * @exception java.lang.Exception
	 */
	public boolean existDistributionGroup(String groupName)
			throws Exception
	{
		final String tDN = "cn=" + groupName + ",ou=DistributionGroups,ou=Groups," + baseDN;
		
		boolean         rc = false;

		rc = ldapDir.existObject(tDN);
		
		return(rc);
	}

	/**
	 * Returns a password that meets the following criteria:
	 *  1) is 6 characters long.
	 *  2) has 4 lower-case letters and 2 digits in random order.
	 *  3) doesn't have 2 identical characters in a row.
	 * 
	 * @return java.lang.String
	 */
	private String generatePassword()
	{
		final byte      pWordLen = 6;   // Length of the returned string.
		final byte      numDigits = 2;  // Number of digits in returned string (the remaining characters in the string will be letters).
		Random          random = new Random(GetNewRandomSeed());;
		String          ret = new String();
		boolean         isDigit[] = new boolean[pWordLen];
		byte            bytes[] = new byte[1];
		byte            randVal = 0;
		byte            prevVal = (byte) 0;

		// Determine which characters will be digits.
		for (int x = 0; x < numDigits; x++) {
			do {
				randVal = getRandomNumber(random, (byte) 0, (byte) (pWordLen - 1));
			} while (isDigit[randVal] == true);
			
			isDigit[randVal] = true;
		}
		
		// Fill the string with random letters and numbers.
		for (int x = 0; x < pWordLen; x++) {
			do {
				if (isDigit[x] == true) {
					do {
						randVal = getRandomNumber(random, (byte) '0', (byte) '9');
					} while (randVal == '1');  // Don't allow number one in password (it's too easy to confuse with lower-case L).
				}
				else {
					do {
						randVal = getRandomNumber(random, (byte) 'a', (byte) 'z');
					} while (randVal == 'l');  // Don't allow 'l' in password (it's too easy to confuse with '1').
				}
			} while (randVal == prevVal);  // Don't allow two identical characters in a row.
			
			ret = ret + (char) randVal;
			prevVal = randVal;
		}

		return(ret);
	}
	/**
	 * Gets a list of Admin Groups that the user is a member of.
	 * 
	 * @return Vector of AdminGroup that the user is a member of.
	 * 		   The vector may be empty but never null.
	 * @param loginID java.lang.String
	 * @exception java.lang.Exception
	 */
	public Vector getAdminGroupsOfUser(String loginID)
			throws Exception
	{
		final String    tUserDN = "uid=" + loginID + ",ou=People," + baseDN;
		Vector          ret = new Vector();
		AdminGroup      group;
		Vector          vector1, vector2;
		Hashtable       hashT1;
		String          tDN;
		String          tFilter;

		tDN = "ou=AdminGroups,ou=Groups," + baseDN;
		tFilter = "(uniquemember=" + tUserDN + ")";

		// Get a list of all the Admin Groups the user is a member of.
		if ((vector1 = ldapDir.search(tDN, tFilter, new String[] {"cn"}, true)) != null) {
			final int vector1Size = vector1.size();
			for (int x1 = 0; x1 < vector1Size; x1++) {
				vector2 = (Vector) vector1.elementAt(x1);
				hashT1 = (Hashtable) vector2.elementAt(1);
		
				group = new AdminGroup(getAttributeValue(hashT1, "cn"));
				ret.addElement(group);
			}
		}
	  
		ret.trimToSize();
		VectorFuncs.sort(ret);

		return(ret);
	}
	/**
	 * Gets a list of aliases for the store.
	 * 
	 * @return Vector of StoreAlias. The vector may be empty
	 * 		   but never null.
	 * @param storeNumber java.lang.String
	 * @exception java.lang.Exception
	 */
	public Vector getAliasListForStore(String storeNumber)
			throws Exception
	{
		Vector          ret = new Vector();
		StoreAlias      tAlias;
		Vector          vector1, vector2;
		Hashtable       hashT1;
		String          tDN;
		String          tFilter;

		tDN = "ou=StoreAlias,ou=Stores," + baseDN;
		tFilter = "(sn=" + storeNumber + ")";
		
		// Get a list of all the Aliases for the store.
		if ((vector1 = ldapDir.search(tDN, tFilter, new String[] {"uid", "description"}, true)) != null) {
			final int vector1Size = vector1.size();
			for (int x1 = 0; x1 < vector1Size; x1++) {
				vector2 = (Vector) vector1.elementAt(x1);
				hashT1 = (Hashtable) vector2.elementAt(1);

				// Add a string to the vector.
				tAlias = new StoreAlias(storeNumber,
										getAttributeValue(hashT1, "uid"),
										getAttributeValue(hashT1, "description"));
				ret.addElement(tAlias);
			}
		}

		ret.trimToSize();
		VectorFuncs.sort(ret);

		return(ret);
	}
	/**
	 * Gets details about the specified alias.
	 * 
	 * @return
	 *      StoreAlias - An object containing the alias details
	 * 					 Returns null if the alias doesn't exist.
	 * @param storeNumber java.lang.String
	 * @exception java.lang.Exception
	 */
	public StoreAlias getAliasDetail(String alias)
			throws Exception
	{
		final String	tStoreDN = "uid=" + alias + ",ou=StoreAlias,ou=Stores," + baseDN;
		StoreAlias		ret = null;
		Hashtable		hashT;

		// Read all the fields from the StoreAlias object.
		if ((hashT = ldapDir.read(tStoreDN, new String[] {"sn", "uid", "description"})) != null) {
			ret = new StoreAlias(getAttributeValue(hashT, "sn"),
								 getAttributeValue(hashT, "uid"),
								 getAttributeValue(hashT, "description"));
		}

		return ret;
	}
	/**
	 * Gets a list of all SVHarbor applications.
	 * 
	 * @return Vector of Application objects.  The
	 *         vector may be empty but never null.
	 * @exception java.lang.Exception
	 */
	public Vector getAppList()
			throws Exception
	{
		return(getAppList(null));
	}
	/**
	 * Gets a list of SVHarbor applications.  If appType is specified,
	 * only the applications of that type are returned.  Currently the 
	 * possible values for appType are "store" and "admin".  Pass null
	 * to see all SVHarbor applications.
	 * 
	 * @return Vector of Application objects.  The
	 *         vector may be empty but never null.
	 * @param appType java.lang.String
	 * @exception java.lang.Exception
	 */
	public Vector getAppList(String appType)
			throws Exception
	{
		final String tappTypeFilter = appType == null ? "*" : appType;
		Vector      vector1, vector2;
		Hashtable   hashT1;
		String      tDN;
		String      tFilter;
		Application application;
		Vector      ret = new Vector();

		tDN = "ou=ApplicationList,ou=Applications," + baseDN;

		// Don't use compareToIgnoreCase() below, it's not supported by Microsoft.
		if ((appType != null) &&
			((appType.toLowerCase().compareTo("broker") == 0) ||
			 (appType.toLowerCase().compareTo("vendor") == 0))) {

			tFilter = "(&(businessCategory=application)(|(preferredLanguage=" + tappTypeFilter + ")(preferredLanguage=vendor/broker)))";
		}
		else {
			tFilter = "(&(businessCategory=application)(preferredLanguage=" + tappTypeFilter + "))";
		}

		// Get a list of applications.
		if ((vector1 = ldapDir.search(tDN, tFilter, new String[] {"uid", "sn", "physicalDeliveryOfficeName"}, true)) != null) {
			final int vector1Size = vector1.size();
			for (int x1 = 0; x1 < vector1Size; x1++) {
				vector2 = (Vector) vector1.elementAt(x1);
				hashT1 = (Hashtable) vector2.elementAt(1);

				application = new Application(getAttributeValue(hashT1, "uid"),
											  getAttributeValue(hashT1, "sn"),
											  getAttributeValue(hashT1, "physicalDeliveryOfficeName").equalsIgnoreCase("forced"),
											  getAttributeValue(hashT1, "physicalDeliveryOfficeName").equalsIgnoreCase("default"));
				ret.addElement(application);
			}
		}

		ret.trimToSize();
		VectorFuncs.sort(ret);

		return ret;
	}
	/**
	 * Gets a list of applications that the specified broker is using.
	 * 
	 * @return Vector of Application objects.  The
	 *         vector may be empty but never null.
	 * @param brokerNumber java.lang.String
	 * @exception java.lang.Exception
	 */
	public Vector getAppListForBroker(String brokerNumber)
			throws Exception
	{
		final String    tApplicationBaseDN = "ou=ApplicationList,ou=Applications," + baseDN;
		final Name      tApplicationBaseDNName = ldapDir.convertToName(tApplicationBaseDN);
		Vector      ret = new Vector();
		Hashtable   hashT;
		Hashtable   hashT2;
		Application application;
		Object[]    attrib_value;
		String      tDN;
		Name        tDNName;

		tDN = "cn=" + brokerNumber + ",ou=Brokers," + baseDN;
		if (((hashT = ldapDir.read(tDN, new String[] {"uniquemember"})) != null) &&
			((attrib_value = (Object[]) hashT.get("uniquemember")) != null)) {

			// Look at each member and pull out only the applications.
			for (int i = 0; i < attrib_value.length; i++) {	
				tDN = attrib_value[i].toString();
				tDNName = ldapDir.convertToName(tDN);

				// Ignore everything except applications.
				if (tDNName.startsWith(tApplicationBaseDNName)) {
					// Read all the fields from the object.
					if ((hashT2 = ldapDir.read(tDN, new String[] {"uid", "sn", "physicalDeliveryOfficeName"})) != null) {
						application = new Application(getAttributeValue(hashT2, "uid"),
													  getAttributeValue(hashT2, "sn"),
													  getAttributeValue(hashT2, "physicalDeliveryOfficeName").equalsIgnoreCase("forced"),
													  getAttributeValue(hashT2, "physicalDeliveryOfficeName").equalsIgnoreCase("default"));
						
						ret.addElement(application);
					}
				}
			}
		}

		ret.trimToSize();
		VectorFuncs.sort(ret);

		return ret;
	}
	/**
	 * Gets a list of applications that the specified store is using.
	 * 
	 * @return Vector of Application objects.  The
	 *         vector may be empty but never null.
	 * @param storeNumber java.lang.String
	 * @exception java.lang.Exception
	 */
	public Vector getAppListForStore(String storeNumber)
			throws Exception
	{
		final String    tApplicationBaseDN = "ou=ApplicationList,ou=Applications," + baseDN;
		final Name      tApplicationBaseDNName = ldapDir.convertToName(tApplicationBaseDN);
		Vector      ret = new Vector();
		Hashtable   hashT;
		Hashtable   hashT2;
		Application application;
		Object[]    attrib_value;
		String      tDN;
		Name        tDNName;

		tDN = "cn=" + storeNumber + ",ou=Stores," + baseDN;
		if (((hashT = ldapDir.read(tDN, new String[] {"uniquemember"})) != null) &&
			((attrib_value = (Object[]) hashT.get("uniquemember")) != null)) {

			// Look at each member and pull out only the applications.
			for (int i = 0; i < attrib_value.length; i++) {	
				tDN = attrib_value[i].toString();
				tDNName = ldapDir.convertToName(tDN);

				// Ignore everything except applications.
				if (tDNName.startsWith(tApplicationBaseDNName)) {
					// Read all the fields from the object.
					if ((hashT2 = ldapDir.read(tDN, new String[] {"uid", "sn", "physicalDeliveryOfficeName"})) != null) {
						application = new Application(getAttributeValue(hashT2, "uid"),
													  getAttributeValue(hashT2, "sn"),
													  getAttributeValue(hashT2, "physicalDeliveryOfficeName").equalsIgnoreCase("forced"),
													  getAttributeValue(hashT2, "physicalDeliveryOfficeName").equalsIgnoreCase("default"));
						
						ret.addElement(application);
					}
				}
			}
		}

		ret.trimToSize();
		VectorFuncs.sort(ret);

		return(ret);
	}
	/**
	 * Gets a list of applications that the specified vendor is using.
	 * 
	 * @return Vector of Application objects.  The
	 *         vector may be empty but never null.
	 * @param vendorID java.lang.String
	 * @exception java.lang.Exception
	 */
	// Jan 26, 2003 - Modified for Vendor Conversion		

	public Vector getAppListForVendor(String vendorID)
			throws Exception
	{
		String 			originalVendorNumber = "";
		originalVendorNumber = vendorID;		
		vendorID = convertToInternalVendorNbr(vendorID);
		
		final String    tApplicationBaseDN = "ou=ApplicationList,ou=Applications," + baseDN;
		final Name      tApplicationBaseDNName = ldapDir.convertToName(tApplicationBaseDN);
		Vector      ret = new Vector();
		Hashtable   hashT;
		Hashtable   hashT2;
		Application application;
		Object[]    attrib_value;
		String      tDN;
		Name        tDNName;

		tDN = "cn=" + vendorID + ",ou=Vendors," + baseDN;
		if (((hashT = ldapDir.read(tDN, new String[] {"uniquemember"})) != null) &&
			((attrib_value = (Object[]) hashT.get("uniquemember")) != null)) {

			// Look at each member and pull out only the applications.
			for (int i = 0; i < attrib_value.length; i++) {	
				tDN = attrib_value[i].toString();
				tDNName = ldapDir.convertToName(tDN);

				// Ignore everything except applications.
				if (tDNName.startsWith(tApplicationBaseDNName)) {
					// Read all the fields from the object.
					if ((hashT2 = ldapDir.read(tDN, new String[] {"uid", "sn", "physicalDeliveryOfficeName"})) != null) {
						application = new Application(getAttributeValue(hashT2, "uid"),
													  getAttributeValue(hashT2, "sn"),
													  getAttributeValue(hashT2, "physicalDeliveryOfficeName").equalsIgnoreCase("forced"),
													  getAttributeValue(hashT2, "physicalDeliveryOfficeName").equalsIgnoreCase("default"));
						
						ret.addElement(application);
					}
				}
			}
		}

		ret.trimToSize();
		VectorFuncs.sort(ret);

		return ret;
	}
	/**
	 * Gets a list of Application Roles for an application.
	 * 
	 * @return Vector of ApplicationRole.
	 *         The vector may be empty but never null.
	 * @param applicationName java.lang.String
	 * @exception java.lang.Exception
	 */
	public Vector getAppRolesOfApp(String applicationName)
			throws Exception
	{
		Vector          ret = new Vector();
		ApplicationRole role;
		Vector          vector1, vector2;
		Hashtable       hashT1;
		String          tDN;
		String          tFilter;

		tDN = "ou=" + applicationName + ",ou=Applications," + baseDN;
		tFilter = "(cn=*)";

		// Get a list of all the application's roles.
		if ((vector1 = ldapDir.search(tDN, tFilter, new String[] {"cn", "description"}, true)) != null) {
			final int vector1Size = vector1.size();
			for (int x1 = 0; x1 < vector1Size; x1++) {
				vector2 = (Vector) vector1.elementAt(x1);
				hashT1 = (Hashtable) vector2.elementAt(1);
		
				role = new ApplicationRole(getAttributeValue(hashT1, "cn"),
										   getAttributeValue(hashT1, "description"));
				ret.addElement(role);
			}
		}
	  
		ret.trimToSize();
		VectorFuncs.sort(ret);

		return(ret);
	}
	/**
	 * Gets a list of\Roles that the user is a member of.
	 * 
	 * @return Vector of ApplicationRole that the user is a member of.
	 *         The vector may be empty but never null.
	 * @param loginID java.lang.String
	 * @param applicationName java.lang.String
	 * @exception java.lang.Exception
	 */
	public Vector getAppRolesOfUser(String loginID,
									String applicationName)
			throws Exception
	{
		final String    tUserDN = "uid=" + loginID + ",ou=People," + baseDN;
		Vector          ret = new Vector();
		ApplicationRole role;
		Vector          vector1, vector2;
		Hashtable       hashT1;
		String          tDN;
		String          tFilter;

		tDN = "ou=" + applicationName + ",ou=Applications," + baseDN;
		tFilter = "(uniquemember=" + tUserDN + ")";

		// Get a list of all the application roles the user is a member of.
		if ((vector1 = ldapDir.search(tDN, tFilter, new String[] {"cn", "description"}, true)) != null) {
			final int vector1Size = vector1.size();
			for (int x1 = 0; x1 < vector1Size; x1++) {
				vector2 = (Vector) vector1.elementAt(x1);
				hashT1 = (Hashtable) vector2.elementAt(1);

				role = new ApplicationRole(getAttributeValue(hashT1, "cn"),
										   getAttributeValue(hashT1, "description"));
				ret.addElement(role);
			}
		}
	  
		ret.trimToSize();
		VectorFuncs.sort(ret);

		return(ret);
	}
	private String getAttributeValue(Hashtable table,
									 String attrName)
	{
		Object[] value;

		value = (Object[]) table.get(attrName.toLowerCase());

		return value != null ? value[0].toString() : new String("");
	}
	/**
	 * Gets details about the specified Broker.
	 * 
 	 * @return com.supervalu.svharborldap.Broker
 	 * @param brokerNumber java.lang.String
	 * @exception java.lang.Exception
	 */
	public Broker getBrokerDetail(String brokerNumber)
		throws Exception
	{
		final String	tDN = "uid=" + brokerNumber + ",ou=Brokers," + baseDN;
		Broker			ret;
		Hashtable		hashT;

		// Read all the fields from the person object.
		if ((hashT = ldapDir.read(tDN, null)) != null) {
			ret = new Broker(getAttributeValue(hashT, "uid"), // brokerNumber
							 getAttributeValue(hashT, "sn"), // brokerName
							 getAttributeValue(hashT, "mail"), // emailAddress
							 getAttributeValue(hashT, "street"), // address
							 getAttributeValue(hashT, "homePostalAddress"), // city
							 getAttributeValue(hashT, "st"), // stateCode
							 getAttributeValue(hashT, "postalCode"), // zipCode
							 getAttributeValue(hashT, "telephoneNumber"), // phoneNumber
							 getAttributeValue(hashT, "facsimileTelephoneNumber"), // faxNumber
							 getAttributeValue(hashT, "manager") //contact 
							 ); 
		}
		else {
			String tMsg = "Error in getBrokerDetail().  Broker: " + brokerNumber + " doesn't exist in the LDAP directory.";
			throw new Exception(tMsg);
		}

		return ret;
	}
	/**
	 * Gets a list of all the brokers.
	 * 
	 * @return Vector of Broker objects.
	 *         The vector may be empty but never null.
	 * @param brokerNameFilter For example, pass "AAA" to
	 *		  get a list of all brokers whose name starts
	 * 		  with "AAA".
	 * @exception java.lang.Exception
	 */
	public Vector getBrokerList(String brokerNameFilter)
			throws Exception
	{
		Vector          ret = new Vector();
		Broker			broker;
		Vector          vector1, vector2;
		Hashtable       hashT1;

		final String tDN = "ou=Brokers," + baseDN;
		final String tFilter = "(&(uid=*)" +
							   "(sn=" + (brokerNameFilter != null ?
								   		 brokerNameFilter : "") + "*))";

		// Get a list of all the brokers that match the filter.
		if ((vector1 = ldapDir.search(tDN, tFilter, null, true)) != null) {
			final int vector1Size = vector1.size();
			for (int x1 = 0; x1 < vector1Size; x1++) {
				vector2 = (Vector) vector1.elementAt(x1);
				hashT1 = (Hashtable) vector2.elementAt(1);

				broker = new Broker(getAttributeValue(hashT1, "uid"), // brokerNumber
								 	getAttributeValue(hashT1, "sn"), // brokerName
								 	getAttributeValue(hashT1, "mail"), // emailAddress
								 	getAttributeValue(hashT1, "street"), // address
								 	getAttributeValue(hashT1, "homePostalAddress"), // city
								 	getAttributeValue(hashT1, "st"), // stateCode
								 	getAttributeValue(hashT1, "postalCode"), // zipCode
								 	getAttributeValue(hashT1, "telephoneNumber"), // phoneNumber
									getAttributeValue(hashT1, "facsimileTelephoneNumber"), // faxNumber
									getAttributeValue(hashT1, "manager") //contact 	 	
								 	); // faxNumber

				ret.addElement(broker);
			}
		}

		ret.trimToSize();

		Broker.sortByBrokerName(ret);

		return ret;
	}
	/**
	 * Gets the Central Support Phone Number.
	 * 
	 * @return java.lang.String
	 */
	public String getCentralSupportPhoneNumber()
	{
		return(svharborConstants.getCentralSupportPhoneNumber());
	}
	/**
	 * Returns the DCs that the passed admin group has access to.
	 * 
	 * @return
	 *      Vector - Vector of DCGroup objects.
	 *               The vector may be empty but never null.
	 * @param adminGroup java.lang.String
	 * @exception java.lang.Exception
	 */
	public Vector getDCsOfAdminGroup(String adminGroup)
			throws Exception
	{
		final String    tAdminGroupDN = "cn=" + adminGroup + ",ou=AdminGroups,ou=Groups," + baseDN;
		Vector          ret = new Vector();
		DCGroup         dcGroup;
		Vector          vector1, vector2;
		Hashtable       hashT1;
		String          tDN;
		String          tFilter;

		tDN = "ou=SharedGroups," + baseDN;
		tFilter = "(&(uniquemember=" + tAdminGroupDN + ")(businesscategory=DC))";
		
		// Find all the DCs the Admin Group has access to.
		if ((vector1 = ldapDir.search(tDN, tFilter, new String[] {"description","cn","owner","seeAlso"}, true)) != null) {
			final int vector1Size = vector1.size();
			for (int x1 = 0; x1 < vector1Size; x1++) {
				vector2 = (Vector) vector1.elementAt(x1);
				hashT1 = (Hashtable) vector2.elementAt(1);

				// Add the DCGroup to the vector.
				dcGroup = new DCGroup(getAttributeValue(hashT1, "description"),
									  getAttributeValue(hashT1, "cn"),
									  getAttributeValue(hashT1, "owner"),
									  getAttributeValue(hashT1, "seeAlso"));
				ret.addElement(dcGroup);
			}
		}

		ret.trimToSize();
		DCGroup.sortByName(ret);

		return(ret);
	}
	/**
	 * Gets a list of DCs that are in the specified region.
	 * 
	 * @return
	 *      Vector - Vector of DCGroup that are in the group.  The
	 *               vector may be empty but never null.
	 * @param regionName java.lang.String
	 * @exception java.lang.Exception
	 */
	public Vector getDCsOfRegion(String regionName)
			throws Exception
	{
		final String tSharedGroupBaseDN = "ou=SharedGroups," + baseDN;
		final Name   tSharedGroupBaseDNName = ldapDir.convertToName(tSharedGroupBaseDN);
		Vector      ret = new Vector();
		DCGroup     group;
		Hashtable   hashT;
		Hashtable   hashT2;
		Object[]    attrib_value;
		Object[]    attrib_value2;
		String      tDN;
		Name        tDNName;

		tDN = "cn=" + regionName + ",ou=SharedGroups," + baseDN;

		// Retrieve the Region's SharedGroup object.
		if (((hashT = ldapDir.read(tDN, new String[] {"uniquemember"})) != null) &&
			((attrib_value = (Object[]) hashT.get("uniquemember")) != null)) {

			// Look at each member and pull out the DCs.
			for (int i = 0; i < attrib_value.length; i++) {	
				tDN = attrib_value[i].toString();
				tDNName = ldapDir.convertToName(tDN);

				// Ignore everything except SharedGroups.
				if ((tDNName.startsWith(tSharedGroupBaseDNName)) &&
					((hashT2 = ldapDir.read(tDN, new String[] {"businesscategory","description", "cn", "owner", "seeAlso"})) != null) &&
					((attrib_value2 = (Object[]) hashT2.get("businesscategory")) != null) &&
					(attrib_value2[0].toString().equalsIgnoreCase("DC"))) {

					group = new DCGroup(getAttributeValue(hashT2, "description"),
										getAttributeValue(hashT2, "cn"),
										getAttributeValue(hashT2, "owner"),
										getAttributeValue(hashT2, "seeAlso"));
					ret.addElement(group);
				}
			}
		}

		ret.trimToSize();
		DCGroup.sortByName(ret);
		
		return(ret);
	}
	/**
	 * Returns the DCs that the passed user has access to.
	 * 
	 * @return
	 *      Vector - Vector of DCGroup objects that the user has access to.
	 *               The vector may be empty but never null.
	 * @param loginID java.lang.String
	 * @exception java.lang.Exception
	 */
	public Vector getDCsOfUser(String loginID)
			throws Exception
	{
		final String    tUserDN = "uid=" + loginID + ",ou=People," + baseDN;
		Vector          ret = new Vector();
		DCGroup         dcGroup;
		Vector          vector1, vector2, vector3;
		Hashtable       hashT1;
		String          tDN;
		String          tFilter;

		tDN = "ou=SharedGroups," + baseDN;
		tFilter = "(&(uniquemember=" + tUserDN + ")" +
				  "  (|(businesscategory=DC)(businesscategory=NS)))";

		// Get a list of all the SharedGroups the user is a member of.
		if ((vector1 = ldapDir.search(tDN, tFilter, new String[] {"description", "cn", "owner", "seeAlso"}, true)) != null) {
			final int vector1Size = vector1.size();
			for (int x1 = 0; x1 < vector1Size; x1++) {
				vector2 = (Vector) vector1.elementAt(x1);

				hashT1 = (Hashtable) vector2.elementAt(1);

				// Add a DCGroup object to the vector (if it's not already there).
				dcGroup = new DCGroup(getAttributeValue(hashT1, "description"),
									  getAttributeValue(hashT1, "cn"),
									  getAttributeValue(hashT1, "owner"),
									  getAttributeValue(hashT1, "seeAlso"));
				if (! ret.contains(dcGroup)) {
					ret.addElement(dcGroup);
				}
			}
		}

		tDN = "ou=AdminGroups,ou=Groups," + baseDN;
		tFilter = "(uniquemember=" + tUserDN + ")";

		// Get a list of all the AdminGroups the user is a member of.
		if ((vector1 = ldapDir.search(tDN, tFilter, true)) != null) {
			final int vector1Size = vector1.size();

			for (int x1 = 0; x1 < vector1Size; x1++) {
		  		tDN = "ou=SharedGroups," + baseDN;
				tFilter = "(&(uniquemember=" + (String) vector1.elementAt(x1) + ")" +
				  		  "  (|(businesscategory=DC)(businesscategory=NS)))";
				// Search for the AdminGroup in the SharedGroups.
				if ((vector2 = ldapDir.search(tDN, tFilter, new String[] {"description", "cn", "owner", "seeAlso"}, true)) != null) {
					final int vector2Size = vector2.size();
					for (int x2 = 0; x2 < vector2Size; x2++) {
						vector3 = (Vector) vector2.elementAt(x2);
						hashT1 = (Hashtable) vector3.elementAt(1);

						// Add a DCGroup object to the vector (if it's not already there).
						dcGroup = new DCGroup(getAttributeValue(hashT1, "description"),
											  getAttributeValue(hashT1, "cn"),
											  getAttributeValue(hashT1, "owner"),
											  getAttributeValue(hashT1, "seeAlso"));
						if (! ret.contains(dcGroup)) {
							ret.addElement(dcGroup);
						}
					}
				}
			}
		}
		

		ret.trimToSize();
		DCGroup.sortByDCNumberAndName(ret);
		
		return(ret);
	}
	/**
	 * Returns the Promotional Regions that the passed user has access to.
	 * 
	 * @return
	 *      Vector - Vector of StoreGroup objects.
	 *               The vector may be empty but never null.
	 * @param loginID java.lang.String
	 * @exception java.lang.Exception
	 */
	public Vector getPromoRegionsOfUser(String loginID)
			throws Exception
	{
		return getGroupsOfUser(loginID, "PR", 4);
	}
	/**
	 * Get's the specified user's email address from Domino.
	 * 
	 * @return Returns the email address or an
	 * empty string if there is no email address.
	 * @param userID java.lang.String
	 * @exception java.lang.Exception
	 */
	private String getEmailAddressFromDomino(java.lang.String userID)
		throws Exception
	{
		if (dominoAccessProperties == null) {
			String tMsg = "Error in getEmailAddressFromDomino().  Domino access parameters not found in configuration file.";
			throw new Exception(tMsg);
		}
	
		final String ret = com.svharbor.services.AddressServices.getMailAddress(dominoAccessProperties, userID);
	
		return ret;
	}
	/**
	 * Returns the URL of the "exit" page.
	 * 
	 * @return java.lang.String
	 */
	public String getExitURL()
	{
		return(svharborConstants.getSVHarborExitURL());
	}
	/**
	 * Gets a list of StoreGroups that the user is explicitly assigned to.
     * To be returned in the list, the user must be directly assigned to the
     * group, not indirectly assigned through an admin. group.
	 * 
	 * @return
	 *      Vector - Vector of StoreGroup objects that the user is explicitly
     *               assigned to.
	 *               The vector may be empty but never null.
	 * @param loginID java.lang.String
	 * @param groupType Can be either "DC", "HQ", "UD", "RG", etc.
	 * @param groupNameFilter ie. "Northern".
	 * @param sortOrder 0=No Sort,
	 * 					1=Sort By Type+Name,
	 * 					2=Sort By Name
	 * 					3=Sort By Type+GroupNumber,
	 * 					4=Sort By GroupNumber
	 * @exception java.lang.Exception
	 */
	public Vector getExplicitGroupsOfUser(String loginID,
                                          String groupType,
                                          String groupNameFilter,
                                          int sortOrder)
			throws Exception
	{
		final String    tUserDN = "uid=" + loginID + ",ou=People," + baseDN;
		final String    tGroupTypeFilter = groupType == null ? "*" : groupType;
		final String    tGroupNameFilter = groupNameFilter == null ? "*" : groupNameFilter + "*";
		Vector          ret = new Vector();
		StoreGroup      group;
		Vector          vector1, vector2;
		Hashtable       hashT1;
		String          tDN;
		String          tFilter;

		tDN = "ou=SharedGroups," + baseDN;
		tFilter = "(&(uniquemember=" + tUserDN + ")" +
				  "  (businesscategory=" + tGroupTypeFilter + ")" +
				  "  (cn=" + tGroupNameFilter + "))";

		// Get a list of all the SharedGroups the user is a member of.
		if ((vector1 = ldapDir.search(tDN, tFilter, new String[] {"businesscategory", "description", "cn", "owner", "seeAlso"}, true)) != null) {
			final int vector1Size = vector1.size();
			for (int x1 = 0; x1 < vector1Size; x1++) {
				vector2 = (Vector) vector1.elementAt(x1);

				hashT1 = (Hashtable) vector2.elementAt(1);

				// Add a StoreGroup object to the vector.
				group = new StoreGroup(getAttributeValue(hashT1, "businesscategory"),
									   getAttributeValue(hashT1, "description"),
									   getAttributeValue(hashT1, "cn"),
									   getAttributeValue(hashT1, "owner"),
									   getAttributeValue(hashT1, "seeAlso"));
				ret.addElement(group);
			}
		}

		ret.trimToSize();

		switch (sortOrder) {
			case 0:
				break;
			case 1:
				StoreGroup.sortByTypeAndName(ret);
				break;
			case 2:
				StoreGroup.sortByName(ret);
				break;
			case 3:
				StoreGroup.sortByTypeAndGroupNumber(ret);
				break;
			case 4:
				StoreGroup.sortByGroupNumber(ret);
				break;
			default:
				String tMsg = "Error in getExplicitGroupsOfUser().  Invalid SortOrder parameter.";
				throw new Exception(tMsg);
		}
		
		return(ret);
	}
	/**
	 * Returns the attributes of the specified group.
	 * 
	 * @return StoreGroup
	 * @param groupName java.lang.String
	 * @exception java.lang.Exception
	 */
	public StoreGroup getGroupDetail(String groupName)
			throws Exception
	{
		final String    tGroupDN = "cn=" + groupName + ",ou=SharedGroups," + baseDN;
		StoreGroup      ret = null;
		Hashtable       hashT;

		// Read the necessary fields from the SharedGroups object.
		if ((hashT = ldapDir.read(tGroupDN, new String[] {"businesscategory", "description", "cn", "owner", "seeAlso"})) != null) {
			ret = new StoreGroup(getAttributeValue(hashT, "businesscategory"),
								 getAttributeValue(hashT, "description"),
								 getAttributeValue(hashT, "cn"),
								 getAttributeValue(hashT, "owner"),
								 getAttributeValue(hashT, "seeAlso"));
		}
		else {
			String tMsg = "Error in getGroupDetail().  Group: \"" + groupName + "\" doesn't exist in the LDAP directory.";
			throw new Exception(tMsg);
		}
	  
		return ret;
	}
	/**
	 * Gets the Region, DC or HQ that the store is a member of.
	 * 
	 * @return 
	 *      String - The name of the group. The string may be
	 * 				  empty but never null. If the store isn't
	 * 				  found or if it isn't assigned to the desired
	 * 				  group type, an empty string will be returned.
	 * @param storeNumber java.lang.String
	 * @param groupType java.lang.String
	 *    Can be "DC", "HQ", "UD", "RG", etc.
	 * @exception java.lang.Exception
	 */
	public String getGroupOfStore(String storeNumber,
								  String groupType)
			throws Exception
	{
		final String    tStoreDN = "uid=" + storeNumber + ",ou=Stores," + baseDN;
		String          ret = null;
		Vector          vector1, vector2;
		Hashtable       hashT1;
		String          tDN;
		String          tFilter;
		
		tDN = "ou=SharedGroups," + baseDN;
		tFilter = "(&(uniquemember=" + tStoreDN + ")(businesscategory=" + groupType + "))";

		// Find the SharedGroup that the store is a member of.
		if ((vector1 = ldapDir.search(tDN, tFilter, new String[] {"cn"}, true)) != null) {
			final int vector1Size = vector1.size();
			for (int x1 = 0; x1 < vector1Size; x1++) {
				vector2 = (Vector) vector1.elementAt(x1);
				hashT1 = (Hashtable) vector2.elementAt(1);
				
				ret = getAttributeValue(hashT1, "cn");
			}
		}

		return ret == null ? new String() : ret;
	}
	/**
	 * Returns the groups that the passed admin group has access to and that
	 * match the passed group type.
	 * 
	 * @return
	 *      Vector - Vector of StoreGroup objects.
	 *               The vector may be empty but never null.
	 * @param adminGroup java.lang.String
	 * @param groupType java.lang.String
	 * @exception java.lang.Exception
	 */
	public Vector getGroupsOfAdminGroup(String adminGroup,
										String groupType)
			throws Exception
	{
		final String    tAdminGroupDN = "cn=" + adminGroup + ",ou=AdminGroups,ou=Groups," + baseDN;
		final String    tGroupTypeFilter = groupType == null ? "*" : groupType;
		Vector          ret = new Vector();
		StoreGroup      storeGroup;
		Vector          vector1, vector2;
		Hashtable       hashT1;
		String          tDN;
		String          tFilter;

		tDN = "ou=SharedGroups," + baseDN;
		tFilter = "(&(uniquemember=" + tAdminGroupDN + ")(businesscategory=" + tGroupTypeFilter + "))";

		// Find all the groups the Admin Group has access to.
		if ((vector1 = ldapDir.search(tDN, tFilter, new String[] {"businesscategory","description","cn","owner","seeAlso"}, true)) != null) {
			final int vector1Size = vector1.size();
			for (int x1 = 0; x1 < vector1Size; x1++) {
				vector2 = (Vector) vector1.elementAt(x1);
				hashT1 = (Hashtable) vector2.elementAt(1);

				// Add the StoreGroup to the vector.
				storeGroup = new StoreGroup(getAttributeValue(hashT1, "businesscategory"),
											getAttributeValue(hashT1, "description"),
											getAttributeValue(hashT1, "cn"),
											getAttributeValue(hashT1, "owner"),
											getAttributeValue(hashT1, "seeAlso"));

				ret.addElement(storeGroup);
			}
		}

		ret.trimToSize();
		if (groupType == null) {
			StoreGroup.sortByTypeAndName(ret);
		}
		else {
			StoreGroup.sortByName(ret);
		}

		return ret;
	}
	/**
	 * Gets a list of StoreGroups that the store is a member of.
	 * 
	 * @return
	 *      Vector - Vector of StoreGroup objects that the store is a member of.
	 *               The vector may be empty but never null.
	 * @param storeNumber java.lang.String
	 * @exception java.lang.Exception
	 */
	public Vector getGroupsOfStore(String storeNumber)
			throws Exception
	{
		return(getGroupsOfStore(storeNumber, null, null));
	}
	/**
	 * Gets a list of StoreGroups that the store and user is a member of.
	 * 
	 * @return
	 *      Vector - Vector of StoreGroup objects that the store is a member of.
	 *               The vector may be empty but never null.
	 * @param storeNumber java.lang.String
	 * @param loginID java.lang.String
	 * @exception java.lang.Exception
	 */
	public Vector getGroupsOfStore(String storeNumber,
								   String loginID)
			throws Exception
	{
		return(getGroupsOfStore(storeNumber, loginID, null));
	}
    /**
	 * Gets a list of StoreGroups that the store and user is a member of.
	 * loginID and groupType are optional, just pass null if you don't use
	 * them.
	 * 
	 * @return
	 *      Vector - Vector of StoreGroup objects that the store is a member of.
	 *               The vector may be empty but never null.
	 * @param storeNumber java.lang.String
	 * @param loginID Optional, pass null if not needed.
	 * @param groupType Optional, pass null if not needed.
	 * @exception java.lang.Exception
	 */
	public Vector getGroupsOfStore(String storeNumber,
								   String loginID,
								   String groupType)
			throws Exception
	{
		final String    tUserDN = loginID == null ? null : ("uid=" + loginID + ",ou=People," + baseDN);
		final String    tStoreDN = "uid=" + storeNumber + ",ou=Stores," + baseDN;
		final String    tGroupTypeFilter = groupType == null ? "*" : groupType;
		Vector          ret = new Vector();
		StoreGroup      group;
		Vector          vector1, vector2 = null;
		int             vector1Size, vector2Size = 0;
		int             cntr1, cntr2;
		Hashtable       hashT;
		String          tDN, tAdminGroupDN;
		String          tFilter;
		boolean         foundMatch;

		tDN = "ou=SharedGroups," + baseDN;
		tFilter = "(&(uniquemember=" + tStoreDN + ")(businesscategory=" + tGroupTypeFilter + "))";
		
		// Get a list of all the SharedGroups the store is a member of.
		if ((vector1 = ldapDir.search(tDN, tFilter, true)) != null) {
			/*
			 * If a user was specified, get a list of all the AdminGroups
			 * that the user is a member of.
			 */
			if (loginID != null) {
				tDN = "ou=AdminGroups,ou=Groups," + baseDN;
				tFilter = "(uniquemember=" + tUserDN + ")";

				if ((vector2 = ldapDir.search(tDN, tFilter, true)) != null) {
					vector2Size = vector2.size();
				}
			}
			
			vector1Size = vector1.size();
			for (cntr1 = 0; cntr1 < vector1Size; cntr1++) {
				tAdminGroupDN = (String) vector1.elementAt(cntr1);
				foundMatch = false;

				/*
				 * If a user was specified, make sure the user is a member of
				 * the SharedGroup or is a member of an AdminGroup that is
				 * a member of this SharedGroup.
				 */
				if (loginID != null) {
					// See if the user is a member of the group.
					if (ldapDir.existAttributeInObject(tAdminGroupDN, "uniquemember", tUserDN)) {
						foundMatch = true;
					}
					else {
						// See if the user is a member of an admin group which is a member of this group.
						for (cntr2 = 0; cntr2 < vector2Size; cntr2++) {
							tDN = (String) vector2.elementAt(cntr2);

							if (ldapDir.existAttributeInObject(tAdminGroupDN, "uniquemember", tDN)) {
								foundMatch = true;
								break;
							}
						}
					}
				}
				else {
					foundMatch = true;
				}

				if ((foundMatch) &&
					((hashT = ldapDir.read(tAdminGroupDN, new String[] {"businesscategory", "description", "cn", "owner", "seeAlso"})) != null)) {

					// Add a StoreGroup object to the vector (if it's not already there).
					group = new StoreGroup(getAttributeValue(hashT, "businesscategory"),
										   getAttributeValue(hashT, "description"),
										   getAttributeValue(hashT, "cn"),
										   getAttributeValue(hashT, "owner"),
										   getAttributeValue(hashT, "seeAlso"));
					if (! ret.contains(group)) {
						ret.addElement(group);
					}
				}
			}
		}

		ret.trimToSize();
		StoreGroup.sortByTypeAndName(ret);
		
		return ret;
	}
	/**
	 * Gets a list of StoreGroups that the user is a member of.
	 * 
	 * @return
	 *      Vector - Vector of StoreGroup objects that the user is a member of.
	 *               The vector may be empty but never null.
	 * @param loginID java.lang.String
	 * @exception java.lang.Exception
	 */
	public Vector getGroupsOfUser(String loginID)
			throws Exception
	{
		return(getGroupsOfUser(loginID, null, null, 1));
	}
	/**
	 * Gets a list of StoreGroups that the user is a member of.
	 * 
	 * @return
	 *      Vector - Vector of StoreGroup objects that the user is a member of.
	 *               The vector may be empty but never null.
	 * @param loginID java.lang.String
	 * @param groupType Can be either "DC", "HQ", "UD", "RG", etc.
	 * @exception java.lang.Exception
	 */
	public Vector getGroupsOfUser(String loginID,
								  String groupType)
			throws Exception
	{
		return(getGroupsOfUser(loginID, groupType, null, 1));
	}
	/**
	 * Gets a list of StoreGroups that the user is a member of.
	 * 
	 * @return
	 *      Vector - Vector of StoreGroup objects that the user is a member of.
	 *               The vector may be empty but never null.
	 * @param loginID java.lang.String
	 * @param groupType Can be "DC", "HQ", "UD", "RG", etc.
	 * @param sortOrder 0=No Sort,
	 * 					1=Sort By Type+Name,
	 * 					2=Sort By Name
	 * 					3=Sort By Type+GroupNumber,
	 * 					4=Sort By GroupNumber
	 * @exception java.lang.Exception
	 */
	public Vector getGroupsOfUser(String loginID,
								  String groupType,
								  int sortOrder)
			throws Exception
	{
		return(getGroupsOfUser(loginID, groupType, null, sortOrder));
	}
	/**
	 * Gets a list of StoreGroups that the user is a member of.
	 * 
	 * @return
	 *      Vector - Vector of StoreGroup objects that the user is a member of.
	 *               The vector may be empty but never null.
	 * @param loginID java.lang.String
	 * @param groupType Can be "DC", "HQ", "UD", "RG", etc.
	 * 					Pass null if not needed.
	 * @param groupNameFilter ie. "Northern".  Pass null if not needed.
	 * @param sortOrder 0=No Sort,
	 * 					1=Sort By Type+Name,
	 * 					2=Sort By Name
	 * 					3=Sort By Type+GroupNumber,
	 * 					4=Sort By GroupNumber
	 * @exception java.lang.Exception
	 */
	public Vector getGroupsOfUser(String loginID,
								  String groupType,
								  String groupNameFilter,
								  int sortOrder)
			throws Exception
	{
		final String    tUserDN = "uid=" + loginID + ",ou=People," + baseDN;
		final String    tGroupTypeFilter = groupType == null ? "*" : groupType;
		final String    tGroupNameFilter = groupNameFilter == null ? "*" : groupNameFilter + "*";
		Vector          ret = new Vector();
		StoreGroup      group;
		Vector          vector1, vector2, vector3;
		Hashtable       hashT1;
		String          tDN;
		String          tFilter;

		tDN = "ou=SharedGroups," + baseDN;
		tFilter = "(&(uniquemember=" + tUserDN + ")" +
				  "  (businesscategory=" + tGroupTypeFilter + ")" +
				  "  (cn=" + tGroupNameFilter + "))";

		//System.out.println("DN=" + tDN);
		//System.out.println("Filter : " + tFilter);
		// Get a list of all the SharedGroups the user is a member of.
		if ((vector1 = ldapDir.search(tDN, tFilter, new String[] {"businesscategory", "description", "cn", "owner", "seeAlso"}, true)) != null) {
			final int vector1Size = vector1.size();
			for (int x1 = 0; x1 < vector1Size; x1++) {
				vector2 = (Vector) vector1.elementAt(x1);

				hashT1 = (Hashtable) vector2.elementAt(1);

				// Add a StoreGroup object to the vector (if it's not already there).
				group = new StoreGroup(getAttributeValue(hashT1, "businesscategory"),
									   getAttributeValue(hashT1, "description"),
									   getAttributeValue(hashT1, "cn"),
									   getAttributeValue(hashT1, "owner"),
									   getAttributeValue(hashT1, "seeAlso"));
				if (! ret.contains(group)) {
					ret.addElement(group);
				}
			}
		}

		tDN = "ou=AdminGroups,ou=Groups," + baseDN;
		tFilter = "(uniquemember=" + tUserDN + ")";

		// Get a list of all the AdminGroups the user is a member of.
		if ((vector1 = ldapDir.search(tDN, tFilter, true)) != null) {
			final int vector1Size = vector1.size();

			for (int x1 = 0; x1 < vector1Size; x1++) {
		  		tDN = "ou=SharedGroups," + baseDN;
				tFilter = "(&(uniquemember=" + (String) vector1.elementAt(x1) + ")" +
						  "  (businesscategory=" + tGroupTypeFilter + ")" +
						  "  (cn=" + tGroupNameFilter + "))";

				// Search for the AdminGroup in the SharedGroups.
				if ((vector2 = ldapDir.search(tDN, tFilter, new String[] {"businesscategory", "description", "cn", "owner", "seeAlso"}, true)) != null) {
					final int vector2Size = vector2.size();
					for (int x2 = 0; x2 < vector2Size; x2++) {
						vector3 = (Vector) vector2.elementAt(x2);

						hashT1 = (Hashtable) vector3.elementAt(1);

						// Add a StoreGroup object to the vector (if it's not already there).
						group = new StoreGroup(getAttributeValue(hashT1, "businesscategory"),
											   getAttributeValue(hashT1, "description"),
											   getAttributeValue(hashT1, "cn"),
											   getAttributeValue(hashT1, "owner"),
											   getAttributeValue(hashT1, "seeAlso"));
						if (! ret.contains(group)) {
							ret.addElement(group);
						}
					}
				}
			}
		}

		ret.trimToSize();

		switch (sortOrder) {
			case 0:
				break;
			case 1:
				StoreGroup.sortByTypeAndName(ret);
				break;
			case 2:
				StoreGroup.sortByName(ret);
				break;
			case 3:
				StoreGroup.sortByTypeAndGroupNumber(ret);
				break;
			case 4:
				StoreGroup.sortByGroupNumber(ret);
				break;
			default:
				String tMsg = "Error in getGroupsOfUser().  Invalid SortOrder parameter.";
				throw new Exception(tMsg);
		}
		
		return ret;
	}
	/**
	 * Gets a list of all the Promotional Region groups that
	 * the users at the specified store have access to.  If
	 * a Promo Region is in the list, it doesn't necessarily
	 * mean that all the store's users have access to it, it 
	 * just means that at least one of the store's users have
	 * access to it.
	 * 
	 * @return
	 *      Vector - Vector of StoreGroup objects.
	 *               The vector may be empty but never null.
	 * @param storeNumber java.lang.String
	 * @exception java.lang.Exception
	 */
	public Vector getPromoRegionGroupsOfStoreUsers(String storeNumber)
			throws Exception
	{
		final Vector userAdminUsers = getUserAdminUsersOfStore(storeNumber);
		Vector		groupsOfUser;
		Vector		ret = new Vector();
		UserName 	user;
		StoreGroup	prGroup;

		for (int x1 = 0; x1 < userAdminUsers.size(); x1++)
		{
			user = (UserName) userAdminUsers.elementAt(x1);

			groupsOfUser = getGroupsOfUser(user.getLoginID(), "PR", 2);

			for (int x2 = 0; x2 < groupsOfUser.size(); x2++)
			{
				prGroup = (StoreGroup) groupsOfUser.elementAt(x2);

				if (! ret.contains(prGroup)) 
				{
					ret.addElement(prGroup);
				}
			}
		}

		return ret;
	}
	/**
	 * Gets a list of all the Promotional Region groups.
	 * 
	 * @return
	 *      Vector - Vector of StoreGroup objects.
	 *               The vector may be empty but never null.
	 * @param groupNameFilter ie. "Northern".  Pass null if not needed.
	 * @param sortOrder 0=No Sort,
	 * 					1=Sort By Name
	 * 					2=Sort By Group Number
	 * @exception java.lang.Exception
	 */
	public Vector getPromoRegionGroups(String groupNameFilter,
									   int sortOrder)
			throws Exception
	{
		final String    tGroupNameFilter = groupNameFilter == null ? "*" : groupNameFilter + "*";
		Vector          ret = new Vector();
		StoreGroup      group;
		Vector          vector1;
		Vector          vector2;
		Hashtable       hashT1;
		String          tDN;
		String          tFilter;

		tDN = "ou=SharedGroups," + baseDN;
		tFilter = "(&(businesscategory=PR)" +
				  "  (cn=" + tGroupNameFilter + "))";

		// Get a list of all the SharedGroups that match the filter.
		if ((vector1 = ldapDir.search(tDN, tFilter, new String[] {"businesscategory", "description", "cn", "owner", "seeAlso"}, true)) != null) {
			final int vector1Size = vector1.size();
			for (int x1 = 0; x1 < vector1Size; x1++) {
				vector2 = (Vector) vector1.elementAt(x1);

				hashT1 = (Hashtable) vector2.elementAt(1);

				// Add a StoreGroup object to the vector.
				group = new StoreGroup(getAttributeValue(hashT1, "businesscategory"),
									   getAttributeValue(hashT1, "description"),
									   getAttributeValue(hashT1, "cn"),
									   getAttributeValue(hashT1, "owner"),
									   getAttributeValue(hashT1, "seeAlso"));

				ret.addElement(group);
			}
		}

		ret.trimToSize();

		switch (sortOrder) {
			case 0:
				break;
			case 1:
				StoreGroup.sortByName(ret);
				break;
			case 2:
				StoreGroup.sortByGroupNumber(ret);
				break;
			default:
				String tMsg = "Error in getPromoRegionGroups().  Invalid SortOrder parameter.";
				throw new Exception(tMsg);
		}

		return ret;
	}
	/**
	 * Returns the attributes of the specified group.
	 * 
	 * @return GroupType
	 * @param groupType java.lang.String
	 * @exception java.lang.Exception
	 */
	public GroupType getGroupTypeDetail(String groupType)
			throws Exception
	{
		final String    tGroupTypeDN = "uid=" + groupType + ",ou=SharedGroupTypes,ou=SharedGroups," + baseDN;
		GroupType       ret = null;
		Hashtable       hashT;

		// Read the necessary fields from the SharedGroupTypes object.
		if ((hashT = ldapDir.read(tGroupTypeDN, new String[] {"uid", "description"})) != null) {
			ret = new GroupType(getAttributeValue(hashT, "uid"),
								getAttributeValue(hashT, "description"));
		}
		else {
			String tMsg = "Error in getGroupTypeDetail().  GroupType: \"" + groupType + "\" doesn't exist in the LDAP directory.";
			throw new Exception(tMsg);
		}

		return(ret);
	}
	/**
	 * Gets the list of available Group Types.
	 * 
	 * @return
	 *      Vector - Vector of GroupType.
	 *               The vector may be empty but never null.
	 * @exception java.lang.Exception
	 */
	public Vector getGroupTypes()
			throws Exception
	{
		Vector          ret = new Vector();
		GroupType       groupType;
		Vector          vector1, vector2;
		Hashtable       hashT1;
		String          tDN;
		String          tFilter;

		tDN = "ou=SharedGroupTypes,ou=SharedGroups," + baseDN;
		tFilter = "(uid=*)";

		// Get a list of all the group types.
		if ((vector1 = ldapDir.search(tDN, tFilter, new String[] {"uid", "description"}, true)) != null) {
			final int vector1Size = vector1.size();
			for (int x1 = 0; x1 < vector1Size; x1++) {
				vector2 = (Vector) vector1.elementAt(x1);
				hashT1 = (Hashtable) vector2.elementAt(1);

				groupType = new GroupType(getAttributeValue(hashT1, "uid"),
										  getAttributeValue(hashT1, "description"));

				ret.addElement(groupType);
			}
		}
	  
		ret.trimToSize();
		VectorFuncs.sort(ret);

		return(ret);
	}
	/**
	 * Gets a list of Group Types that the user has access to.
	 * 
	 * @return
	 *      Vector - Vector of GroupType that the user has access to.
	 *               The vector may be empty but never null.
	 * @param loginID java.lang.String
	 * @exception java.lang.Exception
	 */
	public Vector getGroupTypesOfUser(String loginID)
			throws Exception
	{
		final String    tUserDN = "uid=" + loginID + ",ou=People," + baseDN;
		Vector          ret = new Vector();
		GroupType       groupType;
		Vector          vector1, vector2, vector3, vector4;
		Hashtable       hashT1;
		String          tDN;
		String          tFilter;

		tDN = "ou=StoreGroupAdmin,ou=Applications," + baseDN;
		tFilter = "(uniquemember=" + tUserDN + ")";

		// Get a list of all the Store Group Admin Roles the user is a member of.
		if ((vector1 = ldapDir.search(tDN, tFilter, new String[] {"description"}, true)) != null) {
			final int vector1Size = vector1.size();
			for (int x1 = 0; x1 < vector1Size; x1++) {
				vector2 = (Vector) vector1.elementAt(x1);
				hashT1 = (Hashtable) vector2.elementAt(1);

				tDN = "ou=SharedGroupTypes,ou=SharedGroups," + baseDN;
				tFilter = "(description=" + getAttributeValue(hashT1, "description") + ")";

				// Find the SharedGroupTypes object with that description.
				if ((vector3 = ldapDir.search(tDN, tFilter, new String[] {"uid", "description"}, true)) != null) {
					final int vector3Size = vector3.size();
					for (int x2 = 0; x2 < vector3Size; x2++) {
						vector4 = (Vector) vector3.elementAt(x2);
						hashT1 = (Hashtable) vector4.elementAt(1);

						groupType = new GroupType(getAttributeValue(hashT1, "uid"),
												  getAttributeValue(hashT1, "description"));
						ret.addElement(groupType);
					}
				}
			}
		}

		ret.trimToSize();
		VectorFuncs.sort(ret);

		return(ret);
	}
	/**
	 * Counts how many of the store's users have a SVHarbor email address.
	 * 
	 * @return int
	 * @param storeNumber java.lang.String
	 * @exception java.lang.Exception
	 */
	public int getHarborMailCount(String storeNumber)
			throws Exception
	{
		final String 	tHarborEmailSuffix = getMailSuffix().toLowerCase();
		String			tUserDN;
		Hashtable		hashT1;
		int				ret = 0;

		Vector userDNList = getUserDNsOfStore(storeNumber);

		final int vectorSize = userDNList.size();
		for (int x = 0; x < vectorSize; x++) {
			tUserDN = (String) userDNList.elementAt(x);

			// Read the email adddress from the user object.
			if (((hashT1 = ldapDir.read(tUserDN, new String[] {"mail"})) != null) &&
				(getAttributeValue(hashT1, "mail").toLowerCase().endsWith(tHarborEmailSuffix))) {

				ret++;
			}
		}

		return ret;
	}
	/**
	 * Get's the LoginID for the specified email address.  This function
	 * first looks for the email address in Domino, if it's not there, it
	 * looks in LDAP.
	 *
	 * @return The login ID or null if the emailAddress
	 * isn't found in LDAP or Domino.
	 * @param emailAddress java.lang.String
	 * @exception java.lang.Exception
	 */
	public String getLoginIDForEmailAddress(java.lang.String emailAddress)
		throws Exception
	{
		String ret;
	
		ret = getLoginIDForEmailAddressFromDomino(emailAddress);
	
		if (ret == null) {
			ret = getLoginIDForEmailAddressFromLDAP(emailAddress);
		}
	
		return ret;
	}
	/**
	 * Get's the LoginID for the specified email address from Domino.
	 * 
	 * @return java.lang.String - Returns the login ID or NULL
	 * if the email address isn't found in Domino.
	 * @param emailAddress java.lang.String
	 * @exception java.lang.Exception
	 */
	private String getLoginIDForEmailAddressFromDomino(java.lang.String emailAddress)
		throws Exception
	{
		if (dominoAccessProperties == null) {
			String tMsg = "Error in getLoginIDForEmailAddressFromDomino().  Domino access parameters not found in configuration file.";
			throw new Exception(tMsg);
		}
	
		final String ret = com.svharbor.services.AddressServices.getUserID(dominoAccessProperties, emailAddress);
	
		return(ret.length() > 0 ? ret : null);
	}
	/**
	 * Get's the LoginID for the specified email address from LDAP.
	 * 
	 * @return java.lang.String - Returns the login ID or NULL
	 * if the email address isn't found in LDAP.
	 * @param emailAddress java.lang.String
	 * @exception java.lang.Exception
	 */
	private String getLoginIDForEmailAddressFromLDAP(java.lang.String emailAddress)
		throws Exception
	{
		final String    tDN = "ou=People," + baseDN;
		final String    tFilter = "(mail=" + emailAddress + ")";
		Vector          vector1;
		Vector          vector2;
		Hashtable		hashT1;
		String			ret = null;
	
		if ((vector1 = ldapDir.search(tDN, tFilter, new String[] {"uid"}, true)) != null) {
			if (vector1.size() > 0) {
				vector2 = (Vector) vector1.elementAt(0);
				hashT1 = (Hashtable) vector2.elementAt(1);
				ret = getAttributeValue(hashT1, "uid");
			}
		}
	
		return ret;
	}
	/**
	 * Returns the URL of the logout screen.
	 * 
	 * @return java.lang.String
	 * @exception java.lang.Exception
	 */
	public String getLogoutURL()
			throws Exception
	{
		return(svharborConstants.getSVHarborLogoutURL());
	}
	/**
	 * Gets the email suffix that identify SVHarbor email users.
	 * 
	 * @return java.lang.String
	 * @exception java.lang.Exception
	 */
	public String getMailSuffix()
			throws Exception
	{
		return(svharborConstants.getEMailSuffix());
	}
	/**
	 * Get a new seed for the random number generator.  Be sure
	 * not to return the same seed twice.
	 */
	private long GetNewRandomSeed()
	{
		long ret;
		
		do {
			ret = (new Date()).getTime();
		} while(ret == previousRandomSeed);
		
		previousRandomSeed = ret;
		
		return(ret);
	}
	/*
	 * Returns the name of the specified object.  This is done
	 * by reading the name from the first segment of the DN.
	 * Example: getObjectName("uid=test,ou=People,ou=svharbor,o=supervalu.com");
	 * Returns "test"
	 */
	private String getObjectName(Name theDNName)
	{
		final int   tSegmentOffset = theDNName.size() - 1;
		String      ret = null;

		if (tSegmentOffset >= 0) {
			String  tSegment = theDNName.get(tSegmentOffset);
			int     tOffset;
		   
			if ((tOffset = tSegment.indexOf('=') + 1) > 0) {
				ret = tSegment.substring(tOffset);
			}
		}

		return ret != null ? ret : new String("");
	}
	/*
	 * Returns the name of the specified object.  This is done
	 * by reading the name from the first segment of the DN.
	 * Example: getObjectName("uid=test,ou=People,ou=svharbor,o=supervalu.com");
	 * Returns "test"
	 */
	private String getObjectName(String theDN)
			throws Exception
	{
		final Name tDNName = ldapDir.convertToName(theDN);

		return getObjectName(tDNName);
	}
	/**
	 * Gets the URL of the "privacy" page..
	 * 
	 * @return java.lang.String
	 * @exception java.lang.Exception
	 */
	public String getPrivacyURL()
			throws Exception
	{
		return(svharborConstants.getSVHarborPrivacyURL());
	}
	/**
	 * Gets the name of the Publication Dropoff directory.
	 * 
	 * @return java.lang.String
	 * @exception java.lang.Exception
	 */
	public String getPubDropoffDir()
			throws Exception
	{
		return(svharborConstants.getPubDropoffDir());
	}
	/**
	 * Gets a random number that falls between lowVal and highVal (inclusive).
	 */
	private byte getRandomNumber(Random random,
								 byte lowVal,
								 byte highVal)
	{
		final byte  range = (byte) (((byte) (highVal - lowVal)) + ((byte) 1));
		byte        bytes[] = new byte[1];
		byte        ret;

		// Get a random number.
		do {
			random.nextBytes(bytes);
		} while (bytes[0] == -128);

		// Convert negative numbers to positive numbers.
		ret = (byte) (bytes[0] < 0 ? 0 - bytes[0] : bytes[0]);
		
		// Make sure the number is in the desired range.
		ret = (byte) ((ret % range) + lowVal);

		return(ret);
	}
	/**
	 * Returns the DN of the Region Admin group that the user is
	 * a member of.
	 *
	 * This function returns the first admin group containing the word
	 * "region" that the user is a member of.  If the user isn't a member
	 * of any group containing the word "region", the first admin group
	 * is returned.  If the user isn't a member of any admin group, the
	 * DN of the user is returned.
	 * 
	 * @return The DN of the Region AdminGroup that the user is a member of.
	 * @param loginID java.lang.String
	 * @exception java.lang.Exception
	 */
	private String getRegionAdminGroupDNOfUser(String loginID)
			throws Exception
	{
		final String    tUserDN = "uid=" + loginID + ",ou=People," + baseDN;
		Vector          vector1;
		String          tDN;
		String          tFilter;
		String          ret = null;

		tDN = "ou=AdminGroups,ou=Groups," + baseDN;
		tFilter = "(&(uniquemember=" + tUserDN + ")(cn=*region*))";

		// Get a list of all the Region Admin Groups the user is a member of.
		if ((vector1 = ldapDir.search(tDN, tFilter, true)) != null) {
			ret = (String) vector1.elementAt(0);
		}
		else {
			tDN = "ou=AdminGroups,ou=Groups," + baseDN;
			tFilter = "(uniquemember=" + tUserDN + ")";
			
			// Get a list of all the Admin Groups the user is a member of.
			if ((vector1 = ldapDir.search(tDN, tFilter, true)) != null) {
				ret = (String) vector1.elementAt(0);
			}
			else {
				ret = tUserDN;
			}
		}
	  
		return(ret);
	}
	/**
	 * Gets a list of stores that the user has access to.
	 * 
	 * This function is identical to getStoreDCListForUser_Unsorted
	 * except this function returns a Vector of Store objects
	 * instead of a Vector of StoreDC objects.
	 *
	 * @return
	 *      Vector - Vector of StoreDC objects.
	 *               The vector may be empty but never null.
	 * @param loginID java.lang.String
	 * @param storeFilter java.lang.String
	 * @exception java.lang.Exception
	 */
	private Vector doGetStoreObjectListForUser(String loginID,
											   Store storeFilter)
			throws Exception
	{
		final String    tUserDN = "uid=" + loginID + ",ou=People," + baseDN;
		Vector          ret = new Vector();
		Store         	store;
		Vector          vector1;
		Hashtable       hashT1;
		Object[]        attrib_value;
		String          tDN;
		Name            tDNName;
		String          tFilter;
		boolean         passesFilterTest;
		int             storeListSize;

		// Look up the user's store (if any) in the user object.
		if (((hashT1 = ldapDir.read(tUserDN, new String[] {"roomnumber"})) != null) &&
			((attrib_value = (Object[]) hashT1.get("roomnumber")) != null)) {

			tDN = "uid=" + attrib_value[0].toString() + ",ou=Stores," + baseDN;

			// Add a Store object to the vector.
			if ((hashT1 = ldapDir.read(tDN, null)) != null) {
				String tStoreNumber = getAttributeValue(hashT1, "uid");
				String tStoreName = getAttributeValue(hashT1, "sn");
				String tCity = getAttributeValue(hashT1, "homepostaladdress");
				String tStateCode = getAttributeValue(hashT1, "st");
				
				// Ignore stores that don't match the filter.
				passesFilterTest = true;
				if (storeFilter != null) {
					if ((storeFilter.getStoreNumber().length() > 0) &&
						(! tStoreNumber.toLowerCase().startsWith(storeFilter.getStoreNumber().toLowerCase()))) {
						passesFilterTest = false;
					}
					else if ((storeFilter.getName().length() > 0) &&
							 (! tStoreName.toLowerCase().startsWith(storeFilter.getName().toLowerCase()))) {
						passesFilterTest = false;
					}
					else if ((storeFilter.getCity().length() > 0) &&
							 (! tCity.toLowerCase().startsWith(storeFilter.getCity().toLowerCase()))) {
						passesFilterTest = false;
					}
					else if ((storeFilter.getStateCode().length() > 0) &&
							 (! tStateCode.equalsIgnoreCase(storeFilter.getStateCode()))) {
						passesFilterTest = false;
					}
				}
				
				if (passesFilterTest) {
					store = new Store(tStoreNumber,	// storeNumber
									  getAttributeValue(hashT1, "businessCategory"), // type
									  tStoreName, // storeName
									  getAttributeValue(hashT1, "street"),	// address
									  tCity, // city
									  tStateCode, // stateCode
									  getAttributeValue(hashT1, "postalCode"),	// zipCode
									  getAttributeValue(hashT1, "manager"),	// contact
									  getAttributeValue(hashT1, "telephoneNumber"), // phoneNumber
									  getAttributeValue(hashT1, "labeledURI")); // logo

					ret.addElement(store);
				}
			}
		}

		// Add all the necessary stores from the SharedGroups objects.
		getStoreObjectListFromSharedGroups(ret, tUserDN, storeFilter);

		tDN = "ou=AdminGroups,ou=Groups," + baseDN;
		tFilter = "(uniquemember=" + tUserDN + ")";

		// Get a list of all the AdminGroups the user is a member of.
		if ((vector1 = ldapDir.search(tDN, tFilter, true)) != null) {
			final int vector1Size = vector1.size();

			for (int x1 = 0; x1 < vector1Size; x1++) {
				tDN = (String) vector1.elementAt(x1);

				// Add all the necessary stores from the SharedGroups objects.
				getStoreObjectListFromSharedGroups(ret, tDN, storeFilter);
			}
		}

		ret.trimToSize();

		return ret;
	}
	/**
	 * Searches for the specified DN in the uniqueMember attribute of the
	 * SharedGroups.  For each SharedGroup found, add it's stores to the
	 * storeList Vector.
	 */
	private void getStoreObjectListFromSharedGroups(Vector storeList,
											    	String theDN,
													Store storeFilter)
			throws Exception
	{
		final String    tStoresBaseDN = "ou=Stores," + baseDN;
		final Name      tStoresBaseDNName = ldapDir.convertToName(tStoresBaseDN);
		Vector          vector1;
		Vector          vector2;
		Vector          noMatchList = new Vector();
		int             noMatchListSize;
		Hashtable       hashT1;
		Hashtable       hashT2;
		Object[]        attrib_value;
		Store         	store;
		Store         	tempStore;
		String          tDN;
		Name            tDNName;
		String          tFilter;
		int             index;
		int             storeListSize;
		String          tStoreNumber;
		boolean         passesFilterTest;

		tDN = "ou=SharedGroups," + baseDN;
		tFilter = "(uniquemember=" + theDN + ")";

		// Get a list of all the SharedGroups theDN is a member of.
		if ((vector1 = ldapDir.search(tDN, tFilter, new String[] {"uniquemember","businesscategory","cn"}, true)) != null) {
			final int vector1Size = vector1.size();
			for (int x1 = 0; x1 < vector1Size; x1++) {
				vector2 = (Vector) vector1.elementAt(x1);

				tDN = (String) vector2.elementAt(0);
				hashT1 = (Hashtable) vector2.elementAt(1);

				if ((attrib_value = (Object[]) hashT1.get("uniquemember")) != null) {
					// Look at each member and pull out the stores.
					for (int i = 0; i < attrib_value.length; i++) {	
						tDN = attrib_value[i].toString();
						tDNName = ldapDir.convertToName(tDN);

						// Ignore everything except stores.
						if (! tDNName.startsWith(tStoresBaseDNName)) {
							continue;
						}

						tStoreNumber = tDNName.get(tDNName.size() - 1).substring(4);

						// If we have a store number filter, make sure this store conforms.
						if ((storeFilter != null) &&
							(storeFilter.getStoreNumber().length() > 0) &&
							(! tStoreNumber.toLowerCase().startsWith(storeFilter.getStoreNumber().toLowerCase()))) {

							continue;
						}

						// If we have a filter, check if we already know this store doesn't match the filter.
						if (((storeFilter != null) &&
							 ((storeFilter.getName().length() > 0) ||
							  (storeFilter.getCity().length() > 0) ||
							  (storeFilter.getStateCode().length() > 0)))) {

							noMatchListSize = noMatchList.size();
							for (index = 0; index < noMatchListSize; index++) {
								String ignoreNumber = (String) noMatchList.elementAt(index);

								if (ignoreNumber.equalsIgnoreCase(tStoreNumber)) {
									break;
								}
							}
							if (index < noMatchListSize) {
								continue;
							}
						}

						// Skip this store if it's already in the list.
						storeListSize = storeList.size();
						for (index = 0; index < storeListSize; index++) {
							tempStore = (Store) storeList.elementAt(index);
							if (tempStore.getStoreNumber().equalsIgnoreCase(tStoreNumber)) {
								break;
							}
						}
						if (index < storeListSize) {
							continue;
						}

						// Add a Store object to the vector.
						if ((hashT2 = ldapDir.read(tDN, null)) != null) {
							String tStoreName = getAttributeValue(hashT2, "sn");
							String tCity = getAttributeValue(hashT2, "homepostaladdress");
							String tStateCode = getAttributeValue(hashT2, "st");
							passesFilterTest = true;

							// Ignore stores that don't match the filter.
							if (storeFilter != null) {
								if ((storeFilter.getName().length() > 0) &&
									(! tStoreName.toLowerCase().startsWith(storeFilter.getName().toLowerCase()))) {
									passesFilterTest = false;
								}
								else if ((storeFilter.getCity().length() > 0) &&
										 (! tCity.toLowerCase().startsWith(storeFilter.getCity().toLowerCase()))) {
									passesFilterTest = false;
								}
								else if ((storeFilter.getStateCode().length() > 0) &&
										 (! tStateCode.equalsIgnoreCase(storeFilter.getStateCode()))) {
									passesFilterTest = false;
								}
							}

							if (passesFilterTest) {
								store = new Store(tStoreNumber,	// storeNumber
												  getAttributeValue(hashT2, "businessCategory"), // type
												  tStoreName, // storeName
												  getAttributeValue(hashT2, "street"),	// address
												  tCity, // city
												  tStateCode, // stateCode
												  getAttributeValue(hashT2, "postalCode"),	// zipCode
												  getAttributeValue(hashT2, "manager"),	// contact
												  getAttributeValue(hashT2, "telephoneNumber"), // phoneNumber
												  getAttributeValue(hashT2, "labeledURI")); // logo
								storeList.addElement(store);
							}
							else {
								// Add this store number to the list of stores to ignore.
								noMatchList.addElement(tStoreNumber);
							}
						}
					}
				}
			}
		}
	}
	/**
	 * Gets a list of stores that the user has access to.
	 * 
	 * This function is identical to doGetStoreObjectListForUser
	 * except this function returns a Vector of StoreDC objects
	 * instead of a Vector of Store objects.
	 * 
	 * @return
	 *      Vector - Vector of StoreDC objects.
	 *               The vector may be empty but never null.
	 * @param loginID java.lang.String
	 * @param dcNameFilter java.lang.String
	 * @param storeFilter java.lang.String
	 * @param stopAtFirstStore boolean - If set to true, the search
	 * will stop when it finds the first store.
	 * @exception java.lang.Exception
	 */
	private Vector getStoreDCListForUser_Unsorted(String loginID,
												  String dcNameFilter,
												  Store storeFilter,
												  boolean stopAtFirstStore)
			throws Exception
	{
		final String    tUserDN = "uid=" + loginID + ",ou=People," + baseDN;
		Vector          ret = new Vector();
		StoreDC         storeDC;
		Vector          vector1;
		Hashtable       hashT1;
		Object[]        attrib_value;
		String          tDN;
		Name            tDNName;
		String          tFilter;
		boolean         passesFilterTest;
		int             storeDCListSize;
		
		//System.out.println("1. Getting Home Store " );
		//System.out.println("1.1 User DN : " + tUserDN);
		
		// Look up the user's store (if any) in the user object.
		if (((hashT1 = ldapDir.read(tUserDN, new String[] {"roomnumber"})) != null) &&
			((attrib_value = (Object[]) hashT1.get("roomnumber")) != null)) {

			tDN = "uid=" + attrib_value[0].toString() + ",ou=Stores," + baseDN;
			//System.out.println("1.2 DN : " + tDN);
			// Add a StoreDC object to the vector.
			if ((hashT1 = ldapDir.read(tDN, new String[] {"uid", "sn", "homepostaladdress", "st"})) != null) {
				String tStoreNumber = getAttributeValue(hashT1, "uid");
				String tStoreName = getAttributeValue(hashT1, "sn");
				String tCity = getAttributeValue(hashT1, "homepostaladdress");
				String tStateCode = getAttributeValue(hashT1, "st");
				
				// Ignore stores that don't match the filter.
				passesFilterTest = true;
				if (storeFilter != null) {
					if ((storeFilter.getStoreNumber().length() > 0) &&
						(! tStoreNumber.toLowerCase().startsWith(storeFilter.getStoreNumber().toLowerCase()))) {
						passesFilterTest = false;
					}
					else if ((storeFilter.getName().length() > 0) &&
							 (! tStoreName.toLowerCase().startsWith(storeFilter.getName().toLowerCase()))) {
						passesFilterTest = false;
					}
					else if ((storeFilter.getCity().length() > 0) &&
							 (! tCity.toLowerCase().startsWith(storeFilter.getCity().toLowerCase()))) {
						passesFilterTest = false;
					}
					else if ((storeFilter.getStateCode().length() > 0) &&
							 (! tStateCode.equalsIgnoreCase(storeFilter.getStateCode()))) {
						passesFilterTest = false;
					}
				}
				if ((passesFilterTest) &&
					(dcNameFilter != null) &&
					(dcNameFilter.length() > 0)) {
						
					if (! existStoreInGroup(tStoreNumber, dcNameFilter)) {
						passesFilterTest = false;
					}
				}
				
				if (passesFilterTest) {
					storeDC = new StoreDC(tStoreNumber, tStoreName, "", "");
					ret.addElement(storeDC);
				}
			}
		}

		if ((! stopAtFirstStore) || (ret.size() == 0)) {
			// Add all the necessary stores from the SharedGroups objects.
			//System.out.println("2.1");
			//System.out.println("2.2 -> tUserDN " + tUserDN);
			//System.out.println("2.3 -> dcNameFilter " + dcNameFilter);
			//System.out.println("2.4 -> storeFilter "  + storeFilter);
			
			getStoreDCListFromSharedGroups(ret, tUserDN, dcNameFilter, storeFilter, stopAtFirstStore);
		}

		if ((! stopAtFirstStore) || (ret.size() == 0)) {
			tDN = "ou=AdminGroups,ou=Groups," + baseDN;
			tFilter = "(uniquemember=" + tUserDN + ")";

			//System.out.println("3.0 Processing shared groups");
			//System.out.println("3.1 DN : " + tDN);
			//System.out.println("3.2 Filter : " + tFilter);
			// Get a list of all the AdminGroups the user is a member of.
			if ((vector1 = ldapDir.search(tDN, tFilter, true)) != null) {
				final int vector1Size = vector1.size();

				for (int x1 = 0; x1 < vector1Size; x1++) {
					tDN = (String) vector1.elementAt(x1);

					// Add all the necessary stores from the SharedGroups objects.
					//System.out.println("4.0 Processing shared groups");
					//System.out.println("4.1 DN : " + tDN);
					//System.out.println("4.2 dcNameFilter : " + dcNameFilter);
					//System.out.println("4.2 storeFilter : " + storeFilter);

					getStoreDCListFromSharedGroups(ret, tDN, dcNameFilter, storeFilter, stopAtFirstStore);

					if ((stopAtFirstStore) && (ret.size() > 0)) {
						break;
					}
				}
			}
		}

		// Fill in any missing DC or Region values.
		storeDCListSize = ret.size();
		for (int index = 0; index < storeDCListSize; index++) {
			storeDC = (StoreDC) ret.elementAt(index);

			if (storeDC.getDC().length() == 0) {
				storeDC.setDC(getGroupOfStore(storeDC.getStoreNumber(), "DC"));
			}
			if (storeDC.getRegion().length() == 0) {
				storeDC.setRegion(getGroupOfStore(storeDC.getStoreNumber(), "RG"));
			}
		}
		
		ret.trimToSize();
		
		return(ret);
	}
	/**
	 * Searches for the specified DN in the uniqueMember attribute of the
	 * SharedGroups.  For each SharedGroup found, add it's stores to the
	 * storeDCList Vector.
	 * @param stopAtFirstStore boolean - If set to true, the search
	 * will stop when it finds the first store.
	 */
	private void getStoreDCListFromSharedGroups(Vector storeDCList,
											    String theDN,
												String dcNameFilter,
												Store storeFilter,
												boolean stopAtFirstStore)
			throws Exception
	{
		final String    tStoresBaseDN = "ou=Stores," + baseDN;
		final Name      tStoresBaseDNName = ldapDir.convertToName(tStoresBaseDN);
		Vector          vector1;
		Vector          vector2;
		Vector          noMatchList = new Vector();
		int             noMatchListSize;
		Hashtable       hashT1;
		Hashtable       hashT2;
		Object[]        attrib_value;
		StoreDC         storeDC;
		StoreDC         tempStoreDC;
		String          tDN;
		Name            tDNName;
		String          tFilter;
		int             index;
		int             storeDCListSize;
		String          tDC = new String("");
		String          tRegion = new String("");
		String          tStoreNumber;
		boolean         passesFilterTest;

		tDN = "ou=SharedGroups," + baseDN;
		tFilter = "(uniquemember=" + theDN + ")";
		
		//System.out.println("Shared Groups ");
		//System.out.println("DN : " + tDN);
		//System.out.println("Filter : " + tFilter);
		
		// Get a list of all the SharedGroups theDN is a member of.
		if ((vector1 = ldapDir.search(tDN, tFilter, new String[] {"uniquemember","businesscategory","cn"}, true)) != null) {
			final int vector1Size = vector1.size();
			for (int x1 = 0; x1 < vector1Size; x1++) {
				if ((stopAtFirstStore) && (storeDCList.size() > 0)) {
					break;
				}

				vector2 = (Vector) vector1.elementAt(x1);

				tDN = (String) vector2.elementAt(0);
				hashT1 = (Hashtable) vector2.elementAt(1);

				if ((attrib_value = (Object[]) hashT1.get("uniquemember")) != null) {
					if (getAttributeValue(hashT1, "businesscategory").equalsIgnoreCase("DC")) {
						tDC = getAttributeValue(hashT1, "cn");
					}
					else {
						tDC = "";
					}

					if (getAttributeValue(hashT1, "businesscategory").equalsIgnoreCase("RG")) { 
						tRegion = getAttributeValue(hashT1, "cn");
					}
					else {
						tRegion = "";
					}
						
					// Look at each member and pull out the stores.
					for (int i = 0; i < attrib_value.length; i++) {	
						tDN = attrib_value[i].toString();
						tDNName = ldapDir.convertToName(tDN);
						//System.out.println("2222 tDN " + tDN);
						//System.out.println("2222 tDNName " + tDNName);
						// Ignore everything except stores.
						if (! tDNName.startsWith(tStoresBaseDNName)) {
							continue;
						}

						tStoreNumber = tDNName.get(tDNName.size() - 1).substring(4);

						// If we have a store number filter, make sure this store conforms.
						if ((storeFilter != null) &&
							(storeFilter.getStoreNumber().length() > 0) &&
							(! tStoreNumber.toLowerCase().startsWith(storeFilter.getStoreNumber().toLowerCase()))) {

							continue;
						}

						// If we have a filter, check if we already know this store doesn't match the filter.
						if (((storeFilter != null) &&
							 ((storeFilter.getName().length() > 0) ||
							  (storeFilter.getCity().length() > 0) ||
							  (storeFilter.getStateCode().length() > 0))) ||
							((dcNameFilter != null) &&
							 (dcNameFilter.length() > 0))) {

							noMatchListSize = noMatchList.size();
							for (index = 0; index < noMatchListSize; index++) {
								String ignoreNumber = (String) noMatchList.elementAt(index);

								if (ignoreNumber.equalsIgnoreCase(tStoreNumber)) {
									break;
								}
							}
							if (index < noMatchListSize) {
								continue;
							}
						}

						// Skip this store if it's already in the list.
						storeDCListSize = storeDCList.size();
						for (index = 0; index < storeDCListSize; index++) {
							tempStoreDC = (StoreDC) storeDCList.elementAt(index);
							if (tempStoreDC.getStoreNumber().equalsIgnoreCase(tStoreNumber)) {
								// Add information to the existing record.
								if (tDC.length() > 0) {
									tempStoreDC.setDC(tDC);
								}
								if (tRegion.length() > 0) {
									tempStoreDC.setRegion(tRegion);
								}
								break;
							}
						}
						if (index < storeDCListSize) {
							continue;
						}

						// Add a StoreDC object to the vector.
						//System.out.println("1111111DN : " + tDN);
						
						if ((hashT2 = ldapDir.read(tDN, new String[] {"sn", "homepostaladdress", "st"})) != null) {
							// String tType = getAttributeValue(hashT2, "businesscategory");
							String tStoreName = getAttributeValue(hashT2, "sn");
							// String tAddress = getAttributeValue(hashT2, "street");
							String tCity = getAttributeValue(hashT2, "homepostaladdress");
							String tStateCode = getAttributeValue(hashT2, "st");
							// String tZipCode = getAttributeValue(hashT2, "postalcode");
							// String tContact = getAttributeValue(hashT2, "manager");
							// String tPhoneNumber = getAttributeValue(hashT2, "telephonenumber");
							// String tLogo = getAttributeValue(hashT2, "labeledURI");
							passesFilterTest = true;

							// Ignore stores that don't match the filter.
							if (storeFilter != null) {
								if ((storeFilter.getName().length() > 0) &&
									(! tStoreName.toLowerCase().startsWith(storeFilter.getName().toLowerCase()))) {
									passesFilterTest = false;
								}
								else if ((storeFilter.getCity().length() > 0) &&
										 (! tCity.toLowerCase().startsWith(storeFilter.getCity().toLowerCase()))) {
									passesFilterTest = false;
								}
								else if ((storeFilter.getStateCode().length() > 0) &&
										 (! tStateCode.equalsIgnoreCase(storeFilter.getStateCode()))) {
									passesFilterTest = false;
								}
							}
							if ((passesFilterTest) &&
								(dcNameFilter != null) &&
								(dcNameFilter.length() > 0)) {
									
								if (! existStoreInGroup(tStoreNumber, dcNameFilter)) {
									passesFilterTest = false;
								}
							}

							if (passesFilterTest) {
								storeDC = new StoreDC(tStoreNumber, tStoreName, tDC, tRegion);
								storeDCList.addElement(storeDC);

								if (stopAtFirstStore) {
									break;
								}
							}
							else {
								// Add this store number to the list of stores to ignore.
								noMatchList.addElement(tStoreNumber);
							}
						}
					}
				}
			}
		}
	}
	/**
	 * Gets details about the specified store.
	 * 
	 * @return
	 *      Store - An object containing the store details.
	 * @param storeNumber java.lang.String
	 * @exception java.lang.Exception
	 */
	public Store getStoreDetail(String storeNumber)
			throws Exception
	{
		final String    tStoreDN = "uid=" + storeNumber + ",ou=Stores," + baseDN;
		Store           ret = null;
		Hashtable       hashT;

		// Read all the fields from the Stores object.
		if ((hashT = ldapDir.read(tStoreDN, null)) != null) {
			ret = new Store(getAttributeValue(hashT, "uid"),
							getAttributeValue(hashT, "businessCategory"),
							getAttributeValue(hashT, "sn"),
							getAttributeValue(hashT, "street"),
							getAttributeValue(hashT, "homePostalAddress"),
							getAttributeValue(hashT, "st"),
							getAttributeValue(hashT, "postalCode"),
							getAttributeValue(hashT, "manager"),
							getAttributeValue(hashT, "telephoneNumber"),
							getAttributeValue(hashT, "labeledURI"));
		}
		else {
			String tMsg = "Error in getStoreDetail().  Store: " + storeNumber + " doesn't exist in the LDAP directory.";
			throw new Exception(tMsg);
		}

		return(ret);
	}
	/**
	 * This function returns the same list of stores as getStoreListForUser(),
	 * but the stores are arranged in a hierarchical fashion to make it easier
	 * for a web page to trace through and display the list.
	 * 
	 * @return
	 *      Vector - A "nested" Vector.  The "outer" Vector will have one element
	 *               for each region that the passed user has access to stores
	 *               of.  Each element is itself a Vector.  Each of these
	 *               "middle" Vectors will have at least two elements.  The
	 *               first element will always be a String containing the
	 *               name of the region.  The rest of the Vector will contain
	 *               an element for each DC in the "outer" Vector's region
	 *               that the passed user has access to stores of.  Each of
	 *               these DC elements is itself a Vector.  Each of these
	 *               "inner" Vectors will have at least two elements.  The
	 *               first element will always be a String containing the
	 *               name of the DC.  The rest of the Vector will be StoreDC
	 *               objects for each store that the passed user has access
	 *               to in that DC.
	 *               The returned Vector may be empty but never null.
	 * @param loginID java.lang.String
	 * @exception java.lang.Exception
	 */
	public Vector getStoreHierarchyForUser(String loginID)
			throws Exception
	{
		Vector          retVector = new Vector();
		Vector          regionVector = null;
		Vector          dcVector = null;
		Vector          storeList = null;
		int             storeListSize;
		StoreDC         store;
		String          prevRegion = null, prevDC = null;
		int             x1;

		storeList = getStoreDCListForUser_Unsorted(loginID, null, null, false);
		StoreDC.sortByRegionDCStoreNumber(storeList);

		storeListSize = storeList.size();
		for (x1 = 0; x1 < storeListSize; x1++) {
			store = (StoreDC) storeList.elementAt(x1);
			
			if ((prevRegion == null) || (! prevRegion.equalsIgnoreCase(store.getRegion()))) {
				dcVector = new Vector();
				dcVector.addElement(store.getDC());
				dcVector.addElement(store);
				
				regionVector = new Vector();
				regionVector.addElement(store.getRegion());
				regionVector.addElement(dcVector);

				retVector.addElement(regionVector);
				
				prevRegion = store.getRegion();
				prevDC = store.getDC();
			}
			else if (! prevDC.equalsIgnoreCase(store.getDC())) { 
				dcVector = new Vector();
				dcVector.addElement(store.getDC());
				dcVector.addElement(store);
				regionVector.addElement(dcVector);

				prevDC = store.getDC();
			}
			else {
				dcVector.addElement(store);
			}
		}
					
		return(retVector);
	}
	/**
	 * Gets a list of stores that the user has access to.
	 * 
	 * @return
	 *      Vector - Vector of StoreDC objects.
	 *               The vector may be empty but never null.
	 * @param loginID java.lang.String
	 * @exception java.lang.Exception
	 */
	public Vector getStoreListForUser(String loginID)
			throws Exception
	{
		Vector storeList = getStoreDCListForUser_Unsorted(loginID, null, null, false);
		
		StoreDC.sortByStoreNumber(storeList);
		
		return(storeList);
	}
	/**
	 * Gets a list of stores that the user has access to.
	 * 
	 * @return
	 *      Vector - Vector of StoreDC objects.
	 *               The vector may be empty but never null.
	 * @param loginID java.lang.String
	 * @param storeNumberFilter java.lang.String
	 * @param storeNameFilter java.lang.String
	 * @exception java.lang.Exception
	 */
	public Vector getStoreListForUser(String loginID,
									  String storeNumberFilter,
									  String storeNameFilter)
			throws Exception
	{
		Vector storeList = null;
		Store storeFilter = null;
		
		if (((storeNumberFilter != null) &&
			 (storeNumberFilter.length() > 0)) ||
			((storeNameFilter != null) &&
			 (storeNameFilter.length() > 0))) {

			storeFilter = new Store();
			
			if ((storeNumberFilter != null) &&
				(storeNumberFilter.length() > 0)) {
					
				storeFilter.setStoreNumber(storeNumberFilter);
			}
			
			if ((storeNameFilter != null) &&
				(storeNameFilter.length() > 0)) {
					
				storeFilter.setName(storeNameFilter);
			}
		}

		storeList = getStoreDCListForUser_Unsorted(loginID, null, storeFilter, false);
		
		StoreDC.sortByStoreNumber(storeList);
		
		return(storeList);
	}
	/**
	 * Gets a list of stores that the user has access to.
	 * 
	 * @return
	 *      Vector - Vector of StoreDC objects.
	 *               The vector may be empty but never null.
	 * @param loginID java.lang.String
	 * @param dcNameFilter java.lang.String
	 * @param numberFilter java.lang.String
	 * @param nameFilter java.lang.String
	 * @param cityFilter java.lang.String
	 * @param stateFilter java.lang.String
	 * @exception java.lang.Exception
	 */
	public Vector getStoreListForUser(String loginID,
									  String dcNameFilter,
									  String numberFilter,
									  String nameFilter,
									  String cityFilter,
									  String stateFilter)
			throws Exception
	{
		Vector storeList = null;
		Store storeFilter = null;

		if (((numberFilter != null) &&
			 (numberFilter.length() > 0)) ||
			((nameFilter != null) &&
			 (nameFilter.length() > 0)) ||
			((cityFilter != null) &&
			 (cityFilter.length() > 0)) ||
			((stateFilter != null) &&
			 (stateFilter.length() > 0))) {

			storeFilter = new Store();

			if ((numberFilter != null) &&
				(numberFilter.length() > 0)) {
					
				storeFilter.setStoreNumber(numberFilter);
			}

			if ((nameFilter != null) &&
				(nameFilter.length() > 0)) {
					
				storeFilter.setName(nameFilter);
			}

			if ((cityFilter != null) &&
				(cityFilter.length() > 0)) {
					
				storeFilter.setCity(cityFilter);
			}

			if ((stateFilter != null) &&
				(stateFilter.length() > 0)) {
					
				storeFilter.setStateCode(stateFilter);
			}
		}

		storeList = getStoreDCListForUser_Unsorted(loginID, dcNameFilter, storeFilter, false);
		
		StoreDC.sortByStoreNumber(storeList);
		
		return(storeList);
	}
	/**
	 * Gets a list of stores that the user has access to
	 * that also have access to the specified application.
	 * 
	 * @return
	 *      Vector - Vector of StoreDC objects.
	 *               The vector may be empty but never null.
	 * @param loginID java.lang.String
	 * @param applicationName java.lang.String
	 * @exception java.lang.Exception
	 */
	public Vector getStoreListForUserWithApp(String loginID,
											 String applicationName)
			throws Exception
	{
		StoreDC	storeDC;
		Vector 	storeList = getStoreDCListForUser_Unsorted(loginID, null, null, false);

		for (int x = 0; x < storeList.size(); x++) {
			storeDC = (StoreDC) storeList.elementAt(x);

			// Remove any stores that don't have access to the application.
			if (! existAppAtStore(storeDC.getStoreNumber(), applicationName)) {
				storeList.removeElementAt(x);
				x--;
			}
		}

		StoreDC.sortByStoreNumber(storeList);

		return storeList;
	}
	/**
	 * Gets a list of stores that the user has access to.
	 * 
	 * @return
	 *      Vector - Vector of Store objects.
	 *               The vector may be empty but never null.
	 * @param loginID java.lang.String
	 * @exception java.lang.Exception
	 */
	public Vector getStoreObjectListForUser(String loginID)
			throws Exception
	{
		Vector storeList = doGetStoreObjectListForUser(loginID, null);

		Store.sortByStoreNumber(storeList);

		return(storeList);
	}
	/**
	 * Gets a list of stores that the user has access to.
	 * 
	 * @return
	 *      Vector - Vector of Store objects.
	 *               The vector may be empty but never null.
	 * @param loginID java.lang.String
	 * @param numberFilter java.lang.String - Pass "015" to see
	 * all the stores whose number starts with "015".
	 * @param nameFilter java.lang.String - Pass "Bill" to see all
	 * the stores whose name starts with "Bill".
	 * @param cityFilter java.lang.String
	 * @param stateFilter java.lang.String
	 * @exception java.lang.Exception
	 */
	public Vector getStoreObjectListForUser(String loginID,
									  		String numberFilter,
											String nameFilter,
											String cityFilter,
											String stateFilter)
			throws Exception
	{
		Vector storeList;
		Store storeFilter = null;

		if (((numberFilter != null) &&
			 (numberFilter.length() > 0)) ||
			((nameFilter != null) &&
			 (nameFilter.length() > 0)) ||
			((cityFilter != null) &&
			 (cityFilter.length() > 0)) ||
			((stateFilter != null) &&
			 (stateFilter.length() > 0))) {

			storeFilter = new Store();

			if ((numberFilter != null) &&
				(numberFilter.length() > 0)) {
					
				storeFilter.setStoreNumber(numberFilter);
			}

			if ((nameFilter != null) &&
				(nameFilter.length() > 0)) {
					
				storeFilter.setName(nameFilter);
			}

			if ((cityFilter != null) &&
				(cityFilter.length() > 0)) {
					
				storeFilter.setCity(cityFilter);
			}

			if ((stateFilter != null) &&
				(stateFilter.length() > 0)) {
					
				storeFilter.setStateCode(stateFilter);
			}
		}

		storeList = doGetStoreObjectListForUser(loginID, storeFilter);

		Store.sortByStoreNumber(storeList);

		return storeList;
	}
	/**
	 * Gets a list of store numbers that the user has access to.
	 * 
	 * @return
	 *      Vector - Vector of Strings.
	 *               The vector may be empty but never null.
	 * @param loginID java.lang.String
	 * @exception java.lang.Exception
	 */
	public Vector getStoreNumberListForUser(String loginID)
			throws Exception
	{
		final String    tUserDN = "uid=" + loginID + ",ou=People," + baseDN;
		Vector          ret = new Vector();
		StoreDC         storeDC;
		Vector          vector1;
		Hashtable       hashT1;
		Object[]        attrib_value;
		String          tDN;
		Name            tDNName;
		String          tFilter;
		int             storeDCListSize;

		// Look up the user's store (if any) in the user object.
		if (((hashT1 = ldapDir.read(tUserDN, new String[] {"roomnumber"})) != null) &&
			((attrib_value = (Object[]) hashT1.get("roomnumber")) != null)) {

			tDN = "uid=" + attrib_value[0].toString() + ",ou=Stores," + baseDN;

			/*
             * Make sure that the value in the roomnumber field is really a 
             * store number.  Add the store number to the vector.
             */
			if ((hashT1 = ldapDir.read(tDN, new String[] {"uid"})) != null) {
				String tStoreNumber = getAttributeValue(hashT1, "uid");
				
       			ret.addElement(tStoreNumber);
			}
		}

		// Add all the necessary stores from the SharedGroups objects.
		getStoreNumberListFromSharedGroups(ret, tUserDN);

		tDN = "ou=AdminGroups,ou=Groups," + baseDN;
		tFilter = "(uniquemember=" + tUserDN + ")";
		
		// Get a list of all the AdminGroups the user is a member of.
		if ((vector1 = ldapDir.search(tDN, tFilter, true)) != null) {
			final int vector1Size = vector1.size();

			for (int x1 = 0; x1 < vector1Size; x1++) {
				tDN = (String) vector1.elementAt(x1);
				
				// Add all the necessary stores from the SharedGroups objects.
				getStoreNumberListFromSharedGroups(ret, tDN);
			}
		}

		ret.trimToSize();
		
		return(ret);
	}
	/**
	 * Gets a list of stores that the user has access to.  This
	 * function stops searching when it finds the first store.
	 * 
	 * @return
	 *      StoreDC - The object will be null if the user
	 *                doesn't have access to any stores.
	 * @param loginID java.lang.String
	 * @exception java.lang.Exception
	 */
	public StoreDC getFirstStoreForUser(String loginID)
			throws Exception
	{
		Vector storeList = getStoreDCListForUser_Unsorted(loginID, null, null, true);

		return storeList.size() > 0 ? 
			   (StoreDC) storeList.elementAt(0) :
			   null;
	}
	/**
	 * Searches for the specified DN in the uniqueMember attribute of the
	 * SharedGroups.  For each SharedGroup found, add it's stores to the
	 * Vector of store numbers.
	 * 
	 * @return void
	 * @param storeNumberList Vector
	 * @param theDN java.lang.String
	 * @exception java.lang.Exception
	 */
	private void getStoreNumberListFromSharedGroups(Vector storeNumberList,
											        String theDN)
			throws Exception
	{
		final String    tStoresBaseDN = "ou=Stores," + baseDN;
		final Name      tStoresBaseDNName = ldapDir.convertToName(tStoresBaseDN);
		Vector          vector1;
		Vector          vector2;
		Hashtable       hashT1;
		Object[]        attrib_value;
		String          tDN;
		Name            tDNName;
		String          tFilter;
		int             index;
		int             storeNumberListSize;
        int             result;
		String          tStoreNumber;
        String          holdStoreNumber;

		tDN = "ou=SharedGroups," + baseDN;
		tFilter = "(uniquemember=" + theDN + ")";

		// Get a list of all the SharedGroups theDN is a member of.
		if ((vector1 = ldapDir.search(tDN, tFilter, new String[] {"uniquemember"}, true)) != null) {
			final int vector1Size = vector1.size();
			for (int x1 = 0; x1 < vector1Size; x1++) {
				vector2 = (Vector) vector1.elementAt(x1);

				tDN = (String) vector2.elementAt(0);
				hashT1 = (Hashtable) vector2.elementAt(1);

				if ((attrib_value = (Object[]) hashT1.get("uniquemember")) != null) {
					// Look at each member and pull out the stores.
					for (int i = 0; i < attrib_value.length; i++) {	
						tDN = attrib_value[i].toString();
						tDNName = ldapDir.convertToName(tDN);

						// Ignore everything except stores.
						if (! tDNName.startsWith(tStoresBaseDNName)) {
							continue;
						}

						tStoreNumber = tDNName.get(tDNName.size() - 1).substring(4);

                        // Add the store number to the list in the proper order.
						storeNumberListSize = storeNumberList.size();
						for (index = 0; index < storeNumberListSize; index++) {
							holdStoreNumber = (String) storeNumberList.elementAt(index);
                            
                            if ((result = holdStoreNumber.toLowerCase().compareTo(tStoreNumber.toLowerCase())) == 0) {
								break;
                            }
                            else if (result > 0) {
                                storeNumberList.insertElementAt(tStoreNumber, index);
								break;
                            }
						}
						if (index >= storeNumberListSize) {
                            storeNumberList.addElement(tStoreNumber);
						}
                    }
				}
			}
		}
	}
	/**
	 * Gets a list of stores that are in the specified group.
	 * 
	 * @return 
	 *      Vector - Vector of Store objects that are in the group.  The
	 *               vector may be empty but never null.
	 * @param groupName java.lang.String
	 * @exception java.lang.Exception
	 */
	public Vector getStoresInGroup(String groupName)
			throws Exception
	{
		return(getStoresInGroup(groupName, null, null));
	}
	/**
	 * Gets a list of stores that are in the specified group and which meet
	 * the specified filter criteria.
	 * Pass null for dcNumberFilter if there isn't a DC filter.
	 * Pass null for filter if there isn't a filter.
	 * 
	 * @return
	 *      Vector - Vector of Store objects that are in the group.  The
	 *               vector may be empty but never null.
	 * @param groupName java.lang.String
	 * @param dcNameFilter java.lang.String
	 * @param filter Store
	 * @exception java.lang.Exception
	 */
	private Vector getStoresInGroup(String groupName,
									String dcNameFilter,
									Store filter)
			throws Exception
	{
		final String tStoresBaseDN = "ou=Stores," + baseDN;
		final Name  tStoresBaseDNName = ldapDir.convertToName(tStoresBaseDN);
		Vector      ret = new Vector();
		Hashtable   hashT;
		Hashtable   hashT2;
		Store       store;
		Object[]    attrib_value;
		String      tDN;
		Name        tDNName;
		String      tStoreNumber, tType,  tStoreName, tAddress, tCity, tStateCode, tZipCode, tContact, tPhoneNumber, tLogo;

		tDN = "cn=" + groupName + ",ou=SharedGroups," + baseDN;

		if (((hashT = ldapDir.read(tDN, new String[] {"uniquemember"})) != null) &&
			((attrib_value = (Object[]) hashT.get("uniquemember")) != null)) {

			// Look at each member and pull out only the stores.
			for (int i = 0; i < attrib_value.length; i++) {	
				tDN = attrib_value[i].toString();
				tDNName = ldapDir.convertToName(tDN);

				// Ignore everything except stores.
				if (tDNName.startsWith(tStoresBaseDNName)) {
					// Read all the fields from the object.
					if ((hashT2 = ldapDir.read(tDN, null)) != null) {
						tStoreNumber = getAttributeValue(hashT2, "uid");
						tType = getAttributeValue(hashT2, "businesscategory");
						tStoreName = getAttributeValue(hashT2, "sn");
						tAddress = getAttributeValue(hashT2, "street");
						tCity = getAttributeValue(hashT2, "homepostaladdress");
						tStateCode = getAttributeValue(hashT2, "st");
						tZipCode = getAttributeValue(hashT2, "postalcode");
						tContact = getAttributeValue(hashT2, "manager");
						tPhoneNumber = getAttributeValue(hashT2, "telephonenumber");
						tLogo = getAttributeValue(hashT2, "labeledURI");

						// Ignore records that don't meet the filters.
						if (filter != null) {
							if ((filter.getStoreNumber().length() > 0) &&
								(! tStoreNumber.toLowerCase().startsWith(filter.getStoreNumber().toLowerCase()))) {
								continue;
							}
							if ((filter.getName().length() > 0) &&
								(! tStoreName.toLowerCase().startsWith(filter.getName().toLowerCase()))) {
								continue;
							}
							if ((filter.getCity().length() > 0) &&
								(! tCity.toLowerCase().startsWith(filter.getCity().toLowerCase()))) {
								continue;
							}
							if ((filter.getStateCode().length() > 0) &&
								(! tStateCode.equalsIgnoreCase(filter.getStateCode()))) {
								continue;
							}
						}
						if ((dcNameFilter != null) &&
							(dcNameFilter.length() > 0)) {
								
							if (! existStoreInGroup(tStoreNumber, dcNameFilter)) {
								continue;
							}
						}
						
						store = new Store(tStoreNumber,
										  tType,
										  tStoreName,
										  tAddress,
										  tCity,
										  tStateCode,
										  tZipCode,
										  tContact,
										  tPhoneNumber,
										  tLogo);

						ret.addElement(store);
					}
				}
			}
		}
	   
		ret.trimToSize();
		VectorFuncs.sort(ret);
		
		return(ret);
	}
	/**
	 * Gets a list of stores that are in the specified group and which meet
	 * the specified filter criteria.
	 * 
	 * @return
	 *      Vector - Vector of Store objects that are in the group.  The
	 *               vector may be empty but never null.
	 * @param groupName java.lang.String
	 * @param dcNameFilter Pass null or empty string for the filters if there isn't a filter.
	 * @param storeNumberFilter Pass null or empty string for the filters if there isn't a filter.
	 * @param storeNameFilter Pass null or empty string for the filters if there isn't a filter.
	 * @param cityFilter Pass null or empty string for the filters if there isn't a filter.
	 * @param stateCodeFilter Pass null or empty string for the filters if there isn't a filter.
	 * @exception java.lang.Exception
	 */
	public Vector getStoresInGroup(String groupName,
								   String dcNameFilter,
								   String storeNumberFilter,
								   String storeNameFilter,
								   String cityFilter,
								   String stateCodeFilter)
			throws Exception
	{
		String  tDCNameFilter = null;
		Store   filter = null;
		
		if (dcNameFilter.length() > 0) {
			tDCNameFilter = dcNameFilter;
		}
		
		if ((storeNumberFilter.length() > 0) ||
			(storeNameFilter.length() > 0) ||
			(cityFilter.length() > 0) ||
			(stateCodeFilter.length() > 0)) {
				
			filter = new Store();
			filter.setStoreNumber(storeNumberFilter);
			filter.setName(storeNameFilter);
			filter.setCity(cityFilter);
			filter.setStateCode(stateCodeFilter);
		}
		
		return(getStoresInGroup(groupName, dcNameFilter, filter));
	}
	/**
	 * Returns the URL of the "terms" page.
	 * 
	 * @return java.lang.String
	 * @exception java.lang.Exception
	 */
	public String getTermsURL()
			throws Exception
	{
		return(svharborConstants.getSVHarborTermsURL());
	}
	// This function is used for performance testing.
	private static String getTimeStamp()
	{
		final Calendar      currDateTime = new GregorianCalendar();
		String ret = (currDateTime.get(Calendar.HOUR_OF_DAY) < 10 ? "0" : "") + currDateTime.get(Calendar.HOUR_OF_DAY) + ":" + (currDateTime.get(Calendar.MINUTE) < 10 ? "0" : "") + currDateTime.get(Calendar.MINUTE) + ":" + (currDateTime.get(Calendar.SECOND) < 10 ? "0" : "") + currDateTime.get(Calendar.SECOND) + ":" + (currDateTime.get(Calendar.MILLISECOND) / 10  < 10 ? "0" : "") + currDateTime.get(Calendar.MILLISECOND) / 10 + " ";
		return(ret);
	}
	/**
	 * Counts how many users in the store have access to User Admin.
	 * 
	 * @return
	 *      int - Number of users with access.
	 * @param storeNumber java.lang.String
	 * @exception java.lang.Exception
	 */
	public int getUserAdminCount(String storeNumber)
			throws Exception
	{
		final String tUserAdminUsersDN = "cn=UserAdminUsers,ou=UserAdmin,ou=Applications," + baseDN;
		String	tUserDN;
        int		tCount = 0;

		Vector userDNList = getUserDNsOfStore(storeNumber);

		final int vectorSize = userDNList.size();
		for (int x = 0; x < vectorSize; x++) {
			tUserDN = (String) userDNList.elementAt(x);

			// Check if the user has access to User Admin.
			if (ldapDir.existAttributeInObject(tUserAdminUsersDN,
											   "uniquemember",
											   tUserDN)) {
				tCount++;
			}
		}

		return tCount;
	}
	/**
	 * Gets a list of users at the specified store that have
	 * access to the User Admin application.
	 * 
	 * @return
	 *      Vector - Vector of UserName objects.
	 *               The vector may be empty but never null.
	 * @param storeNumber java.lang.String
	 * @exception java.lang.Exception
	 */
	public Vector getUserAdminUsersOfStore(String storeNumber)
			throws Exception
	{
		final String tUserAdminUsersDN = "cn=UserAdminUsers,ou=UserAdmin,ou=Applications," + baseDN;
		Vector      ret = new Vector();
		Hashtable   hashT2;
		UserName	user;
		String		tUserDN;

		Vector userDNList = getUserDNsOfStore(storeNumber);

		final int vectorSize = userDNList.size();
		for (int x = 0; x < vectorSize; x++)
		{
			tUserDN = (String) userDNList.elementAt(x);

			// Check if the user has access to User Admin.
			if ((ldapDir.existAttributeInObject(tUserAdminUsersDN, "uniquemember", tUserDN)) &&
				((hashT2 = ldapDir.read(tUserDN, new String[] {"uid","givenName","initials","sn","cn"})) != null))
			{
				user = new UserName(getAttributeValue(hashT2, "uid"),
									getAttributeValue(hashT2, "givenName"),
									getAttributeValue(hashT2, "initials"),
									getAttributeValue(hashT2, "sn"),
									getAttributeValue(hashT2, "cn"));
				ret.addElement(user);
			}
		}

		ret.trimToSize();
		VectorFuncs.sort(ret);

		return ret;
	}
	/**
	 * Counts how many users are in the specified store.
	 * 
	 * @return
	 *      int - Number of users in the specified store.
	 * @param storeNumber java.lang.String
	 * @exception java.lang.Exception
	 */
	public int getUserCountForStore(String storeNumber)
			throws Exception
	{
		Vector userDNList = getUserDNsOfStore(storeNumber);

		return userDNList.size();
	}
	/**
	 * Gets details about the specified user.
	 * 
	 * @return
	 *      UserDetail - An object containing the user details.
	 * @param loginID java.lang.String
	 * @exception java.lang.Exception
	 */
	public UserDetail getUserDetail(String loginID)
			throws Exception
	{
		return getUserDetail(loginID, 0);
	}
	/**
	 * Gets details about the specified user.
	 *
	 * @return UserDetail - Returns the object, throws an exception if
	 *                      the user doesn't exist.
	 * @param loginID java.lang.String
	 * @param emailAddressMode int
	 *		0 = Get the user's email address from LDAP.
	 *		1 = First look in Domino for the user's address, if
	 *          there isn't one there, get it from LDAP.
	 * @exception java.lang.Exception
	 */
	public UserDetail getUserDetail(String loginID,
									int emailAddressMode)
			throws Exception
	{
		final String    tUserDN = "uid=" + loginID + ",ou=People," + baseDN;
		UserDetail      ret = null;
		Hashtable       hashT;
	
		// Read all the fields from the person object.
		//System.out.println("DN " + tUserDN);
		if ((hashT = ldapDir.read(tUserDN, null)) != null) {
			String tEmailAddress = "";
			String tEmailType;
	
			if (emailAddressMode == 0) {
				tEmailAddress = getAttributeValue(hashT, "mail");
			}
			else if (emailAddressMode == 1) {
				tEmailAddress = getEmailAddressFromDomino(loginID);
	
				if (tEmailAddress.length() == 0) {
					tEmailAddress = getAttributeValue(hashT, "mail");
				}
			}
			else {
				String tMsg = "Error in getUserDetail().  Invalid emailAddressMode: \"" + emailAddressMode + "\".";
				throw new Exception(tMsg);
			}
	
			// Determine what type of Email address the user has.
			if (tEmailAddress.length() == 0) {
				tEmailType = "None";
			}
			else if (tEmailAddress.toLowerCase().endsWith(getMailSuffix().toLowerCase())) {
				tEmailType = "SVHarbor";
			}
			else {
				tEmailType = "Other";
			}
	
			ret = new UserDetail(getAttributeValue(hashT, "uid"),
								 getAttributeValue(hashT, "givenName"),
								 getAttributeValue(hashT, "sn"),
								 getAttributeValue(hashT, "initials"),
								 getAttributeValue(hashT, "cn"),
								 getAttributeValue(hashT, "roomNumber"),
								 getAttributeValue(hashT, "destinationIndicator"),
								 getAttributeValue(hashT, "title"),
								 getAttributeValue(hashT, "telephoneNumber"),
								 tEmailType,
								 tEmailAddress);
		}
		else {
			String tMsg = "Error in getUserDetail().  User: " + loginID + " doesn't exist in the LDAP directory.";
			throw new Exception(tMsg);
		}
	
		return ret;
	}
	/**
	 * Gets a list of users in the specified admin group.
	 * 
	 * @return
	 *      Vector - Vector of UserName objects.
	 *               The vector may be empty but never null.
	 * @param adminGroup java.lang.String
	 * @exception java.lang.Exception
	 */
	public Vector getUsersOfAdminGroup(String adminGroup)
			throws Exception
	{
		final String tUserBaseDN = "ou=People," + baseDN;
		final Name   tUserBaseDNName = ldapDir.convertToName(tUserBaseDN);
		Vector      ret = new Vector();
		UserName    userName;
		Hashtable   hashT;
		Hashtable   hashT2;
		Object[]    attrib_value;
		String      tDN;
		Name        tDNUser;

		tDN = "cn=" + adminGroup + ",ou=AdminGroups,ou=Groups," + baseDN;

		// Retrieve the AdminGroup object.
		if (((hashT = ldapDir.read(tDN, new String[] {"uniquemember"})) != null) &&
			((attrib_value = (Object[]) hashT.get("uniquemember")) != null)) {

			// Look at each member and pull out the users.
			for (int i = 0; i < attrib_value.length; i++) {	
				tDN = attrib_value[i].toString();
				tDNUser = ldapDir.convertToName(tDN);

				// Ignore everything except users.
				if (tDNUser.startsWith(tUserBaseDNName)) {
					// Read the fields from the object.
					if ((hashT2 = ldapDir.read(tDN, new String[] {"uid","givenName","initials","sn","cn"})) != null) {
						userName = new UserName(getAttributeValue(hashT2, "uid"),
												getAttributeValue(hashT2, "givenName"),
												getAttributeValue(hashT2, "initials"),
												getAttributeValue(hashT2, "sn"),
												getAttributeValue(hashT2, "cn"));
						
						ret.addElement(userName);
					}
				}
			}
		}

		ret.trimToSize();
		UserName.sortByLastFirstMiddle(ret);
		
		return(ret);
	}
	/**
	 * Gets a list of users that have access to the specified application role.
	 * 
 	 * @return Vector - Returns a vector of UserName objects.  The
 	 * vector may be empty but never null.
 	 * @param appName java.lang.String
 	 * @param roleName java.lang.String
 	 * @param userIdFilter java.lang.String
 	 * @param userNameFilter java.lang.String
	 * @exception java.lang.Exception
	 */
	public Vector getUsersOfAppRole(java.lang.String appName,
									java.lang.String roleName, String userIdFilter, String userNameFilter)
			throws Exception
	{
		UserName    user;
		Vector v = getUsersOfAppRole(appName,roleName);
		String userId = "", name = "";
		Vector ret = new Vector();
		if  (userIdFilter == null)
		{
			userIdFilter = "";
		}
		if  (userNameFilter == null)
		{
			userNameFilter = "";
		}
			
		userIdFilter = userIdFilter.toUpperCase();
		userNameFilter = userNameFilter.toUpperCase();
		for (int i=0;i<v.size();++i)
		{
			user = (UserName) v.elementAt(i);
			
			userId = user.getLoginID().toUpperCase();
			
			name   = user.getFullName().toUpperCase();
			
			if  (userIdFilter.length() == 0 && userNameFilter.length() == 0)
			{
				ret.addElement(user);	
			}else
			{
				if  (userIdFilter.length() > 0 && userId.startsWith(userIdFilter))
				{
					ret.addElement(user);
				}
				if  (userNameFilter.length() > 0 && name.startsWith(userNameFilter))
				{
					ret.addElement(user);
				}
			}		
		}		
		
		VectorFuncs.sort(ret);		
		return ret;
		
	}
	/**
	 * Gets a list of users that have access to the specified application role.
	 * 
 	 * @return Vector - Returns a vector of UserName objects.  The
 	 * vector may be empty but never null.
 	 * @param appName java.lang.String
 	 * @param roleName java.lang.String
	 * @exception java.lang.Exception
	 */
	public Vector getUsersOfAppRole(java.lang.String appName,
									java.lang.String roleName)
			throws Exception
	{
		final String tUserBaseDN = "ou=People," + baseDN;
		final Name  tUserBaseDNName = ldapDir.convertToName(tUserBaseDN);
		Vector      ret = new Vector();
		Hashtable   hashT;
		Hashtable   hashT2;
		UserName    user;
		Object[]    attrib_value;
		String      tDN;
		Name        tDNName;

		tDN = "cn=" + roleName + ",ou=" + appName + ",ou=Applications," + baseDN;
		
		if (((hashT = ldapDir.read(tDN, new String[] {"uniquemember"})) != null) &&
			((attrib_value = (Object[]) hashT.get("uniquemember")) != null)) {

			// Look at each member and pull out only the users.
			for (int i = 0; i < attrib_value.length; i++) {	
				tDN = attrib_value[i].toString();
				tDNName = ldapDir.convertToName(tDN);

				// Ignore everything except users.
				if (tDNName.startsWith(tUserBaseDNName)) {
					if ((hashT2 = ldapDir.read(tDN, new String[] {"uid","givenName","initials","sn","cn"})) != null) {
						user = new UserName(getAttributeValue(hashT2, "uid"),
											getAttributeValue(hashT2, "givenName"),
											getAttributeValue(hashT2, "initials"),
											getAttributeValue(hashT2, "sn"),
											getAttributeValue(hashT2, "cn"));

						ret.addElement(user);
					}
				}
			}
		}
	   
		ret.trimToSize();
		
		return(ret);
	}
	/**
	 * Gets a list of users that are assigned to the specified broker.
	 * 
	 * @return
	 *      Vector - Vector of UserName objects that are in the broker.
	 *               The vector may be empty but never null.
	 * @param brokerNumber java.lang.String
	 * @exception java.lang.Exception
	 */
	public Vector getUsersOfBroker(String brokerNumber)
			throws Exception
	{
		Vector      ret = new Vector();
		Hashtable   hashT2;
		UserName	user;
		String		tUserDN;

		Vector userDNList = getUserDNsOfBroker(brokerNumber);

		final int vectorSize = userDNList.size();
		for (int x = 0; x < vectorSize; x++) {
			tUserDN = (String) userDNList.elementAt(x);

			// Read all the fields from the object.
			if ((hashT2 = ldapDir.read(tUserDN, new String[] {"uid","givenName","initials","sn","cn"})) != null) {
				user = new UserName(getAttributeValue(hashT2, "uid"),
									getAttributeValue(hashT2, "givenName"),
									getAttributeValue(hashT2, "initials"),
									getAttributeValue(hashT2, "sn"),
									getAttributeValue(hashT2, "cn"));
				ret.addElement(user);
			}
		}

		ret.trimToSize();
		VectorFuncs.sort(ret);

		return ret;
	}
	/**
	 * Gets a list of users that are in the specified store.
	 * 
	 * @return
	 *      Vector - Vector of UserName objects that are in the store.
	 *               The vector may be empty but never null.
	 * @param storeNumber java.lang.String
	 * @exception java.lang.Exception
	 */
	public Vector getUsersOfStore(String storeNumber)
			throws Exception
	{
		Vector      ret = new Vector();
		Hashtable   hashT2;
		UserName	user;
		String		tUserDN;

		Vector userDNList = getUserDNsOfStore(storeNumber);

		final int vectorSize = userDNList.size();
		for (int x = 0; x < vectorSize; x++) {
			tUserDN = (String) userDNList.elementAt(x);

			// Read all the fields from the object.
			if ((hashT2 = ldapDir.read(tUserDN, new String[] {"uid","givenName","initials","sn","cn"})) != null) {
				user = new UserName(getAttributeValue(hashT2, "uid"),
									getAttributeValue(hashT2, "givenName"),
									getAttributeValue(hashT2, "initials"),
									getAttributeValue(hashT2, "sn"),
									getAttributeValue(hashT2, "cn"));
				ret.addElement(user);
			}
		}

		ret.trimToSize();
		VectorFuncs.sort(ret);

		return ret;
	}
	/**
	 * Gets a list of users that are assigned to the specified vendor.
	 * 
	 * @return
	 *      Vector - Vector of UserName objects that are in the vendor.
	 *               The vector may be empty but never null.
	 * @param vendorID java.lang.String
	 * @exception java.lang.Exception
	 */

	// Jan 26, 2003 - Modified for Vendor Conversion		

	public Vector getUsersOfVendor(String vendorID)
			throws Exception
	{
		String 			originalVendorNumber = "";
		originalVendorNumber = vendorID;		
		vendorID = convertToInternalVendorNbr(vendorID);

		Vector      ret = new Vector();
		Hashtable   hashT2;
		UserName	user;
		String		tUserDN;

		Vector userDNList = getUserDNsOfVendor(vendorID);

		final int vectorSize = userDNList.size();
		for (int x = 0; x < vectorSize; x++) {
			tUserDN = (String) userDNList.elementAt(x);

			// Read all the fields from the object.
			if ((hashT2 = ldapDir.read(tUserDN, new String[] {"uid","givenName","initials","sn","cn"})) != null) {
				user = new UserName(getAttributeValue(hashT2, "uid"),
									getAttributeValue(hashT2, "givenName"),
									getAttributeValue(hashT2, "initials"),
									getAttributeValue(hashT2, "sn"),
									getAttributeValue(hashT2, "cn"));
				ret.addElement(user);
			}
		}

		ret.trimToSize();
		VectorFuncs.sort(ret);

		return ret;
	}
	/**
	 * Gets details about the specified Vendor.
	 * 
 	 * @return Vendor
 	 * @param vendorID java.lang.String
	 * @exception Exception
	 */
	// Jan 26, 2003 - Modified for Vendor Conversion		
	public Vendor getVendorDetail(String vendorID)
		throws Exception
	{
		String 			originalVendorNumber = "";
		originalVendorNumber = vendorID;		
		vendorID = convertToInternalVendorNbr(vendorID);

		final String	tDN = "uid=" + vendorID + ",ou=Vendors," + baseDN;
		Vendor			ret;
		Hashtable		hashT;

		// Read all the fields from the person object.
		if ((hashT = ldapDir.read(tDN, null)) != null) {
			String vendorOut = "";
			vendorOut = getAttributeValue(hashT, "uid");
			vendorOut = convertToExternalVendorNbr(vendorOut);
			ret = new Vendor(vendorOut, // vendorID
							 getAttributeValue(hashT, "sn"), // vendorName
							 getAttributeValue(hashT, "mail"), // emailAddress
							 getAttributeValue(hashT, "street"), // address
							 getAttributeValue(hashT, "homePostalAddress"), // city
							 getAttributeValue(hashT, "st"), // stateCode
							 getAttributeValue(hashT, "postalCode"), // zipCode
							 getAttributeValue(hashT, "telephoneNumber"), // phoneNumber
							 getAttributeValue(hashT, "facsimileTelephoneNumber"), // faxNumber
							 getAttributeValue(hashT, "manager"), // contact  
							 getAttributeValue(hashT, "businessCategory") // vendor type  
							 ); 
		}
		else {
			String tMsg = "Error in getVendorDetail().  Vendor: " + originalVendorNumber + " doesn't exist in the LDAP directory.";
			throw new Exception(tMsg);
		}

		return ret;
	}
	/**
	 * Gets a list of all the vendors.
	 * 
	 * @return
	 *      Vector - Vector of Vendor objects.
	 *               The vector may be empty but never null.
	 * @param vendorNumberFilter java.lang.String
	 * @param vendorNameFilter java.lang.String
	 * @exception java.lang.Exception
	 */
	// Jan 26, 2003 - Modified for Vendor Conversion		
	public Vector getVendorList(String vendorNumberFilter, String vendorNameFilter)
			throws Exception
	{
		if  (vendorNumberFilter != null)
		{
			vendorNumberFilter = "V" + vendorNumberFilter;
		}	
		Vector          ret = new Vector();
		Vendor			vendor;
		Vector          vector1, vector2;
		Hashtable       hashT1;

		final String tDN = "ou=Vendors," + baseDN;
		final String tFilter = "(&(uid=" + (vendorNumberFilter != null ?
											vendorNumberFilter: "") + "*)" +
							   "(sn=" + (vendorNameFilter != null ?
								   		 vendorNameFilter : "") + "*))";

		// Get a list of all the vendors that match the filter.
		if ((vector1 = ldapDir.search(tDN, tFilter, null, true)) != null) {
			final int vector1Size = vector1.size();
			for (int x1 = 0; x1 < vector1Size; x1++) {
				vector2 = (Vector) vector1.elementAt(x1);
				hashT1 = (Hashtable) vector2.elementAt(1);
				
				String vendorOut = getAttributeValue(hashT1, "uid");
				vendorOut = convertToExternalVendorNbr(vendorOut);

				vendor = new Vendor(vendorOut,  // vendorID
									getAttributeValue(hashT1, "sn"), // vendorName
									getAttributeValue(hashT1, "mail"), // emailAddress
								 	getAttributeValue(hashT1, "street"), // address
								 	getAttributeValue(hashT1, "homePostalAddress"), // city
								 	getAttributeValue(hashT1, "st"), // stateCode
								 	getAttributeValue(hashT1, "postalCode"), // zipCode
								 	getAttributeValue(hashT1, "telephoneNumber"), // phoneNumber
									getAttributeValue(hashT1, "facsimileTelephoneNumber"), // faxNumber
									getAttributeValue(hashT1, "manager"), // contact  
									getAttributeValue(hashT1, "businessCategory") // vendor type  
							 ); 

				ret.addElement(vendor);
			}
		}

		ret.trimToSize();

		if (vendorNumberFilter != null)
		{
			Vendor.sortByVendorNumber(ret);
		}
		else
		{
			Vendor.sortByVendorName(ret);
		}

		return ret;
	}
	/**
	 * Gets a list of all the vendors.
	 * 
	 * @return
	 *      Vector - Vector of Vendor objects.
	 *               The vector may be empty but never null.
	 * @param vendorNameFilter java.lang.String
	 * @exception java.lang.Exception
	 */
	public Vector getVendorList(String vendorNameFilter)
			throws Exception
	{
		Vector ret = getVendorList(null, vendorNameFilter);

		return ret;
	}
	/**
	 * Gets a list of vendors that are assigned to the specified broker.
	 * 
	 * @return
	 *      Vector - Vector of Vendor objects that are in the group.  The
	 *               vector may be empty but never null.
	 * @param brokerNumber java.lang.String
	 * @exception java.lang.Exception
	 */
	// Jan 26, 2003 - Modified for Vendor Conversion		
	public Vector getVendorsOfBroker(String brokerNumber)
			throws Exception
	{
		final String tVendorsBaseDN = "ou=Vendors," + baseDN;
		final Name  tVendorsBaseDNName = ldapDir.convertToName(tVendorsBaseDN);
		Vector      ret = new Vector();
		Hashtable   hashT;
		Hashtable   hashT2;
		Vendor      vendor;
		String		tDN;
		Name        tDNName;
		Object[]    attrib_value;

		final String tBrokerDN = "cn=" + brokerNumber + ",ou=Brokers," + baseDN;

		if (((hashT = ldapDir.read(tBrokerDN, new String[] {"uniquemember"})) != null) &&
			((attrib_value = (Object[]) hashT.get("uniquemember")) != null)) {

			// Look at each member and pull out only the vendors.
			for (int i = 0; i < attrib_value.length; i++) {	
				tDN = attrib_value[i].toString();
				tDNName = ldapDir.convertToName(tDN);

				// Ignore everything except vendors.
				if (tDNName.startsWith(tVendorsBaseDNName)) {
					// Read all the fields from the object.
					if ((hashT2 = ldapDir.read(tDN, null)) != null) {
						String vendorOut = getAttributeValue(hashT2, "uid");
						vendorOut = convertToExternalVendorNbr(vendorOut);
						
						vendor = new Vendor(vendorOut, // vendorID
											getAttributeValue(hashT2, "sn"), // vendorName
											getAttributeValue(hashT2, "mail"), // emailAddress
										 	getAttributeValue(hashT2, "street"), // address
										 	getAttributeValue(hashT2, "homePostalAddress"), // city
										 	getAttributeValue(hashT2, "st"), // stateCode
										 	getAttributeValue(hashT2, "postalCode"), // zipCode
										 	getAttributeValue(hashT2, "telephoneNumber"), // phoneNumber
											getAttributeValue(hashT2, "facsimileTelephoneNumber"), // faxNumber
											getAttributeValue(hashT2, "manager"), // contact  
											getAttributeValue(hashT2, "businessCategory") // vendorType  
										);	
						ret.addElement(vendor);
					}
				}
			}
		}


		ret.trimToSize();

		Vendor.sortByVendorName(ret);

		return ret;
	}
	/**
	 * Gets the Vendors that the specified userID has access to.
	 * 
 	 * @return Vector - Returns a Vector of Vendor objects.  The vector
 	 * may be empty but never null.
 	 * @param userID java.lang.String
	 * @exception java.lang.Exception
	 */
	// Jan 26, 2003 - Modified for Vendor Conversion		
	public Vector getVendorsOfBrokerUser(String userID)
		throws Exception
	{
		return (getVendorsOfBrokerUser(userID,null)); 
	}	
	
	/**
	 * Gets the Vendors that the specified userID & application have access to.
	 * 
 	 * @return Vector - Returns a Vector of Vendor objects.  The vector
 	 * may be empty but never null.
 	 * @param userID java.lang.String
 	 * @param appName java.lang.String
	 * @exception java.lang.Exception
	 */
	// Jan 26, 2003 - Modified for Vendor Conversion		
	public Vector getVendorsOfBrokerUser(String userID, String appName)
		throws Exception
	{
		
		final String 	tVendorsBaseDN = "ou=Vendors," + baseDN;
		final Name  	tVendorsBaseDNName = ldapDir.convertToName(tVendorsBaseDN);
		final String    tUserDN = "uid=" + userID + ",ou=People," + baseDN;
		Hashtable       hashT;
		Hashtable		hashT2;
		Object[]    	attrib_value;
		String			tDN;
		Name			tDNName;
		Vendor			vendor;
		Vector			ret = new Vector();
		String    		tAppDN = "uid=" + appName + ",ou=ApplicationList,ou=Applications," + baseDN;
		String     		tVendorDN = "";
		String vendorOut, tempStr = "";
		boolean checkApplication = false;
		
		if  (appName != null &&  appName.trim().length() > 0)
		{
			checkApplication = true;
		}

// get authorized vendors from vendor groups

		Vector groupVector = null;
		Vector vendorVector = null;
		VendorGroup vendorGroup = null;
		
		groupVector = getVendorGroupsForUser(userID);

		// iterate through vendor group collection
		
		for (int i=0;i< groupVector.size(); ++i)
		{
			vendorGroup = (VendorGroup) groupVector.elementAt(i);
			vendorVector = getVendorsInVendorGroup(vendorGroup.getGroupName());
			
			int j = 0;
			// iterate through vendor collection
			for (j = 0; j<vendorVector.size();++j)
			{
				vendor = (Vendor) vendorVector.elementAt(j);

				if  (checkApplication)
				{
					tempStr = vendor.getVendorID();
					tempStr = convertToInternalVendorNbr(tempStr);
					tVendorDN = "cn=" + tempStr + ",ou=Vendors," + baseDN;
					if (ldapDir.existAttributeInObject(tVendorDN, "uniqueMember",tAppDN)) 
					{
						ret.addElement(vendor);
					}
				}else
				{	
					ret.addElement(vendor);
				}	
			}	
		}

// end 

// 05/21/2004 - Changes to limit vendor access to brokers
// Josh commented out the following code on 05/25/04 per Kris/Amy of Supplier Central


		if (((hashT = ldapDir.read(tUserDN, new String[] {"destinationIndicator", "roomNumber"})) != null) 
		&&   (getAttributeValue(hashT, "destinationIndicator").equalsIgnoreCase("Broker"))
		&&   (ret.size() <= 0)
		) {

			final String tBrokerDN = "cn=" + getAttributeValue(hashT, "roomNumber") + ",ou=Brokers," + baseDN;

			if (((hashT = ldapDir.read(tBrokerDN, new String[] {"uniquemember"})) != null) &&
				((attrib_value = (Object[]) hashT.get("uniquemember")) != null)) {

				// Look at each member and pull out only the vendors.
				for (int i = 0; i < attrib_value.length; i++) {	
					tDN = attrib_value[i].toString();
					tDNName = ldapDir.convertToName(tDN);

					// Ignore everything except vendors.
					if (tDNName.startsWith(tVendorsBaseDNName)) {
						// Read all the fields from the object.
						if ((hashT2 = ldapDir.read(tDN, null)) != null) {
							// Build the Vendor object.
							
							vendorOut = getAttributeValue(hashT2, "uid");
							tempStr   = vendorOut;
							vendorOut = convertToExternalVendorNbr(vendorOut);
							vendor = new Vendor(vendorOut, // vendorID
												getAttributeValue(hashT2, "sn"), // vendorName
							 					getAttributeValue(hashT2, "mail"), // emailAddress
												getAttributeValue(hashT2, "street"), // address
												getAttributeValue(hashT2, "homePostalAddress"), // city
												getAttributeValue(hashT2, "st"), // stateCode
												getAttributeValue(hashT2, "postalCode"), // zipCode
												getAttributeValue(hashT2, "telephoneNumber"), // phoneNumber
												getAttributeValue(hashT2, "facsimileTelephoneNumber"), // faxNumber
												getAttributeValue(hashT2, "manager")); // contact  

							if  (checkApplication)
							{
								tVendorDN = "cn=" + tempStr + ",ou=Vendors," + baseDN;
								if (ldapDir.existAttributeInObject(tVendorDN, "uniqueMember",tAppDN)) 
								{
									ret.addElement(vendor);
								}
							}else
							{	
								ret.addElement(vendor);
							}	
						}
					}
				}
			}
		}

		//ret.trimToSize();
		VectorFuncs.sort(ret);

		return ret;
	}
	/**
	 * Gets the Vendors that the specified userID has access to.
	 * 
 	 * @return Vector - Returns a Vector of Vendor objects.  The vector
 	 * may be empty but never null.
 	 * @param userID java.lang.String
	 * @exception java.lang.Exception
	 */
	// Jan 26, 2003 - Modified for Vendor Conversion		
	public Vector getVendorsOfVendorUser(String userID)
		throws Exception
	{
		return (getVendorsOfVendorUser(userID, null));
	}	
	/**
	 * Gets the Vendors that the specified userID & application have access to.
	 * 
 	 * @return Vector - Returns a Vector of Vendor objects.  The vector
 	 * may be empty but never null.
 	 * @param userID java.lang.String
	 * @exception java.lang.Exception
	 */
	// Jan 26, 2003 - Modified for Vendor Conversion		
	public Vector getVendorsOfVendorUser(String userID, String appName)
		throws Exception
	{
		final String 	tVendorsBaseDN = "ou=Vendors," + baseDN;
		final Name  	tVendorsBaseDNName = ldapDir.convertToName(tVendorsBaseDN);
		final String    tUserDN = "uid=" + userID + ",ou=People," + baseDN;
		Hashtable       hashT;
		Hashtable		hashT2;
		Object[]    	attrib_value;
		String			tDN;
		Name			tDNName;
		Vendor			vendor;
		Vector			ret = new Vector();
		String    		tAppDN = "uid=" + appName + ",ou=ApplicationList,ou=Applications," + baseDN;
		String     		tVendorDN = "";
		String vendorOut, tempStr = "";
		boolean checkApplication = false;
		
		if  (appName != null &&  appName.trim().length() > 0)
		{
			checkApplication = true;
			//System.out.println("checkapp = " + checkApplication);
		}

		if (((hashT = ldapDir.read(tUserDN, new String[] {"destinationIndicator", "roomNumber"})) != null) &&
			(getAttributeValue(hashT, "destinationIndicator").equalsIgnoreCase("Vendor"))) {
//		if ((hashT = ldapDir.read(tUserDN, new String[] {"destinationIndicator", "roomNumber"})) != null)
//		{ 
//			System.out.println("User Type : " + getAttributeValue(hashT, "destinationIndicator"));
				
			vendor = getVendorDetail(getAttributeValue(hashT, "roomNumber"));

			if  (checkApplication)
			{
				tempStr = vendor.getVendorID();
				//System.out.println("Vendor Nbr : " + tempStr);
				tempStr = convertToInternalVendorNbr(tempStr);
				tVendorDN = "cn=" + tempStr + ",ou=Vendors," + baseDN;
				if (ldapDir.existAttributeInObject(tVendorDN, "uniqueMember",tAppDN)) 
				{
					ret.addElement(vendor);
				}
			}else
			{	
				ret.addElement(vendor);
			}	
		}

// get authorized vendors from vendor groups

		Vector groupVector = null;
		Vector vendorVector = null;
		VendorGroup vendorGroup = null;
		
		groupVector = getVendorGroupsForUser(userID);

		// iterate through vendor group collection
		
		for (int i=0;i< groupVector.size(); ++i)
		{
			vendorGroup = (VendorGroup) groupVector.elementAt(i);
			//System.out.println("Vendor group name : " + vendorGroup.getGroupName());
			vendorVector = getVendorsInVendorGroup(vendorGroup.getGroupName());
			int j = 0;
			// iterate through vendor collection
			for (j = 0; j<vendorVector.size();++j)
			{
				vendor = (Vendor) vendorVector.elementAt(j);
				if  (checkApplication)
				{
					tempStr = vendor.getVendorID();
					tempStr = convertToInternalVendorNbr(tempStr);
					tVendorDN = "cn=" + tempStr + ",ou=Vendors," + baseDN;
					if (ldapDir.existAttributeInObject(tVendorDN, "uniqueMember",tAppDN)) 
					{
						ret.addElement(vendor);
					}
				}else
				{	
					ret.addElement(vendor);
				}	
			}	
		}

// end 
		ret.trimToSize();
//		VectorFuncs.sort(ret);
		Vendor.sortByVendorNumber(ret);
		return ret;
	}

	/**
	 * Returns the version number of this class.
	 * 
	 * @return java.lang.String
	 */
	public String getVersionNumber()
	{
		return("45");
	}
	/**
	 * Initialize the object.  This function initializes the object
	 * and establishes a connection to the LDAP database.
	 * 
	 * One of the initialize() functions MUST be called before
	 * any other function in this class is called.
	 * 
	 * This function will look up the passed appName in the
	 * object's properties file to get the userid and password
	 * for connecting to ldap.
	 * 
	 * @return void
	 * @param appName java.lang.String
	 * @exception java.lang.Exception
	 */
	public void initialize(String appName)
			throws Exception
	{
		if (ldapDir != null) {
			return;
		}

		svharborConstants = CbkLdapConstants.getInstance();

		ldapDir = new LDAPDirectory();

		try {
			// Establish a connection with the server.
			ldapDir.connect(svharborConstants.getLDAPHost(), svharborConstants.getLDAPPort(), svharborConstants.getLDAPVersion(), svharborConstants.getLDAPUserName(appName), svharborConstants.getLDAPPassword(appName));
		}
		catch (Exception e) {
			ldapDir = null;
			throw e;    // Rethrow the exception.
		}

		domino = new DominoServletFuncs(svharborConstants.getDominoServletUserName(), svharborConstants.getDominoServletPassword(), svharborConstants.getDominoServletBaseURL(), svharborConstants.IsDominoServletsEnabled());
		eventLog = new EventLog(svharborConstants.getLDAPLogDir(),
								"<unknown>",
								"<unknown>");

		// Initialize the Domino Access Properties object (if necessary).
		if ((svharborConstants.getDominoServerName() != null) &&
			(svharborConstants.getDominoUserName() != null) &&
			(svharborConstants.getDominoUserPassword() != null) &&
			(svharborConstants.getDominoSVHONABPath() != null) &&
			(svharborConstants.getDominoCacheMaxAge() != null)) {

			dominoAccessProperties = new java.util.Properties();
			// Don't use setProperty() instead of put() here, it's not supported by Microsoft.
			dominoAccessProperties.put("server", svharborConstants.getDominoServerName());
			dominoAccessProperties.put("remoteUser", svharborConstants.getDominoUserName());
			dominoAccessProperties.put("remoteUserPwd", svharborConstants.getDominoUserPassword());
			dominoAccessProperties.put("nabPath", svharborConstants.getDominoSVHONABPath());
			dominoAccessProperties.put("maxAge", svharborConstants.getDominoCacheMaxAge());
		}
		else {
			dominoAccessProperties = null;
		}

		baseDN = svharborConstants.getLDAPBaseDN();
	}
	/**
	 * Initialize the object.  This function initializes the object
	 * and establishes a connection to the LDAP database.
	 * 
	 * One of the initialize() functions MUST be called before
	 * any other function in this class is called.
	 * 
	 * This function will look up the passed appName in the
	 * object's properties file to get the userid and password
	 * for connecting to ldap.
	 * 
	 * @return void
	 * @param appName java.lang.String
	 * @param appFullName java.lang.String
	 * @param appUserLoginID java.lang.String
	 * @exception java.lang.Exception
	 */
	public void initialize(String appName,
						   String appFullName,
						   String appUserLoginID)
			throws Exception
	{
		initialize(appName);

		eventLog.setAppName(appFullName);
		eventLog.setAppUserLoginID(appUserLoginID);
	}
	/**
	 * This is strictly for testing the class during development.
	 */
public static void main(String[] arguments) throws Exception {
    String tAppUserName = "howmr0";
    String storeNumber = "0988888";
    String name = "yhp6y2l's Test Store #2";
    String address = "111 Any Street";
    String city = "YourTown";
    String state = "MN";
    String zip = "55416-2222";
    String contact = "Bob Smith";
    String phone = "(952) 828-4303";
    String logo = "logo.gif";
    String regionName = "Northern Region";
    String dcName = "Minneapolis DC";
    SVHarborLDAPFuncs obj = new SVHarborLDAPFuncs();
    obj.initialize("SupAdmin");
//    obj.initialize("SupAdmin", "TestApp", "hojrk0");
//    Vector testvect;

    //System.out.println("Version number is: " + obj.getVersionNumber());

    /*
    System.out.println("Email address is: " + obj.getEmailAddressFromDomino("howmr0"));
    System.out.println("LoginID is: " + obj.getLoginIDForEmailAddress("bill.m.rossman@supervalu.com"));
    System.out.println("LoginID is: " + obj.getLoginIDForEmailAddress("Kay.Tislar@test.svharbor.com"));
    */

    //        obj.ldapDir.renameObject("cn=,ou=SharedGroups,ou=SVHarbor,o=supervalu.com", "cn=AAATest3,ou=SharedGroups,ou=SVHarbor,o=supervalu.com");

    /*
    String tLoginID = "Admin0988888";
    String newPassword = obj.resetPassword(tLoginID);
    System.out.println("New password is: " + newPassword);
    if (obj.checkPassword(tLoginID, newPassword)) {
    	System.out.println("Password check #1 is OK");
    }
    else {
    	System.out.println("Password check #1 is NOT OK");
    }
    if (obj.checkPassword(tLoginID, newPassword + "XXX")) {
    	System.out.println("Password check #2 is OK");
    }
    else {
    	System.out.println("Password check #2 is NOT OK");
    }
     */

	/*
	String tStoreNumber = "0989901";
	String newPassword = obj.setStorePassword(tStoreNumber);
	System.out.println("New store password is: " + newPassword);
	*/

    /*
    String tUserID = "hojls1";
    String tStoreNumber = "0980001";
    if (obj.checkStoreAccess(tUserID, tStoreNumber)) {
    	System.out.println("Password check #2 is OK");
    }
    else {
    	System.out.println("Password check #2 is NOT OK");
    }
     */

    /*
    System.out.println("Exit URL: " + obj.getExitURL());
    System.out.println("Logout URL: " + obj.getLogoutURL());
    System.out.println("Privacy URL: " + obj.getPrivacyURL());
    System.out.println("Terms URL: " + obj.getTermsURL());
    System.out.println("Email Suffix: " + obj.getMailSuffix());
    */

    /*
    String tStoreNumber = "0980001";
    System.out.println(getTimeStamp() + "Start");
    int emailCount = obj.getHarborMailCount(tStoreNumber);
    System.out.println(getTimeStamp() + "Finish");
    System.out.println("Store: " + tStoreNumber + " has " + emailCount + " SVHarbor Email user(s).");
    */

    /*
    String tAdminGroup = "Northern Region";
    System.out.println("Users in Admin Group: " + tAdminGroup);
    testvect = obj.getUsersOfAdminGroup(tAdminGroup);
    for (int x = 0; x < testvect.size(); x++) {
    	UserName tUser = (UserName) testvect.elementAt(x);
    	System.out.println("ID: \"" + tUser.getLoginID() + "\"" +
    					   " N: \"" + tUser.getFullName() + "\"");
    }
    System.out.println("");
     */

    /*
    obj.addUserToGroup("Admin0988888", "yhp6y2l's Test HQ #1");
    obj.deleteUserFromGroup("Admin0988888", "yhp6y2l's Test HQ #1");
     */

    /*
    obj.addUserToAdminGroup("howmr0", "DSG Admin Group");
    obj.deleteUserFromAdminGroup("howmr0", "DSG Admin Group");
    */

    /*
    obj.updateDominoMailRoles("DonRuder");
    */

    /*
    obj.addUserToRole("Admin0988888", "UserAdmin", "UserAdminUsers");
    System.out.println("User added to role.");
    obj.deleteUserFromRole("Admin0988888", "UserAdmin", "UserAdminUsers");
    System.out.println("User deleted from role.");
     */

    /*
    obj.addUserToRole("Admin0988888", "MailGroups", "Bakery");
    obj.addUserToRole("Admin0988888", "MailGroups", "Dairy");
    obj.addUserToRole("Admin0988888", "MailGroups", "Meat");
    System.out.println("User added to roles.");
    obj.deleteUserFromRole("Admin0988888", "MailGroups", "Bakery");
    obj.deleteUserFromRole("Admin0988888", "MailGroups", "Dairy");
    obj.deleteUserFromRole("Admin0988888", "MailGroups", "Meat");
    System.out.println("User deleted from roles.");
     */

    /*
    for (int x = 0; x < 500; x++) {
    	System.out.println(obj.generatePassword());
    }
     */

	/*
 	//final String tUserID = "howmr0";
	final String tUserID = "z6pah0";
    System.out.println("Stores for " + tUserID);
    System.out.println(getTimeStamp() + "Start");
    final Calendar startDateTime = new GregorianCalendar();
    // testvect = obj.getStoreListForUser(tUserID, "018", "hales");
    testvect = obj.getStoreListForUser(tUserID);
    final Calendar endDateTime = new GregorianCalendar();
    System.out.println(getTimeStamp() + "Finish");
    System.out.println(testvect.size() + " stores in " + ((endDateTime.getTime().getTime() - startDateTime.getTime().getTime())/1000) + " seconds.");
    // System.out.println(getTimeStamp() + "TRACER DONE");
    for (int x = 0; x < testvect.size(); x++) {
    	StoreDC tObj = (StoreDC) testvect.elementAt(x);
    	System.out.println("storeNumber: \"" + tObj.getStoreNumber() + "\"" +
    					   " Name: \"" + tObj.getName() + "\"" +
    					   " DC: \"" + tObj.getDC() + "\"" +
    					   " Region: \"" + tObj.getRegion() + "\"");
    }
    System.out.println("");
    */

	/*
    final String tUserID = "howmr0";
	// final String tUserID = "z6pah0";
    System.out.println("Stores for " + tUserID);
    System.out.println(getTimeStamp() + "Start");
    final Calendar startDateTime = new GregorianCalendar();
    testvect = obj.getStoreObjectListForUser(tUserID);
    final Calendar endDateTime = new GregorianCalendar();
    System.out.println(getTimeStamp() + "Finish");
    System.out.println(testvect.size() + " stores in " + ((endDateTime.getTime().getTime() - startDateTime.getTime().getTime())/1000) + " seconds.");
    for (int x = 0; x < testvect.size(); x++) {
    	Store tDetail = (Store) testvect.elementAt(x);
	    System.out.println("Store #: \"" + tDetail.getStoreNumber() + "\"" +
	    				   " Type: \"" + tDetail.getType() + "\"" +
	    				   " Name: \"" + tDetail.getName() + "\"" +
	    				   " Address: \"" + tDetail.getAddress() + "\"" +
	    				   " City: \"" + tDetail.getCity() + "\"" +
	    				   " St: \"" + tDetail.getStateCode() + "\"" +
	    				   " Zip: \"" + tDetail.getZipCode() + "\"" +
	    				   " Contact: \"" + tDetail.getContact() + "\"" +
	    				   " Phone: \"" + tDetail.getPhoneNumber() + "\"" +
	    				   " Logo: \"" + tDetail.getLogo() + "\"");
    }
    System.out.println("");
    */

	/*
    final String tUserID = "howmr0";
    System.out.println("Stores for " + tUserID);
    System.out.println(getTimeStamp() + "Start");
    final Calendar startDateTime = new GregorianCalendar();
    testvect = obj.getStoreListForUserWithApp(tUserID, "eCrip");
    final Calendar endDateTime = new GregorianCalendar();
    System.out.println(getTimeStamp() + "Finish");
    System.out.println(testvect.size() + " stores in " + ((endDateTime.getTime().getTime() - startDateTime.getTime().getTime())/1000) + " seconds.");
    for (int x = 0; x < testvect.size(); x++) {
    	StoreDC tObj = (StoreDC) testvect.elementAt(x);
    	System.out.println("storeNumber: \"" + tObj.getStoreNumber() + "\"" +
    					   " Name: \"" + tObj.getName() + "\"" +
    					   " DC: \"" + tObj.getDC() + "\"" +
    					   " Region: \"" + tObj.getRegion() + "\"");
    }
    System.out.println("");
    */

    /*
    final String tUserID = "howmr0";
    System.out.println("Stores for " + tUserID);
    System.out.println(getTimeStamp() + "Start");
    final Calendar startDateTime2 = new GregorianCalendar();
    testvect = obj.getStoreNumberListForUser(tUserID);
    final Calendar endDateTime2 = new GregorianCalendar();
    System.out.println(getTimeStamp() + "Finish");
    System.out.println(testvect.size() + " stores in " + ((endDateTime2.getTime().getTime() - startDateTime2.getTime().getTime())/1000) + " seconds.");
    for (int x = 0; x < testvect.size(); x++) {
    	String tObj = (String) testvect.elementAt(x);
    	System.out.println("storeNumber: \"" + tObj + "\"");
    }
    System.out.println("");
     */

    /*
    System.out.println("Group Types");
    System.out.println(getTimeStamp() + "Start");
    testvect = obj.getGroupTypes();
    System.out.println(getTimeStamp() + "Finish");
    for (int x = 0; x < testvect.size(); x++) {
    	GroupType tObj = (GroupType) testvect.elementAt(x);
    	System.out.println("Type: \"" + tObj.getType() + "\"" +
    					   " Description: \"" + tObj.getDescription() + "\"");
    }
    System.out.println("");
     */

    /*
    String tGroupType = "DC";
    System.out.println("Group Type Detail for " + tGroupType);
    GroupType tObj = obj.getGroupTypeDetail(tGroupType);
    System.out.println("Type: \"" + tObj.getType() + "\"" +
    				   " Description: \"" + tObj.getDescription() + "\"");
     */

    /*
    String tUserLogin = "hojls1";
    System.out.println("Group Types of User: " + tUserLogin);
    System.out.println(getTimeStamp() + "Start");
    testvect = obj.getGroupTypesOfUser(tUserLogin);
    System.out.println(getTimeStamp() + "Finish");
    for (int x = 0; x < testvect.size(); x++) {
    	GroupType tObj = (GroupType) testvect.elementAt(x);
    	System.out.println("Type: \"" + tObj.getType() + "\"" +
    					   " Description: \"" + tObj.getDescription() + "\"");
    }
    System.out.println("");
     */

    /*
    final String tUserID = "Joe.Black";
    System.out.println("Stores for " + tUserID);
    Vector hierarchyVector = obj.getStoreHierarchyForUser(tUserID);
    for (int x1 = 0; x1 < hierarchyVector.size(); x1++) {
    	Vector regionVector = (Vector) hierarchyVector.elementAt(x1);
    
    	System.out.println("Region: " + (String) regionVector.elementAt(0));
    	for (int x2 = 1; x2 < regionVector.size(); x2++) {
    		Vector dcVector = (Vector) regionVector.elementAt(x2);
    
    		System.out.println("\tDC: " + (String) dcVector.elementAt(0));
    		for (int x3 = 1; x3 < dcVector.size(); x3++) {
    			StoreDC tObj = (StoreDC) dcVector.elementAt(x3);
    			System.out.println("\t\t" +
    							   "storeNumber: \"" + tObj.getStoreNumber() + "\"" +
    							   " Name: \"" + tObj.getName() + "\"" +
    							   " Region: \"" + tObj.getRegion() + "\"" +
    							   " DC: \"" + tObj.getDC() + "\"");
    		}
    	}
    }
    System.out.println("");
     */

    /*
    final String tUserID = "joe.black";
    final String tGroupType = "HQ";
    System.out.println("StoreGroups for " + tUserID);
    System.out.println(getTimeStamp() + "Start");
    // testvect = obj.getGroupsOfUser(tUserID, tGroupType, "jim's", 2);
    // testvect = obj.getGroupsOfUser(tUserID, tGroupType);
    testvect = obj.getGroupsOfUser(tUserID);
    // testvect = obj.getExplicitGroupsOfUser(tUserID+".7", "ag", "dale", 2);
    System.out.println(getTimeStamp() + "Finish");
    for (int x = 0; x < testvect.size(); x++) {
    	StoreGroup tGroup = (StoreGroup) testvect.elementAt(x);
    	System.out.println("Type: \"" + tGroup.getType() + "\"  Name: \"" + tGroup.getName() + "\"  Owner: \"" + tGroup.getOwner() + "\"" + " Group ID: " + tGroup.getGroupID());
    }
    System.out.println("");
     */

	/*
    System.out.println("Promotional Regions ");
    System.out.println(getTimeStamp() + "Start");
    testvect = obj.getPromoRegionGroups(null, 1);
    System.out.println(getTimeStamp() + "Finish");
    for (int x = 0; x < testvect.size(); x++) {
    	StoreGroup tGroup = (StoreGroup) testvect.elementAt(x);
    	System.out.println("Type: \"" + tGroup.getType() + "\"  Name: \"" + tGroup.getName() + "\"  Owner: \"" + tGroup.getOwner() + "\"" + " Group ID: " + tGroup.getGroupID());
    }
    System.out.println("");
    */

	/*
    String tStoreNumber = "0988888";
    System.out.println("Promotional Regions at store " + tStoreNumber);
    System.out.println(getTimeStamp() + "Start");
    testvect = obj.getPromoRegionGroupsOfStoreUsers(tStoreNumber);
    System.out.println(getTimeStamp() + "Finish");
    for (int x = 0; x < testvect.size(); x++) {
    	StoreGroup tGroup = (StoreGroup) testvect.elementAt(x);
    	System.out.println("Type: \"" + tGroup.getType() + "\"  Name: \"" + tGroup.getName() + "\"  Owner: \"" + tGroup.getOwner() + "\"" + " Group ID: " + tGroup.getGroupID());
    }
    System.out.println("");
    */

    /*
    final String tAdminGroup = "Northern Region";
    final String tGroupType = "DC";
    System.out.println("StoreGroups for Admin Group: " + tAdminGroup);
    System.out.println(getTimeStamp() + "Start");
    // testvect = obj.getGroupsOfAdminGroup(tAdminGroup, tGroupType);
    testvect = obj.getGroupsOfAdminGroup(tAdminGroup, null);
    System.out.println(getTimeStamp() + "Finish");
    System.out.println("Found: " + testvect.size());
    for (int x = 0; x < testvect.size(); x++) {
    	StoreGroup tGroup = (StoreGroup) testvect.elementAt(x);
    	System.out.println("Type: \"" + tGroup.getType() + "\"  Name: \"" + tGroup.getName() + "\"  Owner: \"" + tGroup.getOwner() + "\"" + " Group ID: " + tGroup.getGroupID());
    }
    System.out.println("");
     */

    /*
    final String tAdminGroup = "Northern Region";
    System.out.println("DCs for Admin Group: " + tAdminGroup);
    System.out.println(getTimeStamp() + "Start");
    testvect = obj.getDCsOfAdminGroup(tAdminGroup);
    System.out.println(getTimeStamp() + "Finish");
    System.out.println("Found: " + testvect.size());
    for (int x = 0; x < testvect.size(); x++) {
    	DCGroup tGroup = (DCGroup) testvect.elementAt(x);
    	System.out.println("DC: \"" + tGroup.getDCNumber() + "Type: \"" + tGroup.getType() + "\"  Name: \"" + tGroup.getName() + "\"  Owner: \"" + tGroup.getOwner() + "\"" + " Group ID: " + tGroup.getGroupID());
    }
    System.out.println("");
     */

    /*
    final String tStoreNumber = "0610070";
    final String tUserID = "howmr0";
    System.out.println("StoreGroups for Store: " + tStoreNumber + " User: " + tUserID);
    System.out.println(getTimeStamp() + "Start");
    // testvect = obj.getGroupsOfStore(tStoreNumber, tUserID);
    testvect = obj.getGroupsOfStore(tStoreNumber, "hojls1", null);
    System.out.println(getTimeStamp() + "Finish");
    for (int x = 0; x < testvect.size(); x++) {
    	StoreGroup tGroup = (StoreGroup) testvect.elementAt(x);
    	System.out.println("Type: \"" + tGroup.getType() + "\"  Name: \"" + tGroup.getName() + "\"  Owner: \"" + tGroup.getOwner() + "\"" + " Group ID: " + tGroup.getGroupID());
    }
    System.out.println("");
     */

    /*
    final String tUserID = "hojls1";
    final String tApplicationName = "eReports";
    System.out.println("AppRoles for " + tUserID + " in " + tApplicationName);
    System.out.println(getTimeStamp() + "Start");
    testvect = obj.getAppRolesOfUser(tUserID, tApplicationName);
    System.out.println(getTimeStamp() + "Finish");
    for (int x = 0; x < testvect.size(); x++) {
    	ApplicationRole tRole = (ApplicationRole) testvect.elementAt(x);
    	System.out.println("Role Name: \"" + tRole.getName() + "\" Role Description: \"" + tRole.getDescription() + "\"");
    }
    System.out.println("");
     */

    /*
    final String tUserID = "hobbb0";
    obj.deleteUserFromMailRoles(tUserID);
     */

    /*
    final String tApplicationName = "eReports";
    System.out.println("AppRoles for " + tApplicationName);
    System.out.println(getTimeStamp() + "Start");
    testvect = obj.getAppRolesOfApp(tApplicationName);
    System.out.println(getTimeStamp() + "Finish");
    for (int x = 0; x < testvect.size(); x++) {
    	ApplicationRole tRole = (ApplicationRole) testvect.elementAt(x);
    	System.out.println("Role Name: \"" + tRole.getName() + "\" Role Description: \"" + tRole.getDescription() + "\"");
    }
    System.out.println("");
     */

    /*
    String tUserID = "howmr0";
    System.out.println("DCs in " + tUserID);
    System.out.println(getTimeStamp() + "Start");
    testvect = obj.getDCsOfUser(tUserID);
    System.out.println(getTimeStamp() + "Finish");
    for (int x = 0; x < testvect.size(); x++) {
    	DCGroup tGroup = (DCGroup) testvect.elementAt(x);
    	System.out.println("DC ID: \"" + tGroup.getDCNumber() + "\" DC Name: \"" + tGroup.getName() + "\" Owner: \"" + tGroup.getOwner() + "\"" + " DC Group ID: " + tGroup.getGroupID());
    }
    System.out.println("");
    */

	/*
    String tUserID = "howmr0";
    System.out.println("Regions for " + tUserID);
    System.out.println(getTimeStamp() + "Start");
    testvect = obj.getRegionsOfUser(tUserID);
    System.out.println(getTimeStamp() + "Finish");
    for (int x = 0; x < testvect.size(); x++) {
    	RegionGroup tGroup = (RegionGroup) testvect.elementAt(x);
    	System.out.println("Region ID: \"" + tGroup.getRegionNumber() + "\" Region Name: \"" + tGroup.getName() + "\" Owner: \"" + tGroup.getOwner() + "\"" + " Region Group ID: " + tGroup.getGroupID());
    }
    System.out.println("");
    */

    /*
    String tStoreNumber = "0980001";
    String tAlias = "980001";
    if (obj.existAlias(tAlias)) {
    	System.out.println("Alias " + tAlias + " exists.");
    	obj.deleteAlias(tAlias);
    	if (obj.existAlias(tAlias)) {
    		System.out.println("Alias " + tAlias + " exists.");
    	}
    	else {
    		System.out.println("Alias " + tAlias + " doesn't exist.");
    	}
    }
    else {
    	System.out.println("Alias " + tAlias + " doesn't exist.");
    }
    obj.addAlias(tStoreNumber, tAlias, "Test Description!!");
    if (obj.existAlias(tAlias)) {
    	System.out.println("Alias " + tAlias + " exists.");
    }
    else {
    	System.out.println("Alias " + tAlias + " doesn't exist.");
    }
    */

    /*
    String tStoreNumber = "0980001";
    System.out.println("Aliases for " + tStoreNumber);
    System.out.println(getTimeStamp() + "Start");
    testvect = obj.getAliasListForStore(tStoreNumber);
    System.out.println(getTimeStamp() + "Finish");
    for (int x = 0; x < testvect.size(); x++) {
    	StoreAlias tAliasObj = (StoreAlias) testvect.elementAt(x);
    	System.out.println("Store Number: " + tAliasObj.getStoreNumber() +
    					   "  Alias: \"" + tAliasObj.getAlias() + "\"" + 
    					   "  Description: \"" + tAliasObj.getDescription() + "\"");
    }
    System.out.println("");
    */

    /*
    String groupName = "yhp6y2l's Test HQ #1";
    //        Store filter = new Store("", "", "Bill", "", "", "", "", "", "", "");
    String dcNameFilter = ("Minneapolis DC");
    Store filter = new Store("", "", "", "", "", "MN", "", "", "", "");
    System.out.println("Stores in " + groupName);
    testvect = obj.getStoresInGroup(groupName, "", "", "","MN");
    
    for (int x = 0; x < testvect.size(); x++) {
    	Store tStore = (Store) testvect.elementAt(x);
    	System.out.println("storeNumber: \"" + tStore.getStoreNumber() + "\" Store Name: \"" + tStore.getName() + "\"");
    }
    System.out.println("");
     */

    /*
    regionName = "AAATest1";
    System.out.println("Stores in " + regionName);
    System.out.println(getTimeStamp() + "Start");
    testvect = obj.getStoresInGroup(regionName);
    System.out.println(getTimeStamp() + "Finish");
    for (int x = 0; x < testvect.size(); x++) {
    	Store tStore = (Store) testvect.elementAt(x);
    	System.out.println("storeNumber: \"" + tStore.getStoreNumber() + "\" Store Name: \"" + tStore.getName() + "\"");
    }
    System.out.println("");
     */

    /*
    String tStoreNumber = "0980001";
    System.out.println(getTimeStamp() + "Start");
    int tUserCount = obj.getUserCountForStore(tStoreNumber);
    System.out.println(getTimeStamp() + "Finish");
    System.out.println("There are " + tUserCount + " users in the store");
    System.out.println("");
    */

    /*
    String tStoreNumber = "0980001";
    System.out.println("Users in store: " + tStoreNumber);
    System.out.println(getTimeStamp() + "Start");
    testvect = obj.getUsersOfStore(tStoreNumber);
    System.out.println(getTimeStamp() + "Finish");
    for (int x = 0; x < testvect.size(); x++) {
    	UserName tUser = (UserName) testvect.elementAt(x);
    	System.out.println("ID: \"" + tUser.getLoginID() + "\"" +
    					   " N: \"" + tUser.getFullName() + "\"");
    }
    System.out.println("There are " + testvect.size() + " users in the store");
    System.out.println("");
    */

	/*
    String tStoreNumber = "0988888";
    System.out.println("User Admin Users at store: " + tStoreNumber);
    System.out.println(getTimeStamp() + "Start");
    testvect = obj.getUserAdminUsersOfStore(tStoreNumber);
    System.out.println(getTimeStamp() + "Finish");
    for (int x = 0; x < testvect.size(); x++) {
    	UserName tUser = (UserName) testvect.elementAt(x);
    	System.out.println("ID: \"" + tUser.getLoginID() + "\"" +
    					   " N: \"" + tUser.getFullName() + "\"");
    }
    System.out.println("");
    */

    /*
    String tStoreNumber = "0988888";
    System.out.println("Applications for store: " + tStoreNumber);
    testvect = obj.getAppListForStore(tStoreNumber);
    for (int x = 0; x < testvect.size(); x++) {
    	Application tApp = (Application) testvect.elementAt(x);
    	System.out.println("Name: \"" + tApp.getName() + "\"" +
    					   " Description: \"" + tApp.getDescription() + "\"" +
    					   " Is Forced: \"" + tApp.isForced() + "\"" +
    					   " Is Default: \"" + tApp.isDefault() + "\"");
    }
    System.out.println("");
     */

    /*
    String tAppType = "Vendor";
    System.out.println("Applications for: " + tAppType);
    System.out.println(getTimeStamp() + "Start");
    testvect = obj.getAppList(tAppType);
    System.out.println(getTimeStamp() + "Finish");
    for (int x = 0; x < testvect.size(); x++) {
    	Application tApp = (Application) testvect.elementAt(x);
    	System.out.println("Name: \"" + tApp.getName() + "\"" +
    					   " Description: \"" + tApp.getDescription() + "\"" +
    					   " Is Forced: \"" + tApp.isForced() + "\"" +
    					   " Is Default: \"" + tApp.isDefault() + "\"");
    }
    System.out.println("");
    */

    /*
    String tLoginID = "howmr0";
    System.out.println("Details for User: " + tLoginID);
    UserDetail tDetail = obj.getUserDetail(tLoginID, 1);
    System.out.println("ID: \"" + tDetail.getLoginID() + "\"" +
    				   " UserType: \"" + tDetail.getUserType() + "\"" +
    				   " FN: \"" + tDetail.getFirstName() + "\"" +
    				   " LN: \"" + tDetail.getLastName() + "\"" +
    				   " MI: \"" + tDetail.getMiddleInitial() + "\"" +
    				   " N: \"" + tDetail.getFullName() + "\"" +
    				   " Store#: \"" + tDetail.getStoreNumber() + "\"" +
    				   " Region: \"" + tDetail.getRegion() + "\"" +
    				   " Title: \"" + tDetail.getTitle() + "\"" +
    				   " Phone: \"" + tDetail.getPhoneNumber() + "\"" +
    				   " EmailType: \"" + tDetail.getEmailType() + "\"" +
    				   " EmailAddress: \"" + tDetail.getEmailAddress() + "\"");
    System.out.println("");
    */

    /*
    String tUserLogin = "hojls1";
    System.out.println("Admin Groups for: " + tUserLogin);
    System.out.println(getTimeStamp() + "Start");
    testvect = obj.getAdminGroupsOfUser(tUserLogin);
    System.out.println(getTimeStamp() + "Finish");
    for (int x = 0; x < testvect.size(); x++) {
    	AdminGroup tApp = (AdminGroup) testvect.elementAt(x);
    	System.out.println("Name: \"" + tApp.getName() + "\"");
    }
    System.out.println("");
     */

    /*
    String tGroupName = "Bismarck DC";
    System.out.println("Details for Group: " + tGroupName);
    StoreGroup tObj = obj.getGroupDetail(tGroupName);
    System.out.println("Type: \"" + tObj.getType() + "\"" + 
    				   " Name: \"" + tObj.getName() + "\"" +
    				   " Owner: \"" + tObj.getOwner() + "\"" +
    				   " Group ID: " + tObj.getGroupID());
    System.out.println("");
     */

    /*
    String tStoreNumber = "0610070";
    System.out.println(getTimeStamp() + "Start");
    int tCount = obj.getUserAdminCount(tStoreNumber);
    System.out.println(getTimeStamp() + "Finish");
    System.out.println("In store " + tStoreNumber + ", " + tCount + " users have access to User Admin.");
    */

    /*
    String tVendorID = "180";
    System.out.println(getTimeStamp() + "Start");
    int tCount = obj.getVendorUserAdminCount(tVendorID);
    System.out.println(getTimeStamp() + "Finish");
    System.out.println("In vendor " + tVendorID + ", " + tCount + " users have access to User Admin.");
    */

	/*
    String tVendorID = "180";
    System.out.println(getTimeStamp() + "Start");
    int tCount = obj.getUserCountForVendor(tVendorID);
    System.out.println(getTimeStamp() + "Finish");
    System.out.println("In vendor " + tVendorID + ", there are " + tCount + " users.");
    */

	/*
    String tBrokerID = "0180";
    System.out.println(getTimeStamp() + "Start");
    int tCount = obj.getBrokerUserAdminCount(tBrokerID);
    System.out.println(getTimeStamp() + "Finish");
    System.out.println("In broker " + tBrokerID + ", " + tCount + " users have access to User Admin.");
    */

	/*
    String tBrokerID = "0180";
    System.out.println(getTimeStamp() + "Start");
    int tCount = obj.getUserCountForBroker(tBrokerID);
    System.out.println(getTimeStamp() + "Finish");
    System.out.println("In broker " + tBrokerID + ", there are " + tCount + " users.");
    */

	/*     
    String tStoreNumber = "0610070";
    System.out.println(getTimeStamp() + "Start");
    String tGroup = obj.getGroupOfStore(tStoreNumber, "DC");
    System.out.println(getTimeStamp() + "Finish");
    System.out.println("Store: " + tStoreNumber + " is in group " + tGroup);
    */

	/*
    String tGroupName = "AAA Test #1";
    String tGroupType = "UD";
    String tLoginID = "howmr0";
    String tAdminGroup = "BMR's Admin Group";
    if (obj.existGroup(tGroupName)) {
    	System.out.println("Store Group " + tGroupName + " exists.");
    	obj.deleteGroup(tGroupName);
    	System.out.println("Record deleted from LDAP");
    }

    obj.addGroup(tGroupName, tGroupType, tLoginID, tAdminGroup);
    System.out.println("Store Group " + tGroupName + " added to LDAP.");

    obj.updateGroup(tGroupName, tGroupName, tLoginID + "!!!", tGroupType);
    System.out.println("Record successfully updated in LDAP!");

    obj.deleteGroup(tGroupName + "xxx");
    System.out.println("Record successfully deleted from LDAP!");
    */

    /*
    Vendor vendor = obj.getVendorDetail("100");
    System.out.println("vendorID: \"" + vendor.getVendorID() + "\"" +
    				   " vendorName: \"" + vendor.getVendorName() + "\"" +
    				   " emailAddress: \"" + vendor.getEmailAddress() + "\"" +
    				   " address: \"" + vendor.getAddress() + "\"" +
    				   " city: \"" + vendor.getCity() + "\"" +
    				   " stateCode: \"" + vendor.getStateCode() + "\"" +
    				   " zipCode: \"" + vendor.getZipCode() + "\"" +
    				   " phoneNumber: \"" + vendor.getPhoneNumber() + "\"" +
    				   " faxNumber: \"" + vendor.getFaxNumber() + "\"");
    System.out.println("");
    */

    /*
    Vector vect = obj.getVendorsOfBrokerUser("broker1");
    for (int x = 0; x < vect.size(); x++) {
    	Vendor vendor = (Vendor) vect.elementAt(x);
    	System.out.println("vendorID: \"" + vendor.getVendorID() + "\"" +
    					   " vendorName: \"" + vendor.getVendorName() + "\"" +
    					   " emailAddress: \"" + vendor.getEmailAddress() + "\"" +
    					   " address: \"" + vendor.getAddress() + "\"" +
    					   " city: \"" + vendor.getCity() + "\"" +
    					   " stateCode: \"" + vendor.getStateCode() + "\"" +
    					   " zipCode: \"" + vendor.getZipCode() + "\"" +
    					   " phoneNumber: \"" + vendor.getPhoneNumber() + "\"" +
    					   " faxNumber: \"" + vendor.getFaxNumber() + "\"");
    }
    */

    /*
    Broker broker = obj.getBrokerDetail("1000");
    System.out.println("brokerNumber: \"" + broker.getBrokerNumber() + "\"" +
    				   " brokerName: \"" + broker.getBrokerName() + "\"" +
    				   " emailAddress: \"" + broker.getEmailAddress() + "\"" +
    				   " address: \"" + broker.getAddress() + "\"" +
    				   " city: \"" + broker.getCity() + "\"" +
    				   " stateCode: \"" + broker.getStateCode() + "\"" +
    				   " zipCode: \"" + broker.getZipCode() + "\"" +
    				   " phoneNumber: \"" + broker.getPhoneNumber() + "\"" +
    				   " faxNumber: \"" + broker.getFaxNumber() + "\"");
    System.out.println("");
    */

    //		Vector userNameVect = obj.getUsersOfAppRole("UserAdminx", "UserAdminSupport");

	/*
	if (obj.existStore(storeNumber)) {
		System.out.println("Record already exists in LDAP");
    	obj.deleteStore(storeNumber);
    	System.out.println("Record deleted from LDAP.");
    }

    obj.addStore(tAppUserName, storeNumber, "HQ", name, address, city, state, zip, contact, phone, logo, regionName, dcName);
    System.out.println("Record successfully added in LDAP!");

    obj.updateStore(storeNumber, name, address, city + "!!!", state, zip, contact, phone, logo);
    System.out.println("Record successfully updated in LDAP!");

    String tStoreNumber = "0988888";
    System.out.println("Details for store: " + tStoreNumber);
    Store tDetail = obj.getStoreDetail(tStoreNumber);
    System.out.println("Store #: \"" + tDetail.getStoreNumber() + "\"" +
    				   " Type: \"" + tDetail.getType() + "\"" +
    				   " Name: \"" + tDetail.getName() + "\"" +
    				   " Address: \"" + tDetail.getAddress() + "\"" +
    				   " City: \"" + tDetail.getCity() + "\"" +
    				   " St: \"" + tDetail.getStateCode() + "\"" +
    				   " Zip: \"" + tDetail.getZipCode() + "\"" +
    				   " Contact: \"" + tDetail.getContact() + "\"" +
    				   " Phone: \"" + tDetail.getPhoneNumber() + "\"" +
    				   " Logo: \"" + tDetail.getLogo() + "\"");
    System.out.println("");
	*/
	/*
	String tStoreNumber = "0989901";
    Store tDetail;
    tDetail = obj.getStoreDetail(tStoreNumber);
    System.out.println("Store " + tStoreNumber + " is a " + tDetail.getType());
    obj.convertStoreToHQ(tAppUserName, tStoreNumber);
    tDetail = obj.getStoreDetail(tStoreNumber);
    System.out.println("Now store " + tStoreNumber + " is a " + tDetail.getType());
    System.out.println("");
	*/

	/*
    String vendorNumber = "180";
    String vendorName = "Test Vendor #0";
    String vendorAddress = "123 YourStreet";
    String vendorCity = "YourTown";
    String vendorState = "MN";
    String vendorZip = "55416-1234";
    String vendorPhoneNumber = "952-828-0000";
    String vendorFaxNumber = "952-828-0001";
    String vendorEmailAddress = "joe@testvendor.com";
    
    if (obj.existVendor(vendorNumber)) {
    	System.out.println("Record already exists in LDAP");
    	obj.deleteVendor(vendorNumber);
    	System.out.println("Record deleted from LDAP.");
    }
    
    obj.addVendor(vendorNumber,
    			  vendorName, 
    			  vendorAddress,
    			  vendorCity,
    			  vendorState,
    			  vendorZip,
    			  vendorPhoneNumber,
    			  vendorFaxNumber,
    			  vendorEmailAddress);
    System.out.println("Record successfully added in LDAP!");
    
    obj.updateVendor(vendorNumber,
    				 vendorName, 
    				 vendorAddress,
    				 vendorCity + "!!!",
    				 vendorState,
    				 vendorZip,
    				 vendorPhoneNumber,
    				 vendorFaxNumber,
    				 vendorEmailAddress);
    System.out.println("Record successfully updated in LDAP!");
    
    System.out.println("Details for vendor: " + vendorNumber);
    Vendor tDetail = obj.getVendorDetail(vendorNumber);
    
    System.out.println("Vendor #: \"" + tDetail.getVendorID() + "\"" +
    				   " VendorName: \"" + tDetail.getVendorName() + "\"" +
    				   " EmailAddress: \"" + tDetail.getEmailAddress() + "\"" +
    				   " Address: \"" + tDetail.getAddress() + "\"" +
    				   " City: \"" + tDetail.getCity() + "\"" +
    				   " St: \"" + tDetail.getStateCode() + "\"" +
    				   " Zip: \"" + tDetail.getZipCode() + "\"" +
    				   " Phone: \"" + tDetail.getPhoneNumber() + "\"" +
    				   " Fax: \"" + tDetail.getFaxNumber() + "\"");
    System.out.println("");
    */

    /*
	testvect = obj.getVendorList("J");
	for (int x = 0; x < testvect.size(); x++) {
		Vendor tObj = (Vendor) testvect.elementAt(x);
		System.out.println("Vendor #: \"" + tObj.getVendorID() + "\"" +
							" VendorName: \"" + tObj.getVendorName() + "\"" +
							" EmailAddress: \"" + tObj.getEmailAddress() + "\"" +
							" Address: \"" + tObj.getAddress() + "\"" +
							" City: \"" + tObj.getCity() + "\"" +
							" St: \"" + tObj.getStateCode() + "\"" +
							" Zip: \"" + tObj.getZipCode() + "\"" +
							" Phone: \"" + tObj.getPhoneNumber() + "\"" +
							" Fax: \"" + tObj.getFaxNumber() + "\"");
	}
	System.out.println("");

	testvect = obj.getVendorList("1", "C");
	for (int x = 0; x < testvect.size(); x++) {
		Vendor tObj = (Vendor) testvect.elementAt(x);
		System.out.println("Vendor #: \"" + tObj.getVendorID() + "\"" +
							" VendorName: \"" + tObj.getVendorName() + "\"" +
							" EmailAddress: \"" + tObj.getEmailAddress() + "\"" +
							" Address: \"" + tObj.getAddress() + "\"" +
							" City: \"" + tObj.getCity() + "\"" +
							" St: \"" + tObj.getStateCode() + "\"" +
							" Zip: \"" + tObj.getZipCode() + "\"" +
							" Phone: \"" + tObj.getPhoneNumber() + "\"" +
							" Fax: \"" + tObj.getFaxNumber() + "\"");
	}
	System.out.println("");
    */

    /*
    String brokerNumber = "0180";
    String brokerName = "Test broker #0";
    String brokerAddress = "123 YourStreet";
    String brokerCity = "YourTown";
    String brokerState = "MN";
    String brokerZip = "55416-1234";
    String brokerPhoneNumber = "952-828-0000";
    String brokerFaxNumber = "952-828-0001";
    String brokerEmailAddress = "joe@testbroker.com";
    
    if (obj.existBroker(brokerNumber)) {
    	System.out.println("Record already exists in LDAP");
    	obj.deleteBroker(brokerNumber);
    	System.out.println("Record deleted from LDAP.");
    }
    
    obj.addBroker(brokerNumber,
    			  brokerName, 
    			  brokerAddress,
    			  brokerCity,
    			  brokerState,
    			  brokerZip,
    			  brokerPhoneNumber,
    			  brokerFaxNumber,
    			  brokerEmailAddress);
    System.out.println("Record successfully added in LDAP!");
    
    obj.updateBroker(brokerNumber,
    				 brokerName,
    				 brokerAddress,
    				 brokerCity + "!!!",
    				 brokerState,
    				 brokerZip,
    				 brokerPhoneNumber,
    				 brokerFaxNumber,
    				 brokerEmailAddress);
    System.out.println("Record successfully updated in LDAP!");
    
    System.out.println("Details for broker: " + brokerNumber);
    Broker tDetail = obj.getBrokerDetail(brokerNumber);
    
    System.out.println("Broker #: \"" + tDetail.getBrokerNumber() + "\"" +
    				   " BrokerName: \"" + tDetail.getBrokerName() + "\"" +
    				   " EmailAddress: \"" + tDetail.getEmailAddress() + "\"" +
    				   " Address: \"" + tDetail.getAddress() + "\"" +
    				   " City: \"" + tDetail.getCity() + "\"" +
    				   " St: \"" + tDetail.getStateCode() + "\"" +
    				   " Zip: \"" + tDetail.getZipCode() + "\"" +
    				   " Phone: \"" + tDetail.getPhoneNumber() + "\"" +
    				   " Fax: \"" + tDetail.getFaxNumber() + "\"");
    System.out.println("");
    */

    /*
    testvect = obj.getBrokerList(null);
    for (int x = 0; x < testvect.size(); x++) {
    	Broker tObj = (Broker) testvect.elementAt(x);
    	System.out.println("Broker #: \"" + tObj.getBrokerNumber() + "\"" +
    					   " BrokerName: \"" + tObj.getBrokerName() + "\"" +
    					   " EmailAddress: \"" + tObj.getEmailAddress() + "\"" +
    					   " Address: \"" + tObj.getAddress() + "\"" +
    					   " City: \"" + tObj.getCity() + "\"" +
    					   " St: \"" + tObj.getStateCode() + "\"" +
    					   " Zip: \"" + tObj.getZipCode() + "\"" +
    					   " Phone: \"" + tObj.getPhoneNumber() + "\"" +
    					   " Fax: \"" + tObj.getFaxNumber() + "\"");
    }
    System.out.println("");
    */

    /*
    obj.addVendorToBroker("180", "0180");
    obj.deleteVendorFromBroker("180", "0180");
    */

    /*
    obj.addVendorToBroker("180", "0180");
    testvect = obj.getVendorsOfBroker("0180");
    for (int x = 0; x < testvect.size(); x++) {
    	Vendor tObj = (Vendor) testvect.elementAt(x);
    	System.out.println("Vendor #: \"" + tObj.getVendorID() + "\"" +
    					   " VendorName: \"" + tObj.getVendorName() + "\"" +
    					   " EmailAddress: \"" + tObj.getEmailAddress() + "\"" +
    					   " Address: \"" + tObj.getAddress() + "\"" +
    					   " City: \"" + tObj.getCity() + "\"" +
    					   " St: \"" + tObj.getStateCode() + "\"" +
    					   " Zip: \"" + tObj.getZipCode() + "\"" +
    					   " Phone: \"" + tObj.getPhoneNumber() + "\"" +
    					   " Fax: \"" + tObj.getFaxNumber() + "\"");
    }
    System.out.println("");
    */

    /*
    String brokerNumber = "0180";
    System.out.println("Users in broker: " + brokerNumber);
    testvect = obj.getUsersOfBroker(brokerNumber);
    for (int x = 0; x < testvect.size(); x++) {
    	UserName tUser = (UserName) testvect.elementAt(x);
    	System.out.println("ID: \"" + tUser.getLoginID() + "\"" +
    					   " N: \"" + tUser.getFullName() + "\"");
    }
    System.out.println("");
    */

    /*
    String vendorNumber = "180";
    System.out.println("Users in vendor: " + vendorNumber);
    testvect = obj.getUsersOfVendor(vendorNumber);
    for (int x = 0; x < testvect.size(); x++) {
    	UserName tUser = (UserName) testvect.elementAt(x);
    	System.out.println("ID: \"" + tUser.getLoginID() + "\"" +
    					   " N: \"" + tUser.getFullName() + "\"");
    }
    System.out.println("");
    */

    /*
    String vendorNumber = "180";
    String appName = "JohnsTesting";
    System.out.println("Applications for vendor: " + vendorNumber);
    testvect = obj.getAppListForVendor(vendorNumber);
    for (int x = 0; x < testvect.size(); x++) {
    	Application tApp = (Application) testvect.elementAt(x);
    	System.out.println("Name: \"" + tApp.getName() + "\"" +
    					   " Description: \"" + tApp.getDescription() + "\"" +
    					   " Is Forced: \"" + tApp.isForced() + "\"" +
    					   " Is Default: \"" + tApp.isDefault() + "\"");
    }
    
    System.out.println("Adding application \"" + appName + "\" to vendor: " + vendorNumber);
    obj.addAppToVendor(vendorNumber, appName);
    System.out.println("Applications for vendor: " + vendorNumber);
    testvect = obj.getAppListForVendor(vendorNumber);
    for (int x = 0; x < testvect.size(); x++) {
    	Application tApp = (Application) testvect.elementAt(x);
    	System.out.println("Name: \"" + tApp.getName() + "\"" +
    					   " Description: \"" + tApp.getDescription() + "\"" +
    					   " Is Forced: \"" + tApp.isForced() + "\"" +
    					   " Is Default: \"" + tApp.isDefault() + "\"");
    }
    
    System.out.println("Removing application \"" + appName + "\" from vendor: " + vendorNumber);
    obj.deleteAppFromVendor(vendorNumber, appName);
    System.out.println("Applications for vendor: " + vendorNumber);
    testvect = obj.getAppListForVendor(vendorNumber);
    for (int x = 0; x < testvect.size(); x++) {
    	Application tApp = (Application) testvect.elementAt(x);
    	System.out.println("Name: \"" + tApp.getName() + "\"" +
    					   " Description: \"" + tApp.getDescription() + "\"" +
    					   " Is Forced: \"" + tApp.isForced() + "\"" +
    					   " Is Default: \"" + tApp.isDefault() + "\"");
    }
    System.out.println("");
    */

    /*
    String brokerNumber = "0180";
    String appName = "JohnsBrokerApp";
    System.out.println("Applications for broker: " + brokerNumber);
    testvect = obj.getAppListForBroker(brokerNumber);
    for (int x = 0; x < testvect.size(); x++) {
    	Application tApp = (Application) testvect.elementAt(x);
    	System.out.println("Name: \"" + tApp.getName() + "\"" +
    					   " Description: \"" + tApp.getDescription() + "\"" +
    					   " Is Forced: \"" + tApp.isForced() + "\"" +
    					   " Is Default: \"" + tApp.isDefault() + "\"");
    }
    
    System.out.println("Adding application \"" + appName + "\" to broker: " + brokerNumber);
    obj.addAppToBroker(brokerNumber, appName);
    System.out.println("Applications for broker: " + brokerNumber);
    testvect = obj.getAppListForBroker(brokerNumber);
    for (int x = 0; x < testvect.size(); x++) {
    	Application tApp = (Application) testvect.elementAt(x);
    	System.out.println("Name: \"" + tApp.getName() + "\"" +
    					   " Description: \"" + tApp.getDescription() + "\"" +
    					   " Is Forced: \"" + tApp.isForced() + "\"" +
    					   " Is Default: \"" + tApp.isDefault() + "\"");
    }
    
    System.out.println("Removing application \"" + appName + "\" from broker: " + brokerNumber);
    obj.deleteAppFromBroker(brokerNumber, appName);
    System.out.println("Applications for broker: " + brokerNumber);
    testvect = obj.getAppListForBroker(brokerNumber);
    for (int x = 0; x < testvect.size(); x++) {
    	Application tApp = (Application) testvect.elementAt(x);
    	System.out.println("Name: \"" + tApp.getName() + "\"" +
    					   " Description: \"" + tApp.getDescription() + "\"" +
    					   " Is Forced: \"" + tApp.isForced() + "\"" +
    					   " Is Default: \"" + tApp.isDefault() + "\"");
    }
    System.out.println("");
    */

    /*
    String tStoreNumber = "0988888";
    String tGroupName = "Bill's Test Group";
    obj.addStoreToGroup(tStoreNumber, tGroupName);
    obj.deleteStoreFromGroup(tStoreNumber, tGroupName);
     */

    /*
    obj.addAppToStore("0988888", "eReportsPublishing");
    obj.deleteAppFromStore("0988888", "eReportsPublishing");
     */

    /*
    final String tloginID = "johnx";
    if (obj.checkLoginID(tloginID)) {
    	System.out.println("Record already exists in LDAP");
    }
    else {
    	System.out.println("Record doesn't exist in LDAP");
    }
     */

	/*
    if (obj.checkDCAccess("howmr0", "015")) {
    	System.out.println("Record exists in LDAP");
    }
    else {
    	System.out.println("Record doesn't exist in LDAP");
    }
    */

	/*
    if (obj.checkGroupAccessForUser("howmr0", "Midwest Region", "RG")) {
    	System.out.println("Record exists in LDAP");
    }
    else {
    	System.out.println("Record doesn't exist in LDAP");
    }
    */

	/*
    if (obj.checkRegionAccess("howmr0", "Midwest Region")) {
    	System.out.println("Record exists in LDAP");
    }
    else {
    	System.out.println("Record doesn't exist in LDAP");
    }
    */

	/*
    if (obj.checkRegionAccessByNumber("howmr0", "079")) {
    	System.out.println("Record exists in LDAP");
    }
    else {
    	System.out.println("Record doesn't exist in LDAP");
    }
    */

	/*
    if (obj.checkVendorAccess("broker2", "44556677")) {
    	System.out.println("Record exists in LDAP");
    }
    else {
    	System.out.println("Record doesn't exist in LDAP");
    }
    */

	/*
    if (obj.checkBrokerAccess("joebarney", "11223344")) {
    	System.out.println("Record exists in LDAP");
    }
    else {
    	System.out.println("Record doesn't exist in LDAP");
    }
    */

    /*
    final String tloginID = "howmr0";
    if (obj.existUser(tloginID, false)) {
    	System.out.println("User " + tloginID + " exists in LDAP.");
    }
    else {
    	System.out.println("User " + tloginID + " doesn't exist in LDAP.");
    }
     */

    /*
    final String tloginID = "ho8880";
    final String tStoreNumber = "0988888";
    final String tFirstName = "Bart";
    final String tLastName = "Simpson";
    final String tTitle = "Cartoon Character";
    final String tMI = "X";
    final String tPhoneNumber = "(612) 555-4321";
    final String tEmailAddress = "bart@hotmail.com";
    String       tPassword;
    if (obj.existUser(tloginID, true)) {
    	System.out.println("Record already exists in LDAP");
    	obj.deleteUser(tloginID);
    	System.out.println("Record deleted from LDAP.");
    }
    
    tPassword = obj.addUser(tloginID, tStoreNumber, tFirstName, tLastName, tMI, tTitle, tPhoneNumber, tEmailAddress);
    System.out.println("Record successfully added to LDAP!  Password: " + tPassword);
    
    //        tPassword = obj.addAdminUser(tloginID, "BMR's Admin Group", tFirstName, tLastName, tMI, tTitle, tPhoneNumber, tEmailAddress);
    //        System.out.println("Record successfully added to LDAP!  Password: " + tPassword);
     
    obj.updateUser(tloginID, tFirstName, tLastName, tMI, tTitle + "!!!", tPhoneNumber, "xxx" + tEmailAddress);
    System.out.println("Record successfully updated in LDAP!");
     */

	/*
	Carrier carrier = obj.getCarrierDetail("C1234567");
	System.out.println("Carrier ID: \"" + carrier.getCarrierID() + "\"" +
						"  Name: \"" + carrier.getCarrierName() + "\"" +
						"  emailAddress: \"" + carrier.getEmailAddress() + "\"" +
						"  address: \"" + carrier.getAddress() + "\"" +
						"  city: \"" + carrier.getCity() + "\"" +
						"  stateCode: \"" + carrier.getStateCode() + "\"" +
						"  zipCode: \"" + carrier.getZipCode() + "\"" +
						"  phoneNumber: \"" + carrier.getPhoneNumber() + "\"" +
						"  faxNumber: \"" + carrier.getFaxNumber() + "\"");
	System.out.println("");
	*/

	/*
	String carrierID = "C9898989";
	String carrierName = "Test Carrier 9898989";
	String carrierAddress = "123 YourStreet";
	String carrierCity = "YourTown";
	String carrierState = "MN";
	String carrierZip = "55123-4567";
	String carrierPhoneNumber = "952-828-0000";
	String carrierFaxNumber = "952-828-0001";
	String carrierEmailAddress = "joe@testcarrier.com";

	if (obj.existCarrier(carrierID)) {
		System.out.println("Record already exists in LDAP");
		obj.deleteCarrier(carrierID);
		System.out.println("Record deleted from LDAP.");
	}

	obj.addCarrier(carrierID,
					carrierName, 
					carrierAddress,
					carrierCity,
					carrierState,
					carrierZip,
					carrierPhoneNumber,
					carrierFaxNumber,
					carrierEmailAddress);
	System.out.println("Record successfully added in LDAP!");

	obj.updateCarrier(carrierID,
						carrierName, 
						carrierAddress,
						carrierCity + "!!!",
						carrierState,
						carrierZip,
						carrierPhoneNumber,
						carrierFaxNumber,
						carrierEmailAddress);
	System.out.println("Record successfully updated in LDAP!");

	System.out.println("Details for carrier: " + carrierID);
	Carrier tDetail = obj.getCarrierDetail(carrierID);

	System.out.println("Carrier ID: \"" + tDetail.getCarrierID() + "\"" +
						"  Name: \"" + tDetail.getCarrierName() + "\"" +
						"  EmailAddress: \"" + tDetail.getEmailAddress() + "\"" +
						"  Address: \"" + tDetail.getAddress() + "\"" +
						"  City: \"" + tDetail.getCity() + "\"" +
						"  St: \"" + tDetail.getStateCode() + "\"" +
						"  Zip: \"" + tDetail.getZipCode() + "\"" +
						"  Phone: \"" + tDetail.getPhoneNumber() + "\"" +
						"  Fax: \"" + tDetail.getFaxNumber() + "\"");
	System.out.println("");
	*/

	/*
	String tCarrierID = "C9898989";
	System.out.println(getTimeStamp() + "Start");
	int tCount = obj.getUserCountForCarrier(tCarrierID);
	System.out.println(getTimeStamp() + "Finish");
	System.out.println("In carrier " + tCarrierID + ", there are " + tCount + " users.");
	*/

	/*
	String tCarrierID = "C9898989";
	System.out.println(getTimeStamp() + "Start");
	int tCount = obj.getCarrierUserAdminCount(tCarrierID);
	System.out.println(getTimeStamp() + "Finish");
	System.out.println("In carrier " + tCarrierID + ", " + tCount + " users have access to User Admin.");
	*/

	/*
	String tCarrierID = "C9898989";
	System.out.println("Users in carrier: " + tCarrierID);
	testvect = obj.getUsersOfCarrier(tCarrierID);
	for (int x = 0; x < testvect.size(); x++) {
		UserName tUser = (UserName) testvect.elementAt(x);
		System.out.println("ID: \"" + tUser.getLoginID() + "\"" +
							" N: \"" + tUser.getFullName() + "\"");
	}
	System.out.println("");
	*/

	/*
	String tCarrierID = "C9898989";
	String appName = "JohnsCarrierApp";
	System.out.println("Applications for carrier: " + tCarrierID);
	testvect = obj.getAppListForCarrier(tCarrierID);
	for (int x = 0; x < testvect.size(); x++) {
		Application tApp = (Application) testvect.elementAt(x);
		System.out.println("Name: \"" + tApp.getName() + "\"" +
							" Description: \"" + tApp.getDescription() + "\"" +
							" Is Forced: \"" + tApp.isForced() + "\"" +
							" Is Default: \"" + tApp.isDefault() + "\"");
	}

	System.out.println("Adding application \"" + appName + "\" to carrier: " + tCarrierID);
	obj.addAppToCarrier(tCarrierID, appName);
	System.out.println("Applications for carrier: " + tCarrierID);
	testvect = obj.getAppListForCarrier(tCarrierID);
	for (int x = 0; x < testvect.size(); x++) {
		Application tApp = (Application) testvect.elementAt(x);
		System.out.println("Name: \"" + tApp.getName() + "\"" +
							" Description: \"" + tApp.getDescription() + "\"" +
							" Is Forced: \"" + tApp.isForced() + "\"" +
							" Is Default: \"" + tApp.isDefault() + "\"");
	}

	System.out.println("Removing application \"" + appName + "\" from carrier: " + tCarrierID);
	obj.deleteAppFromCarrier(tCarrierID, appName);
	System.out.println("Applications for carrier: " + tCarrierID);
	testvect = obj.getAppListForCarrier(tCarrierID);
	for (int x = 0; x < testvect.size(); x++) {
		Application tApp = (Application) testvect.elementAt(x);
		System.out.println("Name: \"" + tApp.getName() + "\"" +
							" Description: \"" + tApp.getDescription() + "\"" +
							" Is Forced: \"" + tApp.isForced() + "\"" +
							" Is Default: \"" + tApp.isDefault() + "\"");
	}
	System.out.println("");
	*/

	/*
	System.out.println("C9898989 by AdminC9898989 is " + obj.checkCarrierAccess("AdminC9898989", "C9898989"));
	System.out.println("C1234567 by AdminC9898989 is " + obj.checkCarrierAccess("AdminC9898989", "C1234567"));
	System.out.println("C9898989 by hojme0 is " + obj.checkCarrierAccess("hojme0", "C9898989"));
	*/

	/*
	testvect = obj.getCarrierList(null);
	for (int x = 0; x < testvect.size(); x++) {
		Carrier tObj = (Carrier) testvect.elementAt(x);
		System.out.println("Carrier ID: \"" + tObj.getCarrierID() + "\"" +
							" CarrierName: \"" + tObj.getCarrierName() + "\"" +
							" EmailAddress: \"" + tObj.getEmailAddress() + "\"" +
							" Address: \"" + tObj.getAddress() + "\"" +
							" City: \"" + tObj.getCity() + "\"" +
							" St: \"" + tObj.getStateCode() + "\"" +
							" Zip: \"" + tObj.getZipCode() + "\"" +
							" Phone: \"" + tObj.getPhoneNumber() + "\"" +
							" Fax: \"" + tObj.getFaxNumber() + "\"");
    }
    System.out.println("");
	*/

	/*
	final String tLoginID = "test_vendor";
	System.out.println("Distribution Groups for user: " + tLoginID);
	testvect = obj.getDistributionGroupsOfUser(tLoginID);
	for (int x = 0; x < testvect.size(); x++) {
		DistributionGroup tGroup = (DistributionGroup) testvect.elementAt(x);
		System.out.println("Number: \"" + tGroup.getNumber() + "\"" +
							"  Description: \"" + tGroup.getDescription() + "\"");
	}
	*/

	obj.destroy();
	obj = null;
}

	/**
 	 * Re-reads the properties file.  Call this function after
 	 * you make changes to the properties file to force the
 	 * class to re-read the file.
	 *
	 * @return void
	 * @exception java.lang.Exception
	 */
	public void refreshProperties()
			throws Exception
	{
		CbkLdapConstants.refresh();
	}

	/**
	 * Resets the user's password to a new random password.
	 *
	 * @return The new password.
	 * @param loginID java.lang.String
	 * @exception java.lang.Exception
	 */
	public String resetPassword(String loginID)
			throws Exception
	{
		final String tPeopleObjectDN = "uid=" + loginID + ",ou=People," + baseDN;
		String      password;
		Hashtable   attrib_set = new Hashtable(10);

		// Get a new password for the user.
		password = generatePassword();

		// Update the People Object.
		attrib_set.put("userPassword", new String[] {password});
		attrib_set.put("carLicense", new String[] {"16777216"});
		ldapDir.updateObject(tPeopleObjectDN, attrib_set);

		// Write a record to the audit log.
		eventLog.writeLog("User", "Reset", "\"" + loginID + "\"");

		return(password);
	}

	/**
	 * Resets a store's password to a new random password.
	 *
	 * @return The new password.
	 * @param loginID java.lang.String
	 * @exception java.lang.Exception
	 */
	public String setStorePassword(String storeNumber)
			throws Exception
	{
		final String StoreObjectDN = "uid=" + storeNumber + ",ou=Stores," + baseDN;
		String password;
		Hashtable attrib_set = new Hashtable(10);

		// Get a new password for the user.
		password = generatePassword();

		// Update the People Object.
		attrib_set.put("userPassword", new String[] {password});
		attrib_set.put("carLicense", new String[] {"0"});
		ldapDir.updateObject(StoreObjectDN, attrib_set);

		// Write a record to the audit log.
		eventLog.writeLog("Store", "SetPassword", "\"" + storeNumber + "\"");

		return(password);
	}

	/**
	 * Function to test the domino servlets.  This function
	 * uses the servlets to create a test user, edit the 
	 * user and then delete the user.
	 *
	 * @return void
	 * @exception java.lang.Exception
	 */
	public void testDominoServlets()
			throws Exception
	{
		String tloginID = "hotest";
		String temailAddress = "bart.x.simpson@hotmail.com";
		String tfirstName = "Bart";
		String tmiddleInitial = "X";
		String tlastName = "Simpson";
		String tstoreNumber = "0988888";
		String tStoreName = "test";
		String tstoreCity = "Test City";
		String tStoreState = "MN";

		try {
			domino.createUser(tloginID, tfirstName, tmiddleInitial, tlastName, temailAddress);
			domino.updateUser(tloginID, tfirstName, tmiddleInitial, tlastName, temailAddress);
			domino.deleteUser(tloginID);
		}
		catch(Exception e){
			throw e;    // Rethrow the exception.
		}
	}
	/**
	 * Modifies the specified user in the LDAP database.
	 *
	 * @return void
	 * @param loginID java.lang.String
	 * @param firstName java.lang.String
	 * @param lastName java.lang.String
	 * @param middleInitial java.lang.String
	 * @param title java.lang.String
	 * @param phoneNumber java.lang.String
	 * @exception java.lang.Exception
	 */
	public void updateAdminUser(String loginID,
								String firstName,
								String lastName,
								String middleInitial,
								String title,
								String phoneNumber)
			throws Exception
	{
		updateNonRetailUser(loginID,
							firstName,
							lastName,
							middleInitial,
							title,
							phoneNumber,
							null);
	}
	/**
	 * Updates the basic information for a broker.
	 *
	 * @return void
	 * @param brokerNumber java.lang.String
	 * @param name java.lang.String
	 * @param address java.lang.String
	 * @param city java.lang.String
	 * @param state java.lang.String
	 * @param zip java.lang.String
	 * @param phoneNumber java.lang.String
	 * @param faxNumber java.lang.String
	 * @param emailAddress java.lang.String
	 * @exception java.lang.Exception
	 */
	public void updateBroker(String brokerNumber,
						     String name,
						     String address,
						     String city,
						     String state,
						     String zip,
						     String phoneNumber,
						     String faxNumber,
						     String emailAddress)
		throws Exception
	{
		updateBroker(brokerNumber
					,name
					,address
					,city
					,state
					,zip
					,phoneNumber
					,faxNumber
					,emailAddress
					,""
					);
	}				
					
					
	/**
	 * Updates the basic information for a broker.
	 *
	 * @return void
	 * @param brokerNumber java.lang.String
	 * @param name java.lang.String
	 * @param address java.lang.String
	 * @param city java.lang.String
	 * @param state java.lang.String
	 * @param zip java.lang.String
	 * @param phoneNumber java.lang.String
	 * @param faxNumber java.lang.String
	 * @param emailAddress java.lang.String
	 * @param contact java.lang.String
	 * @exception java.lang.Exception
	 */
	public void updateBroker(String brokerNumber,
						     String name,
						     String address,
						     String city,
						     String state,
						     String zip,
						     String phoneNumber,
						     String faxNumber,
						     String contact,
			     		     String emailAddress)
		throws Exception
	{
		
		final String    brokerObjectDN = "uid=" + brokerNumber + ",ou=Brokers," + baseDN;
		Hashtable       attrib_set = new Hashtable(20);

		// Make sure the specified broker exists.
		if (! ldapDir.existObject(brokerObjectDN)) {
			String tMsg = "Unable to update broker.  Broker: \"" + brokerNumber + "\" doesn't exist in LDAP database.";
			throw new Exception(tMsg);
		}

		// Update the broker Object.
		attrib_set.put("sn", new String[] {name});
		attrib_set.put("cn", new String[] {"Broker " + name});
		attrib_set.put("mail", new String[] {emailAddress});
		attrib_set.put("street", new String[] {address});
		attrib_set.put("homePostalAddress", new String[] {city});
		attrib_set.put("st", new String[] {state});
		attrib_set.put("postalCode", new String[] {zip});
		attrib_set.put("telephoneNumber", new String[] {phoneNumber});
		attrib_set.put("facsimileTelephoneNumber", new String[] {faxNumber});
		attrib_set.put("manager", new String[] {contact});
		
		ldapDir.updateObject(brokerObjectDN, attrib_set);
	}
	/**
	 * Updates the mail groups in Domino to be in synch with LDAP.
	 *
	 * @return void
	 * @param loginID java.lang.String
	 * @exception java.lang.Exception
	 */
	public void updateDominoMailRoles(String loginID)
			throws Exception
	{
		final UserDetail userDetail = getUserDetail(loginID);

		if (userDetail.getEmailAddress().length() > 0) {
			final Vector	mailRolesVector = getAppRolesOfUser(loginID, "MailGroups");
			StringBuffer	tMailRoleList = new StringBuffer();
			ApplicationRole	tRole;

			// Build a list of all the mail roles that the user is assigned to.
			final int mailRolesVectorSize = mailRolesVector.size();
			for (int cntr1 = 0; cntr1 < mailRolesVectorSize; cntr1++) {
				tRole = (ApplicationRole) mailRolesVector.elementAt(cntr1);
				if (cntr1 > 0) {
					tMailRoleList.append(",");
				}
				tMailRoleList.append(tRole.getName());
			}

			// Update the user in Domino.
			domino.updateMailGroups(loginID,
									userDetail.getEmailAddress(),
									userDetail.getStoreNumber(),
									tMailRoleList.toString());
		}
	}
	/**
	 * Modifies the specified Store Group in the LDAP database.
	 *
	 * @return void
	 * @param oldGroupName java.lang.String
	 * @param newGroupName java.lang.String
	 * group type doesn't have a number.
	 * @param loginID java.lang.String
	 * @param groupType java.lang.String
	 * @param groupNumber java.lang.String - Pass null if the
	 * group doesn't have a number.
	 * @exception java.lang.Exception
	 */
	private void doUpdateGroup(String oldGroupName,
							   String newGroupName,
							   String loginID,
							   String groupType,
							   String groupNumber)
			throws Exception
	{
		final String tOldStoreGroupDN = "cn=" + oldGroupName + ",ou=SharedGroups," + baseDN;
		final String tNewStoreGroupDN = "cn=" + newGroupName + ",ou=SharedGroups," + baseDN;
		Hashtable   attrib_set = new Hashtable(10);
		Hashtable   hashT;

		// Make sure the store group exists.
		if ((hashT = ldapDir.read(tOldStoreGroupDN, new String[] {"owner"})) == null) {
			String tMsg = "Unable to update group in LDAP database.  Group doesn't exist." +
						  "  Group: \"" + oldGroupName + "\"";
			throw new Exception(tMsg);
		}

		// Make sure the group type exists.
		if (! existGroupType(groupType)) {
			String tMsg = "Unable to update group in LDAP database.  Group type doesn't exist." +
						  "  Group Type: \"" + groupType + "\"";
			throw new Exception(tMsg);
		}

		if (! oldGroupName.equalsIgnoreCase(newGroupName)) {
			// Make sure the new store group doesn't exist.
			if (ldapDir.existObject(tNewStoreGroupDN)) {
				String tMsg = "Unable to update rename group in LDAP database.  A group with the new name already exists." +
							  "  Old Group Name: \"" + oldGroupName + "\"" +
							  "  New Group Name: \"" + newGroupName + "\"";
				throw new Exception(tMsg);
			}

			// Rename the object.
			ldapDir.renameObject(tOldStoreGroupDN, tNewStoreGroupDN);

			// Write a record to the audit log.
			eventLog.writeLog("Group", "Rename", "From \"" + oldGroupName + "\" to \"" + newGroupName + "\"");
		}

		// Update the Stored Groups object (if necessary).
		if ((! getAttributeValue(hashT, "owner").equalsIgnoreCase(loginID)) ||
			(! getAttributeValue(hashT, "businessCategory").equalsIgnoreCase(groupType)) ||
			((groupNumber != null) &&
			 (! getAttributeValue(hashT, "description").equalsIgnoreCase(groupNumber)))) {

			attrib_set.put("owner", new String[] {loginID});
			attrib_set.put("businessCategory", new String[] {groupType});
			if ((groupNumber != null) &&
				(groupNumber.length() > 0))
			{
				attrib_set.put("description", new String[] {groupNumber});
			}
			else
			{
				attrib_set.put("description", new String[] {null});
			}
			ldapDir.updateObject(tNewStoreGroupDN, attrib_set);

			// Write a record to the audit log.
			eventLog.writeLog("Group", "Change", "\"" + newGroupName + "\" (Manager=\"" + loginID + "\")(GroupType=\"" + groupType + "\")");
		}
	}
	/**
	 * Modifies the specified Store Group in the LDAP database.
	 *
	 * @return void
	 * @param oldGroupName java.lang.String
	 * @param newGroupName java.lang.String
	 * @param loginID java.lang.String
	 * @param groupType java.lang.String
	 * @exception java.lang.Exception
	 */
	public void updateGroup(String oldGroupName,
							String newGroupName,
							String loginID,
							String groupType)
			throws Exception
	{
		doUpdateGroup(oldGroupName, newGroupName, loginID, groupType, null);
	}
	/**
	 * Modifies the specified Numbered Store Group in the LDAP database.
	 *
	 * @return void
	 * @param oldGroupName java.lang.String
	 * @param newGroupName java.lang.String
	 * @param groupNumber java.lang.String
	 * @param loginID java.lang.String
	 * @param groupType java.lang.String
	 * @exception java.lang.Exception
	 */
	public void updateGroup(String oldGroupName,
							String newGroupName,
							String loginID,
							String groupType,
							String groupNumber)
			throws Exception
	{
		doUpdateGroup(oldGroupName, newGroupName, loginID, groupType, groupNumber);
	}
	/**
	 * Updates the basic information for a store.
	 *
	 * @return void
	 * @param storeNumber java.lang.String
	 * @param name java.lang.String
	 * @param address java.lang.String
	 * @param city java.lang.String
	 * @param state java.lang.String
	 * @param zip java.lang.String
	 * @param contact java.lang.String
	 * @param phone java.lang.String
	 * @param logo java.lang.String
	 * @exception java.lang.Exception
	 */
	public void updateStore(String storeNumber,
							String name,
							String address,
							String city,
							String state,
							String zip,
							String contact,
							String phone,
							String logo)
			throws Exception
	{
		final String    storeObjectDN = "uid=" + storeNumber + ",ou=Stores," + baseDN;
		Hashtable       attrib_set = new Hashtable(20);

		// Make sure the specified store exists.
		if (! ldapDir.existObject(storeObjectDN)) {
			String tMsg = "Unable to update store.  Store: \"" + storeNumber + "\" doesn't exist in LDAP database.";
			throw new Exception(tMsg);
		}
		
		// Update the Store Object.
		attrib_set.put("sn", new String[] {name});
		attrib_set.put("cn", new String[] {"Store " + name});
		attrib_set.put("street", new String[] {address});
		attrib_set.put("homePostalAddress", new String[] {city});
		attrib_set.put("st", new String[] {state});
		attrib_set.put("postalCode", new String[] {zip});
		attrib_set.put("manager", new String[] {contact});
		attrib_set.put("telephoneNumber", new String[] {phone});
		attrib_set.put("labeledURI", new String[] {logo});
		ldapDir.updateObject(storeObjectDN, attrib_set);
	}
	/**
	 * Modifies the specified user in the LDAP database.
	 *
	 * @return void
	 * @param loginID java.lang.String
	 * @param firstName java.lang.String
	 * @param lastName java.lang.String
	 * @param middleInitial java.lang.String
	 * @param title java.lang.String
	 * @param phoneNumber java.lang.String
	 * @param emailAddress java.lang.String
	 * @exception java.lang.Exception
	 */
	public void updateUser(String loginID,
						   String firstName,
						   String lastName,
						   String middleInitial,
						   String title,
						   String phoneNumber,
						   String emailAddress)
			throws Exception
	{
		final String tPeopleObjectDN = "uid=" + loginID + ",ou=People," + baseDN;
		Hashtable   attrib_set = new Hashtable(20);
		String      tDN;

		// Make sure user exists.
		if (! ldapDir.existObject(tPeopleObjectDN)) {
			String tMsg = "Unable to update user in LDAP database.  User doesn't exist." +
						  "  User: \"" + loginID + "\"";
			throw new Exception(tMsg);
		}

		// Get the current user's current information.
		final UserDetail tOldUserValues = getUserDetail(loginID);

		// Update the user in Domino.
		if (emailAddress.length() == 0) {
			// Delete the user from Domino.
			domino.deleteUser(loginID);
			
			// Remove the user from all the Mail Roles that they belong to.
			deleteUserFromMailRoles(loginID);
		}
		else {
			if (tOldUserValues.getEmailAddress().length() == 0) {
				// Create the user in Domino.
				domino.createUser(loginID, firstName, middleInitial, lastName, emailAddress);
			}
			else {
				// Update the user in Domino.
				domino.updateUser(loginID, firstName, middleInitial, lastName, emailAddress);
			}
		}
		
		// Update the People Object.
		attrib_set.put("givenname", new String[] {firstName});
		attrib_set.put("sn", new String[] {lastName});
		attrib_set.put("initials", new String[] {middleInitial});
		attrib_set.put("cn", new String[] {firstName + " " + lastName});
		attrib_set.put("title", new String[] {title});
		attrib_set.put("telephoneNumber", new String[] {phoneNumber});
		attrib_set.put("mail", new String[] {emailAddress});
		ldapDir.updateObject(tPeopleObjectDN, attrib_set);

		// Write to the audit log only when the user's email address is changed.
		if (tOldUserValues.getEmailAddress().compareTo(emailAddress) != 0) {
			// Write a record to the audit log.
			eventLog.writeLog("User", "Change", "\"" + loginID + "\" (Address=\"" + emailAddress + "\")");
		}
	}
	/**
	 * Updates the basic information for a vendor.
	 *
	 * @return void
	 * @param storeNumber java.lang.String
	 * @param name java.lang.String
	 * @param address java.lang.String
	 * @param city java.lang.String
	 * @param state java.lang.String
	 * @param zip java.lang.String
	 * @param phoneNumber java.lang.String
	 * @param faxNumber java.lang.String
	 * @param emailAddress java.lang.String
	 * @exception java.lang.Exception
	 */
	public void updateVendor(String vendorNumber,
						     String name,
						     String address,
						     String city,
						     String state,
						     String zip,
						     String phoneNumber,
						     String faxNumber,
						     String emailAddress)
		throws Exception
	{
		updateVendor(vendorNumber
					,name
					,address
					,city
					,state
					,zip
					,phoneNumber
					,faxNumber
					,emailAddress
					,""
					,""
					);
	}				
					
		
	/**
	 * Updates the basic information for a vendor.
	 *
	 * @return void
	 * @param storeNumber java.lang.String
	 * @param name java.lang.String
	 * @param address java.lang.String
	 * @param city java.lang.String
	 * @param state java.lang.String
	 * @param zip java.lang.String
	 * @param phoneNumber java.lang.String
	 * @param faxNumber java.lang.String
	 * @param emailAddress java.lang.String
	 * @param contact java.lang.String
	 * @exception java.lang.Exception
	 */
	// Jan 26, 2003 - Modified for Vendor Conversion		
	public void updateVendor(String vendorNumber,
						     String name,
						     String address,
						     String city,
						     String state,
						     String zip,
						     String phoneNumber,
						     String faxNumber,
						     String emailAddress,
						     String contact,
						     String vendorType)
		throws Exception
	{
		String 			originalVendorNumber = "";
		originalVendorNumber = vendorNumber;		
		vendorNumber = convertToInternalVendorNbr(vendorNumber);
		
		final String    vendorObjectDN = "uid=" + vendorNumber + ",ou=Vendors," + baseDN;
		Hashtable       attrib_set = new Hashtable(20);

		// Make sure the specified vendor exists.
		if (! existVendor(originalVendorNumber)) {
			String tMsg = "Unable to update vendor.  Vendor: \"" + originalVendorNumber + "\" doesn't exist in LDAP database.";
			throw new Exception(tMsg);
		}

		// Update the vendor Object.
		attrib_set.put("sn", new String[] {name});
		attrib_set.put("cn", new String[] {"Vendor " + name});
		attrib_set.put("mail", new String[] {emailAddress});
		attrib_set.put("street", new String[] {address});
		attrib_set.put("homePostalAddress", new String[] {city});
		attrib_set.put("st", new String[] {state});
		attrib_set.put("postalCode", new String[] {zip});
		attrib_set.put("telephoneNumber", new String[] {phoneNumber});
		attrib_set.put("facsimileTelephoneNumber", new String[] {faxNumber});
		attrib_set.put("manager", new String[] {contact});
		attrib_set.put("businessCategory", new String[] {vendorType});
		ldapDir.updateObject(vendorObjectDN, attrib_set);
	}
	/**
	 * Write a line into the LDAP audit log.
	 *
	 * @return void
	 * @param table java.lang.String
	 * @param action java.lang.String
	 * @param text java.lang.String
	 * @exception java.lang.Exception
	 */
	public void writeLog(String table,
						 String action,
						 String text)
			throws Exception
	{
		eventLog.writeLog(table, action, text);
	}
	/**
	 * Delete the specified broker user.
	 *
	 * @return void
	 * @param loginID java.lang.String
	 * @exception java.lang.Exception
	 */
	public void deleteBrokerUser(String loginID)
			throws Exception
	{
		deleteUser(loginID, false);
	}
	/**
	 * Delete the specified vendor user.
	 *
	 * @return void
	 * @param loginID java.lang.String
	 * @exception java.lang.Exception
	 */
	public void deleteVendorUser(String loginID)
			throws Exception
	{
		deleteUser(loginID, false);
	}
	/**
	 * Modifies the specified broker user in the LDAP database.
	 *
	 * @return void
	 * @param loginID java.lang.String
	 * @param firstName java.lang.String
	 * @param lastName java.lang.String
	 * @param middleInitial java.lang.String
	 * @param title java.lang.String
	 * @param phoneNumber java.lang.String
	 * @param emailAddress java.lang.String
	 * @exception java.lang.Exception
	 */
	public void updateBrokerUser(String loginID,
								 String firstName,
								 String lastName,
								 String middleInitial,
								 String title,
								 String phoneNumber,
								 String emailAddress)
			throws Exception
	{
		updateNonRetailUser(loginID,
							firstName,
							lastName,
							middleInitial,
							title,
							phoneNumber,
							emailAddress);
	}
	/**
	 * Modifies the specified non-retail user in the LDAP database.
	 * Use updateUser() to modify retail users.
	 *
	 * @return void
	 * @param loginID java.lang.String
	 * @param firstName java.lang.String
	 * @param lastName java.lang.String
	 * @param middleInitial java.lang.String
	 * @param title java.lang.String
	 * @param phoneNumber java.lang.String
	 * @param emailAddress java.lang.String
	 * @exception java.lang.Exception
	 */
	private void updateNonRetailUser(String loginID,
									String firstName,
									String lastName,
									String middleInitial,
									String title,
									String phoneNumber,
									String emailAddress)
			throws Exception
	{
		final String tPeopleObjectDN = "uid=" + loginID + ",ou=People," + baseDN;
		Hashtable   attrib_set = new Hashtable(20);
		String      tDN;

		// Make sure user exists.
		if (! ldapDir.existObject(tPeopleObjectDN)) {
			String tMsg = "Unable to update user in LDAP database.  User doesn't exist." +
						  "  User: \"" + loginID + "\"";
			throw new Exception(tMsg);
		}

		// Update the People Object.
		attrib_set.put("givenname", new String[] {firstName});
		attrib_set.put("sn", new String[] {lastName});
		attrib_set.put("initials", new String[] {middleInitial});
		attrib_set.put("cn", new String[] {firstName + " " + lastName});
		attrib_set.put("title", new String[] {title});
		attrib_set.put("telephoneNumber", new String[] {phoneNumber});
		if (emailAddress != null)
		{
			attrib_set.put("mail", new String[] {emailAddress});
		}
		ldapDir.updateObject(tPeopleObjectDN, attrib_set);
	}
	/**
	 * Modifies the specified vendor user in the LDAP database.
	 *
	 * @return void
	 * @param loginID java.lang.String
	 * @param firstName java.lang.String
	 * @param lastName java.lang.String
	 * @param middleInitial java.lang.String
	 * @param title java.lang.String
	 * @param phoneNumber java.lang.String
	 * @param emailAddress java.lang.String
	 * @exception java.lang.Exception
	 */
	public void updateVendorUser(String loginID,
								 String firstName,
								 String lastName,
								 String middleInitial,
								 String title,
								 String phoneNumber,
								 String emailAddress)
			throws Exception
	{
		updateNonRetailUser(loginID,
							firstName,
							lastName,
							middleInitial,
							title,
							phoneNumber,
							emailAddress);
	}
	/**
	 * Counts how many users in the broker have access to User Admin.
	 *
	 * @return
	 *      int - Number of users with access.
	 * @param brokerNumber java.lang.String
	 * @exception java.lang.Exception
	 */
	public int getBrokerUserAdminCount(String brokerNumber)
			throws Exception
	{
		final String tUserAdminUsersDN = "cn=Administrator,ou=BrokerUserAdmin,ou=Applications," + baseDN;
		String	tUserDN;
        int		tCount = 0;

		Vector userDNList = getUserDNsOfBroker(brokerNumber);

		final int vectorSize = userDNList.size();
		for (int x = 0; x < vectorSize; x++) {
			tUserDN = (String) userDNList.elementAt(x);

			// Check if the user has access to User Admin.
			if (ldapDir.existAttributeInObject(tUserAdminUsersDN,
											   "uniquemember",
											   tUserDN)) {
				tCount++;
			}
		}

		return tCount;
	}
	/**
	 * Counts how many users are in the specified broker.
	 *
	 * @return
	 *      int - Number of users in the specified broker.
	 * @param brokerNumber java.lang.String
	 * @exception java.lang.Exception
	 */
	public int getUserCountForBroker(String brokerNumber)
			throws Exception
	{
		Vector userDNList = getUserDNsOfBroker(brokerNumber);

		return userDNList.size();
	}
	/**
	 * Gets a list of user DNs for each user in the specified object.
	 *
	 * @return
	 *      Vector - Vector of String objects.
	 *               The vector may be empty but never null.
	 * @param objectOU java.lang.String
	 * @param objectCN java.lang.String
	 * @exception java.lang.Exception
	 */
	private Vector getUserDNsOfObject(String objectOU,
										String objectCN)
			throws Exception
	{
		final Name	tPeopleBaseDNName = ldapDir.convertToName("ou=People," + baseDN);
		Vector		ret = new Vector();
		Hashtable	hashT;
		Object[]	attrib_value;
		String		tDN;
		Name		tDNName;

		tDN = "cn=" + objectCN + ",ou=" + objectOU + "," + baseDN;
		if (((hashT = ldapDir.read(tDN, new String[] {"uniquemember"})) != null) &&
			((attrib_value = (Object[]) hashT.get("uniquemember")) != null)) {

			// Look at each member and pull out only the people.
			for (int i = 0; i < attrib_value.length; i++) {	
				tDN = attrib_value[i].toString();
				tDNName = ldapDir.convertToName(tDN);

				// Ignore everything except people.
				if (tDNName.startsWith(tPeopleBaseDNName)) {
					ret.addElement(tDN);
				}
			}
		}

		return ret;
	}
	/**
	 * Gets a list of user DNs for each user in the specified broker.
	 *
	 * @return
	 *      Vector - Vector of String objects.
	 *               The vector may be empty but never null.
	 * @param brokerNumber java.lang.String
	 * @exception java.lang.Exception
	 */
	private Vector getUserDNsOfBroker(String brokerNumber)
			throws Exception
	{
		return(getUserDNsOfObject("Brokers", brokerNumber));
	}
	/**
	 * Gets a list of user DNs for each user in the specified store.
	 *
	 * @return
	 *      Vector - Vector of String objects.
	 *               The vector may be empty but never null.
	 * @param storeNumber java.lang.String
	 * @exception java.lang.Exception
	 */
	private Vector getUserDNsOfStore(String storeNumber)
			throws Exception
	{
		return(getUserDNsOfObject("Stores", storeNumber));
	}
	/**
	 * Gets a list of user DNs for each user in the specified vendor.
	 *
	 * @return
	 *      Vector - Vector of String objects.
	 *               The vector may be empty but never null.
	 * @param vendorID java.lang.String
	 * @exception java.lang.Exception
	 */
	// Jan 26, 2003 - Modified for Vendor Conversion		
	// Note : No change is required.  Methods calling this 	getUserDNsOfVendor() will do the conversion.
	private Vector getUserDNsOfVendor(String vendorID)
			throws Exception
	{
		return(getUserDNsOfObject("Vendors", vendorID));
	}
	/**
	 * Gets a list of user DNs for each user in the specified carrier.
	 *
	 * @return
	 *      Vector - Vector of String objects.
	 *               The vector may be empty but never null.
	 * @param carrierID java.lang.String
	 * @exception java.lang.Exception
	 */
	private Vector getUserDNsOfCarrier(String carrierID)
			throws Exception
	{
		return(getUserDNsOfObject("Carriers", carrierID));
	}
	/**
	 * Counts how many users in the vendor have access to User Admin.
	 *
	 * @return
	 *      int - Number of users with access.
	 * @param vendorID java.lang.String
	 * @exception java.lang.Exception
	 */
	public int getVendorUserAdminCount(String vendorID)
			throws Exception
	{
		final String tUserAdminUsersDN = "cn=Administrator,ou=VendorUserAdmin,ou=Applications," + baseDN;
		String	tUserDN;
        int		tCount = 0;

		Vector userDNList = getUserDNsOfVendor(vendorID);

		final int vectorSize = userDNList.size();
		for (int x = 0; x < vectorSize; x++) {
			tUserDN = (String) userDNList.elementAt(x);

			// Check if the user has access to User Admin.
			if (ldapDir.existAttributeInObject(tUserAdminUsersDN,
											   "uniquemember",
											   tUserDN)) {
				tCount++;
			}
		}

		return tCount;
	}
	/**
	 * Counts how many users are in the specified vendor.
	 *
	 * @return
	 *      int - Number of users in the specified vendor.
	 * @param vendorID java.lang.String
	 * @exception java.lang.Exception
	 */
	// Jan 26, 2003 - Modified for Vendor Conversion		
	public int getUserCountForVendor(String vendorID)
			throws Exception
	{
		String 			originalVendorNumber = "";
		originalVendorNumber = vendorID;		
		vendorID = convertToInternalVendorNbr(vendorID);
			
		Vector userDNList = getUserDNsOfVendor(vendorID);

		return userDNList.size();
	}

	/**
	 * Gets details about the specified Carrier.
	 * 
	 * @return Carrier
	 * @param carrierID java.lang.String
	 * @exception Exception
	 */
	public Carrier getCarrierDetail(String carrierID)
			throws Exception
	{
		final String	tDN = "uid=" + carrierID + ",ou=Carriers," + baseDN;
		Carrier			ret;
		Hashtable		hashT;

		// Read all the fields from the person object.
		if ((hashT = ldapDir.read(tDN, null)) != null)
		{
			ret = new Carrier(getAttributeValue(hashT, "uid"), // carrierID
							getAttributeValue(hashT, "sn"), // carrierName
							getAttributeValue(hashT, "mail"), // emailAddress
							getAttributeValue(hashT, "street"), // address
							getAttributeValue(hashT, "homePostalAddress"), // city
							getAttributeValue(hashT, "st"), // stateCode
							getAttributeValue(hashT, "postalCode"), // zipCode
							getAttributeValue(hashT, "telephoneNumber"), // phoneNumber
							getAttributeValue(hashT, "facsimileTelephoneNumber")); // faxNumber
		}
		else
		{
			String tMsg = "Error in getCarrierDetail().  Carrier: " + carrierID + " doesn't exist in the LDAP directory.";
			throw new Exception(tMsg);
		}

		return ret;
	}

	/**
	 * Adds the specified carrier to the LDAP database.
	 * The default carrier user "Admin{CarrierID}" is
	 * also created.
	 * Returns the password for the newly added default
	 * carrier user.
	 * 
	 * @return java.lang.String
	 * @param carrierID java.lang.String
	 * @param name java.lang.String
	 * @param address java.lang.String
	 * @param city java.lang.String
	 * @param state java.lang.String
	 * @param zip java.lang.String
	 * @param phoneNumber java.lang.String
	 * @param faxNumber java.lang.String
	 * @param emailAddress java.lang.String
	 * @exception java.lang.Exception
	 */
	public String addCarrier(String carrierID,
							String name,
							String address,
							String city,
							String state,
							String zip,
							String phoneNumber,
							String faxNumber,
							String emailAddress)
			throws Exception
	{
		final String	carrierDN = "uid=" + carrierID + ",ou=Carriers," + baseDN;
		final String	carrierGroupDN = "cn=" + carrierID + ",ou=Carriers," + baseDN;
		Hashtable		attrib_set = new Hashtable(20);
		String			tDN;
		String			tFilter;
		Vector			appList;
		String			tPassword;

		// Check for a duplicate carrier.
		if (existUserAnywhere(carrierID))
		{
			String tMsg = "Duplicate Carrier ID error.  Carrier ID: \"" + carrierID + "\" already exists in the system.";
			throw new Exception(tMsg);
		}

		// Add the Carrier object.
		attrib_set.put("objectclass", new String[] {"top", "person", "organizationalPerson", "inetOrgPerson"});
		attrib_set.put("givenname", new String[] {"Carrier"});
		attrib_set.put("sn", new String[] {name});
		attrib_set.put("cn", new String[] {"Carrier " + name});
		attrib_set.put("mail", new String[] {emailAddress});
		attrib_set.put("street", new String[] {address});
		attrib_set.put("homePostalAddress", new String[] {city});
		attrib_set.put("st", new String[] {state});
		attrib_set.put("postalCode", new String[] {zip});
		attrib_set.put("telephoneNumber", new String[] {phoneNumber});
		attrib_set.put("facsimileTelephoneNumber", new String[] {faxNumber});
		ldapDir.addObject(carrierDN, attrib_set);

		// Write a record to the audit log.
		eventLog.writeLog("Carrier", "Add", "\"" + carrierID + "\"");

		// Add the Carrier Group object.
		attrib_set.clear();
		attrib_set.put("objectclass", new String[] {"top", "groupofuniquenames"});
		ldapDir.addObject(carrierGroupDN, attrib_set);

		// Assign the carrier to all default and forced "carrier" applications.
		tDN = "ou=ApplicationList,ou=Applications," + baseDN;
		tFilter = "(&(preferredlanguage=carrier)(|(physicalDeliveryOfficeName=default)(physicalDeliveryOfficeName=forced)))";
		if ((appList = ldapDir.search(tDN, tFilter, true)) != null)
		{
			final int vectorSize = appList.size();
			for (int x = 0; x < vectorSize; x++)
			{
				tDN = (String) appList.elementAt(x);

				// Add the application's DN to the CarrierGroup object.
				ldapDir.addAttribute(carrierGroupDN, "uniqueMember", new String[] {tDN});
			}
		}

		// Create the initial user for the carrier.
		final String tInitialUser = "Admin" + carrierID;
		tPassword = addCarrierUser(tInitialUser, carrierID, "Temporary",
									"Administrator", "", "Initial Administrative User",
									phoneNumber, "");

		// Flag the user as system generated.
		final String tPeopleObjectDN = "uid=" + tInitialUser + ",ou=People," + baseDN;
		attrib_set.clear();
		attrib_set.put("preferredDeliveryMethod", new String[] {"System Generated"});
		ldapDir.updateObject(tPeopleObjectDN, attrib_set);

		// Give the the initial user rights to the carrier user administration application.
		addUserToRole(tInitialUser, "CarrierUserAdmin", "Administrator");

		return tPassword;
	}

	/**
	 * Updates the basic information for a carrier.
	 *
	 * @return void
	 * @param carrierID java.lang.String
	 * @param name java.lang.String
	 * @param address java.lang.String
	 * @param city java.lang.String
	 * @param state java.lang.String
	 * @param zip java.lang.String
	 * @param phoneNumber java.lang.String
	 * @param faxNumber java.lang.String
	 * @param emailAddress java.lang.String
	 * @exception java.lang.Exception
	 */
	public void updateCarrier(String carrierID,
								String name,
								String address,
								String city,
								String state,
								String zip,
								String phoneNumber,
								String faxNumber,
								String emailAddress)
			throws Exception
	{
		final String	carrierObjectDN = "uid=" + carrierID + ",ou=Carriers," + baseDN;
		Hashtable		attrib_set = new Hashtable(20);

		// Make sure the specified carrier exists.
		if (! ldapDir.existObject(carrierObjectDN))
		{
			String tMsg = "Unable to update carrier.  Carrier: \"" + carrierID + "\" doesn't exist in LDAP database.";
			throw new Exception(tMsg);
		}

		// Update the carrier Object.
		attrib_set.put("sn", new String[] {name});
		attrib_set.put("cn", new String[] {"Carrier " + name});
		attrib_set.put("mail", new String[] {emailAddress});
		attrib_set.put("street", new String[] {address});
		attrib_set.put("homePostalAddress", new String[] {city});
		attrib_set.put("st", new String[] {state});
		attrib_set.put("postalCode", new String[] {zip});
		attrib_set.put("telephoneNumber", new String[] {phoneNumber});
		attrib_set.put("facsimileTelephoneNumber", new String[] {faxNumber});
		ldapDir.updateObject(carrierObjectDN, attrib_set);
	}

	/**
	 * Checks if the specified carrier exists in the database.
	 *
	 * @return boolean
	 * @param carrierID java.lang.String
	 * @exception java.lang.Exception
	 */
	public boolean existCarrier(String carrierID)
			throws Exception
	{
		final String	tDN = "uid=" + carrierID + ",ou=Carriers," + baseDN;
		boolean			rc;

		rc = ldapDir.existObject(tDN);

		return rc;
	}

	/**
	 * Removes the carrier and all the carrier's users from the
	 * database.
	 * 
	 * @return void
	 * @param carrierID java.lang.String
	 * @exception java.lang.Exception
	 */
	public void deleteCarrier(String carrierID)
			throws Exception
	{
		final String	tPeopleBaseDN = "ou=People," + baseDN;
		final Name		tPeopleBaseDNName = ldapDir.convertToName(tPeopleBaseDN);
		Vector			vector1;
		Hashtable		hashT1;
		Hashtable		hashT2;
		Object[]		attrib_value1;
		Object[]		attrib_value2;
		StoreAlias		tAlias;
		String			tDN;
		Name			tDNName;

		// Delete all the carrier's users.
		tDN = "cn=" + carrierID + ",ou=Carriers," + baseDN;
		if (((hashT1 = ldapDir.read(tDN, new String[] {"uniquemember"})) != null) &&
			((attrib_value1 = (Object[]) hashT1.get("uniquemember")) != null))
		{
			// Look at each member and pull out the users.
			for (int i = 0; i < attrib_value1.length; i++)
			{
				tDN = attrib_value1[i].toString();
				tDNName = ldapDir.convertToName(tDN);

				// Delete all the carrier's users.
				if ((tDNName.startsWith(tPeopleBaseDNName)) &&
					((hashT2 = ldapDir.read(tDN, new String[] {"uid"})) != null) &&
					((attrib_value2 = (Object[]) hashT2.get("uid")) != null))
				{
					// Delete the user.
					deleteCarrierUser(attrib_value2[0].toString());
				}
			}
		}

		// Delete the CarrierGroup Object.
		tDN = "cn=" + carrierID + ",ou=Carriers," + baseDN;
		ldapDir.deleteObject(tDN);

		// Delete the Carrier Object.
		tDN = "uid=" + carrierID + ",ou=Carriers," + baseDN;
		ldapDir.deleteObject(tDN);

		// Write a record to the audit log.
		eventLog.writeLog("Carrier", "Delete", "\"" + carrierID + "\"");
	}

	/**
	 * Adds the specified carrier user to the LDAP database.
	 * Returns the password for the newly added user.
	 * 
	 * @return java.lang.String
	 * @param loginID java.lang.String
	 * @param carrierID java.lang.String
	 * @param firstName java.lang.String
	 * @param lastName java.lang.String
	 * @param middleInitial java.lang.String
	 * @param title java.lang.String
	 * @param phoneNumber java.lang.String
	 * @param emailAddress java.lang.String
	 * @exception java.lang.Exception
	 */
	public String addCarrierUser(String loginID,
								String carrierID,
								String firstName,
								String lastName,
								String middleInitial,
								String title,
								String phoneNumber,
								String emailAddress)
			throws Exception
	{
		final String	tPeopleObjectDN = "uid=" + loginID + ",ou=People," + baseDN;
		Hashtable		attrib_set = new Hashtable(20);
		String			password;
		String			tDN;

		// Check for a duplicate user.
		if (existUser(loginID, false))
		{
			String tMsg = "Duplicate Login ID error.  Login ID: \"" + loginID + "\" is already being used.";
			throw new Exception(tMsg);
		}

		// Make sure the specified carrier exists.
		if (! existCarrier(carrierID))
		{
			String tMsg = "Carrier: \"" + carrierID + "\" doesn't exist.";
			throw new Exception(tMsg);
		}

		// Get a password for the user.
		password = generatePassword();

		// Add the People Object.
		attrib_set.put("objectclass", new String[] {"top", "person", "organizationalPerson", "inetOrgPerson"});
		attrib_set.put("businessCategory", new String[] {"person"});
		attrib_set.put("roomNumber", new String[] {carrierID});
		attrib_set.put("givenname", new String[] {firstName});
		attrib_set.put("sn", new String[] {lastName});
		attrib_set.put("initials", new String[] {middleInitial});
		attrib_set.put("cn", new String[] {firstName + " " + lastName});
		attrib_set.put("title", new String[] {title});
		attrib_set.put("telephoneNumber", new String[] {phoneNumber});
		attrib_set.put("destinationIndicator", new String[] {"Carrier"});
		attrib_set.put("userPassword", new String[] {password});
		attrib_set.put("carLicense", new String[] {"16777216"});
		attrib_set.put("mail", new String[] {emailAddress});
		ldapDir.addObject(tPeopleObjectDN, attrib_set);

		// Add the user to the carrier's group.
		tDN = "cn=" + carrierID + ",ou=Carriers," + baseDN;
		ldapDir.addAttribute(tDN, "uniqueMember", new String[] {tPeopleObjectDN});

		// Write a record to the audit log.
		eventLog.writeLog("User", "Add", "\"" + loginID + "\"");

		return password;
	}

	/**
	 * Delete the specified carrier user.
	 *
	 * @return void
	 * @param loginID java.lang.String
	 * @exception java.lang.Exception
	 */
	public void deleteCarrierUser(String loginID)
			throws Exception
	{
		deleteUser(loginID, false);
	}

	/**
	 * Modifies the specified carrier user in the LDAP database.
	 *
	 * @return void
	 * @param loginID java.lang.String
	 * @param firstName java.lang.String
	 * @param lastName java.lang.String
	 * @param middleInitial java.lang.String
	 * @param title java.lang.String
	 * @param phoneNumber java.lang.String
	 * @param emailAddress java.lang.String
	 * @exception java.lang.Exception
	 */
	public void updateCarrierUser(String loginID,
								String firstName,
								String lastName,
								String middleInitial,
								String title,
								String phoneNumber,
								String emailAddress)
			throws Exception
	{
		updateNonRetailUser(loginID,
							firstName,
							lastName,
							middleInitial,
							title,
							phoneNumber,
							emailAddress);
	}

	/**
	 * Counts how many users are in the specified carrier.
	 *
	 * @return
	 *      int - Number of users in the specified carrier.
	 * @param carrierID java.lang.String
	 * @exception java.lang.Exception
	 */
	public int getUserCountForCarrier(String carrierID)
			throws Exception
	{
		Vector userDNList = getUserDNsOfCarrier(carrierID);

		return userDNList.size();
	}

	/**
	 * Counts how many users in a carrier have access to User Admin.
	 *
	 * @return
	 *      int - Number of users with access.
	 * @param carrierID java.lang.String
	 * @exception java.lang.Exception
	 */
	public int getCarrierUserAdminCount(String carrierID)
			throws Exception
	{
		final String tUserAdminUsersDN = "cn=Administrator,ou=CarrierUserAdmin,ou=Applications," + baseDN;
		String	tUserDN;
        int		tCount = 0;

		Vector userDNList = getUserDNsOfCarrier(carrierID);

		final int vectorSize = userDNList.size();
		for (int x = 0; x < vectorSize; x++) {
			tUserDN = (String) userDNList.elementAt(x);

			// Check if the user has access to User Admin.
			if (ldapDir.existAttributeInObject(tUserAdminUsersDN,
											   "uniquemember",
											   tUserDN)) {
				tCount++;
			}
		}

		return tCount;
	}

	/**
	 * Gets a list of users that are assigned to the specified carrier.
	 * 
	 * @return
	 *      Vector - Vector of UserName objects that are in the carrier.
	 *               The vector may be empty but never null.
	 * @param carrierID java.lang.String
	 * @exception java.lang.Exception
	 */
	public Vector getUsersOfCarrier(String carrierID)
			throws Exception
	{
		Vector      ret = new Vector();
		Hashtable   hashT2;
		UserName	user;
		String		tUserDN;

		Vector userDNList = getUserDNsOfCarrier(carrierID);
		final int vectorSize = userDNList.size();

		for (int x = 0; x < vectorSize; x++)
		{
			tUserDN = (String) userDNList.elementAt(x);

			// Read all the fields from the object.
			if ((hashT2 = ldapDir.read(tUserDN, new String[] {"uid","givenName","initials","sn","cn"})) != null)
			{
				user = new UserName(getAttributeValue(hashT2, "uid"),
									getAttributeValue(hashT2, "givenName"),
									getAttributeValue(hashT2, "initials"),
									getAttributeValue(hashT2, "sn"),
									getAttributeValue(hashT2, "cn"));
				ret.addElement(user);
			}
		}

		ret.trimToSize();
		VectorFuncs.sort(ret);

		return ret;
	}

	/**
	 * Gets a list of applications that the specified carrier is using.
	 * 
	 * @return Vector of Application objects.  The
	 *         vector may be empty but never null.
	 * @param carrierID java.lang.String
	 * @exception java.lang.Exception
	 */
	public Vector getAppListForCarrier(String carrierID)
			throws Exception
	{
		final String    tApplicationBaseDN = "ou=ApplicationList,ou=Applications," + baseDN;
		final Name      tApplicationBaseDNName = ldapDir.convertToName(tApplicationBaseDN);
		Vector      ret = new Vector();
		Hashtable   hashT;
		Hashtable   hashT2;
		Application application;
		Object[]    attrib_value;
		String      tDN;
		Name        tDNName;

		tDN = "cn=" + carrierID + ",ou=Carriers," + baseDN;
		if (((hashT = ldapDir.read(tDN, new String[] {"uniquemember"})) != null) &&
			((attrib_value = (Object[]) hashT.get("uniquemember")) != null))
		{
			// Look at each member and pull out only the applications.
			for (int i = 0; i < attrib_value.length; i++)
			{	
				tDN = attrib_value[i].toString();
				tDNName = ldapDir.convertToName(tDN);

				// Ignore everything except applications.
				if (tDNName.startsWith(tApplicationBaseDNName))
				{
					// Read all the fields from the object.
					if ((hashT2 = ldapDir.read(tDN, new String[] {"uid", "sn", "physicalDeliveryOfficeName"})) != null)
					{
						application = new Application(getAttributeValue(hashT2, "uid"),
														getAttributeValue(hashT2, "sn"),
														getAttributeValue(hashT2, "physicalDeliveryOfficeName").equalsIgnoreCase("forced"),
														getAttributeValue(hashT2, "physicalDeliveryOfficeName").equalsIgnoreCase("default"));
						ret.addElement(application);
					}
				}
			}
		}

		ret.trimToSize();
		VectorFuncs.sort(ret);

		return ret;
	}

	/**
	 * Gives the carrier access to an application.
	 * NOTE... The appName parameter must be the "short"
	 *         version of the app name.
	 * 
	 * @return void
	 * @param carrierID java.lang.String
	 * @param appName java.lang.String
	 * @exception java.lang.Exception
	 */
	public void addAppToCarrier(String carrierID,
								String appName)
			throws Exception
	{
		final String tAppListObjectDN = "uid=" + appName + ",ou=ApplicationList,ou=Applications," + baseDN;
		final String tCarrierObjectDN = "cn=" + carrierID + ",ou=Carriers," + baseDN;

		// Make sure the specified carrier exists.
		if (! ldapDir.existObject(tCarrierObjectDN))
		{
			String tMsg = "Unable to add application to carrier.  The carrier doesn't exist." +
							"  Carrier: \"" + carrierID + "\"" +
							"  Application: \"" + appName + "\"";
			throw new Exception(tMsg);
		}

		// Make sure the specified application exists.
		if (! ldapDir.existObject(tAppListObjectDN))
		{
			String tMsg = "Unable to add application to carrier.  Application doesn't exist." +
							"  Carrier: \"" + carrierID + "\"" +
							"  Application: \"" + appName + "\"";
			throw new Exception(tMsg);
		}

		// Add the application to the carrier (if it's not there already).
		if (! ldapDir.existAttributeInObject(tCarrierObjectDN, "uniqueMember", tAppListObjectDN))
		{
			ldapDir.addAttribute(tCarrierObjectDN, "uniqueMember", new String[] {tAppListObjectDN});

			// Write a record to the audit log.
			eventLog.writeLog("CarrierApp", "Add", "\"" + appName + "\" to \"" + carrierID + "\"");
		}
	}

	/**
	 * Removes access to an application.  Also removes access to the app
	 * for any users at the carrier that were using the application.
	 * 
	 * @return void
	 * @param carrierID java.lang.String
	 * @param appName java.lang.String
	 * @exception java.lang.Exception
	 */
	public void deleteAppFromCarrier(String carrierID,
										String appName)
			throws Exception
	{
		final String tAppListObjectDN = "uid=" + appName + ",ou=ApplicationList,ou=Applications," + baseDN;
		final String tCarrierObjectDN = "cn=" + carrierID + ",ou=Carriers," + baseDN;
		Vector			vector1;
		Vector			vector2;
		UserName		tUserName;
		ApplicationRole	tAppRole;
		String			loginID;

		// First delete access to roles of the app for all users at the carrier.
		vector1 = getUsersOfCarrier(carrierID);
		final int vector1Size = vector1.size();

		for (int x1 = 0; x1 < vector1Size; x1++)
		{
			tUserName = (UserName) vector1.elementAt(x1);
			loginID = tUserName.getLoginID();

			vector2 = getAppRolesOfUser(loginID, appName);
			final int vector2Size = vector2.size();

			for (int x2 = 0; x2 < vector2Size; x2++)
			{
				tAppRole = (ApplicationRole) vector2.elementAt(x2);
				deleteUserFromRole(loginID, appName, tAppRole.getName());
			}
		}

		// Remove the app from the carrier.
		if (ldapDir.existAttributeInObject(tCarrierObjectDN, "uniqueMember", tAppListObjectDN))
		{
			ldapDir.deleteAttribute(tCarrierObjectDN, "uniqueMember", new String[] {tAppListObjectDN});

			// Write a record to the audit log.
			eventLog.writeLog("CarrierApp", "Delete", "\"" + appName + "\" from \"" + carrierID + "\"");
		}
	}

	/**
	 * Checks to see if the specified user has access to the
	 * specified carrier.  Returns a boolean with the result.
	 *
	 * @return boolean
	 * @param loginID java.lang.String
	 * @param carrierID java.lang.String
	 * @exception java.lang.Exception
	 */
	public boolean checkCarrierAccess(String loginID,
										String carrierID)
			throws Exception
	{
		UserDetail userDetail;

		// Make sure the user exists.
		if (! existUser(loginID))
		{
			return false;
		}

		// Get the user details.
		userDetail = getUserDetail(loginID, 0);

		/*
		 * If the user is an admin user or a store user, always
		 * return true (they have access to all carriers).
		 */
		if ((userDetail.getUserType().equals("Admin")) ||
			(userDetail.getUserType().equals("Store")))
		{
			return true;
		}

		/*
		 * If the user is a vendor or broker user, always
		 * return false (they never have access to carriers).
		 */
		else if ((userDetail.getUserType().equals("Vendor")) ||
			(userDetail.getUserType().equals("Broker")))
		{
			return false;
		}

		/*
		 * If the user is a carrier user, return true if the passed
		 * carrierID matches the users carrierID.
		 */
		else if (userDetail.getUserType().equals("Carrier"))
		{
			if (userDetail.getCarrierID().equalsIgnoreCase(carrierID))
			{
				return true;
			}
		}

		return false;
	}

	/**
	 * Gets a list of all the carriers.
	 * 
	 * @return
	 *      Vector - Vector of Carrier objects.
	 *               The vector may be empty but never null.
	 * @param carrierNameFilter java.lang.String
	 * @exception java.lang.Exception
	 */
	public Vector getCarrierList(String carrierNameFilter)
			throws Exception
	{
		Vector		ret = new Vector();
		Vector		vector1, vector2;
		Hashtable	hashT1;
		Carrier		carrier;

		final String tDN = "ou=Carriers," + baseDN;
		final String tFilter = "(&(uid=*)" +
								"(sn=" + (carrierNameFilter != null ?
											carrierNameFilter : "") + "*))";

		// Get a list of all the carriers that match the filter.
		if ((vector1 = ldapDir.search(tDN, tFilter, null, true)) != null)
		{
			final int vector1Size = vector1.size();
			for (int x1 = 0; x1 < vector1Size; x1++)
			{
				vector2 = (Vector) vector1.elementAt(x1);
				hashT1 = (Hashtable) vector2.elementAt(1);

				carrier = new Carrier(getAttributeValue(hashT1, "uid"), // carrieID
									getAttributeValue(hashT1, "sn"), // carrieName
									getAttributeValue(hashT1, "mail"), // emailAddress
								 	getAttributeValue(hashT1, "street"), // address
								 	getAttributeValue(hashT1, "homePostalAddress"), // city
								 	getAttributeValue(hashT1, "st"), // stateCode
								 	getAttributeValue(hashT1, "postalCode"), // zipCode
								 	getAttributeValue(hashT1, "telephoneNumber"), // phoneNumber
								 	getAttributeValue(hashT1, "facsimileTelephoneNumber")); // faxNumber

				ret.addElement(carrier);
			}
		}

		ret.trimToSize();

		Carrier.sortByCarrierName(ret);

		return ret;
	}

	/**
	 * Gets a list of Distribution Groups that the broker has access to.
	 * 
	 * @return Vector of DistributionGroup objects that the user has
	 *		has access to.  The vector may be empty but never null.
	 * @param brokerNbr java.lang.String
	 * @exception java.lang.Exception
	 */
	public Vector getDistributionGroupsOfBroker(String brokerNbr)
			throws Exception
	{
		String dn = "cn="+brokerNbr+",ou=Brokers," + baseDN;
		return(getDistributionGroupsOfSupplier(dn));
	}
	/**
	 * Gets a list of Distribution Groups that the vendor has access to.
	 * 
	 * @return Vector of DistributionGroup objects that the user has
	 *		has access to.  The vector may be empty but never null.
	 * @param vendorNbr java.lang.String
	 * @exception java.lang.Exception
	 */
	public Vector getDistributionGroupsOfVendor(String vendorNbr)
			throws Exception
	{
		vendorNbr = convertToInternalVendorNbr(vendorNbr);
		String dn = "cn="+vendorNbr+",ou=Vendors,"+baseDN;
		return(getDistributionGroupsOfSupplier(dn));
	}

	private Vector getDistributionGroupsOfSupplier(String dn)
			throws Exception
	{
		final String    tDistributionGroupBaseDN = "ou=DistributionGroups,ou=Groups," + baseDN;
		final Name      tDistributionGroupBaseDNName = ldapDir.convertToName(tDistributionGroupBaseDN);
		Vector      ret = new Vector();
		Hashtable   hashT;
		Hashtable   hashT2;
		DistributionGroup group;
		Object[]    attrib_value;
		String      tDN;
		Name        tDNName;

		tDN = dn;
		if (((hashT = ldapDir.read(tDN, new String[] {"uniquemember"})) != null) &&
			((attrib_value = (Object[]) hashT.get("uniquemember")) != null)) 
		{

			// Look at each member and pull out only the vendor groups.
			for (int i = 0; i < attrib_value.length; i++) 
			{	
				tDN = attrib_value[i].toString();
				tDNName = ldapDir.convertToName(tDN);

				// Ignore everything except vendor groups
				if (tDNName.startsWith(tDistributionGroupBaseDNName)) 
				{
					
					if ((hashT2 = ldapDir.read(tDN, new String[] {"cn", "description"})) != null) 
					{
						group  = new DistributionGroup(getAttributeValue(hashT2, "cn"), getAttributeValue(hashT2, "description"));
						
						ret.addElement(group);
					}
				}
			} // end of for
		} // end of if

		ret.trimToSize();
		VectorFuncs.sort(ret);

		return ret;
		
/*		
		Vector ret = new Vector();
		DistributionGroup group;
		Vector vector1, vector2;
		Hashtable hashT1;
		String tDN;
		String tFilter;

		tDN = "ou=DistributionGroups,ou=Groups," + baseDN;
		tFilter = "(uniquemember=" + tUserDN + ")";

		// Get a list of all the Distribution Groups the user is a member of.
		if ((vector1 = ldapDir.search(tDN, tFilter, new String[] {"cn", "description"}, true)) != null) {
			final int vector1Size = vector1.size();
			for (int x1 = 0; x1 < vector1Size; x1++) {
				vector2 = (Vector) vector1.elementAt(x1);
				hashT1 = (Hashtable) vector2.elementAt(1);

				group = new DistributionGroup(getAttributeValue(hashT1, "cn"), getAttributeValue(hashT1, "description"));
				ret.addElement(group);
			}
		}
	  
		ret.trimToSize();
		VectorFuncs.sort(ret);

		return(ret);
*/		
	}

	/**
	 * Gets a list of Distribution Groups that the user has access to.
	 * 
	 * @return Vector of DistributionGroup objects that the user has
	 *		has access to.  The vector may be empty but never null.
	 * @param loginID java.lang.String
	 * @exception java.lang.Exception
	 */
	public Vector getDistributionGroupsOfUser(String loginID)
			throws Exception
	{
		final String tUserDN = "uid=" + loginID + ",ou=People," + baseDN;
		Vector ret = new Vector();
		DistributionGroup group;
		Vector vector1, vector2;
		Hashtable hashT1;
		String tDN;
		String tFilter;

		tDN = "ou=DistributionGroups,ou=Groups," + baseDN;
		tFilter = "(uniquemember=" + tUserDN + ")";

		// Get a list of all the Distribution Groups the user is a member of.
		if ((vector1 = ldapDir.search(tDN, tFilter, new String[] {"cn", "description"}, true)) != null) {
			final int vector1Size = vector1.size();
			for (int x1 = 0; x1 < vector1Size; x1++) {
				vector2 = (Vector) vector1.elementAt(x1);
				hashT1 = (Hashtable) vector2.elementAt(1);

				group = new DistributionGroup(getAttributeValue(hashT1, "cn"), getAttributeValue(hashT1, "description"));
				ret.addElement(group);
			}
		}
	  
		ret.trimToSize();
		VectorFuncs.sort(ret);

		return(ret);
	}

	/**
	 * Gets a list of SVHarbor applications. 
	 * 
	 * @return Vector of String.  The vector may be empty but never null.
	 * @param userId java.lang.String
	 * @exception java.lang.Exception
	 */	
	public Vector getAppListForUser(String userId) throws Exception
	{
		Vector vector1, vector2;
		Vector ret = new Vector();
		String appName = "";
		String tDN;
		String tFilter;
		String appDN = "";
		tDN = "ou=Applications,ou=SVHarbor,o=supervalu.com";
		tFilter = "(uniquemember=uid=" + userId.trim() + ",ou=People," + baseDN + ")";
		
		// Get a list of all the application roles the user is a member of.
		if ((vector1 = ldapDir.search(tDN, tFilter, new String[] {"dn"}, false)) != null) {
			final int vector1Size = vector1.size();
			for (int x1 = 0; x1 < vector1Size; x1++) {
				vector2 = (Vector) vector1.elementAt(x1);
				appDN = (String) vector2.elementAt(0);  //this will contail the DN
				appName = extractApplication(appDN);				
				
				if (!ret.contains(appName))
				{
					ret.addElement(appName);
				}	
			}
		}
		ret.trimToSize();
		
		Collections.sort((List)ret);
		return(ret);
	}	
   /*
	*  This function extracts application names from appDN
	*
	*/
	private String extractApplication(String appDN)	
	{
		String appName = "";
		StringTokenizer t = new StringTokenizer(appDN,",");
		String token = "";
		String tokenStr = "";
		int len = 0;
		while (t.hasMoreTokens())
		{
			token = t.nextToken();
			tokenStr = token.substring(0,2);
			
			if  (tokenStr.equalsIgnoreCase("o=") || tokenStr.equalsIgnoreCase("cn")
		  	  || token.equalsIgnoreCase("ou=Applications")
		  	  || token.equalsIgnoreCase("ou=SVHarbor")
			)
			{
				continue;
			}else
			{			
				len = token.length();
				token = token.substring(3,len);
				
				appName = token;
			}	
		}	
		return appName;
	}
		
	/**
	 * Creates vendor group
	 * 
	 * @return void
	 * @param groupName java.lang.String
	 * @param groupType java.lang.String   'SV' - Supervalu created, 'VN' - Vendor created
	 * @param loginID   java.lang.String   SVHarbor User id of the person logged in
	 * @exception java.lang.Exception
	 */
	
	public void addVendorGroup(String groupName,
							String groupType,
							String loginID)
			throws Exception
	{
		String seeAlso = "uid="+loginID+",ou=People," + baseDN;
		final String tVendorGroupsDN = "cn=" + groupName + ",ou=VendorGroups," + baseDN;
		Hashtable   attrib_set = new Hashtable(10);
		Date        currDate = new Date();
		String      tDN;

		if  (existVendorGroup(groupName))
		{
			String tMsg = "Unable to add vendor group.  Group already exist." +
						  "  Group: \"" + groupName + "\"";
			throw new Exception(tMsg);
		}
		// Add the VendorGroups object.
		attrib_set.put("objectclass", new String[] {"top", "groupofuniquenames"});
		attrib_set.put("businessCategory", new String[] {groupType});
		attrib_set.put("owner", new String[] {loginID});
		attrib_set.put("seeAlso", new String[] {seeAlso});
		attrib_set.put("description", new String[] {groupName});
		ldapDir.addObject(tVendorGroupsDN, attrib_set);

		// Write a record to the audit log.
		eventLog.writeLog("Vendor Group", "Add", "\"" + groupName + "\"" + " Creator " + "\"" + loginID);
	}

	/**
	 * Deletes the specified Vendor Group from LDAP.
	 * 
	 * @return void
	 * @param groupName java.lang.String
	 * @exception java.lang.Exception
	 */
	public void deleteVendorGroup(String groupName)
			throws Exception
	{
		final String tDN = "cn=" + groupName + ",ou=VendorGroups," + baseDN;
		ldapDir.deleteObject(tDN);

		// Write a record to the audit log.
		eventLog.writeLog("Group", "Delete", "\"" + groupName + "\"");
	}

	/**
	 * Adds vendor to a vendor group
	 * 
	 * @return void
	 * @param vendor Vendor
	 * @param vendorGroup java.lang.String
	 * @exception java.lang.Exception
	 */
	// Jan 26, 2003 - Modified for Vendor Conversion		
	public void addVendorToVendorGroup(Vendor vendor, String vendorGroup)
			throws Exception
	{
		String 			originalVendorNumber = "", vendorNumber= "";
		originalVendorNumber = vendor.getVendorID();		
		vendorNumber = convertToInternalVendorNbr(originalVendorNumber);

		
		final String tVendorDN = "uid=" + vendorNumber + ",ou=Vendors," + baseDN;
		final String tVendorGroupDN = "cn=" + vendorGroup + ",ou=VendorGroups," + baseDN;

		//make sure vendor exists
		if  (! existVendor(originalVendorNumber))
		{
			String tMsg = "Unable to add vendor to vendor group.  Vendor doesn't exist." +
						  "  Vendor: \"" + originalVendorNumber + "\"" +
						  "  Group : \"" + vendorGroup + "\"";
			throw new Exception(tMsg);
		}

		
		// Make sure the vendor group exists
		if  (! existVendorGroup(vendorGroup))
		{
			String tMsg = "Unable to add vendor to vendor group.  Vendor group doesn't exist." +
						  "  Vendor: \"" + originalVendorNumber + "\"" +
						  "  Vendor Group : \"" + vendorGroup + "\"";
			throw new Exception(tMsg);
		}

		// Add the vendor to the vendor group 
		if (! ldapDir.existAttributeInObject(tVendorGroupDN, "uniqueMember", tVendorDN)) {
			ldapDir.addAttribute(tVendorGroupDN, "uniqueMember", new String[] {tVendorDN});

			// Write a record to the audit log.
			eventLog.writeLog("VendorsOfVendorGroup", "Add", "vendor \"" + vendorNumber + "\" to Vendor Group \"" + vendorGroup + "\"");
		}
	}

	/**
	 * Gives the user access to a vendor group
	 * 
	 * @return void
	 * @param loginID java.lang.String
	 * @param groupName java.lang.String
	 * @exception java.lang.Exception
	 */
	public void addUserToVendorGroup(String loginID,
							   String groupName)
			throws Exception
	{
		final String tGroupDN = "cn=" + groupName + ",ou=VendorGroups," + baseDN;
		final String tPeopleObjectDN = "uid=" + loginID + ",ou=People," + baseDN;

		// Make sure the specified group exists.
		// Make sure the vendor group exists
		if  (! existVendorGroup(groupName))
		{
			String tMsg = "Unable to add user to group.  Group doesn't exist." +
						  "  User: \"" + loginID + "\"" +
						  "  Group: \"" + groupName + "\"";
			throw new Exception(tMsg);
		}

		// Add the user to the group (if it's not there already).
		if (! ldapDir.existAttributeInObject(tGroupDN, "uniqueMember", tPeopleObjectDN)) {
			ldapDir.addAttribute(tGroupDN, "uniqueMember", new String[] {tPeopleObjectDN});

			// Write a record to the audit log.
			eventLog.writeLog("VendorGroup", "Add", "\"" + loginID + "\" to \"" + groupName + "\"");
		}
	}
	
	/**
	 * Returns a vector containing all VendorGroup objects created by Supervalu Employees
	 * 
	 * @return Vector
	 * @exception java.lang.Exception
	 */
	public Vector getSVVendorGroups()
			throws Exception
	{
			return (getVendorGroups(CbkLdapConstants.SV_CREATED_VENDOR_GROUP, null,null));	
	}		

	/**
	 * Returns a vector of VendorGroup  created by Supervalu Employees
	 * @param groupNameFilter java.lang.String 
	 * @return Vector
	 * @exception java.lang.Exception
	 */

	public Vector getSVVendorGroups(String filter)
			throws Exception
	{
			return (getVendorGroups(CbkLdapConstants.SV_CREATED_VENDOR_GROUP, filter, null));	
	}	

	/**
	 * Returns a vector containing all VendorGroup objects created by vendors
	 * 
	 * @return Vector
	 * @exception java.lang.Exception
	 */
	public Vector getVendorCreatedVendorGroups()
			throws Exception
	{
			return (getVendorGroups(CbkLdapConstants.VENDOR_CREATED_VENDOR_GROUP, null,null));	
	}		

	/**
	 * Returns a vector of VendorGroup created by vendors
	 * @param groupNameFilter java.lang.String 
	 * @return Vector
	 * @exception java.lang.Exception
	 */

	public Vector getVendorCreatedVendorGroups(String filter)
			throws Exception
	{
			return (getVendorGroups(CbkLdapConstants.VENDOR_CREATED_VENDOR_GROUP, filter, null));	
	}	
	
	/**
	 * Returns a vector of VendorGroup created by a user
	 * @param groupType       java.lang.String
	 * @param userIdFilter    java.lang.String
	 * @param groupNameFilter java.lang.String
	 * 
	 * @return Vector
	 * @exception java.lang.Exception
	 */
/*
	public Vector getVendorGroupsCreatedByUser(String type, String userId, String nameFilter)
			throws Exception
	{
			if  (type.equals(SVHarborConstants.VENDOR_CREATED_VENDOR_GROUP)
			||   type.equals(SVHarborConstants.SV_CREATED_VENDOR_GROUP))
			{
				return (getVendorGroups(type, nameFilter, userId));	
			}else
			{
				throw new Exception("Invalid group type");
			}
					
	}	
*/	
	
	private Vector getVendorGroups(String type, String nameFilter, String ownerFilter) throws Exception
	{
		Vector vector1, vector2;
		Vector ret = new Vector();
		VendorGroup group = null;
		Hashtable hashT1;
		String tDN;
		String tFilter;
		String appDN = "";
		tDN = "ou=VendorGroups,ou=SVHarbor,o=supervalu.com";

		if  (ownerFilter == null)
		{
			ownerFilter = "";
		}
		if  (nameFilter == null)
		{
			nameFilter = "";
		}
		
				
		tFilter = "(&(businessCategory="+ type + ")";
		
		nameFilter  = nameFilter.trim() + "*";
		ownerFilter = ownerFilter.trim() + "*";
		
		tFilter = tFilter 
		         + " (cn="+ nameFilter + ")"
		         + " (owner="+ ownerFilter + "))"
				;
		if ((vector1 = ldapDir.search(tDN, tFilter, new String[] {"dn","cn","businessCategory", "owner"}, false)) != null) 
		{
			final int vector1Size = vector1.size();
			for (int x1 = 0; x1 < vector1Size; x1++) {
				vector2 = (Vector) vector1.elementAt(x1);
				hashT1 = (Hashtable) vector2.elementAt(1);
				group  = new VendorGroup((String) getAttributeValue(hashT1,"cn")
										,(String) getAttributeValue(hashT1,"businessCategory")
										,(String) getAttributeValue(hashT1,"owner")
										);		
										
				ret.addElement(group);
			}
		}
		return(ret);
	}				

	/**
	 * Returns VendorGroup details object 
	 * @param  vendorGroupName    java.lang.String 
	 * @return VendorGroup object
	 * @exception java.lang.Exception
	 */
	public VendorGroup getVendorGroupDetail(String name) throws Exception
	{
		if  (!existVendorGroup(name))
		{
			throw new Exception("Invalid Vendor Grouop");
		}	
		Vector vector1, vector2;
		Vector ret = new Vector();
		VendorGroup group = null;
		Hashtable hashT1;
		String tDN;
		String tFilter;
		String appDN = "";
		tDN = "ou=VendorGroups," + baseDN;

						
		tFilter =  "(cn="+ name.trim() + ")";
				;
		if ((vector1 = ldapDir.search(tDN, tFilter, new String[] {"dn","cn","businessCategory", "owner"}, false)) != null) 
		{
			final int vector1Size = vector1.size();
			if  (vector1Size >= 0)
			{
				vector2 = (Vector) vector1.elementAt(0);
				hashT1 = (Hashtable) vector2.elementAt(1);
				group  = new VendorGroup((String) getAttributeValue(hashT1,"cn")
										,(String) getAttributeValue(hashT1,"businessCategory")
										,(String) getAttributeValue(hashT1,"owner")
										);		
										
			}
		}
		return(group);
	}				

	/**
	 * Returns a vector of VendorGroup objects that are assigned to a vendor 
	 * @param vendorNbr    java.lang.String 
	 * @return Vector
	 * @exception java.lang.Exception
	 */

	public Vector getVendorGroupsOfVendor(String vendorNbr)
			throws Exception
	{
		vendorNbr = convertToInternalVendorNbr(vendorNbr);
		return (getVendorGroups("cn="+vendorNbr.trim() + ",ou=Vendors," + baseDN));		
	}	

	/**
	 * Returns a vector of VendorGroup objects that are assigned to a broker
	 * @param brokerNbr    java.lang.String 
	 * @return Vector
	 * @exception java.lang.Exception
	 */
	public Vector getVendorGroupsOfBroker(String brokerNbr)
			throws Exception
	{
			return (getVendorGroups("cn="+brokerNbr.trim() + ",ou=Brokers," + baseDN));
	}	

	private Vector getVendorGroups(String dn) 
			throws Exception
	{
		final String    tVendorGroupBaseDN = "ou=VendorGroups," + baseDN;
		final Name      tVendorGroupBaseDNName = ldapDir.convertToName(tVendorGroupBaseDN);
		Vector      ret = new Vector();
		Hashtable   hashT;
		Hashtable   hashT2;
		VendorGroup group;
		Object[]    attrib_value;
		String      tDN;
		Name        tDNName;

		tDN = dn;
		if (((hashT = ldapDir.read(tDN, new String[] {"uniquemember"})) != null) &&
			((attrib_value = (Object[]) hashT.get("uniquemember")) != null)) 
		{

			// Look at each member and pull out only the vendor groups.
			for (int i = 0; i < attrib_value.length; i++) 
			{	
				tDN = attrib_value[i].toString();
				tDNName = ldapDir.convertToName(tDN);

				// Ignore everything except vendor groups
				if (tDNName.startsWith(tVendorGroupBaseDNName)) 
				{
					
					if ((hashT2 = ldapDir.read(tDN, new String[] {"cn", "owner", "businesscategory"})) != null) 
					{
						group  = new VendorGroup((String) getAttributeValue(hashT2,"cn")
										,(String) getAttributeValue(hashT2,"businessCategory")
										,(String) getAttributeValue(hashT2,"owner")
										);		
						
						ret.addElement(group);
					}
				}
			} // end of for
		} // end of if

		ret.trimToSize();
		VectorFuncs.sort(ret);

		return ret;
	}
	/**
	 * Returns a vector of Vendor objects that are authorized for a vendor group
	 * @param vendorGroupName   java.lang.String 
	 * @return Vector of Vendor Object
	 * @exception java.lang.Exception
	 */
	public Vector getVendorsAuthorizedForVendorGroup(String vendorGroupName) 
			throws Exception
	{
		final String    tVendorBaseDN = "ou=Vendors," + baseDN;
		final String    tFilter = "uniqueMember=cn=" +vendorGroupName.trim() +",ou=VendorGroups," + baseDN;
		Vector      ret = new Vector();
		Hashtable   hashT;
		Hashtable   hashT2;
		Vendor vendor = null;
		Object[]    attrib_value;
		String      tDN;
		Name        tDNName;
		String vendorNbr = "";
		Vector results = new Vector();
		results = ldapDir.search(tVendorBaseDN, tFilter, false);
		if (results != null) {
			for (int i=0;i<results.size();++i)
			{
				tDN = (String)results.elementAt(i);
				vendorNbr = getObjectName(tDN);
				vendorNbr = convertToExternalVendorNbr(vendorNbr);
				vendor = getVendorDetail(vendorNbr);
				ret.add(vendor);
			}
		}

		ret.trimToSize();
		VectorFuncs.sort(ret);

		return ret;
	}

	/**
	 * Returns a vector of Broker objects that are authorized for a vendor group
	 * @param vendorGroupName   java.lang.String 
	 * @return Vector of Broker Object
	 * @exception java.lang.Exception
	 */
	public Vector getBrokersAuthorizedForVendorGroup(String vendorGroupName) 
			throws Exception
	{
		final String    tVendorBaseDN = "ou=Brokers," + baseDN;
		final String    tFilter = "uniqueMember=cn=" +vendorGroupName.trim() +",ou=VendorGroups," + baseDN;
		Vector      ret = new Vector();
		Hashtable   hashT;
		Hashtable   hashT2;
		Broker broker = null;
		Object[]    attrib_value;
		String      tDN;
		Name        tDNName;
		String brokerNbr = "";
		Vector results = new Vector();
		results = ldapDir.search(tVendorBaseDN, tFilter, false);
		if (results != null) {
			for (int i=0;i<results.size();++i)
			{
				tDN = (String)results.elementAt(i);
				brokerNbr = getObjectName(tDN);
				broker = getBrokerDetail(brokerNbr);
				ret.add(broker);
			}
		}

		ret.trimToSize();
//		VectorFuncs.sort(ret);
		Broker.sortByBrokerName(ret);

		return ret;
	}

	/**
	 * Returns a vector of String objects 
	 * @param vendorNumber   java.lang.String 
	 * @return Vector of String Object [vendor group name]
	 * @exception java.lang.Exception
	 */
//josh
	public Vector getVendorGroupsContainingVendor(String vendorNumber) 
			throws Exception
	{
		
		String 			originalVendorNumber = "";
		originalVendorNumber = vendorNumber;		
		vendorNumber= convertToInternalVendorNbr(vendorNumber);
		
		final String    tVendorGroupBaseDN = "ou=VendorGroups," + baseDN;
		final String    tFilter = "uniqueMember=uid=" +vendorNumber.trim() +",ou=Vendors," + baseDN;
		Vector      ret = new Vector();
		Hashtable   hashT;
		Hashtable   hashT2;
		Object[]    attrib_value;
		String      tDN;
		Name        tDNName;
		String vendorGroupName = "";
		Vector results = new Vector();
		
		results = ldapDir.search(tVendorGroupBaseDN, tFilter, false);
		if (results != null) {
			for (int i=0;i<results.size();++i)
			{
				tDN = (String)results.elementAt(i);
				vendorGroupName = getObjectName(tDN);
				ret.add(vendorGroupName);
			}
		}

		ret.trimToSize();
//		VectorFuncs.sort(ret);
//		Broker.sortByBrokerName(ret);

		return ret;
	}
	
	/**
	 * Returns a vector of Vendor objects matching selection 
	 * @param vendorNbrFilter    java.lang.String 
	 * @param vendorNameFilter   java.lang.String 
	 * @param vendorStateFilter  java.lang.String 
	 * @param vendorCityFilter   java.lang.String 
	 * @return Vector
	 * @exception java.lang.Exception
	 */
	// Jan 26, 2003 - Modified for Vendor Conversion
	public Vector findVendors(String vendorNbr, String vendorName, String vendorState, String vendorCity)
					   throws Exception
	{
		Vector collection = null;
		if(vendorNbr != null && !vendorNbr.equals("")){
			vendorNbr = convertToInternalVendorNbr(vendorNbr);
		}	

		String targetDN = "ou=Vendors," + baseDN;
		String filter = null;
		StringBuffer buffer = new StringBuffer();
		buffer.append("(&");
		if(vendorNbr != null) // && !vendorNbr.equals(""))
		{
			buffer.append("(uid=" + vendorNbr + "*)");
		}
		if(vendorName != null) // && !vendorName.equals(""))
		{
		buffer.append("(sn=" + vendorName + "*)");
		}
		if(vendorState != null) // && !vendorState.equals(""))
		{
			buffer.append("(st=" + vendorState + "*)");
		}		
		if(vendorCity != null) // && !vendorCity.equals(""))
		{
			buffer.append("(homePostalAddress=" + vendorCity + "*)");
		}
		buffer.append(")");		
		filter = buffer.toString();
	
		
		// Get a list of all the vendors that match the filter.
		Vector results = new Vector();
		try{
			results = ldapDir.search(targetDN, filter, null, true);
		}catch(Exception e){
			throw new Exception("Vendor search failed");			
		}

		if (results != null) {
			Iterator it = results.iterator();
			collection = new Vector();
			while(it != null && it.hasNext()){
				Hashtable table = (Hashtable)((Vector)it.next()).elementAt(1);
		
				String vendorOut = getAttributeValue(table, "uid");
				vendorOut = convertToExternalVendorNbr(vendorOut);
				
				collection.addElement(new Vendor(vendorOut, // vendorID
									getAttributeValue(table, "sn"), // vendorName
									getAttributeValue(table, "mail"), // emailAddress
								 	getAttributeValue(table, "street"), // address
								 	getAttributeValue(table, "homePostalAddress"), // city
								 	getAttributeValue(table, "st"), // stateCode
								 	getAttributeValue(table, "postalCode"), // zipCode
								 	getAttributeValue(table, "telephoneNumber"), // phoneNumber
									getAttributeValue(table, "facsimileTelephoneNumber"), // faxNumber
									getAttributeValue(table, "manager"),  // contact
									getAttributeValue(table, "businessCategory")));   //vendorType
			}
		}
		return( collection );	
	}

	/**
	 * Returns a vector of Broker objects matching selection 
	 * @param brokerNbrFilter    java.lang.String 
	 * @param brokerNameFilter   java.lang.String 
	 * @param stateStateFilter  java.lang.String 
	 * @param cityFilter   java.lang.String 
	 * @return Vector
	 * @exception java.lang.Exception
	 */
	public Vector findBrokers(String nbr, String name, String state, String city) 
			throws Exception {
		Vector collection = null;

		String targetDN = "ou=Brokers," + baseDN;
		String filter = null;
		StringBuffer buffer = new StringBuffer();
		buffer.append("(&");
		if(nbr != null) // && !nbr.equals(""))
		{
			buffer.append("(uid=" + nbr + "*)");
		}
		if(name != null) // && !name.equals(""))
		{
		buffer.append("(sn=" + name + "*)");
		}
		if(state != null) // && !state.equals(""))
		{
			buffer.append("(st=" + state + "*)");
		}		
		if(city != null) // && !city.equals(""))
		{
			buffer.append("(homePostalAddress=" + city + "*)");
		}
		buffer.append(")");		
		filter = buffer.toString();
//		System.out.println("Filter : " + filter);
		
		
		// Get a list of all the brokers that match the filter.
		Vector results = new Vector();
		try{
			results = ldapDir.search(targetDN, filter, null, true);
		}catch(Exception e){
			throw new Exception("Broker search failed");			
		}

		if (results != null) {
			Iterator it = results.iterator();
			collection = new Vector();
			while(it != null && it.hasNext()){
				Hashtable table = (Hashtable)((Vector)it.next()).elementAt(1);

				collection.addElement(new Broker(getAttributeValue(table, "uid"), // vendorID
									getAttributeValue(table, "sn"), // vendorName
									getAttributeValue(table, "mail"), // emailAddress
								 	getAttributeValue(table, "street"), // address
								 	getAttributeValue(table, "homePostalAddress"), // city
								 	getAttributeValue(table, "st"), // stateCode
								 	getAttributeValue(table, "postalCode"), // zipCode
								 	getAttributeValue(table, "telephoneNumber"), // phoneNumber
								 	getAttributeValue(table, "facsimileTelephoneNumber"), //fax number
									getAttributeValue(table, "manager") //contact 
								 	)); 
			}
		}
		return( collection );	
	}
	
	/**
	 * Removes vendor from vendor group.
	 * 
	 * @return void
	 * @param vendorNumber    java.lang.String
	 * @param vendorGroupName java.lang.String
	 * @exception java.lang.Exception
	 */
	// Jan 26, 2003 - Modified for Vendor Conversion
	public void deleteVendorFromVendorGroup(String vendorNumber,
									 String groupName)
			throws Exception
	{
		String 			originalVendorNumber = "";
		originalVendorNumber = vendorNumber;		
		vendorNumber = convertToInternalVendorNbr(vendorNumber);
		

		final String tVendorDN      = "uid=" + vendorNumber + ",ou=Vendors," + baseDN;
		final String tVendorGroupDN = "cn=" + groupName + ",ou=VendorGroups," + baseDN;

		// Remove vendor from the vendor group.
		if (ldapDir.existAttributeInObject(tVendorGroupDN, "uniqueMember", tVendorDN)) {
			ldapDir.deleteAttribute(tVendorGroupDN, "uniqueMember", new String[] {tVendorDN});

			// Write a record to the audit log.
			eventLog.writeLog("VendorGroup", "Delete", "\"" + vendorNumber + "\" from \"" + groupName + "\"");
		}
	}

	/**
	 * Removes user from vendor group.
	 * 
	 * @return void
	 * @param userId          java.lang.String
	 * @param vendorGroupName java.lang.String
	 * @exception java.lang.Exception
	 */
	public void deleteUserFromVendorGroup(String userId,
									 String groupName)
			throws Exception
	{
		final String tUserDN      = "uid=" + userId + ",ou=People," + baseDN;
		final String tVendorGroupDN = "cn=" + groupName + ",ou=VendorGroups," + baseDN;

		// Remove vendor from the vendor group.
		if (ldapDir.existAttributeInObject(tVendorGroupDN, "uniqueMember", tUserDN)) {
			ldapDir.deleteAttribute(tVendorGroupDN, "uniqueMember", new String[] {tUserDN});

			// Write a record to the audit log.
			eventLog.writeLog("VendorGroup", "Delete", "\"" + userId + "\" from \"" + groupName + "\"");
		}
	}

	/**
	 * Gets a list of vendors that are in the specified vendor group and which meet
	 * the specified filter criteria.
	 * 
	 * @return
	 *      Vector - Vector of Vendor objects that are in the vendor group.  The
	 *               vector may be empty but never null.
	 * @param groupName java.lang.String
	 * @exception java.lang.Exception
	 */
	// Jan 26, 2003 - Modified for Vendor Conversion	
	//Note : No changes required
	public Vector getVendorsInVendorGroup(String groupName)	throws Exception
	{
		final String tVendorsBaseDN = "ou=Vendors," + baseDN;
		final Name  tVendorBaseDNName = ldapDir.convertToName(tVendorsBaseDN);
		Vector      ret = new Vector();
		Hashtable   hashT;
		Hashtable   hashT2;
		Vendor      vendor = null;
		Object[]    attrib_value;
		String      tDN;
		Name        tDNName;
		String 		vendorNbr = "";

		tDN = "cn=" + groupName + ",ou=VendorGroups," + baseDN;

		if (((hashT = ldapDir.read(tDN, new String[] {"uniquemember"})) != null) &&
			((attrib_value = (Object[]) hashT.get("uniquemember")) != null)) {

			// Look at each member and pull out only vendors
			for (int i = 0; i < attrib_value.length; i++) {	
				tDN = attrib_value[i].toString();
				tDNName = ldapDir.convertToName(tDN);
				// Ignore everything except vendors.
				if (tDNName.startsWith(tVendorBaseDNName)) 
				{
					vendorNbr = extractVendorNbr(tDN);
					try
					{
						vendor = getVendorDetail(vendorNbr);
						ret.addElement(vendor);
					}catch (Exception e)
					{
					}		
				}
			} // end of for
		} //end of if
		ret.trimToSize();
		VectorFuncs.sort(ret);
		return(ret);
	}
   /*
	*  This function extracts vendor numbers from vendorDN
	*
	*/
	// Jan 26, 2003 - Modified for Vendor Conversion	
	private String extractVendorNbr(String vendorDN)	
	{
		String vendorNbr = "";
		StringTokenizer t = new StringTokenizer(vendorDN,",");
		String token = "";
		String tokenStr = "";
		int len = 0;
		while (t.hasMoreTokens())
		{
			token = t.nextToken();
			tokenStr = token.substring(0,4);
			
			if  (tokenStr.equalsIgnoreCase("uid=")) 
			{			
				len = token.length();
				token = token.substring(4,len);
				
				vendorNbr= token;
			}
			vendorNbr = convertToExternalVendorNbr(vendorNbr);	
		}	
		return vendorNbr;
	}

	/**
	 * Gets a list of users that are in the specified vendor group and which meet
	 * the specified filter criteria.
	 * 
	 * @return
	 *      Vector - Vector of User objects that are in the vendor group.  The
	 *               vector may be empty but never null.
	 * @param groupName java.lang.String
	 * @exception java.lang.Exception
	 */

	public Vector getUsersInVendorGroup(String groupName)	throws Exception
	{
		final String tUserBaseDN = "ou=People," + baseDN;
		final Name  tUserBaseDNName = ldapDir.convertToName(tUserBaseDN);
		Vector      ret = new Vector();
		Hashtable   hashT;
		Hashtable   hashT2;
		UserDetail  user = null;
		Object[]    attrib_value;
		String      tDN;
		Name        tDNName;
		String 		userId = "";

		tDN = "cn=" + groupName + ",ou=VendorGroups," + baseDN;

		if (((hashT = ldapDir.read(tDN, new String[] {"uniquemember"})) != null) &&
			((attrib_value = (Object[]) hashT.get("uniquemember")) != null)) {

			// Look at each member and pull out only users
			for (int i = 0; i < attrib_value.length; i++) {	
				tDN = attrib_value[i].toString();
				tDNName = ldapDir.convertToName(tDN);
				// Ignore everything except users.
				if (tDNName.startsWith(tUserBaseDNName)) 
				{
					userId = extractUserId(tDN);
					user = getUserDetail(userId);
					ret.addElement(user);
				}
			} // end of for
		} //end of if
		ret.trimToSize();
		VectorFuncs.sort(ret);
		return(ret);
	}
	
   /*
	*  This function extracts user name numbers from userDN
	*
	*/
	
	private String extractUserId(String userDN)	
	{
		String userId = "";
		StringTokenizer t = new StringTokenizer(userDN,",");
		String token = "";
		String tokenStr = "";
		int len = 0;
		while (t.hasMoreTokens())
		{
			token = t.nextToken();
			tokenStr = token.substring(0,4);
			
			if  (tokenStr.equalsIgnoreCase("uid=")) 
			{			
				len = token.length();
				token = token.substring(4,len);
				
				userId= token;
			}	
		}	
		return userId;
	}

	/**
	 * Gets a list of users that meets the filter criteria
	 * 
	 * @return
	 *      Vector - Vector of UserName objects.  
	 * 				 The vector may be empty but never be null.
	 * @param userIdFilter java.lang.String
	 * @param userNameFilter java.lang.String
	 * @exception java.lang.Exception
	 */

	public Vector getUserList(String userIdFilter, String userNameFilter)	throws Exception
	{
		
		final String    tUserDN = "ou=People," + baseDN;
		Vector          vector1, vector2;
		Vector          ret = new Vector();

		Hashtable       hashT1;
		Object[]        attrib_value;
		String          tFilter;
		
		if  (userIdFilter == null)
		{
			userIdFilter = "*";
		}else
		{
			userIdFilter = userIdFilter + "*";
		}			
		if  (userNameFilter == null)
		{
			userNameFilter = "*";
		}else
		{
			userNameFilter = userNameFilter + "*";
		}			
		
		UserName user = null;
		tFilter = "(&(uid=" + userIdFilter + ")(cn=" + userNameFilter + "))" ;
		if ((vector1 = ldapDir.search(tUserDN, tFilter, new String[] {"uid","cn", "uid", "sn", "initials", "givenname"}, true)) != null) {
	
			for (int i = 0; i< vector1.size(); ++i)
			{
				vector2 = (Vector) vector1.elementAt(i);
				hashT1 = (Hashtable) vector2.elementAt(1); 
				user = new UserName(getAttributeValue(hashT1,"uid")   // user id
								   ,getAttributeValue(hashT1,"givenname")  // fname
								   ,getAttributeValue(hashT1,"initials") // initial
								   ,getAttributeValue(hashT1,"sn")  // last name
								   ,getAttributeValue(hashT1,"cn")   // full name
								   );
								   
				ret.addElement(user);								   
			}
			
		}
		return ret;
	}


	/**
	 * Gets the list of vendor groups for a given user
	 * 
	 * @return
	 *      Vector - Vector of VendorGroup objects.  
	 * 				 The vector may be empty but never null.
	 * @param userID java.lang.String
	 * @exception java.lang.Exception
	 */

	public Vector getVendorGroupsForUser(String loginID)
			throws Exception
	{
		final String    tUserDN = "uid=" + loginID + ",ou=People," + baseDN;
		Vector          ret = new Vector();
		VendorGroup     group;
		Vector          vector1, vector2, vector3;
		Hashtable       hashT1;
		String          tDN;
		String          tFilter;

		tDN = "ou=VendorGroups," + baseDN;
		tFilter = "(uniquemember=" + tUserDN + ")"; 

		// Get a list of all VendorGroups the user is a member of.
		if ((vector1 = ldapDir.search(tDN, tFilter, new String[] {"businesscategory", "description", "cn", "owner", "seeAlso"}, true)) != null) {
			final int vector1Size = vector1.size();
			for (int x1 = 0; x1 < vector1Size; x1++) {
				vector2 = (Vector) vector1.elementAt(x1);

				hashT1 = (Hashtable) vector2.elementAt(1);

				// Add a StoreGroup object to the vector (if it's not already there).
				group = new VendorGroup(getAttributeValue(hashT1, "cn"),
									    getAttributeValue(hashT1, "businesscategory"),
									    getAttributeValue(hashT1, "owner")
									   );
			if (! ret.contains(group)) {
					ret.addElement(group);
				}
			}
		}

		ret.trimToSize();
		
		return ret;
	}

	/**
	 * Add Distribution Group
	 * 
	 * @return void 
	 * @param groupNbr java.lang.String
	 * @param groupName java.lang.String
	 * @exception java.lang.Exception
	 */
	public void addDistributionGroup(String groupNbr, String groupName)
			throws Exception
	{
		final String tDN = "cn=" + groupNbr + ",ou=DistributionGroups,ou=Groups," + baseDN;
		Hashtable   attrib_set = new Hashtable(10);
		Date        currDate = new Date();

		if  (ldapDir.existObject(tDN))
		{
			String tMsg = "Unable to add Distribution Group.  Distribution Group already exist."; 
			throw new Exception(tMsg);
		}
		// Add Distribution Group object.
		attrib_set.put("objectclass", new String[] {"top", "groupofuniquenames"});
		attrib_set.put("description", new String[] {groupName});
		ldapDir.addObject(tDN, attrib_set);

		// Write a record to the audit log.
		eventLog.writeLog("Distribution Group ", "Add", "\"" + groupNbr);
	}

	/**
	 * Assign distribution group to a vendor
	 * 
	 * @return void
	 * @param groupName java.lang.String
	 * @param vendorNbr java.lang.String
	 * @exception java.lang.Exception
	 */

	public void addDistributionGroupToVendor(String groupName,
							   String vendorNbr) 
							   throws Exception
	{	
		vendorNbr = convertToInternalVendorNbr(vendorNbr);
		String dn="cn="+vendorNbr+",ou=Vendors," + baseDN;
		addDistributionGroupToSupplier(groupName, dn);
	}
	/**
	 * Assign distribution group to a broker
	 * 
	 * @return void
	 * @param groupNbr java.lang.String
	 * @param vendorNbr java.lang.String
	 * @exception java.lang.Exception
	 */

	public void addDistributionGroupToBroker(String groupName,
							   String brokerNbr)
			throws Exception
	{
		String dn="cn="+brokerNbr+",ou=Brokers," + baseDN;
		addDistributionGroupToSupplier(groupName, dn);
	}

	private void addDistributionGroupToSupplier(String groupName, String dn) 
			throws Exception
	{		
		final String tGroupDN = "cn=" + groupName + ",ou=DistributionGroups,ou=Groups," + baseDN;
		
		String tDN = dn;
		if  (! existDistributionGroup(groupName))
		{
			String tMsg = "Unable to add distribution group to supplier.  Group doesn't exist." +
						  "  Distribution group : \"" + groupName + "\"" +
						  "  Supplier : \"" + dn + "\"";
			throw new Exception(tMsg);
		}
/*
		if  (!existBroker(brokerNbr))
		{
			String tMsg = "Unable to add vendor group to vendor.  Vendor doesn't exist." +
						  "  VendorGroup : \"" + groupName + "\"" +
						  "  Broker : \"" + brokerNbr + "\"";
			throw new Exception(tMsg);
		}
*/		
		// Add the group to vendor (if it's not there already).
		if (! ldapDir.existAttributeInObject(tDN, "uniqueMember", tGroupDN)) {
			ldapDir.addAttribute(tDN, "uniqueMember", new String[] {tGroupDN});

			// Write a record to the audit log.
			eventLog.writeLog("DistributionGroup_Vendor ", "Add", "\"" + groupName + "\" to \"" + dn + "\"");
		}
	}
	
	/**
	 * Delete vendor group from a vendor
	 * 
	 * @return void
	 * @param groupName java.lang.String
	 * @param vendorNbr java.lang.String
	 * @exception java.lang.Exception
	 */
	public void deleteVendorGroupFromVendor(String groupName,
							   String vendorNbr)
			throws Exception
	{

		String 			originalVendorNumber = "";
		originalVendorNumber = vendorNbr;		
		vendorNbr = convertToInternalVendorNbr(vendorNbr);

		final String tGroupDN = "cn=" + groupName + ",ou=VendorGroups," + baseDN;
		final String tVendorDN = "cn=" + vendorNbr + ",ou=Vendors," + baseDN;


		if  (!existVendor(originalVendorNumber))
		{
			String tMsg = "Unable to delete vendor group from vendor.  Vendor doesn't exist." +
						  "  VendorGroup : \"" + groupName + "\"" +
						  "  Vendor : \"" + originalVendorNumber + "\"";
			throw new Exception(tMsg);
		}
		
		// Add the group to vendor (if it's not there already).
		if (ldapDir.existAttributeInObject(tVendorDN, "uniqueMember", tGroupDN)) {
			ldapDir.deleteAttribute(tVendorDN, "uniqueMember", new String[] {tGroupDN});
			
			eventLog.writeLog("VendorGroup_Vendor ", "Delete", "\"" + groupName + "\" from \"" + vendorNbr + "\"");
		}
	}

	/**
	 * Delete Distribution Group
	 * 
	 * @return void 
	 * @param groupNbr java.lang.String
	 * @exception java.lang.Exception
	 */
	public void deleteDistibutionGroup(String groupNbr)
			throws Exception
	{
		final String tDN = "cn=" + groupNbr + ",ou=DistributionGroups,ou=Groups," + baseDN;
		Hashtable   attrib_set = new Hashtable(10);
		Date        currDate = new Date();

		if  (!ldapDir.existObject(tDN))
		{
			String tMsg = "Unable to delete Distribution Group.  Distribution Group does not exist."; 
			throw new Exception(tMsg);
		}
		ldapDir.deleteObject(tDN);

		// Write a record to the audit log.
		eventLog.writeLog("Distribution Group ", "Delete ",  groupNbr);
	}

	/**
	 * Gives the user access to a distribution group
	 * 
	 * @return void
	 * @param loginID java.lang.String
	 * @param groupNbr java.lang.String
	 * @exception java.lang.Exception
	 */
	public void addUserToDistributionGroup(String loginID,
							   String groupNbr)
			throws Exception
	{
		final String tGroupDN = "cn=" + groupNbr + ",ou=DistributionGroups,ou=Groups," + baseDN;
		final String tPeopleObjectDN = "uid=" + loginID + ",ou=People," + baseDN;

		// Make sure the specified distriution group exists.
		if  (! ldapDir.existObject(tGroupDN))
		{
			String tMsg = "Unable to add user to distibution group.  Group doesn't exist.";
			throw new Exception(tMsg);
		}

		// Add the user to distibution group (if it's not there already).
		if (! ldapDir.existAttributeInObject(tGroupDN, "uniqueMember", tPeopleObjectDN)) {
			ldapDir.addAttribute(tGroupDN, "uniqueMember", new String[] {tPeopleObjectDN});

			// Write a record to the audit log.
			eventLog.writeLog("Distibution Group", "Add", "\"" + loginID + "\" to \"" + groupNbr + "\"");
		}
	}

	/**
	 * Removes a user from Distribution group
	 * 
	 * @return void
	 * @param loginID    java.lang.String
	 * @param distributionGroupNbr java.lang.String
	 * @exception java.lang.Exception
	 */
	public void deleteUserFromDistributionGroup(String loginID,
									 String groupNbr)
			throws Exception
	{
		final String tGroupDN = "cn=" + groupNbr + ",ou=DistributionGroups,ou=Groups," + baseDN;
		final String tPeopleObjectDN = "uid=" + loginID + ",ou=People," + baseDN;

		// Make sure the specified distriution group exists.
		if  (! ldapDir.existObject(tGroupDN))
		{
			String tMsg = "Unable to delete user from distibution group.  Group doesn't exist.";
			throw new Exception(tMsg);
		}
		
		// Make sure the specified user exists.
		if  (! ldapDir.existObject(tPeopleObjectDN))
		{
			String tMsg = "Unable to delete user from distibution group.  User doesn't exist.";
			throw new Exception(tMsg);
		}

		// Add the user to distibution group (if it's not there already).
		if (ldapDir.existAttributeInObject(tGroupDN, "uniqueMember", tPeopleObjectDN)) {
			ldapDir.deleteAttribute(tGroupDN, "uniqueMember", new String[] {tPeopleObjectDN});
			// Write a record to the audit log.
			eventLog.writeLog("Distibution Group", "Delete User", "\"" + loginID + "\" to \"" + groupNbr + "\"");
		}
	}

	/**
	 * Returns a vector containing DistributionGroup objects
	 * 
	 * @return Vector    java.util.Vector 
	 * @param groupNumberFilter	   java.lang.String
	 * @param groupNameFilter 	   java.lang.String
	 * @exception java.lang.Exception
	 */
	public Vector getDistributionGroups(String groupNbrFilter, String groupNameFilter)
			throws Exception
	{
		Vector ret = new Vector();
		DistributionGroup group = null;
		Vector vector1, vector2;
		Hashtable hashT1;
		String tFilter;

		String tDN = "ou=DistributionGroups,ou=Groups," + baseDN;
		
		if  (groupNbrFilter == null)
		{
			groupNbrFilter = "";
		}
		
		if  (groupNameFilter == null)
		{
			groupNameFilter = "";
		}		
	
		groupNbrFilter  = groupNbrFilter.trim() + "*";
		groupNameFilter = groupNameFilter.trim() + "*";
		
		tFilter =  "(&(cn="+ groupNbrFilter + ")"
		         + "(description="+ groupNameFilter + "))"		
				;
		// Get a list of all the Distribution Groups matching the selection
		if ((vector1 = ldapDir.search(tDN, tFilter, new String[] {"cn", "description"}, false)) != null) {
			final int vector1Size = vector1.size();
			for (int x1 = 0; x1 < vector1Size; x1++) {
				vector2 = (Vector) vector1.elementAt(x1);
				hashT1 = (Hashtable) vector2.elementAt(1);

				group = new DistributionGroup(getAttributeValue(hashT1, "cn"), getAttributeValue(hashT1, "description"));
				ret.addElement(group);
			}
		}
	  
		ret.trimToSize();
		VectorFuncs.sort(ret);

		return(ret);
	}

	/**
	 * Returns object DistributionGroup 
	 * 
	 * @return DistributionGroup    DistributionGroup
	 * @param groupNumber	   java.lang.String
	 * @exception java.lang.Exception
	 */
	public DistributionGroup getDistributionGroupDetails(String groupNbr)
			throws Exception
	{
		Vector ret = new Vector();
		DistributionGroup group = null;
		Vector vector1, vector2;
		Hashtable hashT1;
		String tFilter;

		String tDN = "ou=DistributionGroups,ou=Groups," + baseDN;
		
		
		tFilter =  "(cn="+ groupNbr + ")";

		if ((vector1 = ldapDir.search(tDN, tFilter, new String[] {"cn", "description"}, false)) != null) {
			final int vector1Size = vector1.size();
			vector2 = (Vector) vector1.elementAt(0);
			hashT1 = (Hashtable) vector2.elementAt(1);
			group = new DistributionGroup(getAttributeValue(hashT1, "cn"), getAttributeValue(hashT1, "description"));
		}
		return (group);
	}
	/**
	 * Updates distribution group name
	 *
	 * @return void
	 * @param distributionGroupNbr java.lang.String
	 * @param distributionGroupName java.lang.String
	 * @exception java.lang.Exception
	 */
	public void updateDistributionGroup(String groupNbr,String groupName)
		throws Exception
	{
		
		final String tGroupDN = "cn=" + groupNbr + ",ou=DistributionGroups,ou=Groups," + baseDN;

		Hashtable       attrib_set = new Hashtable(20);

		// Make sure the specified distribution group exists.
		if (! ldapDir.existObject(tGroupDN)) {
			String tMsg = "Unable to update distribution group.  Group : \"" + groupNbr.trim() + "\" doesn't exist.";
			throw new Exception(tMsg);
		}

		attrib_set.put("description", new String[] {groupName});
		
		ldapDir.updateObject(tGroupDN, attrib_set);
	}

	/**
	 * Assign vendor group to a vendor
	 * 
	 * @return void
	 * @param groupName java.lang.String
	 * @param vendorNbr java.lang.String
	 * @exception java.lang.Exception
	 */
	public void addVendorGroupToVendor(String groupName,
							   String vendorNbr)
			throws Exception
	{

		String 			originalVendorNumber = "";
		originalVendorNumber = vendorNbr;		
		vendorNbr = convertToInternalVendorNbr(vendorNbr);

		final String tGroupDN = "cn=" + groupName + ",ou=VendorGroups," + baseDN;
		final String tVendorDN = "cn=" + vendorNbr + ",ou=Vendors," + baseDN;

		// Make sure the specified group exists.
		// Make sure the vendor group exists
		if  (! existVendorGroup(groupName))
		{
			String tMsg = "Unable to add vendor group to vendor.  Vendor group doesn't exist." +
						  "  VendorGroup : \"" + groupName + "\"" +
						  "  Vendor : \"" + vendorNbr + "\"";
			throw new Exception(tMsg);
		}

		if  (!existVendor(originalVendorNumber))
		{
			String tMsg = "Unable to add vendor group to vendor.  Vendor doesn't exist." +
						  "  VendorGroup : \"" + groupName + "\"" +
						  "  Vendor : \"" + originalVendorNumber + "\"";
			throw new Exception(tMsg);
		}
		
		// Add the group to vendor (if it's not there already).
		if (! ldapDir.existAttributeInObject(tVendorDN, "uniqueMember", tGroupDN)) {
			ldapDir.addAttribute(tVendorDN, "uniqueMember", new String[] {tGroupDN});

			// Write a record to the audit log.
			eventLog.writeLog("VendorGroup_Vendor ", "Add", "\"" + groupName + "\" to \"" + vendorNbr + "\"");
		}
	}

	/**
	 * Assign vendor group to a broker
	 * 
	 * @return void
	 * @param groupName java.lang.String
	 * @param vendorNbr java.lang.String
	 * @exception java.lang.Exception
	 */

	public void addVendorGroupToBroker(String groupName,
							   String brokerNbr)
			throws Exception
	{
		final String tGroupDN = "cn=" + groupName + ",ou=VendorGroups," + baseDN;
		final String tBrokerDN = "cn=" + brokerNbr + ",ou=Brokers," + baseDN;

		// Make sure the specified group exists.
		// Make sure the vendor group exists
		if  (! existVendorGroup(groupName))
		{
			String tMsg = "Unable to add vendor group to vendor.  Vendor group doesn't exist." +
						  "  VendorGroup : \"" + groupName + "\"" +
						  "  Broekr : \"" + brokerNbr + "\"";
			throw new Exception(tMsg);
		}

		if  (!existBroker(brokerNbr))
		{
			String tMsg = "Unable to add vendor group to vendor.  Vendor doesn't exist." +
						  "  VendorGroup : \"" + groupName + "\"" +
						  "  Broker : \"" + brokerNbr + "\"";
			throw new Exception(tMsg);
		}
		
		// Add the group to vendor (if it's not there already).
		if (! ldapDir.existAttributeInObject(tBrokerDN, "uniqueMember", tGroupDN)) {
			ldapDir.addAttribute(tBrokerDN, "uniqueMember", new String[] {tGroupDN});

			// Write a record to the audit log.
			eventLog.writeLog("VendorGroup_Vendor ", "Add", "\"" + groupName + "\" to \"" + brokerNbr + "\"");
		}
	}
	
	/**
	 * Delete distribution group from a vendor
	 * 
	 * @return void
	 * @param groupName java.lang.String
	 * @param vendorNbr java.lang.String
	 * @exception java.lang.Exception
	 */
	public void deleteDistributionGroupFromVendor(String groupName,
							   String vendorNbr)
			throws Exception
	{

		String 			originalVendorNumber = "";
		originalVendorNumber = vendorNbr;		
		vendorNbr = convertToInternalVendorNbr(vendorNbr);
		String dn = "cn="+vendorNbr+",ou=Vendors," + baseDN;
		deleteDistributionGroupFromSupplier(groupName,dn);
	}	

	/**
	 * Delete distribution group from a broker
	 * 
	 * @return void
	 * @param groupName java.lang.String
	 * @param brokerNbr java.lang.String
	 * @exception java.lang.Exception
	 */
	public void deleteDistributionGroupFromBroker(String groupName,
							   String brokerNbr)
			throws Exception
	{
		String dn = "cn="+brokerNbr+",ou=Brokers," + baseDN;
		deleteDistributionGroupFromSupplier(groupName,dn);
		
	}	
	private void deleteDistributionGroupFromSupplier(String groupName,
							   String dn)
			throws Exception
	{

		final String tGroupDN = "cn=" + groupName + ",ou=DistributionGroups,ou=Groups," + baseDN;
		final String tDN = dn;

/*
		if  (!existVendor(originalVendorNumber))
		{
			String tMsg = "Unable to delete vendor group from vendor.  Vendor doesn't exist." +
						  "  VendorGroup : \"" + groupName + "\"" +
						  "  Vendor : \"" + originalVendorNumber + "\"";
			throw new Exception(tMsg);
		}
*/		
		// Add the group to vendor (if it's not there already).
		if (ldapDir.existAttributeInObject(tDN, "uniqueMember", tGroupDN)) {
			ldapDir.deleteAttribute(tDN, "uniqueMember", new String[] {tGroupDN});
			
			eventLog.writeLog("DistributionGroup_Vendor ", "Delete", "\"" + groupName + "\" from \"" + dn + "\"");
		}
	}

	/**
	 * Delete vendor group from a broker
	 * 
	 * @return void
	 * @param groupName java.lang.String
	 * @param vendorNbr java.lang.String
	 * @exception java.lang.Exception
	 */
	public void deleteVendorGroupFromBroker(String groupName,
							   String brokerNbr)
			throws Exception
	{

		final String tGroupDN = "cn=" + groupName + ",ou=VendorGroups," + baseDN;
		final String tVendorDN = "cn=" + brokerNbr + ",ou=Brokers," + baseDN;


		if  (!existBroker(brokerNbr))
		{
			String tMsg = "Unable to delete vendor group from vendor.  Vendor doesn't exist." +
						  "  VendorGroup : \"" + groupName + "\"" +
						  "  Broekr : \"" + brokerNbr + "\"";
			throw new Exception(tMsg);
		}
		
		// Add the group to vendor (if it's not there already).
		if (ldapDir.existAttributeInObject(tVendorDN, "uniqueMember", tGroupDN)) {
			ldapDir.deleteAttribute(tVendorDN, "uniqueMember", new String[] {tGroupDN});
			
			eventLog.writeLog("VendorGroup_Vendor ", "Delete", "\"" + groupName + "\" from \"" + brokerNbr + "\"");
		}
	}


    public  Vector getAllUsers() throws Exception{
        String tDN = "ou=People," + baseDN;
        String tFilter = "(businesscategory=*)";
        Vector vector1;
        Vector ret = new Vector();
		String s = "";        
        if((vector1 = ldapDir.search(tDN, tFilter, new String[] 
        		{"uid", "givenName", "initials", "sn", "cn","roomNumber","destinationIndicator"}, true)) != null)
        {
            int vector1Size = vector1.size();
            for(int x1 = 0; x1 < vector1Size; x1++)
            {
                Vector vector2 = (Vector)vector1.elementAt(x1);
                Hashtable hashT1 = (Hashtable)vector2.elementAt(1);

                 UserDetail user = new UserDetail(getAttributeValue(hashT1, "uid"), 
                						getAttributeValue(hashT1, "givenName"), 
                						getAttributeValue(hashT1, "sn"), 
                						getAttributeValue(hashT1, "initials"), 
                						getAttributeValue(hashT1, "cn"),
                						getAttributeValue(hashT1, "roomNumber"),
										getAttributeValue(hashT1, "destinationIndicator"),
                						"",  // title
                						"",  // phoneNumber
                						"",  // email type
                						""   // email address
                						);
               	ret.addElement(user);	
 				
            }

        }
        return ret;
    }


   /*
	* prefix vendor numbers with "V" before writing it to LDAP
	*/	
	/*
	private String convertToInternalVendorNbr(String s)
	{
		String outNbr = "";
		
		if  (formatVendorNumber)
		{
			outNbr = "V" + s;		
		}else
		{
			outNbr = s;
		}		
		return outNbr;
	}	
	*/
   /*
	* Remove vendor prefix "V" before returning vendor numbers to callers
	*/	
	/*
	private String convertToExternalVendorNbr(String s)
	{
		String outNbr = "";
		
		if  (formatVendorNumber)
		{
			if (s.substring(0,1).equals("V"))
			{
				outNbr = s.substring(1,s.length());
			}else
			{
				outNbr = s;
			}		
		}else
		{
			outNbr = s;
		}		
		return outNbr;
	}	
	*/
   /*
	* prefix vendor numbers with "V" before writing it to LDAP
	*/	
	private String convertToInternalVendorNbr(String s)
	{
		String outNbr = "";
		outNbr = "V" + s;		
		return outNbr;
	}	

   /*
	* Remove vendor prefix "V" before returning vendor numbers to callers
	*/	
	private String convertToExternalVendorNbr(String s)
	{
		String outNbr = "";
		if (s.substring(0,1).equals("V"))
		{
			outNbr = s.substring(1,s.length());
		}else
		{
			outNbr = s;
		}		
		return outNbr;
	}	

}

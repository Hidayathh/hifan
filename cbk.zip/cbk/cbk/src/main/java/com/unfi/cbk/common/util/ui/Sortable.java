/*
 * Created on May 27, 2005
 * 
 */
package com.unfi.cbk.common.util.ui;

/**
 * 
 * @author yhp6y2l
 *
 */
public interface Sortable {
	public String getSortName();
	public void setSortName(String name);
	public String getSortDirection();
	public void setSortDirection(String direction);
	public String getPreviousSortName();
	public void setPreviousSortName(String name);
	public String getPreviousSortDirection();
	public void setPreviousSortDirection(String name);
}

package com.unfi.cbk.util;

import java.text.DecimalFormat;
import java.util.Date;
import java.util.StringTokenizer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;

/**
 * The StringFunctions class is a utility class for performing string
 * functions needed by other classes.  All methods are static.
 *
 * @author      yhp6y2l
 * @since       1.0
 */
public class StringFunctions {
	static Logger log = Logger.getLogger(StringFunctions.class);

	public static final String SINGLE_QUOTES = "'"; 
	public static final String QUOTES = "`"; 
	
	/**
	 * Convert a null to an empty string.
	 * This method takes a <code>String</code> and if it is null, 
	 * returns an empty string.
	 * 
	 * @return			the <code>String</code>, or an empty string ("") if it was null
	 * @param value		the <code>String</code> to convert
	 * @since			1.0
	 */
	public static String convertNull(String value) {
		if (value == null) {
			value = "";
		}
		return value;
	}
	
	
	/**
	 * Returns a "0" string if null or empty otherwise returns the string.
	 * 
	 * @return			the <code>String</code>, or "0" if it was null or empty
	 * @param value		the <code>String</code> to convert
	 * @since			1.0
	 */
	public static String zeroIfNullOrEmpty(String value) {
		if ((value == null) || value.equals("")) {
			value = "0";
		}
		return value;
	}
	
	public static int convertToInt(String value) throws NumberFormatException {
		try {
			return Integer.parseInt(value);
			
		} catch (Exception e) {
			throw new NumberFormatException();
			
		}				
		
	}
	
	public static Integer convertToInteger(String value) throws NumberFormatException {
		try {
			return new Integer(value);
			
		} catch (Exception e) {
			throw new NumberFormatException();
			
		}				
		
	}
	
	public static String zeroFillLeft(String value, int length){		
		return fillLeft(convertNull(value),"0",length);
	}
	
	public static String removeLeadingZeroIfNumber(String value){
		String temp = value;
		try{
			int i = Integer.parseInt(value);
			temp = String.valueOf(i);
		}
		catch (Exception ignore){}
		return temp;
	}
					
	public static String spaceFillLeft(String value, int length, boolean convert){
		String temp = value;
		/* if there are preceding zeros, we want to eliminate them*/
		if (convert){
			try{
				int i = Integer.parseInt(value);
				temp = String.valueOf(i);
			}
			catch (Exception ignore){}
		}
		
		return fillLeft(convertNull(temp), " ", length);		
	}
		
	private static String fillLeft(String source, String fill, int length){
		StringBuffer buffer = new StringBuffer();
		for (int i = length; i > source.length(); i--){
			buffer.append(fill);
		}
		buffer.append(source);
		return buffer.toString();
	}
		
	public static String fillRight(String source, String fill, int length){
		StringBuffer buffer = new StringBuffer();
		buffer.append(source);
		for (int i = length; i > source.length(); i--){
			buffer.append(fill);
		}
		return buffer.toString();
	}
    
    public static String capitalizePhrase(String value) {

        StringTokenizer stk = new StringTokenizer(value, " ");
        StringBuffer buffer = new StringBuffer();
        
        while ( stk.hasMoreTokens() ) {

            String tok = stk.nextToken();            

            if ( tok.equals("AND") ) {
                buffer.append("and ");
                continue;
            }

            StringBuffer sB = new StringBuffer(tok.toLowerCase());

            char prevChar = ' ';
            char curChar  = ' ';
            
            for ( int i = 0; i < tok.length(); i++ ) {
                
                curChar = sB.charAt(i);
                
                if ( i == 0 || prevChar == '/' || prevChar == '\\' || prevChar == '-' ) {
                    char firstChar = new String(sB.charAt(i)+"").toUpperCase().charAt(0);
                    sB.setCharAt(i, firstChar);                    
                }

                prevChar = curChar;
            }
                
            buffer.append(sB + " ");
        }
      
      return buffer.toString();
        
    }
    
    public static String displayAsCurrency(Double value, boolean showDollarSign) {
		DecimalFormat formatPreference = null;
		String newValue = "";
		
		try {
	    	if (showDollarSign) {
				formatPreference = new DecimalFormat("$#,##0.00;($#,##0.00)");
	    	} else {
				formatPreference = new DecimalFormat("#,##0.00;-#,##0.00");
	    	}
		
			newValue = formatPreference.format(value.doubleValue());
			
		} catch (Exception e) {
			// Invalid Date
			log.warn("invalid date: " + value);
			return "";
			
		}
		
		return newValue;
    
    }
    
	public static String displayAsCurrencyNoCommas(Double value, boolean showDollarSign) {
		DecimalFormat formatPreference = null;
		String newValue = "";
		
		try {
			if (showDollarSign) {
				formatPreference = new DecimalFormat("$###0.00;($###0.00)");
			} else {
				formatPreference = new DecimalFormat("###0.00;-###0.00");
			}
		
			newValue = formatPreference.format(value.doubleValue());
			
		} catch (Exception e) {
			// Invalid Date
			log.warn("invalid date: " + value);
			return "";
			
		}
		
		return newValue;
    
	}
    
    public static String exportAsCurrency(Double value){
		DecimalFormat formatPreference = new DecimalFormat("$###0.00;($###0.00)");
		String newValue = "";

		try {
			newValue = formatPreference.format(value.doubleValue());
	
		} catch (Exception e) {
			// Invalid Date
			return "";
	
		}

		return newValue;
		
    }
    
    public static String formatFilename(String filenameFromDatabase) {
		String formattedFileName = "";
		
		try {
			int charLocation = filenameFromDatabase.lastIndexOf("_");
			
			formattedFileName = filenameFromDatabase.substring(0, charLocation);
			
		} catch (Exception e) {
			formattedFileName = filenameFromDatabase;
			
		}
		
		return formattedFileName;
    	
    }
    
    public static int toInt(String number) {
    	int returnValue = 0;
    	
    	try {
    		Integer integerObj = new Integer(number);
    		returnValue = integerObj.intValue();
    		
    	} catch (Exception e) {
    		//  Ignore - just return zero.
    		
    	}
    	
    	return returnValue;
    	
    }
    
	public static String addLeadingZeros(String value, int finalLength) {
		if (value != null) {
			StringBuffer returnValue = new StringBuffer(value);
			
			try {
				if (finalLength > value.length()) {
					for (int i = 0; i < finalLength - value.length(); i++) {
						returnValue.insert(0, "0");
						
					}
				}
							
			} catch (Exception e) {
				//  Ignore - just return what was passed.
	    		
			}
    	
	    	return returnValue.toString();
	    	
		} else {
			return "";
			
		}
    	
	}
	
	/**
	 * Replaces the single quotes ' to ` and returns the string.
	 * 
	 * @return			the <code>String</code>, or an empty string ("") if it was null
	 * @param value		the <code>String</code> to replace the single quote
	 * @since			1.0
	 */
	public static String replaceSingleQuotes(String value, String oldString, String newString) {
		if (value != null) {
			try {
				Pattern p = Pattern.compile(oldString);
				Matcher matcher = p.matcher(value);
				value = matcher.replaceAll(newString);
			} catch (Exception e) {
				//  Ignore - just return what was passed.
			}
		}
		return value;
	}
	
	public static String substring(String value, int startIndex, int endIndex) {
		if (value != null) {
			if (value.length() > endIndex) {
				return value.substring(startIndex, endIndex);
			} else {
				return value;
			}
		} else {
			return value;
		}
	}
	
	
	/**
	 * 
	 * @param params	List of parameters to use in constructing the clause
	 * @param exclude	boolean indicator to use "Not" in clause
	 * @return			a clause of the form "[NOT] IN (?,?)"
	 * 
	 */
	public static String createFilterClause(int paramCount, boolean exclude){
		StringBuffer buffer = new StringBuffer();		

		if (exclude){
			buffer.append(" NOT ");
		}
		buffer.append("IN (");
		for (int i=0; i < paramCount; i++){
			buffer.append("?");
			if (i < paramCount - 1){
				buffer.append(",");
			}
		}
		buffer.append(")");

		return buffer.toString();
	}
    
    /**
     * Returns a literal replacement <code>String</code> for the specified
     * <code>String</code>.
     *
     * This method produces a <code>String</code> that will work
     * use as a literal replacement <code>s</code> in the
     * <code>appendReplacement</code> method of the {@link Matcher} class.
     * The <code>String</code> produced will match the sequence of characters
     * in <code>s</code> treated as a literal sequence. Slashes ('\') and
     * dollar signs ('$') will be given no special meaning.
     *
     * @param s The string to be literalized
     * @return A literal string replacement
     * @since 1.5
     */
    public static String quoteReplacement(String s) {
        if ((s.indexOf('\\') == -1) && (s.indexOf('$') == -1))
            return s;
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '\\') {
                sb.append('\\');
                sb.append('\\');
            }
            else if (c == '$') {
                sb.append('\\');
                sb.append('$');
            }
            else {
                sb.append(c);
            }
        }
        return sb.toString();
    }    
  
}
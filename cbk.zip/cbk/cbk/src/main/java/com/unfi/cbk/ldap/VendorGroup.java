package com.unfi.cbk.ldap;
import com.unfi.cbk.ldaputil.CompareTo;
import com.unfi.cbk.ldaputil.Comparer;

public class VendorGroup implements java.io.Serializable, CompareTo {
	protected String groupName = "";
	protected String groupType = "";
	protected String owner     = "";
	
	public VendorGroup(String groupName, String groupType, String owner)
	{
		this.groupName = groupName;
		this.groupType = groupType;
		this.owner     = owner;
	}	

    public int compareTo(java.lang.Object obj) {
        return( groupName.toLowerCase().compareTo(((VendorGroup)obj).groupName.toLowerCase()) );
    }

	/**
	 * Gets the groupName
	 * @return Returns a String
	 */
	public String getGroupName() {
		return groupName;
	}
	/**
	 * Sets the groupName
	 * @param groupName The groupName to set
	 */
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	/**
	 * Gets the groupType
	 * @return Returns a String
	 */
	public String getGroupType() {
		return groupType;
	}
	/**
	 * Sets the groupType
	 * @param groupType The groupType to set
	 */
	public void setGroupType(String groupType) {
		this.groupType = groupType;
	}

	/**
	 * Gets the owner
	 * @return Returns a String
	 */
	public String getOwner() {
		return owner;
	}
	/**
	 * Sets the owner
	 * @param owner The owner to set
	 */
	public void setOwner(String owner) {
		this.owner = owner;
	}

}


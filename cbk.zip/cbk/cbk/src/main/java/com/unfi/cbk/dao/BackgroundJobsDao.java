package com.unfi.cbk.dao;

import java.util.List;

import com.unfi.cbk.exceptions.CbkServiceException;

/**
 * DAO for the background jobs servlet.  Provides necessary functionality
 *  to find and closed aged and no response PASS#s.
 * 
 * @author yhp6y2l
 * @version 1.0
 */
public interface BackgroundJobsDao {

    /**
     * Get a listing of all of the PASS#s that qualify as being open too
     *  long while waiting for a user response.
     * 
     * @return a list containing the PASS#s as Strings
     * @throws CbkServiceException when an error occurs
     */
    public List getNoResponsCbkes() throws CbkServiceException;

    /**
     * Get a listing of all PASS#s that qualify as being aged -- open too long
     *  waiting for the assignee to close.
     * 
     * @return a list containing the PASS#s as Strings
     * @throws CbkServiceException when an error occurs
     */
    public List getAgedPASSes() throws CbkServiceException;

    /**
     * Close a specific PASS# due to lack of user response
     * 
     * @param requestId the PASS# to close
     * @throws CbkServiceException when an error occurs
     */
    public void closCbkNoResponse(String requestId)
        throws CbkServiceException;

    /**
     * Get the date and time of the last successful run of the process as a
     *  long from a file on the filesystem
     * 
     * @param completeFileName the complete file name (including path) of the file 
     * @return the date and time as a long
     * @throws CbkServiceException when an error occurs
     */
    public long getLastRunDate(String completeFileName)
        throws CbkServiceException;

    /**
     * Set the date and time of the last successful run of the proccess as a
     *  long in a file on the filesystem
     * 
     * @param lastRunDate the date and time as a long
     * @param completeFileName the complete file name (including path) of the file
     * @throws CbkServiceException when an error occurs
     */
    public void setLastRunDate(long lastRunDate, String completeFileName)
        throws CbkServiceException;
}
/*
 * StoreGroup.java
 *
 * Created on March 13, 2001, 2:48 PM
 */
package com.unfi.cbk.ldap;

import java.util.Vector;

import com.unfi.cbk.ldaputil.Comparer;
import com.unfi.cbk.ldaputil.VectorFuncs;

/**
 * Class to hold Store Group information.
 * @author: yhp6y2l
 */
public class StoreGroup
	extends Object
{
	private String businessCategory;    // "HQ", "DC" etc.
	private String description;         // "015" for Mpls. DC etc.
	private String name;                // "Minneapolis DC".
	private String owner;               // Who created the group.
	private String seeAlso;             // Unique ID for this group.

	public String getType()     	{return(businessCategory);}
	public String getGroupNumber()	{return(description);}
	public String getName()     	{return(name);}
	public String getOwner()    	{return(owner);}
	public String getGroupID()  	{return(seeAlso);}

	/** Creates new StoreGroup object */
	public StoreGroup(String groupType,
					  String groupNumber,
					  String name,
					  String owner,
					  String groupID)
	{
		super();

		this.businessCategory = groupType;
		this.description = groupNumber;
		this.name = name;
		this.owner = owner;
		this.seeAlso = groupID;
	}
    
	/**
	 * Compares this StoreGroup to the specified object.
	 * The result is true if and only if the argument is not 
	 * null and is a StoreGroup object that represents 
	 * the same store group as this object (ie. the groupType,
	 * name, owner and groupid are the same).
	 *
	 * @param   anObject   the object to compare this StoreGroup against.
	 * @return  true if the StoreGroups are equal;
	 *          false otherwise.
	 */
	public boolean equals(Object anObject)
	{
		if (this == anObject) {
			return true;
		}

		if (anObject instanceof StoreGroup) {
			StoreGroup tStoreGroup = (StoreGroup) anObject;

			if ((this.getType().equalsIgnoreCase(tStoreGroup.getType())) &&
				(this.getGroupNumber().equalsIgnoreCase(tStoreGroup.getGroupNumber())) &&
				(this.getName().equalsIgnoreCase(tStoreGroup.getName())) &&
				(this.getOwner().equalsIgnoreCase(tStoreGroup.getOwner())) &&
				(this.getGroupID().equalsIgnoreCase(tStoreGroup.getGroupID()))) {

				return true;
			}
		}

		return false;
	}
    
	// Sorts by businessCategory + name.
	private static class TypeAndNameOrder implements Comparer
	{
		public int compare(java.lang.Object o1, java.lang.Object o2)
		{
			int ret;
			ret = ((StoreGroup)o1).businessCategory.toLowerCase().compareTo(((StoreGroup)o2).businessCategory.toLowerCase());
			ret = ret == 0 ? ((StoreGroup)o1).name.toLowerCase().compareTo(((StoreGroup)o2).name.toLowerCase()) : ret;
			return(ret);
		}
	}
    
	/**
	 * Sorts the Vector of StoreGroup objects into order by
	 * Type + Name.
	 */
	public static void sortByTypeAndName(Vector vector)
	{
		VectorFuncs.sort(vector, new StoreGroup.TypeAndNameOrder());
	}
    
	// Sorts by businessCategory + description.
	private static class TypeAndGroupNumberOrder implements Comparer
	{
		public int compare(java.lang.Object o1, java.lang.Object o2)
		{
			int ret;
			ret = ((StoreGroup)o1).businessCategory.toLowerCase().compareTo(((StoreGroup)o2).businessCategory.toLowerCase());
			ret = ret == 0 ? ((StoreGroup)o1).description.toLowerCase().compareTo(((StoreGroup)o2).description.toLowerCase()) : ret;
			return ret;
		}
	}

	/**
	 * Sorts the Vector of StoreGroup objects into order by
	 * Type + Name.
	 */
	public static void sortByTypeAndGroupNumber(Vector vector)
	{
		VectorFuncs.sort(vector, new StoreGroup.TypeAndGroupNumberOrder());
	}

	// Sorts by name.
	private static class NameOrder implements Comparer
	{
		public int compare(java.lang.Object o1, java.lang.Object o2)
		{
			int ret = ((StoreGroup)o1).name.toLowerCase().compareTo(((StoreGroup)o2).name.toLowerCase());
			return(ret);
		}
	}
    
	/**
	 * Sorts the Vector of StoreGroup objects into order by
	 * Name.
	 */
	public static void sortByName(Vector vector)
	{
		VectorFuncs.sort(vector, new StoreGroup.NameOrder());
	}

	// Sorts by group number.
	private static class GroupNumberOrder implements Comparer
	{
		public int compare(java.lang.Object o1, java.lang.Object o2)
		{
			int ret = ((StoreGroup)o1).description.toLowerCase().compareTo(((StoreGroup)o2).description.toLowerCase());
			return(ret);
		}
	}

	/**
	 * Sorts the Vector of StoreGroup objects into order by
	 * Group Number.
	 */
	public static void sortByGroupNumber(Vector vector)
	{
		VectorFuncs.sort(vector, new StoreGroup.GroupNumberOrder());
	}
}
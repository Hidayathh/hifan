package com.unfi.cbk.forms;

import java.util.List;

import org.apache.log4j.Logger;


/**
 * The ApproverSelectorForm class is the struts action form used
 * for the user selector pop up.  It extends
 * the ValidatorActionForm class in order to utilize built-in
 * struts validation.
 *
 * @author      vpil001
 * @version     1.0
 */
public class ApproverSelectorForm {//extends ValidatorActionForm {
	
	static Logger log = Logger.getLogger(ApproverSelectorForm.class);

	private String userId = null;
	private String userName = null;
	private List searchResults = null;
	private Integer results = null;
	private String selectedResult = null;

	
	public String getUserId() {
		return userId;
	}



	public void setUserId(String userId) {
		this.userId = userId;
	}



	public String getUserName() {
		return userName;
	}



	public void setUserName(String userName) {
		this.userName = userName;
	}

	
	/**
	 * @return
	 */
	public Integer getResults() {
		return results;
	}


	
	/**
	 * @return
	 */
	public List getSearchResults() {
		return searchResults;
	}

	/**
	 * @param i
	 */
	public void setResults(Integer i) {
		results = i;
	}

	

	
	
	/**
	 * @param list
	 */
	public void setSearchResults(List list) {
		searchResults = list;
	}

	/**
	 * @return
	 */
	public String getSelectedResult() {
		return selectedResult;
	}

	/**
	 * @param string
	 */
	public void setSelectedResult(String string) {
		selectedResult = string;
	}

}
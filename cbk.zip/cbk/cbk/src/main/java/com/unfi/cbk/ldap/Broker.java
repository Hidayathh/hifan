package com.unfi.cbk.ldap;

import java.util.Vector;

import com.unfi.cbk.ldaputil.Comparer;
import com.unfi.cbk.ldaputil.VectorFuncs;

/**
 * Class to hold Broker information.
 * Creation date: (04/04/2002 3:34:51 PM)
 * @author: yhp6y2l
 */
public class Broker implements SupplierInf
{
	private java.lang.String brokerNumber;
	private java.lang.String brokerName;
	private java.lang.String emailAddress;
	private java.lang.String address;
	private java.lang.String city;
	private java.lang.String stateCode;
	private java.lang.String zipCode;
	private java.lang.String phoneNumber;
	private java.lang.String faxNumber;
	protected java.lang.String contact;

    // Sorts by brokerName.
    private static class BrokerNameOrder implements Comparer
    {
        public int compare(java.lang.Object o1,
	        			   java.lang.Object o2)
        {
	        /*
	         * Caution, don't use compareToIgnoreCase(), it's not supported
	         * in Microsoft Java Environment.
	         */
            int ret = ((Broker)o1).brokerName.toLowerCase().compareTo(((Broker)o2).brokerName.toLowerCase());

            return ret;
        }
    }
	public Broker()
	{
		super();
		
		brokerNumber = "";
		brokerName = "";
		emailAddress = "";
		address = "";
		city = "";
		stateCode = "";
		zipCode = "";
		phoneNumber = "";
		faxNumber = "";
	}
	/** Creates new Broker object */
	public Broker(java.lang.String brokerNumber,
				  java.lang.String brokerName,
				  java.lang.String emailAddress,
				  java.lang.String address,
				  java.lang.String city,
				  java.lang.String stateCode,
				  java.lang.String zipCode,
				  java.lang.String phoneNumber,
				  java.lang.String faxNumber)
	{
		super();

		this.brokerNumber = brokerNumber;
		this.brokerName = brokerName;
		this.emailAddress = emailAddress;
		this.address = address;
		this.city = city;
		this.stateCode = stateCode;
		this.zipCode = zipCode;
		this.phoneNumber = phoneNumber;
		this.faxNumber = faxNumber;
	}
	/** Creates new Broker object */
	public Broker(java.lang.String brokerNumber,
				  java.lang.String brokerName,
				  java.lang.String emailAddress,
				  java.lang.String address,
				  java.lang.String city,
				  java.lang.String stateCode,
				  java.lang.String zipCode,
				  java.lang.String phoneNumber,
				  java.lang.String faxNumber,
				  java.lang.String contact)
	{
		super();

		this.brokerNumber = brokerNumber;
		this.brokerName = brokerName;
		this.emailAddress = emailAddress;
		this.address = address;
		this.city = city;
		this.stateCode = stateCode;
		this.zipCode = zipCode;
		this.phoneNumber = phoneNumber;
		this.faxNumber = faxNumber;
		this.contact = contact;
	}

/**
 * Returns the contents of the address field.
 *
 * @return String
 */
public java.lang.String getAddress()  {return(address);}
/**
 * Returns the contents of the brokerName field.
 *
 * @return String
 */
public java.lang.String getBrokerName()  {return(brokerName);}
/**
 * Returns the contents of the brokerNumber field.
 *
 * @return String
 */
public java.lang.String getBrokerNumber()  {return(brokerNumber);}
/**
 * This method is deprecated and should not be used.
 * 
 * TODO:  Remove this method when the ePOF team no longer uses it.
 */
public java.lang.String getBrokerID()  {return(brokerNumber);}
/**
 * Returns the contents of the city field.
 *
 * @return String
 */
public java.lang.String getCity()  {return(city);}
/**
 * Returns the contents of the emailAddress field.
 *
 * @return String
 */
public java.lang.String getEmailAddress()  {return(emailAddress);}
/**
 * Returns the contents of the faxNumber field.
 *
 * @return String
 */
public java.lang.String getFaxNumber()  {return(faxNumber);}
/**
 * Returns the contents of the phoneNumber field.
 *
 * @return String
 */
public java.lang.String getPhoneNumber()  {return(phoneNumber);}
/**
 * Returns the contents of the stateCode field.
 *
 * @return String
 */
public java.lang.String getStateCode()  {return(stateCode);}
/**
 * Returns the contents of the zipCode field.
 *
 * @return String
 */
public java.lang.String getZipCode()  {return(zipCode);}
/**
 * Sorts the Vector of Broker objects into order by
 * Broker Number.
 */
public static void sortByBrokerName(Vector vector)
{
    VectorFuncs.sort(vector, new Broker.BrokerNameOrder());
}

	public String getId()
	{
		return this.brokerNumber;
	}
	
	public String getName()
	{
		return this.brokerName;
	}		

	/**
	 * Gets the contact
	 * @return Returns a java.lang.String
	 */
	public java.lang.String getContact() {
		return contact;
	}
	/**
	 * Sets the contact
	 * @param contact The contact to set
	 */
	public void setContact(java.lang.String contact) {
		this.contact = contact;
	}
	public boolean equals(Object o1)
	{
		return ( this.brokerNumber.equals(((Broker)o1).brokerNumber) );
	}

}

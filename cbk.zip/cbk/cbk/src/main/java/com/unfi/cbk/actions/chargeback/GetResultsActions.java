package com.unfi.cbk.actions.chargeback;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.servlet.ModelAndView;

import com.unfi.cbk.actions.PageAccessResolver;
import com.unfi.cbk.beans.ResultList;
import com.unfi.cbk.bo.ChargebackBO;
import com.unfi.cbk.bo.LocationBO;
import com.unfi.cbk.delegates.ChargebackSearchDelegate;
import com.unfi.cbk.forms.ChargebackSearchForm;
import com.unfi.cbk.util.ActionMessages;
import com.unfi.cbk.util.ActionUrlMapping;
import com.unfi.cbk.util.Constants;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


/**
 * The GetResultsAction class is the struts action called when retrieving
 * the search results.
 * The action simply determines the user type and forwards the request to
 * a secondary struts action specific to the user type.
 * <p>
 * This is to accommodate the struts Validator.  Since all three versions
 * of the search form use the same ActionForm, the different validations that 
 * need to be done specific to the type of form used are accomplished by
 * having the validator use the actions to determine which rules to use.<br>
 * This action, then, makes the user type transparent to the user by always
 * having the same action called when searching, regardless of user type.
 *
 * @author      vpil001
 * @since       1.0
 */
@Controller("getResultsAction_chargebacks")
@Scope(value=WebApplicationContext.SCOPE_REQUEST, proxyMode=ScopedProxyMode.TARGET_CLASS)
public class GetResultsActions {//extends Action {
	static Logger log = Logger.getLogger(GetResultsActions.class);	
	@Autowired
    private ChargebackSearchDelegate chargebackSearchDelegate;
	
	public GetResultsActions(ChargebackSearchDelegate chargebackSearchDelegate) {
		this.chargebackSearchDelegate = chargebackSearchDelegate;
	}
	
	@Autowired
	 ActionMessages messages;
	@Autowired
	Environment env;
	//Externalize this value
    @Value("${cbk.autoGrowCollectionLimit:100000}")
    private int autoGrowCollectionLimit;
    @InitBinder
    public void initBinder(WebDataBinder dataBinder) {
        dataBinder.setAutoGrowCollectionLimit(autoGrowCollectionLimit);
    }
	
	@RequestMapping(value = "/getChargebackResults",method = {RequestMethod.GET,RequestMethod.POST})
	public ModelAndView execute(@ModelAttribute("chargebackSearchForm") ChargebackSearchForm chargebackSearchForm, HttpServletRequest request, HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		log.debug("***** CHARGEBACK SEARCH - RESULTS *****");
		System.out.println("...........CHARGEBACK SEARCH - RESULTS......");
		chargebackSearchForm.setFormParameterMap(request);
		//	****  Exceptions handled by global exception handlers ****
		
		//ChargebackSearchForm chargebackSearchForm = (ChargebackSearchForm) form;
//		MessageResources environmentResources = getResources(request, "environmentResources");
//		String maxPerPage = environmentResources.getMessage("maxDocumentSearchResultsPerPage");

      
		String locationNumber= chargebackSearchForm.getLocationNumber().toString();
		String vendorId = chargebackSearchForm.getVendorId();
		String invoiceFrom = chargebackSearchForm.getInvoiceFrom();
		String invoiceTo = chargebackSearchForm.getInvoiceTo();
		String amountFrom = chargebackSearchForm.getAmountFrom();
		String amountTo = chargebackSearchForm.getAmountTo();
		String apStatus = chargebackSearchForm.getAPStatus();
		String status = chargebackSearchForm.getStatus();
		String type = chargebackSearchForm.getType();
		String originator = chargebackSearchForm.getOriginator();
		String approver = chargebackSearchForm.getApprover();
		String fromDate = chargebackSearchForm.getFromDate();
		String toDate = chargebackSearchForm.getToDate();
		
		
		System.out.println("CHARGEBACK SEARCH - locationNumber......"+locationNumber);
		System.out.println("CHARGEBACK SEARCH - vendorId......"+vendorId);
		System.out.println("CHARGEBACK SEARCH - invoiceFrom......"+invoiceFrom);
		System.out.println("CHARGEBACK SEARCH - invoiceTo......"+invoiceTo);
		System.out.println("CHARGEBACK SEARCH - amountFrom......"+amountFrom);
		System.out.println("CHARGEBACK SEARCH - amountTo......"+amountTo);
		System.out.println("CHARGEBACK SEARCH - APStatus......"+apStatus);
		System.out.println("CHARGEBACK SEARCH - Status......"+status);
		System.out.println("CHARGEBACK SEARCH - Type......"+type);
		System.out.println("CHARGEBACK SEARCH - originator......"+originator);
		System.out.println("CHARGEBACK SEARCH - approver......"+approver);
		System.out.println("CHARGEBACK SEARCH - fromDate......"+fromDate);
		System.out.println("CHARGEBACK SEARCH - toDate......"+toDate);
		
		
        String userId = chargebackSearchForm.getString("userId");
		System.out.println("CHARGEBACK SEARCH - RESULTS...userId..."+userId);
       
        Map searchParametersFromForm = chargebackSearchForm.getMap();
        
        
        if (chargebackSearchForm.getLocationNumber() != null) {
			
			String idPattern = "[\\s0-9,. ]*";
			boolean specialCharFlag = validateSpecialCharacters(chargebackSearchForm.getLocationNumber().toString(), idPattern);
			if (specialCharFlag == true) {
				messages.add("locationNumber", "errors.validateLocation", null);
			}
		}
      
       
        if(messages.isEmpty())
		{
        	System.out.println("--------validation start ----");
        	searchParametersFromForm.put("originator",chargebackSearchForm.getOriginator());
        	searchParametersFromForm.put("approver",chargebackSearchForm.getApprover());
            searchParametersFromForm.put("vendorId",chargebackSearchForm.getVendorId());
            searchParametersFromForm.put("locationNumber",chargebackSearchForm.getLocationNumber());
           
            searchParametersFromForm.put("invoiceFrom",chargebackSearchForm.getInvoiceFrom());
            searchParametersFromForm.put("invoiceTo",chargebackSearchForm.getInvoiceTo());
            searchParametersFromForm.put("amountFrom",chargebackSearchForm.getAmountFrom());
            searchParametersFromForm.put("amountTo",chargebackSearchForm.getAmountTo());
            
            if(chargebackSearchForm.getStatus().equalsIgnoreCase("Cancelled"))
            {//Cancelled IS NOT NULL
            	System.out.println("********CANCELLED SELECTED******");
            	  searchParametersFromForm.put("cancelled","true");
            } else
            	//Active is NULL
            {	    searchParametersFromForm.put("active","true");     
            }   
            if(chargebackSearchForm.getAPStatus().equalsIgnoreCase("Final"))
            {//Final IS NOT NULL
            	System.out.println("********FINAL SELECTED******");
                  searchParametersFromForm.put("final",true);
            }else
            	//notFinal IS NULL
              {   searchParametersFromForm.put("notFinal",true);
              }
           searchParametersFromForm.put("type",chargebackSearchForm.getType());
        // searchParametersFromForm.put("fromDate",chargebackSearchForm.getFromDate());
           // searchParametersFromForm.put("toDate",chargebackSearchForm.getToDate());
           
           
           if(chargebackSearchForm.getLocationNumber()!=null  &&  !chargebackSearchForm.getLocationNumber().isEmpty()) {
            ResultList locationValidatorResult = chargebackSearchDelegate.locationNumberValidator(searchParametersFromForm);
    		System.out.println("-------------AFTER QEURY------locationvalidator--size----------"+locationValidatorResult.getList().size());
    		if(locationValidatorResult.getList().size()==0)
    			{
    				messages.add("locationNumber", "errors.InvalidLocationNumber", null);
    			}
           }
            
           if(chargebackSearchForm.getLocationNumber()!=null  &&  !chargebackSearchForm.getVendorId().isEmpty()) {
               ResultList vendorValidatorResult = chargebackSearchDelegate.vendorNumberValidator(searchParametersFromForm);
       		System.out.println("-------------AFTER QEURY------vendorValidatorResult--size----------"+vendorValidatorResult.getList().size());
       		if(vendorValidatorResult.getList().size()==0)
       			{
       				messages.add("vendorId", "errors.InvalidVendorNumber", null);
       			}
              }
           
           if(chargebackSearchForm.getOriginator()!=null  &&  !chargebackSearchForm.getOriginator().isEmpty()) {
               ResultList originatorValidatorResult = chargebackSearchDelegate.originatorValidator(searchParametersFromForm);
       		System.out.println("-------------AFTER QEURY------originatorValidatorResult--size----------"+originatorValidatorResult.getList().size());
       		if(originatorValidatorResult.getList().size()==0)
       			{
       				messages.add("originator", "errors.InvalidOriginator", null);
       			}
              }
           
           if(chargebackSearchForm.getApprover()!=null  &&  !chargebackSearchForm.getApprover().isEmpty()) {
               ResultList approverValidatorResult = chargebackSearchDelegate.approverValidator(searchParametersFromForm);
       		System.out.println("-------------AFTER QEURY------approverValidatorResult--size----------"+approverValidatorResult.getList().size());
       		if(approverValidatorResult.getList().size()==0)
       			{
       				messages.add("approver", "errors.InvalidApprover", null);
       			}
              }
          
			
			
			
        	
		}
        
        
        chargebackSearchForm.validate(request,env,messages);
		
		if(!messages.isEmpty())
		{
			System.out.println("---------ERROR MESSAGES-----");
			//TODO return back to the same.
			request.setAttribute("actionMessages", messages);
			messages.saveMessages(request);
			request.setAttribute("chargebackSearchForm", chargebackSearchForm);
			mav.setViewName("forward:/newChargebackSearch");
			return mav;
		}
        
		//  Define the display parameters
		int maxRows = 20;
        chargebackSearchForm.setDisplayCount(maxRows);

       if ( chargebackSearchForm.isShowAll() ) {
            searchParametersFromForm.put("showAll", "true");
        }            
        else {
            searchParametersFromForm.put("rowStart", new Integer(chargebackSearchForm.getCurrentRecord()));
            searchParametersFromForm.put("rowEnd",   new Integer(chargebackSearchForm.getCurrentRecord() + maxRows - 1));
        }
       
       HttpSession session=request.getSession();  
       session.setAttribute("searchParametersFromForm",searchParametersFromForm); 
		
		System.out.println("-------------BEFORE QEURY------------------");
		//  Get the search results based on the parameters in the form
		ResultList searchResults = chargebackSearchDelegate.getChargebacks(searchParametersFromForm);
		System.out.println("-------------AFTER QEURY------searchResults--size----------"+searchResults.getList().size());
		
		//  Populate the 'searchResults' property in the ActionForm
		chargebackSearchForm.setSearchResults(searchResults.getList());
		//HttpSession session=request.getSession();  
		//session.setAttribute("searchResults",searchResults.getList()); 

		//  Populate the result count property in the ActionForm
		//chargebackSearchForm.setTotalRecords(searchResults.getTotalCount().intValue());

		// Place the summary information in the messages. 
		// This is necessary, as the criteria is rendered in the header, which knows nothing about our form
       // ActionMessages messages = new ActionMessages();
		//messages.add("searchCriteriaSummary", "messages.searchCriteriaSummary", new String[] {documentDelegate.buildSearchCriteriaSummary(searchParametersFromForm, filterLocations, exclude)});
		//saveMessages(request, messages);
		 messages.saveMessages(request);

		PageAccessResolver resolver = new PageAccessResolver(request);
		if (resolver.hasAccess()){	
			mav.setViewName(ActionUrlMapping.CHARGEBACKGETRESULTSACTION.get(Constants.ACTION_SUCCESS));
			request.setAttribute("actionMessages", messages);
			//return mapping.findForward("success");
			request.setAttribute("chargebackSearchForm", chargebackSearchForm);
			//HttpSession session=request.getSession();
			//session.setAttribute("chargebackSearchForm", chargebackSearchForm);
			System.out.println("---IF--getChargebackSearchResults-------"+mav.getViewName());
			return mav;
		}
		else{
			mav.setViewName(ActionUrlMapping.CHARGEBACKGETRESULTSACTION.get("other"));
			//return mapping.findForward("other");
			
			System.out.println("--ELSE---getChargebackSearchResults-------"+mav.getViewName());
			
			request.setAttribute("actionMessages", messages);
			request.setAttribute("chargebackSearchForm", chargebackSearchForm);
			return mav;
		}			
	}
	
	
	
	
	
	private boolean validateSpecialCharacters(String string,String idNamePattern)
	{
		Pattern pattern=Pattern.compile(idNamePattern);
		
		Matcher matcher = pattern.matcher(string);
		 
		boolean  patternFlag = false;
		
	      if (!matcher.matches()) {
	    	  
	    	  patternFlag=true;
	           System.out.println("String--- "+string+" contains special character");
	      } 
		 
		return patternFlag;
	}
}
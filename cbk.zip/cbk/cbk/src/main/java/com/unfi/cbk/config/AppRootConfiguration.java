/**
 * 
 */
package com.unfi.cbk.config;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;

import javax.servlet.Servlet;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;

import org.apache.catalina.connector.Connector;
import org.apache.tomcat.util.descriptor.web.ContextResource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.embedded.tomcat.TomcatServletWebServerFactory;
import org.springframework.boot.web.embedded.tomcat.TomcatWebServer;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.boot.web.servlet.ServletContextInitializer;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.core.env.Environment;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.accept.ContentNegotiationManager;
import org.springframework.web.context.request.RequestContextListener;
import org.springframework.web.filter.RequestContextFilter;
import org.springframework.web.servlet.ViewResolver;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.view.ContentNegotiatingViewResolver;
import org.springframework.web.servlet.view.JstlView;
import org.springframework.web.servlet.view.UrlBasedViewResolver;
import org.springframework.web.servlet.view.tiles3.TilesConfigurer;
import org.springframework.web.servlet.view.tiles3.TilesViewResolver;

import com.unfi.cbk.filter.HarborFilter;

//import com.unfi.cbk.servlets.BackgroundJobs;
import com.unfi.cbk.servlets.HealthCheck;
import com.unfi.cbk.servlets.ShowHeaders;
import com.unfi.cbk.utilcore.Setup;

/**
 * 
 * @author yhp6y2l
 *
 */
@Configuration
@PropertySources({ 
					@PropertySource("classpath:application.properties"),
					@PropertySource("classpath:server.properties"),
					@PropertySource("classpath:ldap.properties"),
					@PropertySource("classpath:log4j.properties"),
					@PropertySource("classpath:environmentResources.properties"),
					@PropertySource("classpath:com/unfi/cbk/resources/ApplicationResources.properties"),
					@PropertySource("classpath:commons-logging.properties")
					//@PropertySource("classpath:/com/svharbor/epass/dao/ibImpl/xml/IncludesOracle.xml")
})
@ImportResource("classpath:/config/spring-beans.xml")
@EnableTransactionManagement
public class AppRootConfiguration implements WebMvcConfigurer{

	private static Logger logger = LoggerFactory.getLogger(AppRootConfiguration.class.getName());
	
	@Value("${work.nfs.config.svharborldapfuncs.path}")
	private String svHarborLdapFuncsFilePath;

	
//	@Autowired
//	RequestParamFilter requestParamFilter;
	
	@Autowired
    private CSRFTokenFilter csrfTokenFilter;

   @Override
   public void addInterceptors(InterceptorRegistry registry) {
      registry.addInterceptor(csrfTokenFilter);//.excludePathPatterns(AppWebSecurityConfig.skipStaticResource);
 }
	
	/*
	 * RequestContextListener is added to access HttpServletRequest in the bean
	 * using @Autowired else below error java.lang.IllegalStateException: No
	 * thread-bound request found: Are you referring to request attributes outside
	 * of an actual web request, or processing a request outside of the originally
	 * receiving thread? If you are actually operating within a web request and
	 * still receive this message, your code is probably running outside of
	 * DispatcherServlet: In this case, use RequestContextListener or
	 * RequestContextFilter to expose the current request.
	 */

	
	@Bean
	public FilterRegistrationBean<CLRFFilter> clrfFilter(){
	    FilterRegistrationBean<CLRFFilter> registrationBean 
	      = new FilterRegistrationBean<>();
	         
	    registrationBean.setFilter(new CLRFFilter());
	    registrationBean.addUrlPatterns("/*");
	         
	    return registrationBean;    
	}

	@Bean
	public RequestContextListener requestContextListener() {
		
		return new RequestContextListener();
	}
	@Bean
	public RequestContextFilter requestContextFilterr() {
		
		return new RequestContextFilter();
	}

	@Value("${db.schema.name}")
	private String dbschemaname;
	
	
	
	@Value("${work.nfs.config.path}")
	private String worknfsconfigpath;
	
	@Value("${server.servlet.session.cookie.secure}")
	private String isCookieSecure;
	
	@Bean
	public void addToSystemProperties()
	{

		//load the external ldap properties file location to the System properties
		logger.debug("svHarborLdapFuncsFilePath = "+svHarborLdapFuncsFilePath);
		System.setProperty("svHarborLdapFuncsFilePath", svHarborLdapFuncsFilePath);
		System.out.println("************db.schema.name= "+dbschemaname);
		System.setProperty("dbschemaname", dbschemaname);
		System.setProperty("work.nfs.config.path", worknfsconfigpath);
		System.setProperty("server.servlet.session.cookie.secure", isCookieSecure);
	}

	
	/*
	 * PropertySourcesPlaceHolderConfigurer Bean only required for @Value("{}")
	 * annotations. Remove this bean if you are not using @Value annotations for
	 * injecting properties.
	 */
	@Bean
	public static PropertySourcesPlaceholderConfigurer propertySourcesPlaceholderConfigurer() {
		return new PropertySourcesPlaceholderConfigurer();
	}

	
	@Bean("messageSource")
	public ResourceBundleMessageSource messageSource()
	{
		ResourceBundleMessageSource messageSource = new ResourceBundleMessageSource();
		
		messageSource.setBasename("com/unfi/cbk/resources/ApplicationResources");
		messageSource.addBasenames("environmentResources");
		return messageSource;
	}
	
	/**
	 * 
	 * @return
	
	@Bean
	public ServletRegistrationBean<Servlet> reportsPlugIn() {
		ReportsPlugIn reportPlugin = new ReportsPlugIn();
		reportPlugin.setKey("REPORTS_KEY");
		reportPlugin.setXmlFile("/WEB-INF/reports.xml");
		reportPlugin.setXmlRules("/WEB-INF/reports-rules.xml");
		
		ServletRegistrationBean<Servlet> servlet = new ServletRegistrationBean<>(reportPlugin, "/ReportsPlugIn");
		
		servlet.setLoadOnStartup(1);
		servlet.setName("ReportsPlugIn");
		return servlet;
	}
	 */
	
	
	/*@Description("Set the context attributes")
	@Bean(name="servletContextAttributeExporter")
	public ServletContextAttributeExporter servletContextAttributeExporter()
	{
		ServletContextAttributeExporter contextAttributeExporter = new ServletContextAttributeExporter();
		<context-param>
		<param-name>PropertyManager</param-name>
		<param-value>com.supervalu.svharbor.common.util.properties.PropertyBroker</param-value>
	</context-param>
		Map<String,Object> attributes = new HashMap<>();
		
		attributes.put("PropertyManager", "com.supervalu.svharbor.common.util.properties.PropertyBroker");
		attributes.put("appMenu","menu.xml");
		attributes.put("appMenuRules","menuRules.xml");
		attributes.put("appProperties","properties.xml");
		attributes.put("appPropertiesRules","propertiesRules.xml");
		attributes.put("ldapPropertiesFile","SVHarborLDAPFuncs.properties");
		
		contextAttributeExporter.setAttributes(attributes);
		
		return contextAttributeExporter;
	}*/
	@Bean
	public FilterRegistrationBean<HarborFilter> harborFilter(){
		System.out.println("------AppRootConfig.java method harborFilter() method--------");
		FilterRegistrationBean<HarborFilter> registrationBean 
	      = new FilterRegistrationBean<>();
	         
	    registrationBean.setFilter(new HarborFilter());
	    registrationBean.addUrlPatterns("/*");
	         
	    return registrationBean;    
	}
	
	@Bean
	public ServletRegistrationBean<Setup> setup() {
		System.out.println("------AppRootConfig.java method setup() method--------");
		ServletRegistrationBean<Setup> servlet = new ServletRegistrationBean<>(new Setup(), "/Setup");
		servlet.setLoadOnStartup(1);
		servlet.setName("Setup");
		return servlet;
	}

	@Bean
	public ServletRegistrationBean<HealthCheck> healthCheck() {
		System.out.println("------AppRootConfig.java method healthCheck() method--------");
		ServletRegistrationBean<HealthCheck> servlet = new ServletRegistrationBean<>(new HealthCheck(), "/HealthCheck");
		servlet.setLoadOnStartup(1);
		servlet.setName("HealthCheck");
		return servlet;
	}

	@Bean
	public ServletRegistrationBean<ShowHeaders> showHeaders() {
		System.out.println("------AppRootConfig.java method showHeaders() method--------");
		ServletRegistrationBean<ShowHeaders> servlet = new ServletRegistrationBean<>(new ShowHeaders(), "/ShowHeaders");
		servlet.setLoadOnStartup(1);
		servlet.setName("ShowHeaders");
		return servlet;
	}
//	@Bean
//	public ServletRegistrationBean<BackgroundJobs> backgroundJobs() {
//		ServletRegistrationBean<BackgroundJobs> servlet = new ServletRegistrationBean<>(new BackgroundJobs(), "/BackgroundJobs");
//		servlet.setLoadOnStartup(1);
//		servlet.setName("BackgroundJobs");
//		return servlet;
//	}
	
	/*@Bean
	public ServletRegistrationBean<VendorAddrChgJob> vendorAddrChgJob() {
		ServletRegistrationBean<VendorAddrChgJob> servlet = new ServletRegistrationBean<>(new VendorAddrChgJob(), "/VendorAddrChgJob");
		servlet.setLoadOnStartup(1);
		servlet.setName("VendorAddrChgJob");
		return servlet;
	}*/
	

	
	/**
	 * This method is used to register the context init params This method is used
	 * when the application is deployed to external container. This means if the app
	 * is not deployed to embedded tomcat server. For embedded tomcat server use the
	 * application.properties file setup.
	 * 
	 * 
	 * server.context-parameters.* only works for embedded servers, so to configure
	 * context-parameters on Java EE server is necessary to include a @Bean of type
	 * ServletContextInitializer like the following:
	 * 
	 * 
	 * @return
	 */
	@Bean
	public ServletContextInitializer contextInitializer() {
		return new ServletContextInitializer() {

			@Override
			public void onStartup(ServletContext servletContext) throws ServletException {

				servletContext.setInitParameter("javax.servlet.jsp.jstl.fmt.localizationContext", "com.unfi.cbk.resources.ApplicationResources");

			}

		};
	}

	/**
	 * Configure TilesConfigurer.
	 */
	@Bean
	public TilesConfigurer tilesConfigurer() {
		TilesConfigurer tilesConfigurer = new TilesConfigurer();
		tilesConfigurer.setDefinitions(new String[] { 
				"/WEB-INF/forwardDefinition.xml" });
		tilesConfigurer.setCheckRefresh(true);
		return tilesConfigurer;
	}

	/**
	 * This method is used to create tiles view resolver which have view resolver
	 * first priority for resolve response view
	 */
	private TilesViewResolver tilesViewResolver() {
		TilesViewResolver resolver = new TilesViewResolver();
		resolver.clearCache();
		resolver.setCache(false);
		resolver.setCacheLimit(1024);
		resolver.setOrder(0);
		return resolver;
	}

	

	/**
	 * This method is used to create simple jsp view resolver which have third
	 * priority for resolve response views
	 */
	private UrlBasedViewResolver urlBasedViewResolver() {
		UrlBasedViewResolver resolver = new UrlBasedViewResolver();
		resolver.setPrefix("");
		resolver.setSuffix(".jsp");
		resolver.setViewClass(JstlView.class);
		resolver.setCache(false);
		resolver.setCacheLimit(1024);
		resolver.setOrder(1);
		return resolver;
	}
	

	/**
	 * This method is used setup multiple view resolver for applications. This is a
	 * bean register to application.
	 */
	@Bean
	public ViewResolver viewResolver(ContentNegotiationManager manager) {
		List<ViewResolver> viewResolvers = new ArrayList<ViewResolver>();

		viewResolvers.add(tilesViewResolver());
		viewResolvers.add(urlBasedViewResolver());
		ContentNegotiatingViewResolver resolver = new ContentNegotiatingViewResolver();
		resolver.setViewResolvers(viewResolvers);
		resolver.setContentNegotiationManager(manager);
		return resolver;
	}

	
	
	// Quartz configuration. <!-- Job Scheduling -->
	/*@Autowired
	ReportCleanup reportCleanup;
	
	@Bean
	public MethodInvokingJobDetailFactoryBean  jobDetail() {

		MethodInvokingJobDetailFactoryBean bean = new MethodInvokingJobDetailFactoryBean();
		System.out.println("*********reportCleanup ="+reportCleanup);
		bean.setTargetObject(reportCleanup);
		bean.setTargetMethod("cleanupReports");
		return bean;
		
	}
	
	@Bean
	public SimpleTrigger simpleTrigger()
	{
		SimpleTriggerFactoryBean simpleTriggerBean = new SimpleTriggerFactoryBean();
		simpleTriggerBean.setJobDetail((JobDetail) jobDetail().getObject());
		//<!-- Run the job 10s after container start-up -->
		simpleTriggerBean.setStartDelay(10000L);
		//<!-- Repeat the job every hour -->
		simpleTriggerBean.setRepeatInterval(3600000L);
		
		return simpleTriggerBean.getObject();

	}
	
	@Autowired
	@Qualifier("ImportExportCleanup")
	ImportExportCleanup importExportCleanup;
	
	
	@Bean
	public MethodInvokingJobDetailFactoryBean  jobDetail2() {

		MethodInvokingJobDetailFactoryBean bean = new MethodInvokingJobDetailFactoryBean();
		System.out.println("*********ImportExportCleanup ="+importExportCleanup);

		bean.setTargetObject(importExportCleanup);
		bean.setTargetMethod("cleanup");
		return bean;
		
	}
	
	@Bean
	public SimpleTrigger simpleTrigger2()
	{
		SimpleTriggerFactoryBean simpleTriggerBean = new SimpleTriggerFactoryBean();
		simpleTriggerBean.setJobDetail((JobDetail) jobDetail2().getObject());
		//<!-- Run the job 10s after container start-up -->
		simpleTriggerBean.setStartDelay(20000L);
		//<!-- Repeat the job every hour -->
		simpleTriggerBean.setRepeatInterval(7200000L);
		
		return simpleTriggerBean.getObject();

	}*/
	
	/*@Bean(name="schedulerFactoryBean")
	public SchedulerFactoryBean schedulerFactoryBean() {
		SchedulerFactoryBean factoryBean = new SchedulerFactoryBean();
		List<org.quartz.Trigger> triggers = new ArrayList<>();
		triggers.add(simpleTrigger());
		triggers.add(simpleTrigger2());
		factoryBean.setTriggers(simpleTrigger(),simpleTrigger2());

		return factoryBean;
	}*/
	
/*	@Bean
	 public PlatformTransactionManager transactionManager(){ 
	    return new JtaTransactionManager();
	}
	@Bean
	 public PlatformTransactionManager txManagerOracle(){ 
	    return new JtaTransactionManager();
	}*/
	
	/*@Bean
	 public PlatformTransactionManager platformTransactionManager(){ 
	    return new JtaTransactionManager();
	}*/
	
	
	//this value is expected from command line argument 
		@Value("${nfs.config}")
		private String nfsConfigLocation;

		//this value is expected from the envrionmentResources.properties
		@Value("${work.nfs.config.svharbordbfuncs.path}")
		private String svharbordbfuncsPath;
		
		
		@Value("${svharbordbfuncs.file.name}")
		private String svharbordbfuncsFileName;
		
		
		@Autowired
		private WebServerProperties serverProperties;

//		@Bean
//		public TomcatServletWebServerFactory tomcatFactory() {
//			return new TomcatServletWebServerFactory() {
//				@Override
//				protected TomcatWebServer getTomcatWebServer(org.apache.catalina.startup.Tomcat tomcat) {
//					tomcat.enableNaming();
//					return super.getTomcatWebServer(tomcat);
//				}
//
//				
//				@Override
//				protected void postProcessContext(org.apache.catalina.Context context) {
//
//					// Resource classpathResource = new
//					// ClassPathResource("SVHarborDBFuncs.properties");
//					String dbFuncsFileName = "SVHarborDBFuncs.properties";// default
//					
//					if(svharbordbfuncsFileName !=null && !svharbordbfuncsFileName.trim().isEmpty())
//					{
//						dbFuncsFileName = svharbordbfuncsFileName;
//					}
//					
//					String dbFuncsFilePath = nfsConfigLocation;//default
//					if(dbFuncsFilePath == null || dbFuncsFilePath.trim().isEmpty())
//					{
//						dbFuncsFilePath = svharbordbfuncsPath;
//					}
//					
//					InputStream is = null;
//					Map<String, String> dbFuncsMap = new HashMap<>();
//					try {
//						// InputStream is = classpathResource.getInputStream();
//						is = new FileInputStream(dbFuncsFilePath + dbFuncsFileName);
//						try (BufferedReader reader = new BufferedReader(new InputStreamReader(is))) {
//
//							/*
//							 * String values = reader.lines() .collect(Collectors.joining("\n"));
//							 */
//							List<String> values = reader.lines().collect(Collectors.toList());
//
//							for (String dbfuncsvalue : values) {
//								if (dbfuncsvalue.contains("^")) {
//									// System.out.println("dbfuncsvalue ="+dbfuncsvalue);
//									String[] keyvalue = dbfuncsvalue.split("\\^");
//									// System.out.println(keyvalue.length);
//									dbFuncsMap.put(keyvalue[0], keyvalue[1]);
//								}
//								// dbFuncsMap.put(key, value)
//							}
//
//							// values.stream().forEach(System.out::println);
//							// System.out.println(values);
//							// assertEquals("Joe Employee,Jan Employee,James T. Employee", employees);
//						}
//					} catch (IOException e1) {
//						e1.printStackTrace();
//						new RuntimeException(
//								"Error initializing SVHarborDBFuncs.properties file, Please check the file in shared folder!");
//					} finally {
//						if (is != null) {
//							try {
//								is.close();
//							} catch (IOException e) {
//								e.printStackTrace();
//							}
//						}
//					}
//
//
//					// System.out.println("serverProperties=" + serverProperties);
//					if (dbFuncsMap.isEmpty()) {
//						new RuntimeException(
//								"SVHarborDBFuncs.properties file is empty, Please check the file in shared folder!");
//					}
//					if (serverProperties != null) {
//						for (WebServerProperties.Resource resource : serverProperties.getResource()) {
//							//log.debug("resource =" + resource);
//							String url = dbFuncsMap.get(resource.getUrl());
//							String dbusername = dbFuncsMap.get(resource.getUsername());
//							String dbpassword = dbFuncsMap.get(resource.getPassword());
//							if (url == null || dbusername == null || dbpassword == null) {
//								new RuntimeException(
//										"url == null || dbusername == null || dbpassword== null :::: please check the SVHarborDBFuncs.properties file for url="
//												+ resource.getUrl() + " username=" + resource.getUsername() + ", password="
//												+ resource.getPassword());
//
//							}
//
//							ContextResource contextResource = new ContextResource();
//							// check if the url is hard coded in the properties file
//							if (url == null) {
//								url = resource.getUrl();
//							}
//							if (dbusername == null) {
//								dbusername = resource.getUsername();
//							}
//							if (dbpassword == null) {
//								dbpassword = resource.getPassword();
//							}
//
//							resource.setUrl(url);
//							resource.setUsername(dbusername);
//							resource.setPassword(dbpassword);
//
//							logger.debug("Url = " + url);
//							logger.debug("dbusername = " + dbusername);
//							logger.debug("dbpassword = ********");
//
//							try {
//								// BeanUtils.copyProperties(contextResource, resource);
//								/*contextResource.setName(resource.getName());
//								contextResource.setType(DataSource.class.getName());
//								contextResource.setProperty("driverClassName", resource.getDriverClassName());
//								contextResource.setProperty("url", resource.getUrl());
//								contextResource.setProperty("username", resource.getUsername());
//								contextResource.setProperty("password", resource.getPassword());
//
//								if (resource.getMaxActive() != null) {
//									contextResource.setProperty("maxTotal", resource.getMaxActive());
//								}
//								if (resource.getMaxIdle() != null) {
//									contextResource.setProperty("maxIdle", resource.getMaxIdle());
//								}
//								if (resource.getMaxWait() != null) {
//									contextResource.setProperty("maxWaitMillis", resource.getMaxWait());
//								}
//								if (resource.getValidationQuery() != null) {
//									contextResource.setProperty("validationQuery", resource.getValidationQuery());
//								}
//								if (resource.getTestOnBorrow() != null) {
//									contextResource.setProperty("testOnBorrow", resource.getTestOnBorrow());
//								}
//								if (resource.getTestWhileIdle() != null) {
//									contextResource.setProperty("testWhileIdle", resource.getTestWhileIdle());
//								}
//								if (resource.getTimeBetweenEvictionRunsMillis() != null) {
//									contextResource.setProperty("timeBetweenEvictionRunsMillis",
//											resource.getTimeBetweenEvictionRunsMillis());
//								}
//								if (resource.getNumTestsPerEvictionRun() != null) {
//									contextResource.setProperty("numTestsPerEvictionRun",
//											resource.getNumTestsPerEvictionRun());
//								}
//								if (resource.getMinEvictableIdleTimeMillis() != null) {
//									contextResource.setProperty("minEvictableIdleTimeMillis",
//											resource.getMinEvictableIdleTimeMillis());
//								}*/
//
//							} catch (Exception e) {
//								e.printStackTrace();
//								new RuntimeException(
//										"Error populating server properties.perties file, Please check server.properties in classpath!");
//							}
//
//							// this property is used to avoid tomcat-dbcp dependency in maven
//							// contextResource.setProperty("factory",
//							// "org.apache.tomcat.jdbc.pool.DataSourceFactory");
//
//							/*contextResource.setName("jdbc/epassOracle");
//							contextResource.setType(DataSource.class.getName());
//							contextResource.setProperty("driverClassName", "oracle.jdbc.pool.OracleConnectionPoolDataSource");
//							contextResource.setProperty("url", "jdbc:oracle:thin:@ora-d000gih:1587/d000gih");
//							contextResource.setProperty("username", "HPEPASS_FUSER");
//							contextResource.setProperty("password", "G0faster");
//							context.getNamingResources().addResource(contextResource);*/
//							
//							contextResource.setName("jdbc/epass");
//							contextResource.setType(DataSource.class.getName());
//							contextResource.setProperty("driverClassName", "com.ibm.db2.jcc.DB2Driver");
//							contextResource.setProperty("url", "jdbc:db2://db2uat04ip.supervalu.com:50000/EPS01U");
//							contextResource.setProperty("username", "HAEPASS");
//							contextResource.setProperty("password", "wdc5k8");
//							context.getNamingResources().addResource(contextResource);
//
//						}
//					}
//				}
//			};
//		}
		
		private Connector createSslConnector(Connector connector) {
			   // Connector connector = new Connector("org.apache.coyote.http11.Http11NioProtocol");
			  //  Http11NioProtocol protocol = (Http11NioProtocol) connector.getProtocolHandler();
			
			    try {
			    	
			    	Map<String,String> dbFuncsMap =  getAllSVHarborDBFuncs();
			    	
			    	if(serverProperties !=null)
			    	{
			    		Map<String,String> map = serverProperties.getConnector();
			    		
			    		if(map !=null)
			    		{
			    			
			    			for(Entry<String, String> entrySet: map.entrySet())
			    			{
			    				//connector.setProperty(entrySet.getKey(), entrySet.getValue());
			    				//System.out.println("Key ="+entrySet.getKey()+" ,value="+entrySet.getValue());
			    				
			    				String dbFuncValue = dbFuncsMap.get(entrySet.getValue());
			    				logger.info("Before : key= " + entrySet.getKey() + " , value= " + entrySet.getValue());
								if (dbFuncValue != null) 
								{
									connector.setProperty(entrySet.getKey(), dbFuncValue);
									logger.info("After : key= " + entrySet.getKey() + " , value= " + dbFuncValue);
								} else {
									connector.setProperty(entrySet.getKey(), entrySet.getValue());
								}
			    				
			    			}
			    		}
			    	}
			    	
			    	
			    	return connector;
			    }
			    catch (Exception ex) {
			    	ex.getStackTrace();
			        throw new IllegalStateException("can't access keystore: [" + "keystore"
			                + "] or truststore: [" + "keystore" + "]", ex);
			    }
			}
	
	@Bean
	public Map<String,String> getAllSVHarborDBFuncs()
	{
		// Resource classpathResource = new
		// ClassPathResource("SVHarborDBFuncs.properties");
		String dbFuncsFileName = "SVHarborDBFuncs.properties";// default

		if (svharbordbfuncsFileName != null && !svharbordbfuncsFileName.trim().isEmpty()) {
			dbFuncsFileName = svharbordbfuncsFileName;
		}

		String dbFuncsFilePath = nfsConfigLocation;//default
		if (dbFuncsFilePath == null || dbFuncsFilePath.trim().isEmpty()) {
			dbFuncsFilePath = svharbordbfuncsPath;
		}

		InputStream is = null;
		Map<String, String> dbFuncsMap = new HashMap<>();
		try {
			// InputStream is = classpathResource.getInputStream();
			is = new FileInputStream(dbFuncsFilePath + dbFuncsFileName);
			try (BufferedReader reader = new BufferedReader(new InputStreamReader(is))) {

				List<String> values = reader.lines().collect(Collectors.toList());

				for (String dbfuncsvalue : values) {
					if (dbfuncsvalue.contains("^")) {
						// System.out.println("dbfuncsvalue ="+dbfuncsvalue);
						String[] keyvalue = dbfuncsvalue.split("\\^");
						// System.out.println(keyvalue.length);
						dbFuncsMap.put(keyvalue[0], keyvalue[1]);
					}
					// dbFuncsMap.put(key, value)
				}
			}
		} catch (IOException e1) {
			e1.printStackTrace();
			new RuntimeException(
					"Error initializing SVHarborDBFuncs.properties file, Please check the file in shared folder!");
		} finally {
			if (is != null) {
				try {
					is.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

		// System.out.println("serverProperties=" + serverProperties);
		if (dbFuncsMap.isEmpty()) {
			new RuntimeException(
					"SVHarborDBFuncs.properties file is empty, Please check the file in shared folder!");
		}
		return dbFuncsMap;
	}
		
	@Autowired
	private Environment environment;
	
	private boolean isActiveProfileLocal() {
		
		boolean isLocalEnv = false;
		
		String[] profiles = environment.getActiveProfiles();
		List<String> profileList=null;
		if(profiles !=null && profiles.length !=0)
		{
			profileList = Arrays.asList(profiles);
		}
		
		if(profileList !=null && profileList.contains("local"))
		{
			isLocalEnv = true;
		}
		return isLocalEnv;
	}
		
	@Bean
	public TomcatServletWebServerFactory tomcatFactory() {
		System.out.println("serverProperties = "+serverProperties);
		
		TomcatServletWebServerFactory factory= null;
		
		try {
			
			Map<String,String> dbFuncsMap =  getAllSVHarborDBFuncs();
			System.out.println("----dbFuncsMap---"+dbFuncsMap);
			factory = new TomcatServletWebServerFactory() {
				@Override
				protected TomcatWebServer getTomcatWebServer(org.apache.catalina.startup.Tomcat tomcat) {
					tomcat.enableNaming();

					//This check is written to skip connector configuration in local env
					if (!isActiveProfileLocal()) {
						Connector connector = tomcat.getConnector();

						tomcat.setConnector(createSslConnector(connector));

					}

					return super.getTomcatWebServer(tomcat);
				}

				@Override
				protected void postProcessContext(org.apache.catalina.Context context) {

					
					
					if (serverProperties != null) {

						List<Map<String, String>> resourceList = serverProperties.getResource();

						if (resourceList != null) {

							for (Map<String, String> map : resourceList) {
								ContextResource contextResource = new ContextResource();

								String tempValue = map.get("name");
								if (tempValue != null) {
									contextResource.setName(tempValue);
								}
								tempValue = map.get("auth");
								if (tempValue != null) {
									contextResource.setAuth(tempValue);
								}

								tempValue = map.get("scope");
								if (tempValue != null) {
									contextResource.setScope(tempValue);
								}

								tempValue = map.get("type");

								if (tempValue != null) {
									contextResource.setType(tempValue);
								}

								for (Entry<String, String> entrySet : map.entrySet()) {

									String dbFuncValue = dbFuncsMap.get(entrySet.getValue());
									if (dbFuncValue != null) {
										contextResource.setProperty(entrySet.getKey(), dbFuncValue);
										
									} else {
										contextResource.setProperty(entrySet.getKey(), entrySet.getValue());
									}
									System.out.println("key: "+entrySet.getKey() +",value ="+entrySet.getValue() +" , Map value=" + dbFuncValue);
									logger.info("key= " + entrySet.getKey() + " , value= " + dbFuncValue);
								}

								// this property is used to avoid tomcat-dbcp dependency in maven
								// contextResource.setProperty("factory",
								// "org.apache.tomcat.jdbc.pool.DataSourceFactory");
								context.getNamingResources().addResource(contextResource);
							}

						}

					}
				}
			};
		} catch (Exception e) {
			e.printStackTrace();
		}
		return factory;
	}	
		

}

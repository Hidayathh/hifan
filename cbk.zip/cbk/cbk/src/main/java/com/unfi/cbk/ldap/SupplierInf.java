package com.unfi.cbk.ldap;
/**
 * @author Supervalu 
 * Interface for Supplier.
 * Vendor & Broker should impelement this interface
 */
public interface SupplierInf {
	public String getId();
	public String getName();
	public String getAddress();
	public String getCity();
	public String getStateCode();
	public String getZipCode();
	public String getContact();
}


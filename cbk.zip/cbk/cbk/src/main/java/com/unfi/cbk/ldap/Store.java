/*
 * Store.java
 *
 * Created on March 13, 2001, 2:32 PM
 */
package com.unfi.cbk.ldap;

import java.util.Vector;

import com.unfi.cbk.ldaputil.CompareTo;
import com.unfi.cbk.ldaputil.Comparer;
import com.unfi.cbk.ldaputil.VectorFuncs;

/**
 * Class to hold Store information.
 * @author: yhp6y2l
 */
public class Store extends Object implements CompareTo
{
	private String storeNumber;
	private String type;    // "Store" or "HQ".
	private String storeName;
	private String address;
	private String city;
	private String stateCode;
	private String zipCode;
	private String phoneNumber;
	private String contact;
	private String logo;
	
	public String getStoreNumber()  {return(storeNumber);}
	public String getType()         {return(type);}
	public String getName()         {return(storeName);}
	public String getAddress()      {return(address);}
	public String getCity()         {return(city);}
	public String getStateCode()    {return(stateCode);}
	public String getZipCode()      {return(zipCode);}
	public String getContact()      {return(contact);}
	public String getPhoneNumber()  {return(phoneNumber);}
	public String getLogo()         {return(logo);}

	public void setStoreNumber(String storeNumber)  {this.storeNumber = storeNumber;}
	public void setName(String storeName)           {this.storeName = storeName;}
	public void setCity(String city)                {this.city = city;}
	public void setStateCode(String stateCode)      {this.stateCode = stateCode;}
	
	/** Creates new Store object */
	public Store(String storeNumber,
				 String type,
				 String storeName,
				 String address,
				 String city,
				 String stateCode,
				 String zipCode,
				 String contact,
				 String phoneNumber,
				 String logo)
	{
		super();
		
		this.storeNumber = storeNumber;
		this.type = type;
		this.storeName = storeName;
		this.address = address;
		this.city = city;
		this.stateCode = stateCode;
		this.zipCode = zipCode;
		this.contact = contact;
		this.phoneNumber = phoneNumber;
		this.logo = logo;
	}

	public Store()
	{
		super();
		
		this.storeNumber = "";
		this.type = "";
		this.storeName = "";
		this.address = "";
		this.city = "";
		this.stateCode = "";
		this.zipCode = "";
		this.contact = "";
		this.phoneNumber = "";
		this.logo = "";
	}
	
	public boolean isEmpty()
	{
		return(storeNumber.length() == 0 &&
			   type.length() == 0 &&
			   storeName.length() == 0 &&
			   address.length() == 0 &&
			   city.length() == 0 &&
			   stateCode.length() == 0 &&
			   zipCode.length() == 0 &&
			   phoneNumber.length() == 0 &&
			   contact.length() == 0 &&
			   logo.length() == 0 ? true : false);
	}
	
	// Sorts by store number.
	public int compareTo(java.lang.Object storeObj)
	{
		return storeNumber.toLowerCase().compareTo(((Store)storeObj).storeNumber.toLowerCase());
	}

    // Sorts by Store Number.
    private static class StoreNumberOrder implements Comparer
    {
        public int compare(java.lang.Object o1, java.lang.Object o2)
        {
            return ((Store)o1).storeNumber.toLowerCase().compareTo(((Store)o2).storeNumber.toLowerCase());
        }
    }
    
    /**
     * Sorts the Vector of StoreDC objects into order by
     * Store Number.
     */
    public static void sortByStoreNumber(Vector vector)
    {
        VectorFuncs.sort(vector, new Store.StoreNumberOrder());
    }
}
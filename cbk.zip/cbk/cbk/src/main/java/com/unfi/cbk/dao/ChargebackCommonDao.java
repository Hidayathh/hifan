package com.unfi.cbk.dao;

import java.io.InputStream;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;


import com.unfi.cbk.bo.VendorBO;
//import com.unfi.cbk.bo.VendorControl;
import com.unfi.cbk.exceptions.DataAccessException;
//import com.unfi.cbk.exceptions.ChargebackFileServiceException;
import com.unfi.cbk.exceptions.CbkServiceException;
/**
 * @author vpil001
 * @version 1.0
 */

public interface ChargebackCommonDao {

	//public VendorControl getVendorPageAccessCtrl(String vendorId, String screenName) throws EPassServiceException;
	
	//public VendorControl getVendorAccess(String vendorId) throws EPassServiceException;
	
	public List doVendorSearch(String vendorNumber,String vendorName)throws CbkServiceException;
	
	public List doLocationSearch(String locationNumber,String locationName)throws CbkServiceException;

	public List doOriginatorSearch(String userId,String userName)throws CbkServiceException;
	
	public List doApproverSearch(String userId,String userName)throws CbkServiceException;
		
	

	
	
}
package com.unfi.cbk.actions.chargeback;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.servlet.ModelAndView;

import com.unfi.cbk.beans.ResultList;
import com.unfi.cbk.delegates.ChargebackSearchDelegate;
//import com.unfi.cbk.dao.ibImpl.MaintenanceDaoImpl;
import com.unfi.cbk.forms.ChargebackSearchForm;
import com.unfi.cbk.util.ActionMessages;
import com.unfi.cbk.util.ActionUrlMapping;
import com.unfi.cbk.util.Constants;
import com.unfi.cbk.util.SpringUtils;


/**
 * The ChargebackAdminAction class is the struts action called for the 
 * search criteria entry page.
 * The action sets the user data in the request, sets any values
 * needed for the form, and forwards to the JSP specific to the userType.
 *
 * @author      vpil001
 * @since       1.0
 */
@Controller("chargebackAdminAction_chargeback")
@Scope(value=WebApplicationContext.SCOPE_REQUEST, proxyMode=ScopedProxyMode.TARGET_CLASS)
public class ChargebackAdminAction {//extends Action { 
	static Logger log = Logger.getLogger(ChargebackAdminAction.class);
	@Autowired
	ActionMessages errors;
	@Autowired
    private ChargebackSearchDelegate chargebackSearchDelegate;
	/*
	 * public ChargebackNewSearchAction(ChargebackSearchDelegate
	 * chargebackSearchDelegate) { this.chargebackSearchDelegate =
	 * chargebackSearchDelegate; }
	 */
	
	//Externalize this value
    @Value("${cbk.autoGrowCollectionLimit:100000}")
    private int autoGrowCollectionLimit;
    @InitBinder
    public void initBinder(WebDataBinder dataBinder) {
        dataBinder.setAutoGrowCollectionLimit(autoGrowCollectionLimit);
    }
	/* (non-Javadoc)
	 * @see org.apache.struts.action.Action#execute(org.apache.struts.action.ActionMapping, org.apache.struts.action.ActionForm, javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	@RequestMapping(value = "/chargebackAdmin", method = {RequestMethod.GET,RequestMethod.POST},params= {"action=admin"})
	public ModelAndView admin(
		@ModelAttribute("chargebackSearchForm") ChargebackSearchForm chargebackSearchForm,
		HttpServletRequest request,
		HttpServletResponse response)
		throws Exception {
		System.out.println("***** CHARGEBACK ADMIN*****-ChargebackAdminAction.java-- execute()---");
		ModelAndView mav = new ModelAndView();
		//ActionErrors errors = new ActionErrors();
		//ActionMessages errors = new ActionMessages();
		//ActionForward forward = new ActionForward(); // return value
		//DocumentSearchForm documentSearchForm = (DocumentSearchForm) form;
		chargebackSearchForm.setFormParameterMap(request);
		
		if(request.getParameter("isformreset") !=null)
		{
			chargebackSearchForm.reset(request);
		}
		String userType = null;
		if (request.getAttribute("userType") != null){	
			userType = (String) request.getAttribute("userType");
		}
		boolean exceptionOccurred = false;
		
		System.out.println("---userType--"+userType);
		log.debug("***** CHARGEBACK ADMIN *****");
		System.out.println("--*** CHARGEBACK ADMIN ******--");
		
		//	If a message is required, save the specified key(s) into the request.
		if (!errors.isEmpty()) {
			log.debug("FAILED");
			//saveMessages(request, errors);
			errors.saveMessages(request);
		}
				
		// Finish with
		//return (forward);
		mav.setViewName(ActionUrlMapping.CHARGEBACKADMINACTION.get("open"));
		System.out.println("URL mapping"+mav.getViewName());
		request.setAttribute("actionMessages", errors);
		request.setAttribute("chargebackSearchForm", chargebackSearchForm);
			
			
		
		return mav;

	}
	
	
	@RequestMapping(value = "/userMaintenance", method = {RequestMethod.GET,RequestMethod.POST},params= {"action=userMaint"})
	public ModelAndView userMaint(
		@ModelAttribute("chargebackSearchForm") ChargebackSearchForm chargebackSearchForm,
		HttpServletRequest request,
		HttpServletResponse response)
		throws Exception {
		System.out.println("***** CHARGEBACK ADMIN*****-ChargebackAdminAction.java-- userMaint()---");
		ModelAndView mav = new ModelAndView();
		//ActionErrors errors = new ActionErrors();
		//ActionMessages errors = new ActionMessages();
		//ActionForward forward = new ActionForward(); // return value
		//DocumentSearchForm documentSearchForm = (DocumentSearchForm) form;
		chargebackSearchForm.setFormParameterMap(request);
		
		if(request.getParameter("isformreset") !=null)
		{
			chargebackSearchForm.reset(request);
		}
		String userType = null;
		if (request.getAttribute("userType") != null){	
			userType = (String) request.getAttribute("userType");
		}
		boolean exceptionOccurred = false;
		
		System.out.println("---userType--"+userType);
		log.debug("***** CHARGEBACK ADMIN *****userMaint()");
		System.out.println("--*** CHARGEBACK ADMIN ******-userMaint()-");
		
		//	If a message is required, save the specified key(s) into the request.
		if (!errors.isEmpty()) {
			log.debug("FAILED");
			//saveMessages(request, errors);
			errors.saveMessages(request);
		}
				
		// Finish with
		//return (forward);
		mav.setViewName(ActionUrlMapping.CHARGEBACKADMINACTION.get("userSearch"));
		System.out.println("URL mapping"+mav.getViewName());
		request.setAttribute("actionMessages", errors);
		request.setAttribute("chargebackSearchForm", chargebackSearchForm);
			
			
		
		return mav;

	}
	
	
	
	
}
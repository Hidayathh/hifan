/*
 * Application.java
 *
 * Created on March 21, 2001, 5:31 PM
 */
package com.unfi.cbk.ldap;

import com.unfi.cbk.ldaputil.CompareTo;

/**
 * Class to hold Application information.
 * Creation date: (04/04/2002 3:34:51 PM)
 * @author: yhp6y2l
 */
public class Application extends Object implements CompareTo
{
    private String name;
    private String description;
    private boolean isForced;
    private boolean isDefault;
    
    public String getName()         {return(name);}
    public String getDescription()  {return(description);}
    public boolean isForced()       {return(isForced);}
    public boolean isDefault()      {return(isDefault);}

    /** Creates new Application object */
    public Application(String name,
                       String description,
                       boolean isForced,
                       boolean isDefault)
    {
        super();

        this.name = name;
        this.description = description;
        this.isForced = isForced;
        this.isDefault = isDefault;
    }

    // Sorts by Description.
    public int compareTo(java.lang.Object applicationObj) {
        int ret = description.toLowerCase().compareTo(((Application)applicationObj).description.toLowerCase());
        
        return(ret);
    }
    
    public boolean equals(Object obj)
    {
    	Application newApp = null;
    	newApp = (Application) obj;
    	if  (newApp.name.equals(this.name))
    	{
    		return true;
    	}else
    	{
    		return false;
    	}		
    }	
}

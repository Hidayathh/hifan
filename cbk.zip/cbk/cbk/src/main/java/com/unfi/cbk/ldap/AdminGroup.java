/*
 * AdminGroup.java
 *
 * Created on March 30, 2001, 2:19 PM
 */
package com.unfi.cbk.ldap;

import com.unfi.cbk.ldaputil.CompareTo;

/**
 * Class to hold Administrative Group information.
 * Creation date: (04/04/2002 3:34:51 PM)
 * @author: yhp6y2l
 */
public class AdminGroup extends Object implements CompareTo
{
    private String name;

    public String getName() {return(name);}

    /** Creates new AdminGroup */
    public AdminGroup(String name)
    {
        super();

        this.name = name;
    }

    // Sorts by name.
    public int compareTo(java.lang.Object obj)
    {
        int ret = name.toLowerCase().compareTo(((AdminGroup)obj).name.toLowerCase());
        
        return(ret);
    }
}

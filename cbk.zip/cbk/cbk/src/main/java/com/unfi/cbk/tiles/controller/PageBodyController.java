/*
 * Created on Jun 8, 2005
 * 
 */
package com.unfi.cbk.tiles.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.apache.tiles.Attribute;
import org.apache.tiles.AttributeContext;
import org.apache.tiles.ListAttribute;
import org.apache.tiles.preparer.ViewPreparer;
import org.apache.tiles.request.Request;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.unfi.cbk.util.SpringUtils;



/**
 * @author yhp6y2l
 * @version 1.0 Jun 8, 2005
 */
//@Component
public class PageBodyController implements ViewPreparer{//Controller {
	
	/*@Autowired
	private Environment resources;
	
	@Autowired
	private ApplicationContext applicationContext;*/

	private static Logger log = Logger.getLogger(PageBodyController.class);
	
	/* (non-Javadoc)
	 * @see org.apache.struts.tiles.Controller#perform(org.apache.struts.tiles.ComponentContext, javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse, javax.servlet.ServletContext)
	 */
	/*public void execute(
		ComponentContext context,
		HttpServletRequest request,
		HttpServletResponse response,
		ServletContext servletContext)
		throws ServletException, IOException {
				
		//	Get the server=specific Resource Bundle
		MessageResources resources = (MessageResources) servletContext.getAttribute("environmentResources");		
		
		List l = (List) context.getAttribute("insertLists");
		if (l != null){
			for (int i = 0; i < l.size(); i++){
				String s = (String) l.get(i);				
				
				//ListInserter li = (ListInserter) ObjectFactory.getInstance().create(s);
				ListInserter li = (ListInserter) SpringUtils.getBeanFromServletContext(servletContext, s);
				li.insertList(request,resources.getMessage("db.schema.name"));			
			}
		}							
	}*/
	
	/*public void perform(
		ComponentContext context,
		HttpServletRequest request,
		HttpServletResponse response,
		ServletContext servletContext)
		throws ServletException, IOException {
	
		execute(context, request, response, servletContext);		
	}*/

	@Override
	public void execute(Request tilesContext, AttributeContext attributeContext) {
//		Get the server=specific Resource Bundle
		//HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();

		HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
		
		//Map<String, Object> requestMap = tilesContext.getContext("request");

	    //HttpServletRequest request = (HttpServletRequest)requestMap.get(WebApplicationContext.SCOPE_REQUEST);
	    
	    
		ListAttribute listAttribute = (ListAttribute) attributeContext.getAttribute("insertLists");
		if(listAttribute !=null)
		{
			
		List<Attribute> l = listAttribute.getValue();
			if (l != null){
				for (int i = 0; i < l.size(); i++){
					Attribute a = (Attribute) l.get(i);
					String s = a.toString();
					//System.out.println("Attribute to String ="+s);
					//System.out.println("Attribute renderer = "+a.getRenderer() +" , value ="+a.getValue());
					
					ListInserter li = (ListInserter) SpringUtils.getBeanFromRequest(request, s);
					li.insertList(request,System.getProperty("db.schema.name"));			
				}
			}	
		}
		
	}
}

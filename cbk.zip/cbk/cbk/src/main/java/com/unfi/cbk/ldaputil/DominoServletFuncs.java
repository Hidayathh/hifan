/*
 * DominoServletFuncs.java
 *
 * Created on March 21, 2001, 11:52 AM
 */
package com.unfi.cbk.ldaputil;

import java.io.*;
import java.net.URL;
import java.net.URLEncoder;



/**
 * Class to provide access to the Domino servlets.
 * Creation date: (04/04/2002 3:34:51 PM)
 * @author: yhp6y2l
 */
public class DominoServletFuncs extends Object 
{
    String  dominoServletUserName = null;
    String  dominoServletPassword = null;
    String  dominoServletBaseURL = null;
    boolean dominoServletsEnabled = true;

    /** Creates new DominoServletFuncs */
    public DominoServletFuncs(String dominoServletUserName,
                              String dominoServletPassword,
                              String dominoServletBaseURL,
                              boolean dominoServletsEnabled)
    {
		super();
        this.dominoServletUserName = dominoServletUserName;
        this.dominoServletPassword = dominoServletPassword;
        this.dominoServletBaseURL = dominoServletBaseURL;
        this.dominoServletsEnabled = dominoServletsEnabled;
    }

    /**
     * Adds the specified user to the Domino system.
     */
    public void createUser(String loginID,
                           String firstName,
                           String middleInitial,
                           String lastName,
                           String emailAddress)
			throws Exception
    {
        // Don't bother to do anything if the servlets are disabled.
        if (! dominoServletsEnabled) {
            return;
        }

        URL tdominoServletBaseURL;
        
        try {
            tdominoServletBaseURL = new URL(dominoServletBaseURL);
        }
        catch (Exception e) {
            String tMsg = "Error adding user in Domino Email system.  Invalid dominoServletBaseURL.";
            throw new Exception(tMsg);
        }

        final String expectedResults = loginID + " queued for processing (create)";
        String tURL = tdominoServletBaseURL.getFile() +
                      "CreateUserServlet?" +
                      "shortName=" + URLEncoder.encode(loginID) +
                      "&firstName=" + URLEncoder.encode(firstName) +
                      "&middleInitial=" + URLEncoder.encode(middleInitial) +
                      "&lastName=" + URLEncoder.encode(lastName) +
                      "&mailAddress=" + URLEncoder.encode(emailAddress);

        String 		sResult = null;
//        _clsWinInet winInet;
//        try {
//            winInet = (_clsWinInet) new clsWinInet();
//        }
//        catch (Exception e) {
//            String tMsg = "Error adding user in Domino Email system.  Unable to create clsWinInet object.";
//            throw new Exception(tMsg);
//        }

//        try {
//            sResult = winInet.GetURL(new String[] {tdominoServletBaseURL.getHost()}, new String[] {dominoServletUserName}, new String[] {dominoServletPassword}, new String[] {tURL}, new boolean[] {false});
//        }
//        catch (Exception e) {
//            String tMsg = "Error adding user in Domino Email system.  The Servlet reported an exception.";
//            throw new Exception(tMsg);
//        }
//    //    com.ms.com.ComLib.release(winInet);

        if ((sResult == null) ||
            (! expectedResults.equalsIgnoreCase(sResult))) {

            String tMsg = "Error adding user in Domino Email system.  Domino reported: \"" + sResult + "\"";
            throw new Exception(tMsg);
        }
    }
    
    /**
     * Updates the specified user in the Domino system.
     */
    public void updateUser(String loginID,
                           String firstName,
                           String middleInitial,
                           String lastName,
                           String emailAddress)
			throws Exception
    {
        // Don't bother to do anything if the servlets are disabled.
        if (! dominoServletsEnabled) {
            return;
        }

        URL tdominoServletBaseURL;
        
        try {
            tdominoServletBaseURL = new URL(dominoServletBaseURL);
        }
        catch (Exception e) {
            String tMsg = "Error updating user in Domino Email system.  Invalid dominoServletBaseURL.";
            throw new Exception(tMsg);
        }

        final String expectedResults = loginID + " queued for processing (change)";
        String tURL = tdominoServletBaseURL.getFile() +
                      "ChangeUserServlet?" +
                      "shortName=" + URLEncoder.encode(loginID) +
                      "&firstName=" + URLEncoder.encode(firstName) +
                      "&middleInitial=" + URLEncoder.encode(middleInitial) +
                      "&lastName=" + URLEncoder.encode(lastName) +
                      "&mailAddress=" + URLEncoder.encode(emailAddress);

        String 		sResult = null;
//        _clsWinInet winInet;
//        try {
//        	winInet = (_clsWinInet) new clsWinInet();
//        }
//        catch (Exception e) {
//            String tMsg = "Error updating user in Domino Email system.  Unable to create clsWinInet object.";
//            throw new Exception(tMsg);
//        }
//
//        try {
//            sResult = winInet.GetURL(new String[] {tdominoServletBaseURL.getHost()}, new String[] {dominoServletUserName}, new String[] {dominoServletPassword}, new String[] {tURL}, new boolean[] {false});
//        }
//        catch (Exception e) {
//            String tMsg = "Error updating user in Domino Email system.  The Servlet reported an exception.";
//            throw new Exception(tMsg);
//        }
       // com.ms.com.ComLib.release(winInet);

        if ((sResult == null) ||
            (! expectedResults.equalsIgnoreCase(sResult))) {

            String tMsg = "Error updating user in Domino Email system.  Domino reported: \"" + sResult + "\"";
            throw new Exception(tMsg);
        }
    }

    /**
     * Adds the specified user to the specified mail group in the Domino system.
     */
    public void updateMailGroups(String loginID,
                                 String mailAddress,
                                 String storeNumber,
                                 String mailGroupNames)
			throws Exception
    {
        // Don't bother to do anything if the servlets are disabled.
        if (! dominoServletsEnabled) {
            return;
        }

        URL tdominoServletBaseURL;

        try {
            tdominoServletBaseURL = new URL(dominoServletBaseURL);
        }
        catch (Exception e) {
            String tMsg = "Error updating email group in Domino Email system.  Invalid dominoServletBaseURL.";
            throw new Exception(tMsg);
        }

        final String expectedResults = loginID + " queued for processing (mail groups)";
        String tURL = tdominoServletBaseURL.getFile() +
                      "ChangeMailGroupsServlet?" +
                      "shortName=" + URLEncoder.encode(loginID) +
                      "&mailAddress=" + URLEncoder.encode(mailAddress) +
                      "&storeID=" + URLEncoder.encode(storeNumber) +
                      "&mailGroups=" + URLEncoder.encode(mailGroupNames);

        String 		sResult = null;
//        _clsWinInet winInet;
//        try {
//            winInet = (_clsWinInet) new clsWinInet();
//        }
//        catch (Exception e) {
//            String tMsg = "Error updating email group in Domino Email system.  Unable to create clsWinInet object.";
//            throw new Exception(tMsg);
//        }
//
//        try {
//            sResult = winInet.GetURL(new String[] {tdominoServletBaseURL.getHost()}, new String[] {dominoServletUserName}, new String[] {dominoServletPassword}, new String[] {tURL}, new boolean[] {false});
//        }
//        catch (Exception e) {
//            String tMsg = "Error updating email group in Domino Email system.  The Servlet reported an exception.";
//            throw new Exception(tMsg);
//        }
        //com.ms.com.ComLib.release(winInet);

        if ((sResult == null) ||
            (! expectedResults.equalsIgnoreCase(sResult))) {

            String tMsg = "Error updating email group in Domino Email system.  Domino reported: \"" + sResult + "\"";
            throw new Exception(tMsg);
        }
    }

    /**
     * Delete the specified user from the Domino system.
     */
    public void deleteUser(String loginID)
			throws Exception
    {
        // Don't bother to do anything if the servlets are disabled.
        if (! dominoServletsEnabled) {
            return;
        }

        URL tdominoServletBaseURL;
        
        try {
            tdominoServletBaseURL = new URL(dominoServletBaseURL);
        }
        catch (Exception e) {
            String tMsg = "Error deleting user in Domino Email system.  Invalid dominoServletBaseURL.";
            throw new Exception(tMsg);
        }

        final String expectedResults = loginID + " queued for processing (delete)";
        String tURL = tdominoServletBaseURL.getFile() +
                      "DeleteUserServlet?" +
                      "shortName=" + URLEncoder.encode(loginID);

        String 		sResult = null;
//        _clsWinInet winInet;
//        try {
//            winInet = (_clsWinInet) new clsWinInet();
//        }
//        catch (Exception e) {
//            String tMsg = "Error deleting user in Domino Email system.  Unable to create clsWinInet object.";
//            throw new Exception(tMsg);
//        }
//
//        try {
//            sResult = winInet.GetURL(new String[] {tdominoServletBaseURL.getHost()}, new String[] {dominoServletUserName}, new String[] {dominoServletPassword}, new String[] {tURL}, new boolean[] {false});
//        }
//        catch (Exception e) {
//            String tMsg = "Error deleting user in Domino Email system.  The Servlet reported an exception.";
//            throw new Exception(tMsg);
//        }
        //com.ms.com.ComLib.release(winInet);

        if ((sResult == null) ||
            (! expectedResults.equalsIgnoreCase(sResult))) {

            String tMsg = "Error deleting user in Domino Email system.  Domino reported: \"" + sResult + "\"";
            throw new Exception(tMsg);
        }
    }
}

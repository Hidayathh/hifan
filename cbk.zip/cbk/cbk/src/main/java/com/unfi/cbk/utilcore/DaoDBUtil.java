/* Created on Aug 25, 2004 by tcmsr0 */
package com.unfi.cbk.utilcore;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Vector;

import javax.sql.rowset.CachedRowSet;
import javax.sql.rowset.RowSetFactory;
import javax.sql.rowset.RowSetProvider;

import org.apache.log4j.Logger;

import com.unfi.cbk.exceptions.CbkDataChangeException;
import com.unfi.cbk.exceptions.CbkServiceException;
import com.unfi.cbk.util.ESAPIUtil;
import com.unfi.cbk.util.ActionMessages;
import com.unfi.cbk.util.Constants;


/**
 * The DaoDBUtil class handles all database transactions for the DAO's.
 * <p>
 * <code>PreparedStatements</code> are used for every call and the methods in this class are able
 * to handle <code>PreparedStatement</code> calls for any type of database request.
 *
 * @author      yhp6y2l
 * @since       1.0
 */
public class DaoDBUtil {
	static Logger log = Logger.getLogger(DaoDBUtil.class);
	static String IDENTITY_COL_SQL = "SELECT IDENTITY_VAL_LOCAL() FROM SYSIBM.SYSDUMMY1"; 
	
	/**
	 * This method is exposed to other classes for SELECT calls to the database.
	 * This method accepts the SQL string and a <code>Vector</code> of parameters representing
	 * each question mark in the SQL so the <code>PreparedStatement</code> can be built.
	 * It then calls the callPreparedStmt() method which carries out the creation and execution
	 * of the PreparedStatement
	 * 
	 * @return			a <code>CachedRowSet</code> of the query results
	 * @param sql		the SQL string for the database call
	 * @param params	a <code>Vector</code> of objects, 1 for each question mark in the
	 * 					SQL (in order)
	 * @param errors	the struts <code>ActionErrors</code> object used by this request to
	 * 					store any errors handled during execution.
	 * @since			1.0
	 */
	public CachedRowSet callPreparedStmtQuery(String sql, Vector params, ActionMessages errors){
		return (CachedRowSet) callPreparedStmt(sql, params, false, errors);
		
	}
	
	/**
	 * This method is exposed to other classes for update calls to the database.
	 * This method accepts the SQL string and a <code>Vector</code> of parameters representing
	 * each question mark in the SQL so the <code>PreparedStatement</code> can be built.
	 * It then calls the callPreparedStmt() method which carries out the creation and execution
	 * of the PreparedStatement
	 * 
	 * @return			a <code>CachedRowSet</code> of the query results
	 * @param sql		the SQL string for the database call
	 * @param params	a <code>Vector</code> of objects, 1 for each question mark in the
	 * 					SQL (in order)
	 * @param errors	the struts <code>ActionErrors</code> object used by this request to
	 * 					store any errors handled during execution.
	 * @since			1.0
	 */
	public int callPreparedStmtUpdate(String sql, Vector params, ActionMessages errors) {
		return ((Integer) callPreparedStmt(sql, params, true, errors)).intValue();
	}
	
	
	/**
	 * This method carries out the creation and execution of a PreparedStatment.
	 * The method returns an Object which is cast appropriately by the calling method.
	 * 
	 * @return			a Object of whose type is determined bythe type of SQL call
	 * 					being made
	 * @param sql		the SQL string for the database call
	 * @param params	a <code>Vector</code> of objects, 1 for each question mark in the
	 * 					SQL (in order)
	 * @param isUpdate	<code>boolean</code> that indicates if the SQL call performs an
	 * 					update
	 * @param errors	the struts <code>ActionErrors</code> object used by this request to
	 * 					store any errors handled during execution.
	 * @since			1.0
	 */
	private Object callPreparedStmt(String sql, Vector params, boolean isUpdate, ActionMessages errors) {
		CachedRowSet resultsBean = null;
		Connection connection = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		int updateCount = 0;
		Object returnValue = null;
		boolean retry = true;
		int retryCount = 0;
	
		while (retry) {
			try {				
				//	Get a connection
				connection = JNDIDBPool.getConnection();
				RowSetFactory factory = RowSetProvider.newFactory();
				resultsBean = factory.createCachedRowSet();
				if (connection != null) {
					
				
					log.debug("query:" + sql);
					
					//Create the PreparedStatement
					ps = createPreparedStatement(sql, params, connection);
					//log.debug("Prepared Statement is null? " + (ps == null));
					if (isUpdate) {
						connection.setReadOnly(false);
						connection.setTransactionIsolation(Connection.TRANSACTION_REPEATABLE_READ);						
						connection.setAutoCommit(false);
						
						//	The calling method indicated this was an update action, not a select
						updateCount = ps.executeUpdate();
						returnValue = new Integer(updateCount);
						
						try{
							connection.commit();
						}
						catch(Exception e){
							log.error("Exception committing transaction: " + e);
						}
						
					} else {
						//	The calling method indicated this was an select action, not an update
						connection.setReadOnly(true);
						connection.setTransactionIsolation(Connection.TRANSACTION_READ_COMMITTED);
						
						//resultsBean = new CachedRowSet();
						
						rs = ps.executeQuery();
						
						//	Populate the CachedRowSet with the results
						if (rs == null){
							log.debug("No results");
						}
						
						resultsBean.populate(rs);
						//returnValue = resultsBean.clone();
						returnValue = resultsBean.createCopy();
					}
					retry = false;
					/*
					// View Table Metadata
					ResultSetMetaData rsmd = rs.getMetaData();
					for (int j = 1; j <= rsmd.getColumnCount(); j++) {
						log.debug("Column" + j + ": " + rsmd.getColumnName(j));
					}
					*/
					
					
						
					//ps = null;
					
				} else {
					log.error("No database connection made.");
					throw new Exception();
					
				}
			
			} 
			/*catch (com.ibm.websphere.ce.cm.StaleConnectionException e) {
				log.error("StaleConnectionException in callPreparedStmt():" + e);
			
				if (retryCount <= 5) {
					//  Keep trying...
					retryCount++;
					log.error("StaleConnectionException in callPreparedStmt(): retry " + retryCount);
				
					retry = true;
				
				} else {
					//	Retries complete, exit
					log.error("StaleConnectionException in callPreparedStmt(): retries failed.");
					// (Handle Action errors here)
					retry = false;
					
				}
	        	
			}*/
			catch (SQLException e) {
				retry = false;
				log.error("SQLException in callPreparedStmt():" + e);
				errors.add("error", "errors.database");
				
			} catch (Exception e) {
				retry = false;
				//e.printStackTrace();
				log.error("Exception in callPreparedStmt():: " + e);
				errors.add("error", "errors.connection");
				
			} finally {
				//	Cleanup				
				closeResultset(rs);
				closeResultset(resultsBean);
				closeStatement(ps);
				JNDIDBPool.returnConnectionToPool(connection);
			
			}
	
		}
	
		return returnValue;

	}
	
	/*
	 * Called by callPreparedStmt() and sets all supplied input parameters
	 */
	private PreparedStatement createPreparedStatement(String sql, Vector params, Connection connection) {
		PreparedStatement ps = null;
		
		try {
			//log.debug("SQL: " + sql);
			//log.debug("Params is null? " + (params == null));
			//log.debug("Connection is null? " + (connection == null ));
			//log.debug("Connection is open? " + (! connection.isClosed()));
			
			// Create the PreparedStatement
			ps = connection.prepareStatement(sql);
			
			//log.debug("After calling prepareStatement, is statement null? " + (ps == null));
			// Loop through supplied input values in the Vector to populate the PreparedStatement
			if (params != null){
				for (int i = 0; i < (params.size()); i++) {
					//log.debug("param(" + i + "):" + params.elementAt(i));
					ps.setObject(i+1 ,params.elementAt(i));
				}
			}
		}
		catch(SQLException se){
			log.error("SQLException in createPreparedStatement(): " + se.getMessage());
			//se.printStackTrace();
		}	
		catch (Exception e) {
			log.error("Exception in createPreparedStatement(): " + e);
			//e.printStackTrace();
			
		} finally {
			return ps;			
		}
		
	}

	// Assign input parameters to statement object.	
	private PreparedStatement assignInputParameters(PreparedStatement ps, Vector params, Object primaryKey) throws CbkServiceException {
		int type = 0;
		StringBuffer sb = new StringBuffer();
		try {
			if (params != null){
				for (int i = 0; i < (params.size()); i++) {
					sb.append("param(" + i + "):" + params.elementAt(i)+"\n");
					//log.debug("param(" + i + "):" + params.elementAt(i));
					Object obj = params.elementAt(i);
						
/*					
					if (obj instanceof Integer)
						type = Types.INTEGER;
					else if (obj instanceof String)
						type = Types.VARCHAR;
					else if (obj instanceof Double)
						type = Types.DECIMAL;
					else if (obj instanceof Date)
						type = Types.DATE;
*/						
					if (primaryKey != null && i == 0) // This is to set the dependent foreign key
						ps.setObject(i+1 ,primaryKey);
					else if (params.elementAt(i) == null)
						ps.setNull(i+1 ,Types.VARCHAR);
					else ps.setObject(i+1 ,params.elementAt(i));
				}
				//log.debug(ESAPIUtil.encode(sb.toString()));
			}
		} catch(SQLException se){
			log.error("SQLException in assignInputParameters(): " + se.getMessage());
			throw new CbkServiceException("Database SQLException occured.");
		} catch (Exception e) {
			log.error("Exception in assignInputParameters(): " + e);
			throw new CbkServiceException("Exception occured.");
		} finally {
			return ps;			
		}
	}

	/*
	 * Call a stored procedure, return a Vector containing all return objects
	 */
	private Vector callStoredProcedure(String sql, Vector paramList, int maxRows) {
		CachedRowSet resultsBean = null;
		Connection connection = null;
		ResultSet rs = null;
		int updateCount = 0;
		Vector allResultsObjects = new Vector();
		boolean retry = true;
		int retryCount = 0;
		int counter = 1;
		
		while (retry) {
			try {				
				//	Get a connection
				connection = JNDIDBPool.getConnection();
				connection.setAutoCommit(false);
				RowSetFactory factory = RowSetProvider.newFactory();
				resultsBean = factory.createCachedRowSet();
				log.info("Call stored procedure: " + sql);
				
				//	Create the CallableStatement needed to call the stored procdure
				CallableStatement cs = connection.prepareCall(sql);
				cs.setMaxRows(maxRows);
			
				//	Loop through parameter list to populate CallableStatement
				Vector outputParamStore = new Vector();
				for (int i = 0; i < paramList.size(); i++) {
					ParameterBean pbean = (ParameterBean) paramList.elementAt(i);
					log.debug("isOutputParam:" + pbean.isOutputParam());
				
					if (pbean.isOutputParam()) {
						//	Register the putput parameter
						cs.registerOutParameter(counter, ((Integer) pbean.getParamValue()).intValue());
						outputParamStore.add(new Integer(counter));
					
					} else {
						//	Set the input parameter
						cs.setObject(counter, pbean.getParamValue());
						log.debug("paramValue:" + pbean.getParamValue());
					
					}
				
					counter++;
				
				}
				
				if (cs.execute()) {	
					//	There is at least one resultset
					rs = cs.getResultSet();
					//resultsBean = new CachedRowSet();
					resultsBean.populate(rs);
					//allResultsObjects.add(resultsBean.clone());
					allResultsObjects.add(resultsBean.createCopy());
					//	Commit the action
					connection.commit();
					
					// Determine if there are any more resultsets
					while (cs.getMoreResults()) {
						rs = cs.getResultSet();
						//resultsBean = new CachedRowSet();
						resultsBean.populate(rs);
						//allResultsObjects.add(resultsBean.clone());
						allResultsObjects.add(resultsBean.createCopy());
						//	Commit the action
						connection.commit();
						
					}
					
				} else {
					// There were no resultsets, get the update count
					updateCount = cs.getUpdateCount();
					
				}

				//	The action succeeded, no need to retry				
				retry = false;
				
				// Get the outputs defined by the Output Parameters (if any)
				Object outputObject = null;
				for (int j = 0; j < outputParamStore.size(); j++) {
					// Use the index stored in the Vector to retrieve the output at the correct parameterIndex
					outputObject = cs.getObject( ((Integer) outputParamStore.elementAt(j)).intValue() );
					allResultsObjects.add(outputObject);
					
					log.info("Return value of stored procedure(" + j + "):" + outputObject.toString());
					outputObject = null;
					
				}
				
				closeResultset(resultsBean);
				cs = null;
								
			} 
			/*catch (com.ibm.websphere.ce.cm.StaleConnectionException e) {
				log.error("StaleConnectionException in callPreparedStmt():" + e);
			
				if (retryCount <= 5) {
					//	Keep trying...
					retryCount++;
					log.error("StaleConnectionException in callPreparedStmt(): retry " + retryCount);
				
					retry = true;
				
				} else {
					//  Retries complete, exit
					log.error("StaleConnectionException in callPreparedStmt(): retries failed.");
					retry = false;
					
				}
				
	        }*/ catch (SQLException e) {
				retry = false;
			
				if (e.toString().toLowerCase().indexOf("no resultset") < 0) {
					log.error("SQLException in getStoredProcedureResults():" + e);
					//  (Handle Action errors here)
				
				}
					
			} catch (Exception e) {
				retry = false;
				log.error("Exception in getStoredProcedureResults(): " + e);
				//	(Handle Action errors here)
		
			} finally {
				//	Cleanup
				closeResultset(rs);
				closeResultset(resultsBean);
				JNDIDBPool.returnConnectionToPool(connection);
			
			}
			
		}
		
		return allResultsObjects;
 	
	}
	
	/**
	 * Get the number of rows returned in a <code>CachedRowSet</code>.
	 * This method takes a <code>CachedRowSet</code> and returns an int of
	 * the number of rows.  
	 * 
	 * @return			the number of rows in the <code>CachedRowSet</code>
	 * @param bean		the <code>CachedRowSet</code> to inspect
	 * @since			1.0
	 */
	public int getResultCount(CachedRowSet bean) {
		int rowCount = 0;
	
		try {
			bean.last();
			rowCount = bean.getRow();
			bean.beforeFirst();
		
		} catch (Exception e) {
			log.error("Exception in getResultCount():" + e);
		
		} finally {
			log.debug("row count:" + rowCount);
			return rowCount;
		
		}
	
	}
	
	/**
	 * Cleanly closes <code>Resultset</code> objects.
	 * This method takes a <code>Resultset</code> and closes it
	 * 
	 * @param rs		the <code>Resultset</code> to close
	 * @since			1.0
	 */
	public void closeResultset(ResultSet rs) {
		// close the resultset
		if (rs != null) {
			try {
				rs.close();
				rs = null;
				
			} catch (SQLException sqle) {
				log.error("Error logged while closign a result set: "+ sqle);
				
			}
			
		}
		
	}
	
	private void closeStatement(PreparedStatement ps){
		if (ps != null){
			try{
				ps.close();
			}
			catch (Exception ignore){}
		}
	}

	public Object executeSQLQuery(String sql, Vector params, String executeType) throws CbkServiceException {
		Connection connection = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		Object returnValue = null;
		CachedRowSet resultsBean = null;
		
		int updateCount = 0;
		boolean retry = true;
		int retryCount = 0;
		while (retry) {
			try {				
				//	Get a connection
				connection = JNDIDBPool.getConnection();
				RowSetFactory factory = RowSetProvider.newFactory();
				resultsBean = factory.createCachedRowSet();
				if (connection != null) {
					log.debug(ESAPIUtil.encode("query:" + sql));
					System.out.println("---DaoDBUtil.java---executeSQLQuery---"+sql);
					ps = connection.prepareStatement(sql);
					ps = assignInputParameters(ps, params, null);
					if (executeType.equals(Constants.EXECUTE_TYPE_SELECT)) {
						//	The calling method indicated this was an select action, not an update
						connection.setReadOnly(true);
						connection.setTransactionIsolation(Connection.TRANSACTION_READ_COMMITTED);
						//resultsBean = new CachedRowSet();
						rs = ps.executeQuery();
						resultsBean.populate(rs);
						//returnValue = resultsBean.clone();
						returnValue = resultsBean.createCopy();
					} else {
						connection.setReadOnly(false);
						connection.setTransactionIsolation(Connection.TRANSACTION_REPEATABLE_READ);
						connection.setAutoCommit(false);
						updateCount = ps.executeUpdate();
						if (executeType.equals(Constants.EXECUTE_TYPE_INSERT_RETURNKEY)) {
							ps = connection.prepareStatement(IDENTITY_COL_SQL);
							ResultSet resultset = ps.executeQuery();
							if (resultset!= null && resultset.next()) {
								returnValue = new Integer (resultset.getString(1));
							}
						} else { 
							returnValue = new Integer(updateCount);
						}
						connection.commit();
					}
					retry = false;
				} else {
					log.error("No database connection made.");
					throw new CbkServiceException("Database Connection not available.");
				}
			
			} /*catch (com.ibm.websphere.ce.cm.StaleConnectionException e) {
				log.error("StaleConnectionException in executeSQLQuery():" + e);
				if (retryCount <= 5) {
					//  Keep trying...
					retryCount++;
					retry = true;
					log.error("StaleConnectionException in executeSQLQuery(): retry " + retryCount);
				} else {
					//	Retries complete, exit
					log.error("StaleConnectionException in executeSQLQuery(): retries failed.");
					retry = false;
					throw new CbkServiceException("Database StaleConnectionException occured.");
				}
			}*/ catch (SQLException e) {
				retry = false;
				log.error("SQLException in executeSQLQuery():" + e);
				throw new CbkServiceException("SQLException in executeUpdateStmt():" + e);
			} catch (Exception e) {
				retry = false;
				//e.printStackTrace();
				log.error("Exception in executeSQLQuery():: " + e);
				throw new CbkServiceException("SQLException in executeUpdateStmt():" + e);
			} finally {
				//	Cleanup				
				closeResultset(rs);
				closeResultset(resultsBean);
				closeStatement(ps);
				JNDIDBPool.returnConnectionToPool(connection);
			}
		}
		return returnValue;
	}

	/*
	 * executeUpdateBatchQry is created to execute the statement as a batch. If any one insert or updates
	 * fails, then the transaction will be rolled back and nothing will be saved. This accepts the following
	 * parameters.
	 * String sqlQuery[] - Array of Insert or Update sql statement 
	 * Vector paramObj[] - Array of Vector object holds the parameters for the correspoding sql in sqlQuery[] 
	 * String execType[] - This tells if the execution type is Insert or Insert with automated return key or update
	 * String objectType[] - Holds the sql table that affects the insert or update.
	 */	

	public Object[] executeUpdateBatchQry(String sqlQuery[], Vector paramObj[], String execType[], String objectType[]) throws CbkServiceException {
		Connection connection = null;
		PreparedStatement ps = null;
		String[][] returnValue = new String[sqlQuery.length][2];
		Integer primaryKey = null;
		
		int updateCount = 0;
		boolean retry = true;
		int retryCount = 0;
		
		// Get a connection
		try {
			connection = JNDIDBPool.getConnection();
			connection.setReadOnly(false);
			connection.setAutoCommit(false);
			connection.setTransactionIsolation(Connection.TRANSACTION_REPEATABLE_READ);
			for (int i=0; i < sqlQuery.length; i++) {
				String sql = sqlQuery[i];
				Vector params = (Vector) paramObj[i];
				String executeType = execType[i];
				retry = true;
				if (sql != null && !sql.equals("")) { 
					while (retry) {
						try {				
							if (connection != null) {
								log.debug("SQL Query: " + sql);
								System.out.println("---DaoDBUtil.java---executeUpdateBatchQry---"+sql);
								ps = connection.prepareStatement(sql);
								ps = assignInputParameters(ps, params, primaryKey);
								updateCount = ps.executeUpdate();
								if (executeType.equals(Constants.EXECUTE_TYPE_INSERT_RETURNKEY)) {
									ps = connection.prepareStatement(IDENTITY_COL_SQL);
									ResultSet resultset = ps.executeQuery();
									if (resultset!= null && resultset.next()) {
										returnValue[i][0] = objectType[i];
										returnValue[i][1] = resultset.getString(1);
										if (objectType[i].equals("CbkREQUEST"))
											primaryKey = new Integer (resultset.getString(1));
									}
								} else { 
									returnValue[i][0] = objectType[i];
									returnValue[i][1] = String.valueOf(updateCount);
								}
								retry = false;
							} else {
								log.error("No Database Connection made.");
								throw new CbkServiceException("Database Connection not available.");
							}
	
						}/* catch (com.ibm.websphere.ce.cm.StaleConnectionException e) {
							log.error("StaleConnectionException in executeUpdateBatchQry():" + e);
							if (retryCount <= 5) {
								//  Keep trying...
								retryCount++;
								retry = true;
								log.error("StaleConnectionException in executeUpdateBatchQry(): retry " + retryCount);
							} else {
								//	Retries complete, exit
								log.error("StaleConnectionException in executeUpdateBatchQry(): retries failed.");
								retry = false;
								throw new CbkServiceException("StaleConnectionException in executeUpdateBatchQry(): retries failed.");
							}
						}*/ catch (SQLException e) {
							retry = false;
							connection.rollback();
							log.error("SQLException in executeUpdateBatchQry():" + e);
							throw new CbkServiceException("Database SQLException occured.");
						} catch (Exception e) {
							retry = false;
							connection.rollback();
							//e.printStackTrace();
							log.error("Exception in executeUpdateBatchQry(): " + e);
							throw new CbkServiceException("Exception occured.");
						} 
					}
				}
			}
			connection.commit();
		} catch (SQLException se) {
			log.error("SQLException in executeUpdateBatchQry():" + se);
			throw new CbkServiceException("Database SQLException occurred.");
		} finally {
			//	Cleanup				
			closeStatement(ps);
			JNDIDBPool.returnConnectionToPool(connection);
		}
		return returnValue;
	}

	/*
	 * Sql query.
	 */
	public Object executeSQLQuery(String sqlQuery[], String executeType[], String objectType[]) throws CbkServiceException {
		Connection connection = null;
		PreparedStatement ps = null;
//		Object returnValue = null;
		
		String[][] returnValue = new String[sqlQuery.length][2];

		int updateCount = 0;
		boolean retry = true;
		int retryCount = 0;
		// Get a connection
		try {
			connection = JNDIDBPool.getConnection();
			connection.setReadOnly(false);
			connection.setAutoCommit(false);
			connection.setTransactionIsolation(Connection.TRANSACTION_REPEATABLE_READ);
			for (int i=0; i < sqlQuery.length; i++) {
				String sql = sqlQuery[i];
				retry = true;
				if (sql != null && !sql.equals("")) { 
					while (retry) {
						try {				
							if (connection != null) {
								log.debug(ESAPIUtil.encode("SQL Query: " + sql));
								System.out.println("---DaoDBUtil.java---executeSQLQuery11111---"+sql);
								ps = connection.prepareStatement(sql);
								
								
								if (executeType[i].equals(Constants.EXECUTE_TYPE_CHECK)){
									ResultSet resultset = ps.executeQuery();	
									if (resultset!= null && resultset.next()) {
										log.debug("Check Ok");
									} else {
										log.debug("Data has been updated!!!");		
										throw new CbkDataChangeException("Status Changed");	
									}
								} else {
									updateCount = ps.executeUpdate();
								
									if (executeType[i].equals(Constants.EXECUTE_TYPE_INSERT_RETURNKEY)) {
										ps = connection.prepareStatement(IDENTITY_COL_SQL);
										ResultSet resultset = ps.executeQuery();
										if (resultset!= null && resultset.next()) {
											returnValue[i][0] = objectType[i];
											returnValue[i][1] = resultset.getString(1);
										}
									} else { 
										returnValue[i][0] = objectType[i];
										returnValue[i][1] = String.valueOf(updateCount);
									}
								}
								
								retry = false;
								
							} else {
								log.error("No Database Connection made.");
								throw new CbkServiceException("Database Connection not available.");
							}
	
						} /*catch (com.ibm.websphere.ce.cm.StaleConnectionException e) {
							log.error("StaleConnectionException in executeUpdateBatchQry():" + e);
							if (retryCount <= 5) {
								//  Keep trying...
								retryCount++;
								retry = true;
								log.error("StaleConnectionException in executeUpdateBatchQry(): retry " + retryCount);
							} else {
								//	Retries complete, exit
								log.error("StaleConnectionException in executeUpdateBatchQry(): retries failed.");
								retry = false;
								throw new CbkServiceException("StaleConnectionException in executeUpdateBatchQry(): retries failed.");
							}
						}*/ catch (SQLException e) {
							retry = false;
							connection.rollback();
							log.error("SQLException in executeUpdateBatchQry():" + e);
							throw new CbkServiceException("Database SQLException occured.");
						} catch (CbkDataChangeException e) {
							retry = false;
							connection.rollback();
							throw e;
						} catch (Exception e) {
							retry = false;
							connection.rollback();
							//e.printStackTrace();
							log.error("Exception in executeUpdateBatchQry(): " + e);
							throw new CbkServiceException("Exception occured.");
						} 
					}
				}
			}
			connection.commit();
		} catch (SQLException se) {
			log.error("SQLException in executeUpdateBatchQry():" + se);
			throw new CbkServiceException("Database SQLException occurred.");
		} finally {
			//	Cleanup				
			closeStatement(ps);
			JNDIDBPool.returnConnectionToPool(connection);
		}
		return returnValue;
	}
	
	public Object executeSQLQuery(String sqlQuery[], String executeType[], String objectType[],String requestId) throws CbkServiceException {
		Connection connection = null;
		PreparedStatement ps = null;
//		Object returnValue = null;
		
		String[][] returnValue = new String[sqlQuery.length][2];

		int updateCount = 0;
		boolean retry = true;
		int retryCount = 0;
		// Get a connection
		try {
			connection = JNDIDBPool.getConnection();
			connection.setReadOnly(false);
			connection.setAutoCommit(false);
			connection.setTransactionIsolation(Connection.TRANSACTION_REPEATABLE_READ);
			for (int i=0; i < sqlQuery.length; i++) {
				String sql = sqlQuery[i];
				retry = true;
				if (sql != null && !sql.equals("")) { 
					while (retry) {
						try {				
							if (connection != null) {
								log.debug(ESAPIUtil.encode("SQL Query: " + sql));
								System.out.println("---DaoDBUtil.java---executeSQLQuery11111---"+sql);
								ps = connection.prepareStatement(sql);
								
								ps.setString(1, requestId);
								if (executeType[i].equals(Constants.EXECUTE_TYPE_CHECK)){
									ResultSet resultset = ps.executeQuery();	
									if (resultset!= null && resultset.next()) {
										log.debug("Check Ok");
									} else {
										log.debug("Data has been updated!!!");		
										throw new CbkDataChangeException("Status Changed");	
									}
								} else {
									updateCount = ps.executeUpdate();
								
									if (executeType[i].equals(Constants.EXECUTE_TYPE_INSERT_RETURNKEY)) {
										ps = connection.prepareStatement(IDENTITY_COL_SQL);
										ResultSet resultset = ps.executeQuery();
										if (resultset!= null && resultset.next()) {
											returnValue[i][0] = objectType[i];
											returnValue[i][1] = resultset.getString(1);
										}
									} else { 
										returnValue[i][0] = objectType[i];
										returnValue[i][1] = String.valueOf(updateCount);
									}
								}
								
								retry = false;
								
							} else {
								log.error("No Database Connection made.");
								throw new CbkServiceException("Database Connection not available.");
							}
	
						} /*catch (com.ibm.websphere.ce.cm.StaleConnectionException e) {
							log.error("StaleConnectionException in executeUpdateBatchQry():" + e);
							if (retryCount <= 5) {
								//  Keep trying...
								retryCount++;
								retry = true;
								log.error("StaleConnectionException in executeUpdateBatchQry(): retry " + retryCount);
							} else {
								//	Retries complete, exit
								log.error("StaleConnectionException in executeUpdateBatchQry(): retries failed.");
								retry = false;
								throw new CbkServiceException("StaleConnectionException in executeUpdateBatchQry(): retries failed.");
							}
						}*/ catch (SQLException e) {
							retry = false;
							connection.rollback();
							log.error("SQLException in executeUpdateBatchQry():" + e);
							throw new CbkServiceException("Database SQLException occured.");
						} catch (CbkDataChangeException e) {
							retry = false;
							connection.rollback();
							throw e;
						} catch (Exception e) {
							retry = false;
							connection.rollback();
							//e.printStackTrace();
							log.error("Exception in executeUpdateBatchQry(): " + e);
							throw new CbkServiceException("Exception occured.");
						} 
					}
				}
			}
			connection.commit();
		} catch (SQLException se) {
			log.error("SQLException in executeUpdateBatchQry():" + se);
			throw new CbkServiceException("Database SQLException occurred.");
		} finally {
			//	Cleanup				
			closeStatement(ps);
			JNDIDBPool.returnConnectionToPool(connection);
		}
		return returnValue;
	}

	/**
	 * 
	 * @param params	List of parameters to use in constructing the clause
	 * @param exclude	boolean indicator to use "Not" in clause
	 * @return			a clause of the form "[NOT] IN (?,?)"
	 * 
	 */
	protected String createFilterClause(int paramCount, boolean exclude){
		StringBuffer buffer = new StringBuffer();		

		if (exclude){
			buffer.append(" NOT ");
		}
		buffer.append("IN (");
		for (int i=0; i < paramCount; i++){
			buffer.append("?");
			if (i < paramCount - 1){
				buffer.append(",");
			}
		}
		buffer.append(")");

		return buffer.toString();
	}
}